---@omw-context runtime
-- Pure: the half-gap rule. Contracts can carry a player at most half of the reputation between their
-- rank's requirement and the next rank's. Requirements come from the faction record at runtime, so
-- vanilla, Tamriel Data and rank mods all work.

local M = {}

-- requirements: list of factionReputation per rank, index 1 = lowest rank.
-- rank: player's rank index from 1 (0 = not a member). given: rep already granted by contracts at
-- this rank. want: rep this contract would give. Returns the amount to grant now.
function M.allowed(requirements, rank, given, want)
    if rank < 1 or rank >= #requirements then
        return 0
    end
    local gap = (requirements[rank + 1] or 0) - (requirements[rank] or 0)
    local cap = math.floor(math.max(0, gap) / 2)
    return math.max(0, math.min(want, cap - (given or 0)))
end

return M
