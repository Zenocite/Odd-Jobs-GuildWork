---@omw-context global
-- Pure: news, announcements, warnings and jokes for the boards, by board kind. Town boards also
-- draw from story.lua's flavour notices (written by a townsperson of a trade). No engine calls.
-- {town}: the town's name; {fort}: the fort's name; {signer}: the fort's quartermaster.

local M = {}

M.LINES = {
    ['fighters guild'] = {
        { title = 'Recruits wanted', body = 'The Guild is taking on new members. Bring a weapon you can lift and a temper you can keep. We will see to the rest.' },
        { title = 'Sparring, every Tirdas', body = 'Sparring in the hall each Tirdas evening. Blunted blades only. Last week someone forgot, and we are still mopping.' },
        { title = 'A challenge', body = 'I, Garos the Unbowed, will fight any member of this hall with fists, on the training floor, at dusk. The loser buys the mazte. Nobody has taken me up yet. Cowards.' },
        { title = 'Missing: one practice sword', body = 'A wooden practice sword has gone from the rack. It is not worth stealing. Whoever has it, put it back and we will forget it.' },
        { title = 'Dues are due', body = 'Members behind on their dues will find the Steward waiting for them by the door. He is patient. He is also very large.' },
        { title = 'Armour fitting', body = 'The armourer will fit and mend members\' armour at half the town price this week. Clean it before you bring it in, please.' },
        { title = 'A good month', body = 'Every job the hall took on last month was finished on time. Keep it that way. The Thieves Guild keeps count of ours, so we keep count of theirs.' },
        { title = 'Our thanks', body = 'The hall thanks the members who cleared the road to {town} last week. The traders are moving again, and one of them sent a barrel.' },
        { title = 'Archery practice', body = 'Targets are up behind the hall. Bring your own arrows, and collect them after. The guar in the next yard has had enough.' },
        { title = 'A word on bounties', body = 'Bring proof of a bounty, not stories. A head in a sack is not proof either. A signed word from the Watch is.' },
        { title = 'Duel at dawn', body = 'Two of our members will settle a disagreement with practice blades in the yard at dawn on Fredas. Spectators welcome. Wagers are not, officially.' },
        { title = 'New swords in', body = 'A shipment of iron and steel blades has come up from the coast. Members have first pick until Sundas.' },
        { title = 'Wanted: a cook', body = 'The hall needs a cook who can feed twenty hungry members without poisoning any of them. Previous cook need not apply.' },
        { title = 'Whetstones', body = 'Use the whetstones on the bench and put them back on the bench. They are not doorstops.' },
        { title = 'Rank tests', body = 'Members who want to rise in the Guild may ask the Steward for a test of arms. Bring a witness and a bandage.' },
        { title = 'Quiet in the hall', body = 'Members are asked to keep the noise down after dark. The neighbours have complained twice, and one of them is a priest.' },
    },
    ['mages guild'] = {
        { title = 'Lecture: the schools of magic', body = 'A talk on the six schools and how they mix, in the library on Middas evening. Questions welcome; demonstrations are not.' },
        { title = 'Lost: one familiar', body = 'A small grey scamp answering to Fizzle has slipped out of the conjuring room. He bites. He is also very sorry. Bring him back and the Guild will pay a fair price.' },
        { title = 'Warning', body = 'Members are reminded that the enchanting table is not a place to rest a cup. The last cup is still glowing.' },
        { title = 'Books overdue', body = 'Three books on Alteration are overdue to the library. The librarian knows who you are. She has a long memory, and a longer spell list.' },
        { title = 'Soul gems, empty', body = 'Empty soul gems can be left in the box by the stairs. Filled ones go to the enchanters, in person. Do not leave them in the box.' },
        { title = 'Apprentices wanted', body = 'The Guild will take on two apprentices who can read, write and keep their eyebrows. Ask the Steward.' },
        { title = 'Lecture: on Dwemer lenses', body = 'A visiting scholar will speak on Dwemer lenses and why nobody has made one since. Free for members. Bring a candle.' },
        { title = 'Mind the floor', body = 'The ward on the east stair is being renewed. Walk round it. Anyone who steps on it will be teleported somewhere unpleasant, and the Guild will not come looking.' },
        { title = 'Potion tasting', body = 'The alchemists are trying a new restore fatigue draught. Volunteers get a free meal afterwards, and a bucket.' },
        { title = 'About the smell', body = 'The smell from the alchemy room is being looked into. It is not dangerous. It is merely awful.' },
        { title = 'Spell trading', body = 'Members with spare scrolls may trade them on the table in the hall. Cursed scrolls are not spare scrolls.' },
        { title = 'Guild elections', body = 'The hall will choose a new librarian at the end of the month. Candidates should leave their names with the Steward, and their library cards up to date.' },
        { title = 'Telvanni visitors', body = 'Members are asked to be polite to visitors from House Telvanni. It is not hard. They are mostly asleep.' },
        { title = 'A small thank you', body = 'Thank you to whoever fixed the levitation ward in the tower. The cook is grateful too. He has his ceiling back.' },
        { title = 'Research notes found', body = 'A bundle of notes on summoning was found under a chair. The handwriting is terrible. Its owner may claim it from the Steward.' },
        { title = 'Leave the skulls alone', body = 'The skulls in the study are for study. They are not for juggling, wearing or naming.' },
    },
    legion = {
        { title = 'Standing orders', body = 'All soldiers off duty are to sign out at the gate and back in by the second bell. Anyone late does the night watch on the wall.' },
        { title = 'Kit inspection', body = 'Full kit inspection on Morndas at first light. Boots polished, blades clean, and the helmet on your head, not under your arm.' },
        { title = 'Supply wagon due', body = 'The supply wagon from the coast is due on Fredas. Clear the yard and keep your hands off the crates until they are counted.' },
        { title = 'Deserters', body = 'Two soldiers walked out of {fort} with their kit last week. Anyone who sees them on the road is to send word to the gate. They will be judged fairly, then flogged.' },
        { title = 'Drill', body = 'Spear drill in the yard each morning. Anyone who drops a spear on the sergeant\'s foot again will be doing it alone.' },
        { title = 'The tavern down the road', body = 'Soldiers are reminded that the tavern down the road is not part of {fort}. Its ale is weak and its dice are not straight.' },
        { title = 'Mail', body = 'Letters home leave with the courier every Sundas. Write clearly. The courier cannot read, but the censor can.' },
        { title = 'Recruits', body = 'The Legion is taking recruits at {fort}. Pay is regular, food is warm, and the boots nearly fit.' },
        { title = 'Patrol roster', body = 'The patrol roster for the east road is pinned in the barracks. Swaps go through the sergeant, not through dice.' },
        { title = 'Lost: a regimental flag', body = 'The small flag from the north tower has gone. It was not taken by the wind. Return it and no questions will be asked. Some questions will be asked.' },
        { title = 'Healer on hand', body = 'The fort healer sees soldiers each morning before drill. Civilians may be seen after noon, for a fee, if the healer is in a good mood.' },
        { title = 'No gambling on watch', body = 'Gambling on watch is forbidden. So is gambling off watch, in the armoury, with Legion property as a stake.' },
        { title = 'Quartermaster\'s hours', body = 'The stores are open from first bell to noon. Ask for what you need and sign for what you get.' },
        { title = 'Courtesy to locals', body = 'Soldiers are to be polite to the people of {town}. They pay for this fort. Not willingly, but they pay.' },
        { title = 'Night watch', body = 'The night watch is reminded that the lantern is to be carried, not hung on a hook while the watch sleeps.' },
        { title = 'Fitness', body = 'Every soldier will run once round the walls before breakfast. Officers will watch. Officers will not run.' },
    },
    company = {
        { title = 'Prices posted', body = 'This week\'s buying prices are posted inside. Bring goods in good order and leave with coin. Damp goods fetch damp prices.' },
        { title = 'Ship due', body = 'A company ship is due at the docks within the week. Porters wanted for the unloading. Pay by the crate.' },
        { title = 'Notice to traders', body = 'Deals with the company must be signed in the office, not at the tavern. A deal made over mazte is not a deal.' },
        { title = 'Clerk wanted', body = 'The office wants a clerk with a steady hand and a head for sums. Honest applicants only. We check.' },
        { title = 'Warehouse hours', body = 'The warehouse is open from dawn to dusk. Anyone found inside after dark will be counted as stock.' },
        { title = 'New routes', body = 'The company will soon carry goods along the coast road twice a month. Shippers may book space at the office.' },
        { title = 'Damaged crates', body = 'Crates damaged on the road are the carrier\'s loss, not the company\'s. Pack them better.' },
        { title = 'Annual accounts', body = 'The annual accounts are ready for the factor\'s inspection. Staff are asked to find any coin they may have mislaid.' },
        { title = 'A word on tariffs', body = 'The new tariffs apply from the start of next month. The office did not set them, and the office does not want to hear about them.' },
        { title = 'Lost: a ledger page', body = 'One page of this month\'s ledger has gone missing. It shows nothing of interest. Return it at once.' },
    },
    town = {
        { title = 'Lost: a good knife', body = 'Small knife with a bone handle and my name scratched on it. Left on the bench by the well. If found, please hand it in at the tavern.' },
        { title = 'Found: a purse', body = 'Found by the bridge: a purse with some coins in it. The owner may have it back if they can say how many coins, and what else is inside.' },
        { title = 'Did anyone see', body = 'Did anyone see who knocked over the fruit stall on Loredas? The fruit would like to know. So would I.' },
        { title = 'Overheard', body = 'Overheard at the tavern: the Hlaalu are buying land again. Overheard the next night: the Redoran are not happy. Overheard the night after: more mazte, please.' },
        { title = 'Riddle for the week', body = 'What has a head and a tail but no body? Answer at the tavern. Not a coin. We already thought of that.' },
        { title = 'Guar for sale', body = 'Healthy guar, three years old, friendly with children, terrible with doors. Fair price. Ask by the stables.' },
        { title = 'Missing cat', body = 'Orange cat, missing since Middas, answers to nothing. He comes back when he is hungry. If he is hungry at your house, send him home.' },
        { title = 'Rumour has it', body = 'Rumour has it a Dwemer ruin up in the hills is full of gold. Rumour also had it last year. Rumour lies.' },
        { title = 'Good news', body = 'The roof on the market hall is mended at last. It held through the rain. Mostly.' },
        { title = 'Bad news', body = 'The well by the square is dry again. Use the one by the gate, and do not drop anything in it this time.' },
        { title = 'Stolen washing', body = 'Somebody stole three shirts off my line. They were not good shirts. I would still like them back.' },
        { title = 'A joke', body = 'How many Telvanni does it take to light a lamp? None. They have a servant for that, and a servant for the servant.' },
        { title = 'Another joke', body = 'A Nord, a Bosmer and a scrib walk into a tavern. The scrib orders. The others are still arguing about who pays.' },
        { title = 'Word from the road', body = 'Travellers say the road north is clear this week, apart from one very stubborn guar. Go round it.' },
        { title = 'Sore loser', body = 'To the man who lost at cards and then took the table: we know where you live. We are coming for the table.' },
        { title = 'Help wanted at the farm', body = 'Hands wanted for the saltrice harvest. Pay in coin and dinner. Bring a hat; the sun is not your friend.' },
        { title = 'Lessons on the lute', body = 'Lute lessons for beginners. I will teach you three songs. The neighbours will learn them too.' },
        { title = 'Heard at the market', body = 'They say the trader at the end of the row waters his wine. He says he does not. The wine says otherwise.' },
        { title = 'A plea', body = 'Whoever keeps ringing the shrine bell after midnight: the ancestors are awake now. So is everyone else.' },
        { title = 'Market day', body = 'Market day is moved to Turdas this week, because of the rain on Middas. Or because of the rain we expect. The herders are never wrong.' },
        { title = 'Found: a small dog', body = 'A small brown dog has been following me since the bridge. He is very loyal. I would like to give him back.' },
        { title = 'Looking for my brother', body = 'My brother went to the coast to fish a month ago and has not written. If you see a tall Dunmer with a terrible beard, tell him his mother is waiting.' },
        { title = 'Wedding cancelled', body = 'The wedding on Morndas is off. Gifts will be returned. The cake will not.' },
        { title = 'Story night', body = 'Stories at the tavern on Sundas: old tales of the Tribunal and newer ones about the tax man. Bring a cup and a good ear.' },
        { title = 'An honest offer', body = 'I will carry your shopping home for one coin. Two if you live up the hill. Three if you are heavy-handed with the shopping.' },
        { title = 'Advice, free', body = 'Advice to newcomers: do not bargain with a Khajiit when you are tired. Do not bargain with a Hlaalu ever.' },
        { title = 'Seen in the sky', body = 'Several folk saw lights over the hills last night. The Mages Guild says it was nothing. The Mages Guild always says that.' },
        { title = 'A small reward', body = 'Small reward for my reading spectacles, left somewhere in {town} on Fredas. I would look myself, but I cannot see.' },
    },
}

-- The opening a repetition check compares: the body's first two words, lowercased.
function M.opening(body)
    local a, b = body:lower():match("^([%w']+)%W+([%w']+)")
    return (a or '') .. ' ' .. (b or '')
end

local function fill(s, vars)
    return (s:gsub('{(%w+)}', function(k) return vars[k] or ('{' .. k .. '}') end))
end

-- A news line for a board. args: { kind ('fighters guild', 'mages guild', 'legion', 'company',
-- 'town'), town, fort, signer, used = { titles = set, bodies = list }, rnd }. Returns { title,
-- body, from, news = true } or nil when every line is up or was up lately.
function M.pick(args)
    local lines = M.LINES[args.kind]
    if not lines then return nil end
    local used = args.used or {}
    local fresh = {}
    for _, l in ipairs(lines) do
        local seen = used.titles and used.titles[l.title]
        if not seen then
            local probe = l.body:sub(1, 30)
            for _, b in ipairs(used.bodies or {}) do
                if b:find(probe, 1, true) then seen = true break end
            end
        end
        if not seen then fresh[#fresh + 1] = l end
    end
    if #fresh == 0 then return nil end
    local l = fresh[args.rnd(#fresh)]
    local vars = { town = args.town or 'town', fort = args.fort or 'the fort', signer = args.signer or 'the Quartermaster' }
    local from = ({ ['fighters guild'] = 'Steward of the Fighters Guild', ['mages guild'] = 'Steward of the Mages Guild',
        legion = args.signer or 'The Quartermaster', company = 'The office' })[args.kind]
    local body = fill(l.body, vars)
    return { title = l.title, body = body, plain = body, from = from or 'Posted by a neighbour', news = true }
end

-- The one notice a closed fort board keeps up, so work already taken there can still be returned.
-- why: 'siege' (the fort was attacked) or 'noqm' (no quartermaster or stand-in left alive).
M.CLOSED = {
    siege = { title = 'Fort closed',
        body = 'By order of the garrison, {fort} is shut to all civilian business until further notice. '
            .. 'No new work will be given out. Work already under seal may be returned here for payment. '
            .. 'Anyone who saw the beasts on the road is to report to the officer of the watch.',
        from = 'By order of the garrison' },
    noqm = { title = 'Stores closed',
        body = "The quartermaster's stores at {fort} are closed, and no new work will be given out until "
            .. 'a replacement is posted. Work already under seal may be returned here for payment.',
        from = 'The garrison' },
}

function M.closed(why, args)
    local l = M.CLOSED[why]
    if not l then return nil end
    local body = fill(l.body, { fort = args.fort or 'the fort' })
    return { title = l.title, body = body, plain = body, from = l.from, news = true, closed = why }
end

return M
