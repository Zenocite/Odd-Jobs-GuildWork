---@omw-context runtime
-- Boards. Each interior in `doors` carries the board's notices beside the best of its outside
-- doors, found at runtime by the door's destination within a cell of `near`, so overhauls that move
-- doors still work. near: roughly where the first door is in the vanilla or Tamriel Rebuilt
-- layout. main: outside doors known to be the main entrance where the score alone picks a side
-- door (checked in game). posters: who posts on this board. req: content file the town needs.
-- village: a smaller board at a village inn or roadside tavern (config BOARD.MIX.village).
-- signer: a Legion fort's quartermaster, name and rank, from the fort's own NPCs
-- (tools/find_forts.py). qm: that quartermaster's NPC record id and cell; standIn: record id, cell and
-- signature of who signs if the quartermaster is dead or gone (tools/fort_people.py). With neither
-- left the board closes. siege: closes when Bloodmoon's attack on the fort has happened.
-- Forts stand alone or join the town they are part of.

return {
    { key = 'seyda_neen', name = 'Seyda Neen', boards = {
        { key = 'seyda_neen_town', posters = { 'town' }, near = { -12296, -70033 },
          doors = { "Seyda Neen, Arrille's Tradehouse" } },
    } },
    { key = 'balmora', name = 'Balmora', boards = {
        { key = 'balmora_town', posters = { 'town' }, near = { -21620, -12081 },
          doors = { 'Balmora, Eight Plates', 'Balmora, Council Club', 'Balmora, South Wall Cornerclub' } },
        { key = 'balmora_fg', posters = { 'fighters guild' }, near = { -21885, -13719 },
          doors = { 'Balmora, Guild of Fighters' } },
        { key = 'balmora_mg', posters = { 'mages guild' }, near = { -21590, -14373 },
          doors = { 'Balmora, Guild of Mages' } },
    } },
    { key = 'pelagiad', name = 'Pelagiad', boards = {
        { key = 'pelagiad_town', posters = { 'town' }, near = { 2380, -56032 },
          doors = { 'Pelagiad, Halfway Tavern', 'Pelagiad, South Wall' } },
        { key = 'pelagiad_fort', posters = { 'legion' }, near = { 6201, -56063 },
          doors = { 'Pelagiad, Fort Pelagiad' }, signer = 'Shadbak gra-Burbug, Spearman, Quartermaster',
          qm = { 'shadbak gra-burbug', 'Pelagiad, Fort Pelagiad' },
          standIn = { 'angoril', 'Pelagiad, Fort Pelagiad', 'Angoril, Knight Protector, for the Quartermaster' } },
    } },
    { key = 'moonmoth', name = 'Moonmoth Legion Fort', boards = {
        { key = 'moonmoth_fort', posters = { 'legion' }, near = { -5062, -18124 },
          doors = { 'Moonmoth Legion Fort, Interior' }, signer = 'Urfing, Trooper, Quartermaster',
          qm = { 'urfing', 'Moonmoth Legion Fort, Interior' },
          standIn = { 'erla', 'Moonmoth Legion Fort, Interior', 'Erla, Trooper, for the Quartermaster' } },
    } },
    { key = 'buckmoth', name = 'Buckmoth Legion Fort', boards = {
        { key = 'buckmoth_fort', posters = { 'legion' }, near = { -13779, 43540 },
          doors = { 'Buckmoth Legion Fort, Interior' }, signer = 'Yambagorn gor-Shulor, Trooper, Quartermaster',
          qm = { 'yambagorn gor-shulor', 'Buckmoth Legion Fort, Interior' },
          standIn = { 'arnand liric', 'Buckmoth Legion Fort, Interior', 'Arnand Liric, Agent, for the Quartermaster' } },
    } },
    { key = 'frostmoth', name = 'Fort Frostmoth', req = 'bloodmoon.esm', boards = {
        { key = 'frostmoth_fort', posters = { 'legion' }, near = { -173316, 142712 },
          doors = { 'Fort Frostmoth, Armory' }, signer = 'Zeno Faustus, Agent, Quartermaster',
          qm = { 'zeno faustus', 'Fort Frostmoth, Armory' },
          standIn = { 'falx carius', "Fort Frostmoth, Carius' Chambers", 'Captain Falx Carius, for the Quartermaster' },
          siege = true },
    } },
    { key = 'caldera', name = 'Caldera', boards = {
        { key = 'caldera_town', posters = { 'town' }, near = { -10693, 17990 },
          doors = { "Caldera, Shenk's Shovel" } },
        { key = 'caldera_mg', posters = { 'mages guild' }, near = { -13284, 19564 },
          doors = { 'Caldera, Guild of Mages' } },
    } },
    { key = 'ald_ruhn', name = 'Ald-ruhn', boards = {
        { key = 'ald_ruhn_town', posters = { 'town' }, near = { -12930, 51907 },
          doors = { 'Ald-ruhn, The Rat In The Pot', 'Ald-ruhn, Ald Skar Inn' } },
        { key = 'ald_ruhn_fg', posters = { 'fighters guild' }, near = { -14651, 51751 },
          doors = { 'Ald-ruhn, Guild of Fighters' } },
        { key = 'ald_ruhn_mg', posters = { 'mages guild' }, near = { -14735, 53215 },
          doors = { 'Ald-ruhn, Guild of Mages' } },
    } },
    { key = 'vivec', name = 'Vivec', boards = {
        { key = 'vivec_town', posters = { 'town' }, near = { 29900, -79500 },
          doors = { 'Vivec, Foreign Quarter Upper Waistworks', 'Vivec, Foreign Quarter Waistworks',
                    'Vivec, Foreign Quarter Plaza' } },
    } },
    { key = 'ebonheart', name = 'Ebonheart', boards = {
        { key = 'ebonheart_town', posters = { 'town' }, near = { 14794, -101611 },
          doors = { 'Ebonheart, Six Fishes' } },
        { key = 'ebonheart_fort', posters = { 'legion' }, near = { 14085, -100786 },
          doors = { 'Ebonheart, Hawkmoth Legion Garrison' }, signer = 'Landorume, Agent, Quartermaster',
          qm = { 'landorume', 'Ebonheart, Hawkmoth Legion Garrison' },
          standIn = { 'frald the white', 'Ebonheart, Hawkmoth Legion Garrison', 'Frald the White, Knight Protector, for the Quartermaster' } },
    } },
    { key = 'suran', name = 'Suran', boards = {
        { key = 'suran_town', posters = { 'town' }, near = { 57000, -54125 },
          doors = { 'Suran, Suran Tradehouse' } },
    } },
    { key = 'sadrith_mora', name = 'Sadrith Mora', boards = {
        { key = 'sadrith_mora_town', posters = { 'town' }, near = { 144205, 35905 },
          doors = { 'Sadrith Mora, Gateway Inn', "Sadrith Mora, Dirty Muriel's Cornerclub" } },
        { key = 'sadrith_mora_guilds', posters = { 'fighters guild', 'mages guild' }, near = { 149408, 30272 },
          doors = { 'Sadrith Mora, Wolverine Hall' } },
    } },
    { key = 'gnisis', name = 'Gnisis', boards = {
        { key = 'gnisis_town', posters = { 'town' }, near = { -84502, 91263 },
          doors = { 'Gnisis, Madach Tradehouse' } },
        { key = 'gnisis_fort', posters = { 'legion' }, near = { -80116, 90617 },
          doors = { 'Gnisis, Fort Darius' }, signer = 'Mug gro-Dulob, Spearman, Quartermaster',
          qm = { 'mug gro-dulob', 'Gnisis, Fort Darius' },
          standIn = { 'sharkub gro-khashnar', 'Gnisis, Fort Darius', 'Sharkub gro-Khashnar, Agent, for the Quartermaster' } },
    } },
    { key = 'old_ebonheart', name = 'Old Ebonheart', req = 'tr_mainland.esm', boards = {
        { key = 'old_ebonheart_town', posters = { 'town' }, near = { 59433, -150327 },
          doors = { 'Old Ebonheart, The Empress Katariah', 'Old Ebonheart, The Moth and Tiger',
                    'Old Ebonheart, The Salty Futtocks', "Old Ebonheart, Hostel of Stendarr's Mercy" } },
        { key = 'old_ebonheart_fg', posters = { 'fighters guild' }, near = { 53610, -152196 },
          doors = { 'Old Ebonheart, Guild of Fighters' } },
        { key = 'old_ebonheart_mg', posters = { 'mages guild' }, near = { 57565, -150359 },
          doors = { 'Old Ebonheart, Guild of Mages' } },
        { key = 'old_ebonheart_fort', posters = { 'legion' }, near = { 56384, -144912 },
          doors = { 'Ebon Tower, Legion: Headquarters' }, signer = 'Ulvu Ouradas, Spearman, Quartermaster',
          qm = { 'tr_m3_ulvu ouradas', 'Ebon Tower, Legion: Headquarters' },
          standIn = { 'tr_m3_solius zenitarion', 'Ebon Tower, Legion: Headquarters', 'Solius Zenitarion, Knight Errant, for the Quartermaster' } },
    } },
    { key = 'firewatch', name = 'Firewatch', req = 'tr_mainland.esm', boards = {
        { key = 'firewatch_town', posters = { 'town' }, near = { 146674, 124884 },
          doors = { 'Firewatch, The Howling Noose', "Firewatch, The Queen's Cutlass" } },
        { key = 'firewatch_fg', posters = { 'fighters guild' }, near = { 150323, 128276 },
          doors = { 'Firewatch, Guild of Fighters' } },
        { key = 'firewatch_mg', posters = { 'mages guild' }, near = { 146766, 128405 },
          doors = { 'Firewatch, Guild of Mages' }, main = { { 146766, 128405 } } },
        { key = 'firewatch_fort', posters = { 'legion' }, near = { 144028, 126768 },
          doors = { 'Firewatch, Dustmoth Legion Garrison: East Tower' }, signer = "Sa'Assa, Recruit, Quartermaster",
          qm = { "tr_m1_sa'assa", 'Firewatch, Dustmoth Legion Garrison: East Tower' },
          standIn = { 'tr_m1_thromil_rufus', 'Firewatch, Dustmoth Legion Garrison: East Tower', 'Thromil Rufus, Knight of the Imperial Dragon, for the Quartermaster' } },
    } },
    { key = 'narsis', name = 'Narsis', req = 'tr_mainland.esm', boards = {
        { key = 'narsis_town', posters = { 'town' }, near = { 49391, -404125 },
          doors = { 'Narsis, Canyon Air Inn', 'Narsis, Gold Dragon Inn' } },
        { key = 'narsis_fg', posters = { 'fighters guild' }, near = { 49932, -420128 },
          doors = { 'Narsis, Guild of Fighters' } },
        { key = 'narsis_mg', posters = { 'mages guild' }, near = { 60657, -418986 },
          doors = { 'Narsis, Guild of Mages' } },
    } },
    { key = 'necrom', name = 'Necrom', req = 'tr_mainland.esm', boards = {
        { key = 'necrom_town', posters = { 'town' }, near = { 365036, -88229 },
          doors = { "Necrom, Pilgrim's Respite", "Necrom, Seafarer's Rest Hostel" } },
    } },
    { key = 'almas_thirr', name = 'Almas Thirr', req = 'tr_mainland.esm', boards = {
        { key = 'almas_thirr_town', posters = { 'town' }, near = { 52825, -221780 },
          doors = { 'Almas Thirr, Hostel of the Crossing', 'Almas Thirr, Limping Scrib',
                    'Almas Thirr, The Pious Pirate' } },
        { key = 'almas_thirr_fg', posters = { 'fighters guild' }, near = { 44120, -225123 },
          doors = { 'Almas Thirr, Guild of Fighters' } },
        { key = 'almas_thirr_mg', posters = { 'mages guild' }, near = { 45657, -225310 },
          doors = { 'Almas Thirr, Guild of Mages' } },
    } },
    { key = 'fort_ancylis', name = 'Fort Ancylis', req = 'tr_mainland.esm', boards = {
        { key = 'ancylis_fort', posters = { 'legion' }, near = { -19500, -101878 },
          doors = { 'Fort Ancylis, Main Keep' }, signer = 'Apphia Calanius, Recruit, Quartermaster',
          qm = { 'tr_m4_apphia_calanius', 'Fort Ancylis, Main Keep' },
          standIn = { 'tr_m4_kathellomar', 'Fort Ancylis, Main Keep', 'Kathellomar, Champion, for the Quartermaster' } },
    } },
    { key = 'windmoth', name = 'Windmoth Legion Fort', req = 'tr_mainland.esm', boards = {
        { key = 'windmoth_fort', posters = { 'legion' }, near = { 289312, -53184 },
          doors = { 'Windmoth Legion Fort, Interior' }, signer = 'Servo Nierius, Agent, Quartermaster',
          qm = { 'tr_m2_servo_nierius', 'Windmoth Legion Fort, Interior' },
          standIn = { 'tr_m2_sarethi_trinesi', 'Windmoth Legion Fort, Interior', 'Sarethi Trinesi, Trooper, for the Quartermaster' } },
    } },
    { key = 'umbermoth', name = 'Fort Umbermoth', req = 'tr_mainland.esm', boards = {
        { key = 'umbermoth_fort', posters = { 'legion' }, near = { 308823, -135369 },
          doors = { 'Fort Umbermoth, Interior' }, signer = 'Enyid, Agent, Quartermaster',
          qm = { 'tr_m3_ennah', 'Fort Umbermoth, Interior' },
          standIn = { 'tr_m3_fara', 'Fort Umbermoth, Interior', 'Faralval, Agent, for the Quartermaster' } },
    } },
    { key = 'firemoth', name = 'Firemoth Legion Fort', req = 'tr_mainland.esm', boards = {
        { key = 'firemoth_fort', posters = { 'legion' }, near = { -63932, -87004 },
          doors = { 'Firemoth Legion Fort, Keep' }, signer = 'Slick-Skewer, Spearman, Quartermaster',
          qm = { 'tr_fm_slick_skewer', 'Firemoth Legion Fort, Keep' },
          standIn = { 'tr_fm_simone megale', 'Firemoth Legion Fort, Keep', 'Simone Megale, Trooper, for the Quartermaster' } },
    } },
    { key = 'septims_gate', name = "Septim's Gate Pass", req = 'tr_mainland.esm', boards = {
        { key = 'septims_gate_fort', posters = { 'legion' }, near = { -64192, -404832 },
          doors = { "Septim's Gate Pass, Main Keep" }, signer = 'Yssibelle Hayretz, Agent, Quartermaster',
          qm = { 'tr_m7_yssibelle hayretz', "Septim's Gate Pass, Main Keep" },
          standIn = { 'tr_m7_shen gra-tul', "Septim's Gate Pass, Main Keep", 'Shen gra-Tul, Agent, for the Quartermaster' } },
    } },
    -- Village and roadside inns. One board each, beside the inn door. near is an exterior door.
    { key = 'gnaar_mok', name = 'Gnaar Mok', boards = {
        { key = 'gnaar_mok', posters = { 'town' }, near = { -60667, 27533 },
          doors = { "Gnaar Mok, Druegh-jigger's Rest" }, village = true } } },
    { key = 'khuul', name = 'Khuul', boards = {
        { key = 'khuul', posters = { 'town' }, near = { -66728, 139818 },
          doors = { "Khuul, Thongar's Tradehouse" }, village = true } } },
    { key = 'maar_gan', name = 'Maar Gan', boards = {
        { key = 'maar_gan', posters = { 'town' }, near = { -22459, 105506 },
          doors = { 'Maar Gan, Andus Tradehouse' }, village = true } } },
    { key = 'molag_mar', name = 'Molag Mar', boards = {
        { key = 'molag_mar', posters = { 'town' }, near = { 109116, -62277 },
          doors = { "Molag Mar, St. Veloth's Hostel" }, village = true } } },
    { key = 'tel_branora', name = 'Tel Branora', boards = {
        { key = 'tel_branora', posters = { 'town' }, near = { 126374, -102974 },
          doors = { "Tel Branora, Sethan's Tradehouse" }, village = true } } },
    { key = 'vos', name = 'Vos', boards = {
        { key = 'vos', posters = { 'town' }, near = { 98982, 114036 },
          doors = { 'Vos, Varo Tradehouse' }, village = true } } },
    { key = 'hla_oad', name = 'Hla Oad', boards = {
        { key = 'hla_oad', posters = { 'town' }, near = { -46628, -37021 },
          doors = { "Hla Oad, Fatleg's Drop Off" }, village = true } } },
    { key = 'dagon_fel', name = 'Dagon Fel', boards = {
        { key = 'dagon_fel', posters = { 'town' }, near = { 60151, 181159 },
          doors = { 'Dagon Fel, The End of the World', 'Dagon Fel, End of the World Renter Rooms' }, village = true } } },
    { key = 'tel_mora', name = 'Tel Mora', boards = {
        { key = 'tel_mora', posters = { 'town' }, near = { 108537, 116172 },
          doors = { 'Tel Mora, The Covenant' }, village = true } } },
    { key = 'tel_aruhn', name = 'Tel Aruhn', boards = {
        { key = 'tel_aruhn', posters = { 'town' }, near = { 127149, 46752 },
          doors = { 'Tel Aruhn, Plot and Plaster' }, village = true } } },
    { key = 'aimrah', name = 'Aimrah', req = 'tr_mainland.esm', boards = {
        { key = 'aimrah', posters = { 'town' }, near = { 100704, -273092 },
          doors = { "Aimrah, The Sailors' Inn" }, village = true } } },
    { key = 'akamora', name = 'Akamora', req = 'tr_mainland.esm', boards = {
        { key = 'akamora', posters = { 'town' }, near = { 253126, -85114 },
          doors = { 'Akamora, Miners Club' }, village = true } } },
    { key = 'ald_marak', name = 'Ald Marak', req = 'tr_mainland.esm', boards = {
        { key = 'ald_marak', posters = { 'town' }, near = { 46912, -335910 },
          doors = { 'Ald Marak, Elval Tradehouse' }, village = true } } },
    { key = 'ald_verya', name = 'Ald Verya', req = 'tr_mainland.esm', boards = {
        { key = 'ald_verya', posters = { 'town' }, near = { 160461, -177089 },
          doors = { 'Ald Verya, Lodge' }, village = true } } },
    { key = 'andar_mok', name = 'Andar Mok', req = 'tr_mainland.esm', boards = {
        { key = 'andar_mok', posters = { 'town' }, near = { 266273, -3843 },
          doors = { 'Andar Mok, Andalas Tradehouse' }, village = true } } },
    { key = 'bal_foyen', name = 'Bal Foyen', req = 'tr_mainland.esm', boards = {
        { key = 'bal_foyen', posters = { 'town' }, near = { 817, -137862 },
          doors = { 'Bal Foyen, Golden Moons Club' }, village = true } } },
    { key = 'bodrum', name = 'Bodrum', req = 'tr_mainland.esm', boards = {
        { key = 'bodrum', posters = { 'town' }, near = { -94333, -143825 },
          doors = { 'Bodrum, Varalaryn Tradehouse' }, village = true } } },
    { key = 'bosmora', name = 'Bosmora', req = 'tr_mainland.esm', boards = {
        { key = 'bosmora', posters = { 'town' }, near = { 274151, -240360 },
          doors = { 'Bosmora, The Starlight Inn' }, village = true } } },
    { key = 'crystal_scissure', name = 'Crystal Scissure', req = 'tr_mainland.esm', boards = {
        { key = 'crystal_scissure', posters = { 'town' }, near = { 162065, 92026 },
          doors = { "Crystal Scissure, Glaziers' Respite" }, village = true } } },
    { key = 'enamor_dayn', name = 'Enamor Dayn', req = 'tr_mainland.esm', boards = {
        { key = 'enamor_dayn', posters = { 'town' }, near = { 306299, -223848 },
          doors = { 'Enamor Dayn, Tradehouse' }, village = true } } },
    { key = 'gah_sadrith', name = 'Gah Sadrith', req = 'tr_mainland.esm', boards = {
        { key = 'gah_sadrith', posters = { 'town' }, near = { 349225, 111763 },
          doors = { 'Gah Sadrith, The Wetstone Tavern' }, village = true } } },
    { key = 'hlan_oek', name = 'Hlan Oek', req = 'tr_mainland.esm', boards = {
        { key = 'hlan_oek', posters = { 'town' }, near = { 12884, -261677 },
          doors = { 'Hlan Oek, Morning Sun Cornerclub' }, village = true } } },
    { key = 'hlerynhul', name = 'Hlerynhul', req = 'tr_mainland.esm', boards = {
        { key = 'hlerynhul', posters = { 'town' }, near = { 10567, -359240 },
          doors = { 'Hlerynhul, Vermilion Hound Cornerclub' }, village = true } } },
    { key = 'idathren', name = 'Idathren', req = 'tr_mainland.esm', boards = {
        { key = 'idathren', posters = { 'town' }, near = { 47098, -277421 },
          doors = { "Idathren, Sadri's Cornerclub" }, village = true } } },
    { key = 'llothanis', name = 'Llothanis', req = 'tr_mainland.esm', boards = {
        { key = 'llothanis', posters = { 'town' }, near = { 268922, 87386 },
          doors = { "Llothanis, The Water's Shadow Tavern" }, village = true } } },
    { key = 'marog', name = 'Marog', req = 'tr_mainland.esm', boards = {
        { key = 'marog', posters = { 'town' }, near = { 192037, -100378 },
          doors = { 'Marog, Three Treasures Cornerclub' }, village = true } } },
    { key = 'nan_iban', name = 'Nan Iban', req = 'tr_mainland.esm', boards = {
        { key = 'nan_iban', posters = { 'town' }, near = { 336669, -238396 },
          doors = { 'Nan Iban, The Emerald Haven Inn' }, village = true } } },
    { key = 'nivalis', name = 'Nivalis', req = 'tr_mainland.esm', boards = {
        { key = 'nivalis', posters = { 'town' }, near = { 102872, 228480 },
          doors = { 'Nivalis, The Black Ogre Tavern' }, village = true } } },
    { key = 'othmura', name = 'Othmura', req = 'tr_mainland.esm', boards = {
        { key = 'othmura', posters = { 'town' }, near = { 27158, -315524 },
          doors = { 'Othmura, High Wall Cornerclub' }, village = true } } },
    { key = 'othrenis', name = 'Othrenis', req = 'tr_mainland.esm', boards = {
        { key = 'othrenis', posters = { 'town' }, near = { 129514, -233972 },
          doors = { "Othrenis, Zebba's Pate Cornerclub", 'Othrenis, Hostel of St. Rilms' }, village = true } } },
    { key = 'port_telvannis', name = 'Port Telvannis', req = 'tr_mainland.esm', boards = {
        { key = 'port_telvannis', posters = { 'town' }, near = { 338541, 144723 },
          doors = { 'Port Telvannis, The Lost Crab Tavern' }, village = true } } },
    { key = 'roa_dyr', name = 'Roa Dyr', req = 'tr_mainland.esm', boards = {
        { key = 'roa_dyr', posters = { 'town' }, near = { 73357, -221153 },
          doors = { 'Roa Dyr, Lodge' }, village = true } } },
    { key = 'sailen', name = 'Sailen', req = 'tr_mainland.esm', boards = {
        { key = 'sailen', posters = { 'town' }, near = { 308321, -126344 },
          doors = { 'Sailen, Pilgrim Hostel' }, village = true } } },
    { key = 'shipal_sharai', name = 'Shipal-Sharai', req = 'tr_mainland.esm', boards = {
        { key = 'shipal_sharai', posters = { 'town' }, near = { 14118, -403840 },
          doors = { 'Shipal-Sharai, Sapphire Slouch Cornerclub' }, village = true } } },
    { key = 'tel_gilan', name = 'Tel Gilan', req = 'tr_mainland.esm', boards = {
        { key = 'tel_gilan', posters = { 'town' }, near = { 215296, 13716 },
          doors = { "Tel Gilan, The Cliff Racer's Rest" }, village = true } } },
    { key = 'teyn', name = 'Teyn', req = 'tr_mainland.esm', boards = {
        { key = 'teyn', posters = { 'town' }, near = { -28016, -109899 },
          doors = { "Teyn, Cirifae's Tradehouse" }, village = true } } },
    { key = 'uman', name = 'Uman', req = 'tr_mainland.esm', boards = {
        { key = 'uman', posters = { 'town' }, near = { -138276, -169149 },
          doors = { "Uman, Hound's Rest Inn" }, village = true } } },
    { key = 'ilanaam', name = 'Ilanaam', req = 'tr_othreleth_woods.esm', boards = {
        { key = 'ilanaam', posters = { 'town' }, near = { -69182, -296734 },
          doors = { "Ilanaam, Midar's Tradehouse" }, village = true } } },
    { key = 'andrethis', name = 'Andrethis', req = 'tr_othreleth_woods.esm', boards = {
        { key = 'andrethis', posters = { 'town' }, near = { -33602, -298489 },
          doors = { 'TR_Andrethis_10 - East Fence Cornerclub' }, village = true } } },
    { key = 'hunted_hound', name = 'Hunted Hound Inn', req = 'tr_mainland.esm', boards = {
        { key = 'hunted_hound', posters = { 'town' }, near = { 301933, -187840 },
          doors = { 'Hunted Hound Inn' }, village = true } } },
    { key = 'maar_bani', name = 'Maar-Bani Crossing', req = 'tr_mainland.esm', boards = {
        { key = 'maar_bani', posters = { 'town' }, near = { 69517, -284853 },
          doors = { 'Maar-Bani Crossing, Tradehouse' }, village = true } } },
    { key = 'mavandes', name = 'Mavandes Caravanserai', req = 'tr_mainland.esm', boards = {
        { key = 'mavandes', posters = { 'town' }, near = { 85355, -365740 },
          doors = { 'Mavandes Caravanserai, Inn' }, village = true } } },
    { key = 'supai', name = 'Supai Caravanserai', req = 'tr_mainland.esm', boards = {
        { key = 'supai', posters = { 'town' }, near = { 224306, -122443 },
          doors = { 'Supai Caravanserai, Inn' }, village = true } } },
    { key = 'grey_lodge', name = 'The Grey Lodge', req = 'tr_mainland.esm', boards = {
        { key = 'grey_lodge', posters = { 'town' }, near = { -23524, -174134 },
          doors = { 'The Grey Lodge' }, village = true } } },
}
