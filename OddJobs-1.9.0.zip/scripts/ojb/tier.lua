---@omw-context runtime
-- Pure: difficulty tiers. A job's tier comes from the job (who is there, how many, a placed leader,
-- how far), never from the player's level. No engine calls, so tests/run_tests.py runs it as is.

local C = require('scripts.ojb.config')

local TC = C.TIER
local M = {}

M.ORDER = TC.ORDER
M.MARKS = { easy = 1, normal = 2, dangerous = 3, elite = 4 }

local function clamp01(x)
    if x < 0 then return 0 end
    if x > 1 then return 1 end
    return x
end

-- Danger of a place (places.lua t) where its levelled lists resolve for `level`.
local function dangerAt(t, level)
    local L = C.TIER_LEVELS
    if level <= L[1] then return t[1][1] end
    if level >= L[3] then return t[3][1] end
    local i = level <= L[2] and 1 or 2
    return t[i][1] + (t[i + 1][1] - t[i][1]) * (level - L[i]) / (L[i + 1] - L[i])
end

-- The danger a place is rated by: its levelled lists resolved at TYPICAL_LEVEL.
function M.typicalDanger(p)
    return dangerAt(p.t, TC.TYPICAL_LEVEL)
end

-- What was really there against the rating: 'worse' at GAP times the rated danger or more,
-- 'quieter' at 1 / GAP or less, else nil.
function M.gap(rated, found)
    if not rated or rated <= 0 then return nil end
    if found >= rated * TC.GAP then return 'worse' end
    if found <= rated / TC.GAP then return 'quieter' end
    return nil
end

function M.scoreAt(p, level, distCells)
    local s = dangerAt(p.t, level) * (1 + TC.DIST_WEIGHT * clamp01((distCells or 0) / C.DISTANCE_FULL_CELLS))
    if p.b then s = s + TC.CHAMPION end
    return s
end

function M.tierOfScore(s)
    if s >= TC.SCORE.elite then return 'elite' end
    if s >= TC.SCORE.dangerous then return 'dangerous' end
    if s >= TC.SCORE.normal then return 'normal' end
    return 'easy'
end

-- How far up its tier a score sits, 0 to 1. Elite runs to twice its start.
function M.within(s)
    local t = M.tierOfScore(s)
    local lo = t == 'easy' and 0 or TC.SCORE[t]
    local hi = t == 'elite' and 2 * TC.SCORE.elite or TC.SCORE[M.ORDER[M.MARKS[t] + 1]]
    return clamp01((s - lo) / (hi - lo))
end

-- How much a place's danger rides on the player's level: danger at 30 over danger at 5.
function M.swing(p)
    return p.t[3][1] / math.max(1, p.t[1][1])
end

-- { tier, score, within, swing, excluded } for a place this far from the board.
function M.ratePlace(p, distCells)
    local s = M.scoreAt(p, TC.TYPICAL_LEVEL, distCells)
    local sw = M.swing(p)
    return { tier = M.tierOfScore(s), score = s, within = M.within(s), swing = sw, excluded = sw > TC.SWING_MAX }
end

-- A notice's or contract's tier; ones from older saves go by their band's tier, else normal.
function M.of(x)
    if x.diff then return x.diff end
    if x.tier == 'dangerous' or x.tier == 'elite' then return x.tier end
    return 'normal'
end

function M.band(tier)
    return TC.BANDS[tier] or TC.BANDS.normal
end

-- A level inside the tier's band; rnd(n) is math.random-like.
function M.levelIn(tier, rnd)
    local b = M.band(tier)
    return b[1] + rnd(b[2] - b[1] + 1) - 1
end

-- Job value in the tier's band. within: how far up the tier (0 to 1); dist01: distance share;
-- loot: the place's sellable loot (nil: none counted); r: 0 to 1, a little spread.
function M.value(tier, within, dist01, loot, r)
    local v = TC.VALUE[tier] or TC.VALUE.normal
    local lootF = loot and clamp01(loot / (C.LOOT_FULL * v[2])) or 0.5
    local f = clamp01(C.PAY_SCORE * (within or 0.5) + C.PAY_DISTANCE * (dist01 or 0) + C.PAY_LOOT * lootF
        + 0.1 * ((r or 0.5) - 0.5))
    return math.floor((v[1] + (v[2] - v[1]) * f) / 5 + 0.5) * 5
end

function M.cap(tier)
    return (TC.VALUE[tier] or TC.VALUE.normal)[2]
end

-- A board's size from its town key and posters: 'hall', 'city', 'small' or 'fort'.
function M.size(townKey, posters)
    local first = posters and posters[1]
    if first == 'legion' then return 'fort' end
    if not TC.HUBS[townKey or ''] then return 'small' end
    return C.GUILDS[first or ''] and 'hall' or 'city'
end

-- Whether a board of this size posts the tier at all.
function M.postsAt(tier, size)
    return ((TC.SIZE[size or 'city'] or TC.SIZE.city)[tier] or 1) > 0
end

-- How often a board posts this tier: base weight, the region's lean, the poster's, the board's size.
function M.weight(tier, region, poster, size)
    local w = (TC.WEIGHT[tier] or 1) * ((TC.SIZE[size or 'city'] or TC.SIZE.city)[tier] or 1)
    local r = (region or ''):lower()
    for _, lean in pairs(TC.REGION) do
        for _, m in ipairs(lean.match) do
            if r:find(m, 1, true) then w = w * (lean[tier] or 1) break end
        end
    end
    local p = TC.POSTER[poster or '']
    return w * (p and p[tier] or 1)
end

-- The largest contract group of a tier: its most followers and its leaders (DANGER.FOLLOWERS).
-- The most bodies a contract group of this tier takes, leaders included, plus a couple of
-- creatures when the place brings them. Used so a crowded place is not offered a group that
-- would pass CONTRACT.HOSTILE_CAP. The live cap is C.THREAT, scaled by the group size setting.
function M.most(tier)
    local cap = C.THREAT.CAPS[tier]
    if not cap then
        local f = C.DANGER.FOLLOWERS[tier] or C.DANGER.FOLLOWERS.normal
        return f[2] + (tier == 'elite' and 2 or tier == 'easy' and 0 or 1)
    end
    local extra = (tier == 'dangerous' or tier == 'elite') and 2 or 1
    return cap.npc[2] + extra
end

-- The tier a contract group is drawn at (contractGroups): by M.weight among the tiers the board
-- posts and the rules allow, where the place has room for the tier's largest group under
-- CONTRACT.HOSTILE_CAP. Sealed tiers need their feature on and no sealed notice on the board;
-- elite also a big place (CONTRACT.ELITE_KINDS), a guild poster, ELITE_MIN_CELLS of distance and
-- room in the region. o: { size, level, rules, region, poster, occupants (the place's own hostiles
-- at the player's level), kind, dist (cells), eliteRoom, sealed, on (feature switches) }.
-- nil: no tier fits the place.
function M.contractTier(o, rnd)
    local list, total = {}, 0
    for _, t in ipairs(M.ORDER) do
        local ok = M.postsAt(t, o.size) and M.allowed(t, o.level, o.rules)
            and (o.occupants or 0) + M.most(t) <= C.CONTRACT.HOSTILE_CAP
        if ok and (t == 'dangerous' or t == 'elite') then ok = not o.sealed and (o.on or {})[t] ~= false end
        if ok and t == 'elite' then
            ok = C.CONTRACT.ELITE_KINDS[o.kind or ''] == true and C.GUILDS[o.poster or ''] ~= nil
                and (o.dist or 0) >= C.DANGER.ELITE_MIN_CELLS and o.eliteRoom ~= false
        end
        local w = ok and M.weight(t, o.region, o.poster, o.size) or 0
        if w > 0 then
            list[#list + 1] = { t, w }
            total = total + w
        end
    end
    if total <= 0 then return nil end
    local r = rnd() * total
    for _, e in ipairs(list) do
        r = r - e[2]
        if r <= 0 then return e[1] end
    end
    return list[#list][1]
end

-- How far up its tier a contract group sits, 0 to 1: its size in the tier's range and its level
-- in the tier's band, evenly.
function M.groupWithin(tier, size, level)
    local f = C.DANGER.FOLLOWERS[tier] or C.DANGER.FOLLOWERS.normal
    local lead = M.most(tier) - f[2]
    local lo, hi = f[1] + lead, f[2] + lead
    local b = M.band(tier)
    local s = hi > lo and (size - lo) / (hi - lo) or 0.5
    local l = b[2] > b[1] and (level - b[1]) / (b[2] - b[1]) or 0.5
    return clamp01(0.5 * clamp01(s) + 0.5 * clamp01(l))
end

-- Optional rules, both off by default:
--   hideAbove: a job whose band starts HIDE_MARGIN or more levels over the player's is not posted.
--   levelGates: the old rule, dangerous from LEGACY.dangerous and elite from LEGACY.elite.
function M.allowed(tier, level, opts)
    if not opts then return true end
    if opts.levelGates and TC.LEGACY[tier] and level < TC.LEGACY[tier] then return false end
    if opts.hideAbove and M.band(tier)[1] >= level + TC.HIDE_MARGIN then return false end
    return true
end

return M
