---@omw-context player
-- Spawn points for global.lua: walkable ground on the navmesh near the anchors it sends, the floor
-- confirmed by a ray, nothing standing there, away from the player and out of their sight where it
-- can be. Outdoors also: flat enough, above the water (or on the beach, for beach jobs), open sky
-- overhead, not wedged into rock, and reachable on foot from the road point. Runs as a coroutine
-- from onFrame, C.RAYS_PER_FRAME rays a frame, one request at a time.

local core = require('openmw.core')
local nearby = require('openmw.nearby')
local self = require('openmw.self')
local util = require('openmw.util')

local C = require('scripts.ojb.config')

local v3 = util.vector3
local SC, WC = C.SPAWN, C.WILD
local GROUND = nearby.COLLISION_TYPE.World + nearby.COLLISION_TYPE.HeightMap
local SOLID = GROUND + nearby.COLLISION_TYPE.Door
local WALK = nearby.NAVIGATOR_FLAGS.Walk + nearby.NAVIGATOR_FLAGS.OpenDoor
local PATH = nearby.FIND_PATH_STATUS

local M = {}

-- { id, n, anchors, radius, away, outdoor, beach, road, cell, found, tried, rays, frameRays, ... }
local job
local waiting = {}

local function budget()
    job.rays = job.rays + 1
    job.frameRays = job.frameRays + 1
    if job.frameRays > C.RAYS_PER_FRAME then coroutine.yield() end
end

local function ray(a, b, mask)
    budget()
    return nearby.castRay(a, b, { collisionType = mask or SOLID, ignore = self })
end

local function vec(t) return v3(t.x, t.y, t.z) end

local function flat(a, b)
    local dx, dy = a.x - b.x, a.y - b.y
    return math.sqrt(dx * dx + dy * dy)
end

-- Actors and doors near the anchors, read once per request (nearby.actors and nearby.doors are one
-- engine read each).
local function blockers()
    local out = {}
    for _, a in ipairs(nearby.actors) do
        if a ~= self.object then out[#out + 1] = a.position end
    end
    for _, d in ipairs(nearby.doors) do out[#out + 1] = d.position end
    return out
end

local function tooClose(p, list, r)
    for _, q in ipairs(list) do
        if flat(p, q) < r and math.abs(p.z - q.z) < 200 then return true end
    end
    return false
end

-- Hidden from the player's eyes: a solid hit between their eye and the spot's chest height.
local function hidden(p)
    local eye = self.position + v3(0, 0, 110)
    local r = ray(eye, p + v3(0, 0, 70))
    return r.hit and (r.hitPos - eye):length() < (p + v3(0, 0, 70) - eye):length() - 20
end

local function outdoorOk(p, normal)
    if normal and normal.z < WC.MAX_SLOPE then return 'too steep' end
    local water = self.cell.waterLevel or 0
    if job.beach then
        if p.z < water + WC.BEACH_Z[1] or p.z > water + WC.BEACH_Z[2] then return 'not on the beach' end
    elseif p.z < water + WC.LAND_Z then
        return 'by or in the water'
    end
    local up = ray(p + v3(0, 0, 20), p + v3(0, 0, 600), GROUND)
    if up.hit then return 'under rock or a roof' end
    for _, d in ipairs({ { 70, 0 }, { -70, 0 }, { 0, 70 }, { 0, -70 } }) do
        local r = ray(p + v3(0, 0, 50), p + v3(d[1], d[2], 50), GROUND)
        if r.hit then return 'against rock or a wall' end
    end
    if job.road then
        local status, path = nearby.findPath(job.road, p, { includeFlags = WALK })
        local last = path and path[#path]
        if status == PATH.StartPolygonNotFound or status == PATH.EndPolygonNotFound or status == PATH.NavMeshNotFound then
            job.navMissing = job.navMissing + 1
            return 'navmesh not ready'
        end
        if not (status == PATH.Success or (status == PATH.PartialPath and last and (last - p):length() < 120)) then
            return 'no way on foot from the road'
        end
    end
    return nil
end

-- One candidate around `anchor`: a spot or nil and why.
local function try(anchor)
    local p = nearby.findRandomPointAroundCircle(anchor, job.radius, { includeFlags = WALK })
    if not p then
        job.navMissing = job.navMissing + 1
        return nil, 'no navmesh'
    end
    local down = ray(p + v3(0, 0, 60), p - v3(0, 0, SC.FLOOR + 60), GROUND)
    if not down.hit or math.abs(down.hitPos.z - p.z) > SC.FLOOR then return nil, 'no floor under it' end
    local at = down.hitPos
    if not job.outdoor and self.cell.hasWater and self.cell.waterLevel and at.z < self.cell.waterLevel + 10 then
        return nil, 'in water'
    end
    if tooClose(at, job.block, SC.CLEAR) then return nil, 'someone or a door there' end
    if tooClose(at, job.found, job.clear or SC.CLEAR) then return nil, 'too near another' end
    if flat(at, self.position) < job.away then return nil, 'too near you' end
    if job.outdoor then
        local why = outdoorOk(at, down.hitNormal)
        if why then return nil, why end
    end
    return at
end

local function search()
    local tries = job.n * SC.TRIES
    local seenOk = {}
    for i = 1, tries do
        if #job.found >= job.n then break end
        local anchor = job.anchors[(i - 1) % #job.anchors + 1]
        local at, why = try(anchor)
        if at then
            if job.outdoor or hidden(at) or i > tries / 2 then
                job.found[#job.found + 1] = at
            else
                seenOk[#seenOk + 1] = at
            end
        else
            job.tried[why] = (job.tried[why] or 0) + 1
        end
    end
    -- In plain sight only when nothing hidden was enough.
    for _, at in ipairs(seenOk) do
        if #job.found >= job.n then break end
        job.found[#job.found + 1] = at
    end
    -- One good spot and no more: stand the rest of the group within a few metres of it.
    if #job.found > 0 and #job.found < job.n then
        local hub = job.found[1]
        job.radius, job.clear = SC.CLUSTER, SC.CLUSTER_CLEAR
        local extra = (job.n - #job.found) * SC.TRIES
        for _ = 1, extra do
            if #job.found >= job.n then break end
            local at, why = try(hub)
            if at then job.found[#job.found + 1] = at
            else job.tried[why] = (job.tried[why] or 0) + 1 end
        end
    end
end

local function answer(err)
    local spots = {}
    for i, p in ipairs(job.found) do
        local face = job.anchors[(i - 1) % #job.anchors + 1]
        spots[i] = { x = p.x, y = p.y, z = p.z, yaw = math.atan2(face.x - p.x, face.y - p.y) }
    end
    local why = {}
    for k, v in pairs(job.tried) do why[#why + 1] = k .. ' ' .. v end
    core.sendGlobalEvent('OJB_SpawnSpots', {
        id = job.id, spots = spots, rays = job.rays, frames = job.frames, ms = job.ms, maxMs = job.maxMs,
        tried = table.concat(why, ', '), error = err,
        retry = #spots == 0 and job.navMissing > 0,
    })
    job = nil
end

local function begin(e)
    local anchors = {}
    for _, a in ipairs(e.anchors or {}) do anchors[#anchors + 1] = vec(a) end
    if #anchors == 0 then anchors[1] = self.position end
    job = {
        id = e.id, n = e.n or 1, anchors = anchors, radius = e.radius or SC.RADIUS, away = e.away or SC.AWAY,
        outdoor = e.outdoor, beach = e.beach, road = e.road and vec(e.road), cell = e.cell,
        found = {}, tried = {}, rays = 0, frameRays = 0, frames = 0, ms = 0, maxMs = 0, navMissing = 0,
    }
    job.block = blockers()
    job.co = coroutine.create(search)
end

function M.start(e)
    if job then
        waiting[#waiting + 1] = e
        return
    end
    begin(e)
end

function M.active() return job ~= nil or #waiting > 0 end

function M.step()
    if not job then
        local e = table.remove(waiting, 1)
        if not e then return end
        begin(e)
    end
    local here = self.cell
    -- The search only sees the loaded cells: an interior job needs the player in that cell, an
    -- outdoor one needs them outdoors. Dropped otherwise; global.lua asks again.
    if not here or (job.outdoor and not here.isExterior) or (not job.outdoor and here.name ~= job.cell) then
        core.sendGlobalEvent('OJB_SpawnSpots', { id = job.id, spots = {}, error = 'left', retry = true })
        job = nil
        return
    end
    job.frameRays = 0
    local t0 = core.getRealTime()
    -- resume hands back the search's error instead of raising it: answered as no spots, so the
    -- job falls back (or tries again on the next visit) instead of the search repeating every frame.
    local alive, err = coroutine.resume(job.co)
    local ms = (core.getRealTime() - t0) * 1000
    job.frames, job.ms = job.frames + 1, job.ms + ms
    if ms > job.maxMs then job.maxMs = ms end
    if not alive then
        print(C.LOG_TAG .. 'spawn spot search failed: ' .. tostring(err))
        answer(tostring(err))
        return
    end
    if coroutine.status(job.co) == 'dead' then answer() end
end

return M
