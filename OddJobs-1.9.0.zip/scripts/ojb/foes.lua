---@omw-context global
-- Pure: who a job is against, from the foe groups tools/build_places.py read out of the masters
-- (places.lua `e` and `b`). No engine calls, so tests/run_tests.py runs it as is.

local C = require('scripts.ojb.config')

local M = {}

M.PEOPLE = { bandit = true, necromancer = true, smuggler = true, warlock = true, vampire = true, cultist = true,
    graverobber = true, pirate = true }

-- In an ancestral tomb the undead are the family's guardians. Only those who broke in are a job;
-- raised: the dead a contract's necromancers brought with them.
M.INTRUDERS = { bandit = true, necromancer = true, smuggler = true, warlock = true, vampire = true,
    cultist = true, daedra = true, graverobber = true, raised = true, pirate = true }

M.WORDS = {
    undead = 'restless dead', daedra = 'daedra', beast = 'beasts', dwemer = 'Dwemer machines',
    ash = 'ash creatures', monster = 'monsters', bandit = 'bandits', necromancer = 'necromancers',
    smuggler = 'smugglers', warlock = 'warlocks', vampire = 'vampires', cultist = 'cultists',
    graverobber = 'grave robbers', raised = 'raised corpses', pirate = 'pirates',
}

-- Creatures that live in water (by the word places.lua gives them).
M.WATER = { slaughterfish = true, dreugh = true }

-- Whether a place's own largest group lives in water: a wreck or sea cave held by fish.
function M.watery(place)
    local top, most = nil, -1
    for _, e in ipairs(place.e or {}) do
        local n = e[2][2] or e[2][1] or 0
        if n > most then top, most = e, n end
    end
    return top ~= nil and M.WATER[top[3] or ''] == true
end

-- Whether a place or cell name is a quest place (C.QUEST_PLACES, by prefix, any case).
function M.quest(name)
    local low = (name or ''):lower()
    for _, q in ipairs(C.QUEST_PLACES) do
        if low:sub(1, #q) == q then return true end
    end
    return false
end

local function at(ns, level)
    local L = C.TIER_LEVELS
    if level <= L[1] then return ns[1] end
    if level >= L[3] then return ns[3] end
    local i = level <= L[2] and 1 or 2
    local f = (level - L[i]) / (L[i + 1] - L[i])
    return ns[i] + (ns[i + 1] - ns[i]) * f
end

-- { {group, n, word}, ... } at this level, largest first; only groups a job may target here.
function M.targets(place, level)
    local out = {}
    for _, e in ipairs(place.e or {}) do
        local g = e[1]
        if not place.tomb or M.INTRUDERS[g] then
            local n = at(e[2], level)
            if n >= 0.5 then out[#out + 1] = { group = g, n = n, word = e[3] } end
        end
    end
    table.sort(out, function(a, b) return a.n > b.n end)
    return out
end

function M.count(list)
    local n = 0
    for _, t in ipairs(list) do n = n + t.n end
    return n
end

-- The tomb's own dead at this level (0 outside tombs).
function M.guardians(place, level)
    if not place.tomb then return 0 end
    local n = 0
    for _, e in ipairs(place.e or {}) do
        if not M.INTRUDERS[e[1]] then n = n + at(e[2], level) end
    end
    return n
end

local function wordOf(t)
    return (not M.PEOPLE[t.group] and t.word) or M.WORDS[t.group] or 'bandits'
end

-- How the notice names them: the largest group, by its family ("skeletons") when one family is at
-- least half of it, else the group's own word. also: the next group's word when the largest is
-- under three quarters of the count, so the number on the notice isn't all one kind.
function M.describe(list)
    local top = list[1]
    if not top then return nil end
    local word = wordOf(top)
    local also = list[2] and top.n < 0.75 * M.count(list) and wordOf(list[2]) or nil
    if also == word then also = nil end
    return { group = top.group, word = word, also = also }
end

-- The hand-placed boss for a bounty, if this place has one a job may target.
function M.boss(place)
    local b = place.b
    if not b then return nil end
    if place.tomb and not M.INTRUDERS[b[4]] then return nil end
    return { id = b[1], name = b[2], female = b[3], group = b[4] }
end

return M
