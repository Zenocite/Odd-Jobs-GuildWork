---@omw-context runtime
-- Pure: what a contract pays. No engine calls, so tests/run_tests.py runs it as is.

local C = require('scripts.ojb.config')

local M = {}

-- Place stats {danger, loot, hostiles} measured at levels 5, 15 and 30, interpolated to `level`.
-- What the player will actually meet there (levelled lists resolve on their level): for the
-- notice's words, never for its tier or pay.
function M.statsAt(t, level)
    local L = C.TIER_LEVELS
    if level <= L[1] then return t[1][1], t[1][2], t[1][3] end
    if level >= L[3] then return t[3][1], t[3][2], t[3][3] end
    local i = level <= L[2] and 1 or 2
    local f = (level - L[i]) / (L[i + 1] - L[i])
    local a, b = t[i], t[i + 1]
    return a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f, a[3] + (b[3] - a[3]) * f
end

-- The supply pool for a poster: guilds and the temple their own, townsfolk by trade.
function M.poolFor(poster, trade)
    return C.SUPPLY_POOL[poster] or C.TRADE_POOL[trade or ''] or 'land'
end

-- Job notices a board posts when it refreshes. Pay is never cut for working a lot; instead there
-- is less new work: one job fewer for each contract finished in the last REPEAT_WINDOW_DAYS, and
-- while the player is new in town at most EARLY.JOBS. Always at least one.
-- who: { done = contracts finished in all, level, levelGates, newDone, earlyLevel }. New in town:
-- under newDone (nil: EARLY.DONE) finished; with levelGates, under earlyLevel (EARLY.LEVEL) instead.
function M.jobCap(who, recent)
    local n = C.SLOTS - recent
    local new
    if who.levelGates then new = (who.level or 1) < (who.earlyLevel or C.EARLY.LEVEL)
    else new = (who.done or 0) < (who.newDone or C.EARLY.DONE) end
    if new then n = math.min(n, C.EARLY.JOBS) end
    return math.max(1, n)
end

-- Contracts the player may hold: MAX_HELD, or PERK.HELD after perkDone finished (nil: PERK.DONE;
-- false: never); with levelGates, from perkLevel (PERK.LEVEL) instead.
-- who: { done, level, levelGates, perkDone, perkLevel }.
function M.maxHeld(who)
    if who.perkDone == false then return C.MAX_HELD end
    local ok
    if who.levelGates then ok = (who.level or 1) >= (who.perkLevel or C.PERK.LEVEL)
    else ok = (who.done or 0) >= (who.perkDone or C.PERK.DONE) end
    return ok and C.PERK.HELD or C.MAX_HELD
end

-- The highest supply tier a job of this difficulty tier and value may pay.
function M.tier(diff, value)
    local top = C.TIER.SUPPLY[diff] or C.TIER.SUPPLY.normal
    local t = 1
    for i = 2, math.min(top, #C.SUPPLY_TIERS.value) do
        if value >= C.SUPPLY_TIERS.value[i] then t = i end
    end
    return t
end

-- Deterministic shuffle so one notice always offers the same bundle, and two notices differ.
local function shuffled(list, seed)
    local out = {}
    for i, x in ipairs(list) do out[i] = x end
    local s = (seed or 1) % 2147483647
    if s <= 0 then s = s + 2147483646 end
    for i = #out, 2, -1 do
        s = s * 16807 % 2147483647
        local j = s % i + 1
        out[i], out[j] = out[j], out[i]
    end
    return out
end

-- Fill a supplies budget from the poster's pool, open tiers only: the top tier and the one under
-- it, at most SUPPLY_KINDS kinds and SUPPLY_PER_KIND lots of each (or the item's max), no lot over
-- SUPPLY_ITEM_SHARE of the gold. value: the whole job's value; gold: what is paid in coin.
-- Never goes over the budget.
function M.bundle(diff, budget, seed, value, gold, poolName)
    value = value or budget
    gold = gold or budget
    local top = M.tier(diff, value)
    local most = math.max(10, gold * C.SUPPLY_ITEM_SHARE)
    local open = {}
    for _, it in ipairs(C.SUPPLIES[poolName or 'land'] or C.SUPPLIES.land) do
        if it.tier <= top and it.tier >= top - 1 and it.value <= most and it.value <= budget then
            open[#open + 1] = it
        end
    end
    local chosen = {}
    for _, it in ipairs(shuffled(open, seed)) do
        if #chosen >= C.SUPPLY_KINDS then break end
        chosen[#chosen + 1] = it
    end
    local items, spent, lots = {}, 0, {}
    for _ = 1, C.SUPPLY_PER_KIND do
        for _, it in ipairs(chosen) do
            if spent + it.value <= budget and (lots[it] or 0) < (it.max or C.SUPPLY_PER_KIND) then
                items[it.id] = (items[it.id] or 0) + it.stack
                lots[it] = (lots[it] or 0) + 1
                spent = spent + it.value
            end
        end
    end
    return items, spent
end

-- Split a value into gold, supply items and possibly a training session.
-- diff: the job's difficulty tier (nil: 'normal'), which sets gold's share and the supply tiers.
-- trainingPrice: what a session would cost the player (nil when not a guild job or not eligible).
-- seed: picks which supplies (the notice id, so a reward reads the same when paid).
-- poolName: M.poolFor's pick (nil: 'land').
-- Returns {gold, items = {id = count}, supplies = shop value, training = bool, value, pool}.
function M.split(value, diff, trainingPrice, seed, poolName)
    diff = C.TIER.GOLD[diff] and diff or 'normal'
    local gold = math.floor(value * C.TIER.GOLD[diff] + 0.5)
    local rest = math.max(0, value - gold)
    if trainingPrice and trainingPrice > 0 and rest >= trainingPrice * C.TRAINING_SHARE then
        return { gold = gold, items = {}, supplies = 0, training = true, value = value, pool = poolName }
    end
    local items, spent = M.bundle(diff, rest, seed, value, gold, poolName)
    return { gold = gold + (rest - spent), items = items, supplies = spent, training = false, value = value,
        pool = poolName }
end

return M
