---@omw-context global
-- Pure: what a board holds and how it rolls over. A board's notices come down one by one as their
-- stay runs out and the gaps are filled again, instead of the whole board being wiped every few
-- days. No engine calls, so tests run it as is.

local C = require('scripts.ojb.config')

local BC = C.BOARD
local M = {}

-- 'guild', 'fort', 'town', 'village' or 'company' from a board's posters.
-- village: the board's own flag (towns.lua), a smaller inn board.
function M.kindOf(posters, company, village)
    if company then return 'company' end
    if village then return 'village' end
    local first = posters and posters[1]
    if first == 'legion' then return 'fort' end
    if first == 'town' then return 'town' end
    return 'guild'
end

-- The family a notice counts in: 'req', 'news' (flavour, news and shop ads), 'wild' or 'job'.
function M.family(n)
    if n.kind == 'req' then return 'req' end
    if n.flavour or n.kind == 'flavour' or n.kind == 'news' or n.kind == 'ad' then return 'news' end
    if n.wild then return 'wild' end
    return 'job'
end

function M.count(notices, family)
    local k = 0
    for _, n in ipairs(notices or {}) do
        if M.family(n) == family then k = k + 1 end
    end
    return k
end

local function draw(r, rnd)
    return r[1] + rnd(r[2] - r[1] + 1) - 1
end

-- This roll's target for a board kind: { jobs, wild, news, total }; rnd(n) is math.random-like.
function M.target(kind, rnd)
    local m = BC.MIX[kind] or BC.MIX.town
    return { jobs = draw(m.jobs, rnd), wild = draw(m.wild, rnd), news = draw(m.news, rnd), total = m.total }
end

-- A chance given per perDays days (C.CHANCE_DAYS), as a chance for one roll every ROLL_DAYS, so a
-- board that rolls daily posts dangerous work as often as one that refreshed every three days.
function M.perRoll(p, perDays)
    return 1 - (1 - p) ^ (BC.ROLL_DAYS / (perDays or C.CHANCE_DAYS))
end

-- Stamps a notice going up: when, and how many days it stays. first: an empty board being filled.
function M.stamp(n, now, rnd, first)
    if n.postedAt and n.stay then return end
    n.postedAt = n.postedAt or now
    local fam = n.kind == 'ad' and 'ad' or M.family(n)
    local r = first and BC.FIRST or BC.STAY[fam] or BC.STAY.job
    n.stay = draw(r, rnd)
end

-- Whether a notice's stay has run out. Notices from an older save carry no stay: REFRESH_DAYS.
function M.due(n, now)
    return now - (n.postedAt or -1e9) >= (n.stay or C.REFRESH_DAYS)
end

-- Splits a board's notices into those staying up and those coming down. keeps(n): true, false
-- or nil; a requisition answers for itself (reqs.lua keeps), nil falls back to the stay.
function M.roll(notices, now, keeps)
    local stay, down = {}, {}
    for _, n in ipairs(notices or {}) do
        local k = keeps and keeps(n)
        if k == nil then k = not M.due(n, now) end
        if k then stay[#stay + 1] = n else down[#down + 1] = n end
    end
    return stay, down
end

-- How many of each family to put up so the board reaches its target. Paid work (jobs and open
-- world) is held to cap: paid is all of that room, which a dangerous notice may take first; open
-- world work comes next and place jobs get what is left. News fills only what total leaves.
function M.room(notices, target, cap)
    local jobs, wild = M.count(notices, 'job'), M.count(notices, 'wild')
    local paid = math.max(0, (cap or math.huge) - jobs - wild)
    local addWild = math.min(math.max(0, target.wild - wild), paid)
    local addJobs = math.min(math.max(0, target.jobs - jobs), paid - addWild)
    return { paid = paid, wild = addWild, jobs = addJobs }
end

-- Place jobs to put up once dangerous and open world notices have had their turn: whatever paid
-- room is left, up to the target, so a board with no open world work in reach isn't short.
function M.jobsRoom(notices, target, cap)
    local jobs, wild = M.count(notices, 'job'), M.count(notices, 'wild')
    local paid = math.max(0, (cap or math.huge) - jobs - wild)
    return math.min(math.max(0, target.jobs - jobs), paid)
end

function M.newsRoom(notices, target)
    local news = M.count(notices, 'news')
    return math.max(0, math.min(target.news - news, target.total - #(notices or {})))
end

local WORDS = { 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten' }

local function papers(k)
    return (WORDS[k] or tostring(k)) .. (k == 1 and ' paper' or ' papers')
end

-- The line under the board's title for today's changes, or nil. change: { day, up, down }.
function M.changeLine(change, today)
    if not change or change.day ~= today then return nil end
    local up, down = change.up or 0, change.down or 0
    if up > 0 and down > 0 then
        return string.format('%s came down and %s went up today.', papers(down), papers(up):lower())
    elseif up > 0 then
        return string.format('%s went up today.', papers(up))
    elseif down > 0 then
        return string.format('%s came down today.', papers(down))
    end
    return nil
end

return M
