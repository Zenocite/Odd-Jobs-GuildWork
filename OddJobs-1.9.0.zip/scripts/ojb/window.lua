---@omw-context player
-- The board window and the contract log, built only from the game's own textures and sounds:
-- a wood background with notices pinned on it, the selected notice read on the scroll texture,
-- and the book window's Take and Close buttons.

local ambient = require('openmw.ambient')
local async = require('openmw.async')
local ui = require('openmw.ui')
local util = require('openmw.util')
local I = require('openmw.interfaces')

local M = {}

-- Mouse-wheel scrolling of a long notice comes from UIToolkit (it owns onMouseWheel and hands it
-- to getCtx().focusedScrollable). Without it, or older than this, the [ up ] and [ down ] marks
-- on the scroll still work.
M.TOOLKIT_MIN = '1.1.0'

-- Written to openmw.log when a window opens, so a test install can be told apart from an old one.
M.VERSION = 'part6-polish1'

local function versionParts(v)
    local out = {}
    for n in tostring(v or ''):gmatch('%d+') do out[#out + 1] = tonumber(n) end
    return out
end

function M.older(a, b)
    local pa, pb = versionParts(a), versionParts(b)
    for i = 1, math.max(#pa, #pb) do
        local x, y = pa[i] or 0, pb[i] or 0
        if x ~= y then return x < y end
    end
    return false
end

-- { ok, why }. requireFn: for tests.
function M.toolkitCheck(lib, requireFn)
    if not lib then return { ok = false, why = 'UIToolkit is not installed or not enabled' } end
    if type(lib.getCtx) ~= 'function' then return { ok = false, why = 'UIToolkit has no getCtx' } end
    -- Probing: require raises 'module not found' when UIToolkit's config file isn't in the VFS.
    local found, D = pcall(requireFn or require, 'scripts.UIToolkit.config.defaults')
    local version = found and type(D) == 'table' and D.Version or nil
    if version and M.older(version, M.TOOLKIT_MIN) then
        return { ok = false, why = 'UIToolkit ' .. version .. ' is older than ' .. M.TOOLKIT_MIN }
    end
    return { ok = true, why = 'UIToolkit ' .. tostring(version or 'with getCtx') }
end

local toolkit
local PA = require('scripts.ojb.paper')

local INK = util.color.rgb(0.16, 0.10, 0.05)
local INK_SOFT = util.color.rgb(0.27, 0.17, 0.09)
local RED_INK = util.color.rgb(0.52, 0.08, 0.04)
local GOLD = util.color.rgb(0.875, 0.788, 0.624)
local GOLD_DIM = util.color.rgb(0.55, 0.47, 0.34)
local HOVER = util.color.rgb(0.95, 0.55, 0.35)
local BLACK = util.color.rgb(0, 0, 0)
local DARK = util.color.rgb(0.07, 0.05, 0.04)

-- Design size in UI units (1600x900). Shrinks to fit a small UI layer (a high UI scale on a small
-- screen); on a big layer it grows, but only to FILL of the room, so the game stays in view.
local W, H = 1600, 900
local FILL = 0.9
local MIN_TEXT = 12

-- The scroll texture's curls: its top roll ends about 19% down and the bottom roll starts about
-- 89% down (measured on vanilla scroll.dds and common replacers of it).
local SCROLL_TOP, SCROLL_BOTTOM = 0.20, 0.87

local scale = 1
local element
local view          -- what's on screen: { mode = 'board'|'log'|'choice', data, selected = {kind, id} }
local handlers      -- { take(id), handIn(id), abandon(id), handOver(id), choose(option), close() }

local function scaleOf(lw, lh)
    local fit = math.min((lw - 16) / W, (lh - 16) / H)
    return math.min(fit, math.max(1, fit * FILL))
end

local function fitScale()
    local i = ui.layers.indexOf('Windows')
    local size = i and ui.layers[i].size
    if not size then return 1 end
    return scaleOf(size.x, size.y)
end

local function sv(x, y)
    return util.vector2(x * scale, y * scale)
end

local function textSize(n)
    return math.max(MIN_TEXT, math.floor(n * scale + 0.5))
end

local textures = {}
local function tex(name)
    local t = textures[name]
    if not t then
        t = ui.texture({ path = 'textures/' .. name })
        textures[name] = t
    end
    return t
end

local function image(name, x, y, w, h, extra)
    local props = { resource = tex(name), position = sv(x, y), size = sv(w, h) }
    for k, v in pairs(extra or {}) do props[k] = v end
    return { type = ui.TYPE.Image, props = props }
end

local function label(str, x, y, w, h, size, color, extra)
    local props = {
        text = str or '', position = sv(x, y), size = sv(w, h), autoSize = false,
        textSize = textSize(size or 16), textColor = color or INK, wordWrap = true, multiline = true,
    }
    for k, v in pairs(extra or {}) do props[k] = v end
    return { type = ui.TYPE.Text, props = props }
end

local function click(fn)
    return async:callback(function() fn() end)
end

-- Lines a text wraps to: Magic Cards averages under 0.42 of its size per character and replacer
-- fonts run wider, so this errs on the side of more lines. Too many only leaves a gap; too few
-- runs one area into the next.
local CHAR_W = 0.5
local LINE_H = 1.25

function M.lines(str, width, size)
    local perLine = math.max(1, math.floor(width / (size * CHAR_W)))
    local n, col = 0, 0
    for para in ((str or '') .. '\n'):gmatch('(.-)\n') do
        n, col = n + 1, 0
        for word in para:gmatch('%S+') do
            local len = #word
            if col > 0 and col + 1 + len > perLine then
                n, col = n + 1, len
            else
                col = col + (col > 0 and 1 or 0) + len
            end
        end
    end
    return n
end

-- Height in design units of text drawn at `size`. Text never draws under MIN_TEXT pixels while
-- widths keep shrinking with the window, so lines are counted at the size actually drawn.
local function heightOf(str, width, size)
    local px = textSize(size)
    return M.lines(str, width * scale, px) * px * LINE_H / scale
end

-- The words of str that fit in maxLines at `size` across width, cut at a word with '...' when not all do.
-- Counted at the size actually drawn, like heightOf.
function M.clip(str, width, size, maxLines)
    str = str or ''
    local px = textSize(size)
    if M.lines(str, width * scale, px) <= maxLines then return str end
    local words = {}
    for w in str:gmatch('%S+') do words[#words + 1] = w end
    local lo, hi = 0, #words
    while lo < hi do
        local mid = math.floor((lo + hi + 1) / 2)
        if M.lines(table.concat(words, ' ', 1, mid) .. '...', width * scale, px) <= maxLines then lo = mid
        else hi = mid - 1 end
    end
    return (table.concat(words, ' ', 1, lo):gsub('[,;:%.]$', '')) .. '...'
end

-- A header strip's words in capitals on one line, never wider than widthPx: centred text that
-- overflows is cut on both sides. Shrinks to HEADER_MIN pixels, then drops the owner's first name
-- ("HARQUART'S BAKED GOODS"), then keeps the possessive alone ("HARQUART'S"), then cuts the end.
-- Capitals run wider than CHAR_W. Returns the text and its size in pixels.
local CAPS_W, HEADER_MIN = 0.58, 10
function M.fitHeader(words, widthPx, size)
    local px = math.max(HEADER_MIN, math.floor(size * scale + 0.5))
    local function fits(s, p) return #s * p * CAPS_W <= widthPx end
    local full = (words or ''):upper()
    local tries = { full }
    local rest = full:match('^%S+%s+(%S+\'S%s.+)$')
    if rest then tries[#tries + 1] = rest end
    local own = full:match('(%S+\'S)%s')
    if own then tries[#tries + 1] = own end
    for _, s in ipairs(tries) do
        for p = px, HEADER_MIN, -1 do
            if fits(s, p) then return s, p end
        end
    end
    local n = math.max(1, math.floor(widthPx / (HEADER_MIN * CAPS_W)) - 3)
    return full:sub(1, n):gsub('%s+%S*$', '') .. '...', HEADER_MIN
end

local function col(t)
    return util.color.rgb(t[1], t[2], t[3])
end

local function rect(x, y, w, h, color, alpha)
    textures.white = textures.white or ui.texture({ path = 'white' })
    return { type = ui.TYPE.Image, props = { resource = textures.white, position = sv(x, y), size = sv(w, h),
        color = color, alpha = alpha or 1 } }
end

-- Four bars of thickness t just inside x, y, w, h.
local function frame(parts, x, y, w, h, t, color, alpha)
    parts[#parts + 1] = rect(x, y, w, t, color, alpha)
    parts[#parts + 1] = rect(x, y + h - t, w, t, color, alpha)
    parts[#parts + 1] = rect(x, y + t, t, h - 2 * t, color, alpha)
    parts[#parts + 1] = rect(x + w - t, y + t, t, h - 2 * t, color, alpha)
end

-- Sections stacked top to bottom, each in its own area. sections: { {text, size, color, extra}, ... };
-- fills in y and h (empty ones get neither) and returns them with the total height.
function M.column(sections, width, gap)
    local y = 0
    for _, s in ipairs(sections) do
        if s.text and s.text ~= '' then
            s.y, s.h = y, heightOf(s.text, width, s.size)
            y = y + s.h + gap
        end
    end
    return sections, y
end

-- The notice's middle part scrolls when it's taller than the space between title and time limit.
local SCROLL_GUTTER = 18
local scroll = { offset = 0, max = 0, id = nil }
local scroller = {
    isDestroyed = function() return element == nil end,
    isVisible = function() return element ~= nil and scroll.max > 0 end,
    onMouseScrolled = function(_, v) M.scrollBy(-(v or 0) * 3 * 16 * LINE_H) end,
}

function M.scrollBy(dy)
    if scroll.max <= 0 then return false end
    local was = scroll.offset
    scroll.offset = math.max(0, math.min(scroll.max, was + dy))
    if scroll.offset ~= was then M.refresh() end
    return true
end

local function claimWheel()
    if toolkit and toolkit.ok and scroll.max > 0 then
        I.UIToolkit.getCtx().focusedScrollable = scroller
    end
end

local function root(content)
    return {
        layer = 'Windows',
        type = ui.TYPE.Widget,
        props = {
            relativePosition = util.vector2(0.5, 0.5), anchor = util.vector2(0.5, 0.5),
            size = sv(W, H),
        },
        content = ui.content(content),
    }
end

local function findSelected()
    local sel = view.selected
    if not sel then return nil end
    local list = sel.kind == 'notice' and view.data.notices or view.data.contracts
    for _, x in ipairs(list or {}) do
        if x.id == sel.id then return x, sel.kind end
    end
    return nil
end

-- Sealed letters (dangerous and elite work) whose seal has been heard breaking. Key: notice id;
-- lives for the session, so each seal cracks once a session however often it is read.
local sealsBroken = {}

local function select(kind, id)
    view.selected = { kind = kind, id = id }
    local item = findSelected()
    if kind == 'notice' and item and item.seal and not sealsBroken[id] then
        sealsBroken[id] = true
        ambient.playSound('Item Ring Down')
    end
    ambient.playSound('book page')
    M.refresh()
end

local function statusOf(item, kind)
    if kind == 'notice' then
        if item.flavour then return nil end
        if item.req then return item.status end
        return string.format('Open for %d days once taken.', item.days or 7)
    end
    if item.state == 'done' then
        if item.kind == 'recovery' then
            return string.format('Found. Return %s to %s to be paid.', item.itemName or 'it', item.returnTo)
        end
        return 'Done. Return to ' .. item.returnTo .. ' to be paid.'
    end
    return string.format('%d days left.', item.daysLeft or 0)
end

-- Board layout in design units: papers on the left, the reading page on the right, the contracts
-- strip along the bottom.
local AX, AY, AW, AH = 28, 118, 1036, 694
local DX, DY, DW, DH = 1084, 76, 492, 744
local STRIP_Y = 828
-- Room around a paper's own widget for its shadow, pins and selection frame (children are clipped).
local PAD = 14

local KIND_WORD = { nest = 'Clearing', bounty = 'Bounty', recovery = 'Recovery', req = 'Goods wanted',
    ad = 'Shop', news = 'News', flavour = 'Notice' }
local NEWS_WORD = { fighters = 'Guild news', mages = 'Guild news', legion = 'Fort news', company = 'Company news',
    temple = 'Temple news' }
local TIER_WORD = { easy = 'Easy work', normal = 'Normal work', dangerous = 'Dangerous work', elite = 'Elite work' }
local FILTERS = { { 'all', 'All' }, { 'work', 'Work' }, { 'goods', 'Goods wanted' }, { 'news', 'News and shops' } }
local HEADER_INK = util.color.rgb(0.95, 0.90, 0.78)
local LEDGER = util.color.rgb(0.25, 0.42, 0.30)
local MARGIN = util.color.rgb(0.60, 0.20, 0.15)
local DIRT = util.color.rgb(0.45, 0.35, 0.25)

local function tierLook(n)
    return n.seal and PA.TIER_LOOK[n.tier] or nil
end

local function kindLine(n)
    if tierLook(n) then return TIER_WORD[n.tier] end
    if n.kind == 'news' then return NEWS_WORD[n.style] or 'News' end
    if n.wild == 'gather' then return 'Gathering' end
    return KIND_WORD[n.kind] or 'Notice'
end

-- The hover line: what it is, how far, how hard. Never the notice's own words.
-- A held contract's state in a word or two: done ones by what's left to do, others by progress.
local function progressWord(c)
    if c.state == 'done' then
        if c.handIn then return 'ready' end
        return c.kind == 'recovery' and 'found' or 'done'
    end
    return c.progress or string.format('%d days left', c.daysLeft or 0)
end

local function tooltipText(n, kind)
    local bits = { n.kind == 'ad' and n.shop and n.shop.trade or kindLine(n) }
    if kind == 'contract' then
        bits[#bits + 1] = progressWord(n)
        if n.state ~= 'done' and n.progress then bits[#bits + 1] = string.format('%d days left', n.daysLeft or 0) end
        return table.concat(bits, ', ')
    end
    if n.dist then bits[#bits + 1] = n.dist end
    if n.req then
        if n.grade == 'rare' then bits[#bits + 1] = 'rare' end
    elseif not n.flavour and n.diff and not tierLook(n) then
        bits[#bits + 1] = TIER_WORD[n.diff]:lower()
    end
    if n.shop and n.shop.closed then bits[#bits + 1] = 'shut' end
    return table.concat(bits, ', ')
end

local function hover(id)
    if view and view.hover ~= id then
        view.hover = id
        M.refresh()
    end
end

-- Parts under the papers clear the hover when the mouse reaches them.
local function clearsHover(node)
    node.events = { mouseMove = async:callback(function() hover(nil) end) }
    return node
end

-- How deep a sheet's torn edge reaches in from each side: paper_torn.dds's ragged edge and its
-- shaded rim run up to 11 of its 256 pixels and stretch with the sheet.
function M.tornEdge(torn, h)
    return torn and math.ceil(h * 11 / 256) or 0
end

-- A notice's paper without its words: shadow, sheet, header or border, ledger lines and marks, so
-- the board paper and the open letter are the same sheet. opts: shadow = { x, y, alpha } (where the
-- shadow's corner goes), selected (a gold frame), header (the strip's words, nil: the style's).
-- Returns { s, look, ink, top (first free line under the header), sealColor, rnd, age }.
local function paperBack(parts, n, ox, oy, w, h, opts)
    local s = PA.STYLES[n.style] or PA.STYLES.scrap
    local look = tierLook(n)
    local rnd = PA.rand(n.id)
    local age = PA.age(n.age)
    local torn = s.torn and not (look and look.tint)
    local t = look and look.tint or s.tint
    local tint = util.color.rgb(t[1] * (1 - 0.10 * age), t[2] * (1 - 0.14 * age), t[3] * (1 - 0.24 * age))
    local sheet = torn and 'ojb/paper_torn.dds' or 'ojb/paper.dds'
    if opts.shadow then
        parts[#parts + 1] = image(sheet, opts.shadow[1], opts.shadow[2], w, h, { color = BLACK, alpha = opts.shadow[3] })
    end
    if opts.selected then frame(parts, ox - 5, oy - 5, w + 10, h + 10, 3, GOLD, 0.95) end
    parts[#parts + 1] = image(sheet, ox, oy, w, h, { color = tint })

    local top = math.max(14, M.tornEdge(torn, h) + 4)
    if s.header then
        local words = s.header.text
        if n.style == 'shop' then words = n.shop and n.shop.name or n.title end
        if n.style == 'company' and view and view.data then words = view.data.company or words end
        local hh = opts.big and 30 or 22
        parts[#parts + 1] = rect(ox + 6, oy + 6, w - 12, hh, col(s.header.color), 0.95)
        local text, px = M.fitHeader(words, (w - 20) * scale, opts.big and 15 or 12)
        local size = px / scale
        parts[#parts + 1] = label(text, ox + 10, oy + 6 + (hh - size - 4) / 2, w - 20, size + 6, size, HEADER_INK,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false, textSize = px })
        top = hh + 12
    end
    if look and n.tier == 'elite' then
        frame(parts, ox + 4, oy + 4, w - 8, h - 8, 5, col(look.frame), 1)
        frame(parts, ox + 12, oy + 12, w - 24, h - 24, 1, DARK, 0.7)
    elseif look then
        frame(parts, ox + 4, oy + 4, w - 8, h - 8, 4, col(look.frame), 0.95)
        frame(parts, ox + 11, oy + 11, w - 22, h - 22, 1, col(look.frame), 0.8)
    elseif s.border then
        local bc = col(s.border.color)
        if s.border.kind == 'single' then
            frame(parts, ox + 7, oy + 7, w - 14, h - 14, 2, bc, 0.9)
        elseif s.border.kind == 'double' then
            frame(parts, ox + 6, oy + 6, w - 12, h - 12, 3, bc, 0.9)
            frame(parts, ox + 11, oy + 11, w - 22, h - 22, 1, bc, 0.8)
        else
            frame(parts, ox + 5, oy + 5, w - 10, h - 10, 3, bc, 0.9)
            frame(parts, ox + 11, oy + 11, w - 22, h - 22, 1, bc, 0.8)
            for _, c in ipairs({ { 5, 5 }, { w - 15, 5 }, { 5, h - 15 }, { w - 15, h - 15 } }) do
                parts[#parts + 1] = rect(ox + c[1], oy + c[2], 10, 10, bc, 0.9)
            end
        end
    end
    if s.ledger then
        for ly = top + 46, h - 40, 16 do parts[#parts + 1] = rect(ox + 14, oy + ly, w - 28, 1, LEDGER, 0.3) end
        parts[#parts + 1] = rect(ox + 30, oy + top + 38, 1, h - top - 74, MARGIN, 0.3)
    end
    if s.marks == 'stain' and rnd(4) < 0.6 then
        local sz = 44 + rnd(5) * 24
        parts[#parts + 1] = image('ojb/stain.dds', ox + rnd(6) * (w - sz), oy + h * 0.35 + rnd(7) * (h * 0.6 - sz),
            sz, sz, { alpha = 0.8 })
    end
    if s.marks == 'dirt' or (s.marks == 'stain' and rnd(8) < 0.4) then
        parts[#parts + 1] = image('ojb/smudge.dds', ox + 12 + rnd(9) * (w - 54), oy + h - 56 - rnd(10) * 40, 30, 36,
            { alpha = s.marks == 'dirt' and 0.9 or 0.6, color = s.marks == 'dirt' and DIRT or nil })
    end
    if s.marks == 'dirt' then
        parts[#parts + 1] = image('ojb/smudge.dds', ox + 12 + rnd(11) * (w - 66), oy + 30 + rnd(12) * 50, 42, 30,
            { alpha = 0.7, color = DIRT })
    end
    return { s = s, look = look, ink = col(look and look.ink or s.ink), top = top, rnd = rnd, age = age,
        sealColor = look and look.seal or s.seal }
end

local function pins(parts, s, rnd, ox, oy, w)
    if s.pins == 1 then
        parts[#parts + 1] = image('ojb/pin.dds', ox + 20 + rnd(13) * (w - 58), oy - 6, 18, 18)
    else
        parts[#parts + 1] = image('ojb/pin.dds', ox + 4, oy - 5, 18, 18)
        parts[#parts + 1] = image('ojb/pin.dds', ox + w - 22, oy - 5, 18, 18)
    end
end

-- One notice on its poster's paper (paper.lua): shadow, paper, header or border, marks, words,
-- tier marks, seal and pins, in that order so later parts sit on top. bx, by: the paper's corner.
-- kind: 'contract' for a held contract in the log (a progress tag where RARE would go), else a notice.
local function paperWidget(n, bx, by, w, h, hovered, selected, kind)
    local lift = hovered and 3 or 0
    local ox, oy = PAD - lift, PAD - lift
    local parts = {}
    local info = paperBack(parts, n, ox, oy, w, h, { selected = selected,
        shadow = { PAD + (hovered and 8 or 4), PAD + (hovered and 10 or 5), hovered and 0.4 or 0.5 } })
    local s, look, ink, top, rnd, age = info.s, info.look, info.ink, info.top, info.rnd, info.age

    -- Words, top to bottom, each clipped to the room it has.
    local x0, tw = ox + 16, w - 32
    local tag = kind == 'contract' and progressWord(n)
    local tagW = tag and math.min(tw - 60, 14 + #tag * 7) or 44
    parts[#parts + 1] = label(kindLine(n), x0, oy + top, tw - tagW, 16, 12,
        look and (n.tier == 'elite' and DARK or RED_INK) or ink, { wordWrap = false, alpha = look and 1 or 0.75 })
    if tag then
        parts[#parts + 1] = rect(ox + w - 16 - tagW, oy + top - 1, tagW, 17, DARK, 0.85)
        parts[#parts + 1] = label(tag, ox + w - 16 - tagW, oy + top, tagW, 15, 12, n.state == 'done' and HOVER or GOLD,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
    elseif n.grade == 'rare' then
        parts[#parts + 1] = rect(ox + w - 60, oy + top - 1, 44, 17, DARK, 0.85)
        parts[#parts + 1] = label('RARE', ox + w - 60, oy + top, 44, 15, 12, GOLD,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
    end
    local y = top + 18
    local wantedName = n.title:match('^WANTED[:%s%-]*(.*)$')
    if wantedName then
        parts[#parts + 1] = label('WANTED', x0, oy + y, tw, 40, 34, ink, { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
        y = y + 40
        local name = M.clip(wantedName, tw, 16, 2)
        local nh = heightOf(name, tw, 16)
        parts[#parts + 1] = label(name, x0, oy + y, tw, nh + 2, 16, RED_INK, { textAlignH = ui.ALIGNMENT.Center })
        y = y + nh + 2
    else
        local size = (n.kind == 'ad' or n.flavour) and 17 or 18
        local title = M.clip(n.title, tw, size, (n.sheet and #n.sheet > 0) and 1 or n.req and 2 or 3)
        local th = heightOf(title, tw, size)
        parts[#parts + 1] = label(title, x0, oy + y, tw, th + 2, size, ink)
        y = y + th
    end
    parts[#parts + 1] = rect(x0, oy + y + 3, tw, 1, ink, 0.35)
    y = y + 9

    local daggers = n.marks and not n.flavour and not n.req
    local sealColor = info.sealColor
    local bottom = h - (daggers and 60 or 32)
    if n.req and n.sheet and #n.sheet > 0 then
        for i, r in ipairs(n.sheet) do
            if i > 3 or y + 36 > bottom then break end
            local line = r.line or (tostring(r.wanted or 1) .. ' ' .. (r.name or ''))
            -- The price gives way to the goods' name when both don't fit; the order sheet has it.
            local priced = r.each and M.lines(line, (tw - 62) * scale, textSize(13)) <= 1
            local nameW = priced and tw - 62 or tw
            parts[#parts + 1] = label(M.clip(line, nameW, 13, 1), x0, oy + y, nameW, 18, 13, ink, { wordWrap = false })
            if priced then
                parts[#parts + 1] = label(tostring(r.each) .. ' each', x0 + tw - 62, oy + y + 1, 62, 18, 12, ink,
                    { textAlignH = ui.ALIGNMENT.End, wordWrap = false, alpha = 0.75 })
            end
            y = y + 18
        end
    else
        local size = 14
        local lineH = textSize(size) * LINE_H / scale
        local room = math.floor((bottom - (n.req and 20 or 0) - y) / lineH)
        if room >= 1 then
            parts[#parts + 1] = label(M.clip(n.body, tw, size, room), x0, oy + y, tw, room * lineH + 2, size, ink)
            y = y + room * lineH
        end
    end
    if n.req and n.total then
        parts[#parts + 1] = label(string.format('%d gold', n.total), x0, oy + y + 2, tw - 40, 18, 13, RED_INK,
            { wordWrap = false })
    end
    if daggers then
        local mc = look and col(look.marks) or ink
        for i = 1, n.marks do
            parts[#parts + 1] = image('ojb/dagger.dds', x0 - 2 + (i - 1) * 12, oy + h - 58, 14, 28, { color = mc })
        end
    end
    if sealColor then
        parts[#parts + 1] = image('ojb/seal.dds', ox + w - 52, oy + h - 54, 38, 38, { color = col(sealColor) })
    end
    local fromW = tw - (sealColor and 38 or 0)
    parts[#parts + 1] = label(M.clip(n.from or '', fromW, 12, 1), x0, oy + h - 28, fromW, 16, 12, ink,
        { wordWrap = false, alpha = 0.7 })
    if age >= 0.5 then
        parts[#parts + 1] = image('ojb/curl.dds', ox + w - 34, oy + h - 34, 34, 34, { alpha = math.min(1, age) })
    end
    if look and look.ribbon then parts[#parts + 1] = image('ojb/ribbon.dds', ox + w - 62, oy, 62, 62) end
    pins(parts, s, rnd, ox, oy, w)

    -- Clicks and moves on any part propagate to this container, so the whole paper answers.
    return {
        type = ui.TYPE.Widget,
        name = (kind == 'contract' and 'held:' or 'paper:') .. tostring(n.id),
        props = { position = sv(bx - PAD, by - PAD), size = sv(w + 2 * PAD + 10, h + 2 * PAD + 12) },
        events = {
            mouseClick = click(function() select(kind or 'notice', n.id) end),
            mouseMove = async:callback(function() hover(n.id) end),
        },
        content = ui.content(parts),
    }
end

local function tooltip(content, n, x, y, w, h, kind)
    local text = tooltipText(n, kind)
    local tw = math.min(360, 28 + #text * 7.5)
    local tx = math.max(AX, math.min(AX + AW - tw, x + (w - tw) / 2))
    local ty = y + h + 8
    if ty + 30 > AY + AH + 12 then ty = y - 38 end
    content[#content + 1] = rect(tx, ty, tw, 28, DARK, 0.92)
    frame(content, tx, ty, tw, 28, 1, GOLD_DIM, 1)
    content[#content + 1] = label(text, tx + 8, ty + 5, tw - 16, 20, 14, GOLD,
        { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
end

-- Buttons in Morrowind's style: a dark fill and a gold border. fn nil: drawn dim and does nothing.
local BTN_H = 34

local function button(content, name, text, x, y, w, fn)
    local live = fn ~= nil
    content[#content + 1] = rect(x, y, w, BTN_H, DARK, live and 0.94 or 0.6)
    frame(content, x, y, w, BTN_H, 2, live and GOLD or GOLD_DIM, live and 1 or 0.6)
    local node = label(text, x, y + (BTN_H - 22) / 2, w, 22, 17, live and GOLD or GOLD_DIM,
        { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
    node.name = 'btn:' .. name
    if live then node.events = { mouseClick = click(fn) } end
    content[#content + 1] = node
end

-- A row of buttons ending at the right edge, in the order given. list: { { name, text, fn }, ... }.
-- Returns the x left of the first one.
local function buttonRow(content, list, x0, y, w)
    local x = x0 + w
    for i = #list, 1, -1 do
        local b = list[i]
        local bw = math.max(120, 40 + #b[2] * 9)
        x = x - bw
        button(content, b[1], b[2], x, y, bw, b[3])
        x = x - 12
    end
    return x
end

-- Text too tall for its room scrolls: the wheel through UIToolkit, or the ^ and v marks.
-- build(width) returns M.column's sections and total height.
local function scrolling(content, sid, x, y, width, areaH, build)
    local sections, total = build(width)
    local textW = width
    if total > areaH then
        textW = width - SCROLL_GUTTER
        sections, total = build(textW)
    end
    if scroll.id ~= sid then scroll.id, scroll.offset = sid, 0 end
    scroll.max = math.max(0, total - areaH)
    scroll.offset = math.min(scroll.offset, scroll.max)
    local inner = {}
    for _, s in ipairs(sections) do
        if s.y then inner[#inner + 1] = label(s.text, 0, s.y, textW, s.h + 4, s.size, s.color, s.extra) end
    end
    local area = {
        { type = ui.TYPE.Widget, props = { position = sv(0, -scroll.offset), size = sv(textW, total) },
            content = ui.content(inner) },
    }
    if scroll.max > 0 then
        local gx = width - SCROLL_GUTTER + 4
        local up = label('^', gx, 0, 14, 20, 18, scroll.offset > 0 and RED_INK or INK_SOFT,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
        up.events = { mouseClick = click(function() M.scrollBy(-areaH * 0.6) end) }
        local down = label('v', gx, areaH - 20, 14, 20, 18, scroll.offset < scroll.max and RED_INK or INK_SOFT,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
        down.events = { mouseClick = click(function() M.scrollBy(areaH * 0.6) end) }
        local trackH = areaH - 48
        local barH = math.max(14, trackH * areaH / total)
        local barY = 24 + (trackH - barH) * scroll.offset / scroll.max
        area[#area + 1] = rect(gx + 5, 24, 3, trackH, BLACK, 0.15)
        area[#area + 1] = rect(gx + 4, barY, 5, barH, BLACK, 0.55)
        area[#area + 1] = up
        area[#area + 1] = down
    end
    content[#content + 1] = {
        type = ui.TYPE.Widget,
        name = 'noticeText',
        props = { position = sv(x, y), size = sv(width, areaH) },
        events = { mouseMove = async:callback(claimWheel), focusGain = async:callback(claimWheel) },
        content = ui.content(area),
    }
end

-- An order sheet's table: goods, wanted, carried, price each; the total; where to buy what's missing.
-- Fixed, not scrolling: orders are a few lines. Returns the y under it.
local GREEN_INK = util.color.rgb(0.12, 0.38, 0.14)
local function orderTable(content, n, ink, x, y, width)
    local cw = { width * 0.44, width * 0.16, width * 0.19, width * 0.21 }
    local cx = { x, x + cw[1], x + cw[1] + cw[2], x + cw[1] + cw[2] + cw[3] }
    local first = (n.sheet or {})[1]
    local heads = { first and first.head or 'Goods', 'Wanted', 'You have', 'Each' }
    for i, hd in ipairs(heads) do
        content[#content + 1] = label(hd, cx[i], y, cw[i], 18, 13, ink, { wordWrap = false, alpha = 0.7,
            textAlignH = i == 1 and ui.ALIGNMENT.Start or ui.ALIGNMENT.End })
    end
    y = y + 20
    content[#content + 1] = rect(x, y, width, 1, ink, 0.35)
    y = y + 5
    local hints = {}
    for _, r in ipairs(n.sheet or {}) do
        local enough = (r.have or 0) >= (r.wanted or 0)
        local name = M.clip(r.name or '', cw[1] - 6, 15, 2)
        local nameH = math.max(20, heightOf(name, cw[1] - 6, 15) + 2)
        content[#content + 1] = label(name, cx[1], y, cw[1] - 6, nameH, 15, ink)
        content[#content + 1] = label(tostring(r.wanted or 1), cx[2], y, cw[2], 20, 15, ink,
            { wordWrap = false, textAlignH = ui.ALIGNMENT.End })
        content[#content + 1] = label(tostring(r.have or 0), cx[3], y, cw[3], 20, 15, enough and GREEN_INK or RED_INK,
            { wordWrap = false, textAlignH = ui.ALIGNMENT.End })
        content[#content + 1] = label(r.each and (tostring(r.each) .. ' gold') or '', cx[4], y, cw[4], 20, 15, ink,
            { wordWrap = false, textAlignH = ui.ALIGNMENT.End })
        if r.hint and not enough then hints[#hints + 1] = r.hint end
        y = y + nameH + 2
    end
    content[#content + 1] = rect(x, y + 2, width, 1, ink, 0.35)
    y = y + 8
    content[#content + 1] = label('Total on delivery', x, y, width * 0.6, 20, 15, ink, { wordWrap = false })
    content[#content + 1] = label(string.format('%d gold', n.total or 0), x + width * 0.5, y, width * 0.5, 20, 16,
        RED_INK, { wordWrap = false, textAlignH = ui.ALIGNMENT.End })
    y = y + 28
    for _, hint in ipairs(hints) do
        local hh = heightOf(hint, width, 14)
        content[#content + 1] = label(hint, x, y, width, hh + 4, 14, ink, { alpha = 0.8 })
        y = y + hh + 4
    end
    return y
end

-- Right-hand page: the selected notice or contract open on its own paper, buttons under it.
-- Top to bottom, each in its own area so none runs into the next: kind line; title; story and the
-- way (scrolling); reward box with the tier marks; time limit; signature and seal.
local function reading(content, x0, y0, w, h)
    local item, kind = findSelected()
    local ph = h - BTN_H - 16
    local by = y0 + h - BTN_H
    local close = function() handlers.close() end
    local shadow = { x0 + 6, y0 + 7, 0.5 }
    if not item then
        paperBack(content, { id = 0, style = 'flavour', title = '' }, x0, y0, w, ph, { shadow = shadow })
        local hint = view.mode == 'log' and 'You hold no contracts.' or 'Choose a notice to read it.'
        if view.mode == 'log' and #(view.data.contracts or {}) > 0 then hint = 'Choose a contract to read it.' end
        content[#content + 1] = label(hint, x0 + 30, y0 + ph / 2 - 20, w - 60, 40, 18, INK,
            { textAlignH = ui.ALIGNMENT.Center })
        buttonRow(content, { { 'close', 'Close', close } }, x0, by, w)
        return
    end
    local n = item
    local info = paperBack(content, n, x0, y0, w, ph, { shadow = shadow, big = true })
    local ink, look = info.ink, info.look
    local x, width = x0 + 30, w - 60
    local y = y0 + info.top + 6

    local kl = kindLine(n)
    if n.dist and kind == 'notice' then
        kl = kl .. ', ' .. n.dist .. ((n.dist:find('^about') or n.dist == 'a short walk') and ' from here' or '')
    end
    content[#content + 1] = label(kl, x, y, width - 70, 18, 13, look and (n.tier == 'elite' and DARK or RED_INK) or ink,
        { wordWrap = false, alpha = look and 1 or 0.75 })
    if n.grade == 'rare' then
        content[#content + 1] = rect(x + width - 56, y - 1, 56, 19, DARK, 0.85)
        content[#content + 1] = label('RARE', x + width - 56, y, 56, 17, 13, GOLD,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
    end
    y = y + 22
    local wantedName = (n.title or ''):match('^WANTED[:%s%-]*(.*)$')
    if wantedName then
        content[#content + 1] = label('WANTED', x, y, width, 50, 44, ink, { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
        y = y + 50
        local nh = heightOf(wantedName, width, 20)
        content[#content + 1] = label(wantedName, x, y, width, nh + 4, 20, RED_INK,
            { textAlignH = ui.ALIGNMENT.Center })
        y = y + nh + 4
    else
        local th = heightOf(n.title, width, 22)
        content[#content + 1] = label(n.title, x, y, width, th + 4, 22, ink)
        y = y + th + 4
    end
    if n.seal then
        local sh = heightOf(n.seal, width, 15)
        content[#content + 1] = label(n.seal, x, y, width, sh + 4, 15, n.tier == 'elite' and DARK or RED_INK,
            { textAlignH = ui.ALIGNMENT.Center })
        y = y + sh + 4
    end
    content[#content + 1] = rect(x, y + 4, width, 1, ink, 0.35)
    y = y + 12

    -- From the bottom up: signature and seal, time limit, reward box.
    local bottom = y0 + ph - 20
    local sealC = info.sealColor
    if sealC then
        content[#content + 1] = image('ojb/seal.dds', x0 + w - 82, y0 + ph - 84, 58, 58, { color = col(sealC) })
    end
    local fromW = width - (sealC and 62 or 0)
    content[#content + 1] = label(n.from or '', x, bottom - 20, fromW, 20, 15, ink, { wordWrap = false, alpha = 0.85 })
    bottom = bottom - 26
    local status = statusOf(n, kind)
    if status and not n.req then
        local sh = heightOf(status, fromW, 14)
        bottom = bottom - sh
        content[#content + 1] = label(status, x, bottom, fromW, sh + 4, 14, ink, { alpha = 0.85 })
        bottom = bottom - 8
    end
    if sealC then bottom = math.min(bottom, y0 + ph - 92) end
    if n.reward and not n.req and not n.flavour then
        local marksW = n.marks and (n.marks * 15 + 10) or 0
        local rw = width - 24 - marksW
        local rh = heightOf(n.reward, rw, 16)
        local boxH = rh + 36
        bottom = bottom - boxH
        frame(content, x, bottom, width, boxH, 1, look and col(look.frame) or ink, 0.6)
        content[#content + 1] = label('Reward', x + 12, bottom + 7, 120, 18, 14, RED_INK, { wordWrap = false })
        if n.diff and TIER_WORD[n.diff] then
            content[#content + 1] = label(TIER_WORD[n.diff], x + width - 172, bottom + 7, 160, 18, 13, ink,
                { wordWrap = false, textAlignH = ui.ALIGNMENT.End, alpha = 0.75 })
        end
        local node = label(n.reward, x + 12, bottom + 28, rw, rh + 4, 16, ink)
        node.name = 'reward'
        content[#content + 1] = node
        if n.marks then
            local mc = look and col(look.marks) or ink
            for i = 1, n.marks do
                content[#content + 1] = image('ojb/dagger.dds', x + width - 12 - (n.marks - i + 1) * 15, bottom + 26,
                    15, 30, { color = mc })
            end
        end
        bottom = bottom - 8
    end

    local sid = kind .. ':' .. tostring(n.id)
    if n.req then
        local bh = heightOf(M.clip(n.body, width, 15, 4), width, 15)
        content[#content + 1] = label(M.clip(n.body, width, 15, 4), x, y, width, bh + 4, 15, ink)
        y = orderTable(content, n, ink, x, y + bh + 12, width)
        if n.status then
            local sh = heightOf(n.status, width, 14)
            content[#content + 1] = label(n.status, x, y + 4, width, sh + 4, 14, n.ready and GREEN_INK or RED_INK)
        end
        scroll.max, scroll.id = 0, sid
    else
        local shop = n.shop
        local stock = shop and not shop.closed and #(shop.stock or {}) > 0 and ('- ' .. table.concat(shop.stock, '\n- '))
        local where = shop and string.format('%s, %s. %s.', shop.keeper or '', (shop.trade or ''):lower(),
            (shop.where or ''):gsub('^%l', string.upper))
        scrolling(content, sid, x, y, width, math.max(40, bottom - 8 - y), function(textW)
            return M.column({
                { text = n.body, size = 16, color = ink },
                { text = shop and shop.closed and (shop.name .. ' is shut. Nobody answers the door.'), size = 15, color = RED_INK },
                { text = stock and 'In stock', size = 15, color = RED_INK },
                { text = stock, size = 15, color = ink },
                { text = (n.where or where) and (shop and 'Where' or 'The way'), size = 15, color = RED_INK },
                { text = n.where or where, size = 15, color = ink },
                { text = n.here, size = 15, color = RED_INK },
                { text = n.warn, size = 15, color = RED_INK },
            }, textW, 7)
        end)
    end
    if look and look.ribbon then content[#content + 1] = image('ojb/ribbon.dds', x0 + w - 80, y0, 80, 80) end
    pins(content, info.s, info.rnd, x0, y0, w)

    local list, full = {}, false
    if kind == 'notice' and view.mode == 'board' then
        if n.req then
            list[#list + 1] = { 'handover', 'Hand over', n.ready and function() handlers.handOver(n.id) end or nil }
            list[#list + 1] = { 'close', 'Leave it', close }
        elseif n.flavour then
            list[#list + 1] = { 'close', 'Close', close }
        else
            if (view.data.held or 0) < (view.data.max or 3) then
                list[#list + 1] = { 'take', 'Take the contract', function()
                    ambient.playSound('scroll')
                    handlers.take(n.id)
                end }
            else
                full = true
            end
            list[#list + 1] = { 'close', 'Leave it', close }
        end
    elseif kind == 'contract' then
        if n.handIn and view.mode == 'board' then
            list[#list + 1] = { 'handin', 'Hand in', function() handlers.handIn(n.id) end }
        end
        list[#list + 1] = { 'abandon', 'Abandon', function()
            ambient.playSound('scroll')
            handlers.abandon(n.id)
        end }
        list[#list + 1] = { 'close', 'Close', close }
    else
        list[#list + 1] = { 'close', 'Close', close }
    end
    local left = buttonRow(content, list, x0, by, w)
    if full then
        content[#content + 1] = label('You hold all the contracts you can.', x0, by + 8, left - x0, 20, 14, GOLD,
            { wordWrap = false })
    end
end

local function contractLine(content, c, x, y, w)
    local selected = view.selected and view.selected.kind == 'contract' and view.selected.id == c.id
    local word = progressWord(c)
    local ww = math.min(w * 0.45, 16 + #word * 7.5)
    local node = label(M.clip(c.title, w - ww - 6, 15, 1), x, y, w - ww - 6, 22, 15, selected and HOVER or GOLD,
        { wordWrap = false })
    node.name = 'contract:' .. tostring(c.id)
    node.events = { mouseClick = click(function() select('contract', c.id) end) }
    content[#content + 1] = node
    content[#content + 1] = label(word, x + w - ww, y + 1, ww, 20, 14, c.state == 'done' and HOVER or GOLD_DIM,
        { textAlignH = ui.ALIGNMENT.End, wordWrap = false })
end

-- Wood, a dark edge and the title on its plate. The wood clears a paper's hover.
local function chrome(content, title)
    content[#content + 1] = clearsHover(image('tx_wood_greyplanks.dds', 0, 0, W, H,
        { tileH = true, tileV = true, color = util.color.rgb(0.62, 0.56, 0.50) }))
    frame(content, 0, 0, W, H, 4, DARK, 1)
    frame(content, 8, 8, W - 16, H - 16, 1, GOLD_DIM, 0.8)
    local tw = math.min(W - 420, 80 + #(title or '') * 13)
    local tx = (W - tw) / 2
    content[#content + 1] = rect(tx, 12, tw, 44, DARK, 0.92)
    frame(content, tx, 12, tw, 44, 2, GOLD, 0.9)
    content[#content + 1] = label(title or '', tx, 19, tw, 32, 26, GOLD,
        { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
end

-- The bottom-left corner of the screen is where other mods put HUD widgets (moon phases, buffs), so
-- the strip starts STRIP_INSET in and its label sits at the right end.
local STRIP_INSET = 240
local function contractStrip(content, d)
    local y = STRIP_Y
    local x0, w = AX + STRIP_INSET, AW - STRIP_INSET
    content[#content + 1] = clearsHover(rect(x0, y, w, 50, DARK, 0.75))
    frame(content, x0, y, w, 50, 1, GOLD_DIM, 0.9)
    local lw = 190
    content[#content + 1] = label(string.format('Your contracts (%d of %d)', d.held or 0, d.max or 3),
        x0 + w - lw - 12, y + 15, lw, 22, 15, GOLD, { wordWrap = false, textAlignH = ui.ALIGNMENT.End })
    local list = d.contracts or {}
    local slots = math.max(d.max or 3, #list)
    local sx = x0 + 10
    local sw = (w - lw - 34 - (slots - 1) * 8) / slots
    for i = 1, slots do
        local x = sx + (i - 1) * (sw + 8)
        content[#content + 1] = rect(x, y + 9, sw, 32, BLACK, 0.45)
        frame(content, x, y + 9, sw, 32, 1, GOLD_DIM, 0.6)
        if list[i] then
            contractLine(content, list[i], x + 8, y + 14, sw - 16)
        else
            content[#content + 1] = label('free', x + 8, y + 15, sw - 16, 20, 14, GOLD_DIM, { wordWrap = false })
        end
    end
end

local function boardLayout()
    local d = view.data
    local content = {}
    chrome(content, d.title)
    -- Board news and window messages: under the title, never on a notice.
    local status = {}
    if d.change then status[#status + 1] = d.change end
    if d.busy then status[#status + 1] = 'You have done a lot of work lately, so fewer new jobs are posted for now.' end
    if d.note then status[#status + 1] = d.note end
    if #status > 0 then
        content[#content + 1] = label(table.concat(status, '   '), 40, 60, W - 80, 20, 15, GOLD,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
    end

    local notices = d.notices or {}
    local counts = { all = #notices, work = 0, goods = 0, news = 0 }
    for _, n in ipairs(notices) do
        local g = PA.groupOf(n)
        counts[g] = counts[g] + 1
    end
    view.filter = view.filter or 'all'
    local tabX = AX
    for _, f in ipairs(FILTERS) do
        local text = f[2] .. ' ' .. counts[f[1]]
        local tw = 30 + #text * 8.5
        local on = view.filter == f[1]
        content[#content + 1] = rect(tabX, 84, tw, 26, DARK, on and 0.92 or 0.6)
        frame(content, tabX, 84, tw, 26, 1, on and GOLD or GOLD_DIM, on and 1 or 0.7)
        local node = label(text, tabX, 87, tw, 22, 15, on and GOLD or GOLD_DIM,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
        node.name = 'tab:' .. f[1]
        node.events = { mouseClick = click(function()
            view.filter, view.page = f[1], 1
            ambient.playSound('book page2')
            M.refresh()
        end) }
        content[#content + 1] = node
        tabX = tabX + tw + 8
    end

    local list = {}
    for _, n in ipairs(notices) do
        local g = PA.groupOf(n)
        if view.filter == 'all' or view.filter == g then
            local size = PA.SIZES[PA.sizeOf(n)]
            list[#list + 1] = { id = n.id, w = size[1], h = size[2], group = g, n = n }
        end
    end
    content[#content + 1] = clearsHover(rect(AX - 6, AY - 8, AW + 12, AH + 14, BLACK, 0.18))
    if #list == 0 then
        content[#content + 1] = label(#notices == 0 and 'Nothing is pinned here today.'
            or 'Nothing of that kind is pinned here.', AX, AY + AH / 2 - 20, AW, 40, 18, GOLD,
            { textAlignH = ui.ALIGNMENT.Center })
    end
    local spots, pages = PA.place(list, AW, AH)
    view.page = math.min(view.page or 1, pages)
    local hovered
    for _, it in ipairs(list) do
        local at = spots[it.id]
        if at.page == view.page then
            it.x, it.y = AX + at.x, AY + at.y
            local sel = view.selected and view.selected.kind == 'notice' and view.selected.id == it.id
            if view.hover == it.id then hovered = it
            else content[#content + 1] = paperWidget(it.n, it.x, it.y, it.w, it.h, false, sel) end
        end
    end
    if pages > 1 then
        local turn = function(dp) return click(function()
            view.page = (view.page - 1 + dp) % pages + 1
            ambient.playSound('book page2')
            M.refresh()
        end) end
        local px = AX + AW - 180
        local prev = label('<', px, 86, 30, 22, 18, GOLD, { textAlignH = ui.ALIGNMENT.Center })
        prev.events = { mouseClick = turn(-1) }
        local nxt = label('>', px + 150, 86, 30, 22, 18, GOLD, { textAlignH = ui.ALIGNMENT.Center })
        nxt.events = { mouseClick = turn(1) }
        content[#content + 1] = prev
        content[#content + 1] = nxt
        content[#content + 1] = label(string.format('Page %d of %d', view.page, pages), px + 30, 88, 120, 20, 14, GOLD,
            { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
    end
    contractStrip(content, d)
    reading(content, DX, DY, DW, DH)
    -- The paper under the mouse is drawn last, lifted, with its line under it.
    if hovered then
        local sel = view.selected and view.selected.kind == 'notice' and view.selected.id == hovered.id
        content[#content + 1] = paperWidget(hovered.n, hovered.x, hovered.y, hovered.w, hovered.h, true, sel)
        tooltip(content, hovered.n, hovered.x, hovered.y, hovered.w, hovered.h)
    end
    return root(content)
end

-- The contract log: the contracts held, each on the paper it was taken from with its progress,
-- read on the same page as the board.
local function logLayout()
    local d = view.data
    local content = {}
    chrome(content, string.format('Your contracts (%d of %d)', d.held or 0, d.max or 3))
    content[#content + 1] = clearsHover(rect(AX - 6, AY - 8, AW + 12, STRIP_Y + 50 - AY + 8, BLACK, 0.18))
    local list = {}
    for _, c in ipairs(d.contracts or {}) do
        local size = PA.SIZES[PA.sizeOf(c)]
        list[#list + 1] = { id = c.id, w = size[1], h = size[2], group = 'work', n = c }
    end
    if #list == 0 then
        content[#content + 1] = label('You hold no contracts. Notice boards hang in guild halls, temples, taverns '
            .. 'and town squares.', AX + 40, AY + AH / 2 - 30, AW - 80, 60, 18, GOLD, { textAlignH = ui.ALIGNMENT.Center })
    end
    local spots = PA.place(list, AW, AH)
    local hovered
    for _, it in ipairs(list) do
        local at = spots[it.id]
        if at.page == 1 then
            it.x, it.y = AX + at.x, AY + at.y
            local sel = view.selected and view.selected.kind == 'contract' and view.selected.id == it.id
            if view.hover == it.id then hovered = it
            else content[#content + 1] = paperWidget(it.n, it.x, it.y, it.w, it.h, false, sel, 'contract') end
        end
    end
    local free = math.max(0, (d.max or 3) - (d.held or 0))
    content[#content + 1] = label(free == 0 and 'No room for another contract until one is done or dropped.'
        or string.format('Room for %d more.', free), AX, STRIP_Y + 14, AW, 22, 16, GOLD_DIM,
        { textAlignH = ui.ALIGNMENT.Center, wordWrap = false })
    reading(content, DX, DY, DW, DH)
    if hovered then
        local sel = view.selected and view.selected.kind == 'contract' and view.selected.id == hovered.id
        content[#content + 1] = paperWidget(hovered.n, hovered.x, hovered.y, hovered.w, hovered.h, true, sel, 'contract')
        tooltip(content, hovered.n, hovered.x, hovered.y, hovered.w, hovered.h, 'contract')
    end
    return root(content)
end

-- Someone asks the player to decide: a small paper over the dimmed screen, the words, and one
-- button per answer. Closing it without one answers with the last (player.lua).
-- data: { title, text, options = { { id, label } }, style (a paper.lua style, optional) }.
local CHOICE_W = 560
local function choiceLayout()
    local d = view.data
    local width = CHOICE_W - 70
    local titleH = heightOf(d.title or '', width, 24)
    local textH = heightOf(d.text or '', width, 17)
    local options = d.options or {}
    local ph = 40 + 22 + titleH + 14 + textH + 26 + #options * (BTN_H + 10) + 18
    local x0, y0 = (W - CHOICE_W) / 2, (H - ph) / 2
    local content = { rect(0, 0, W, H, BLACK, 0.45) }
    local paper = { id = 7, style = d.style or 'scrap', title = '' }
    local info = paperBack(content, paper, x0, y0, CHOICE_W, ph, { shadow = { x0 + 8, y0 + 9, 0.55 } })
    local x, y = x0 + 35, y0 + info.top + 14
    content[#content + 1] = label('A choice', x, y, width, 18, 13, RED_INK, { wordWrap = false, alpha = 0.85 })
    y = y + 22
    content[#content + 1] = label(d.title or '', x, y, width, titleH + 4, 24, info.ink,
        { textAlignH = ui.ALIGNMENT.Center })
    y = y + titleH + 6
    content[#content + 1] = rect(x, y, width, 1, info.ink, 0.35)
    y = y + 8
    content[#content + 1] = label(d.text or '', x, y, width, textH + 4, 17, info.ink)
    y = y + textH + 26
    for _, o in ipairs(options) do
        button(content, 'choice:' .. o.id, M.clip(o.label, width - 20, 17, 1), x, y, width,
            function() handlers.choose(o.id) end)
        y = y + BTN_H + 10
    end
    pins(content, info.s, info.rnd, x0, y0, CHOICE_W)
    return root(content)
end

-- News while the player is busy (a twist in a dungeon, a contract running out): a paper slip at
-- the top of the screen for SLIP_SECONDS of game time. It takes no input and pauses nothing; the
-- oldest goes when more than SLIP_MAX are up. The layer sits above Windows so a slip shows over
-- the board as well.
local SLIP_SECONDS, SLIP_MAX, SLIP_W, SLIP_LAYER = 8, 3, 470, 'OJB_Slips'
local slips, slipElement, slipSerial = {}, nil, 0

local function drawSlips()
    if #slips == 0 then
        if slipElement then slipElement:destroy() end
        slipElement = nil
        return
    end
    scale = fitScale()
    local parts, y = {}, 0
    for _, s in ipairs(slips) do
        local th = heightOf(s.text, SLIP_W - 64, 16)
        local h = th + 38
        paperBack(parts, { id = s.id, style = 'scrap', title = '' }, 0, y, SLIP_W, h, { shadow = { 5, y + 6, 0.5 } })
        parts[#parts + 1] = label(s.text, 32, y + 18, SLIP_W - 64, th + 4, 16, INK)
        y = y + h + 10
    end
    local layout = {
        layer = SLIP_LAYER,
        name = 'ojbSlips',
        type = ui.TYPE.Widget,
        props = { relativePosition = util.vector2(0.5, 0.07), anchor = util.vector2(0.5, 0), size = sv(SLIP_W + 10, y) },
        content = ui.content(parts),
    }
    if slipElement then
        slipElement.layout = layout
        slipElement:update()
    else
        slipElement = ui.create(layout)
    end
end

function M.slip(text)
    if not ui.layers.indexOf(SLIP_LAYER) then ui.layers.insertAfter('Windows', SLIP_LAYER, { interactive = false }) end
    slipSerial = slipSerial + 1
    local s = { id = slipSerial, text = text }
    slips[#slips + 1] = s
    if #slips > SLIP_MAX then table.remove(slips, 1) end
    ambient.playSound('book page2')
    drawSlips()
    async:newUnsavableSimulationTimer(SLIP_SECONDS, function()
        for i, x in ipairs(slips) do
            if x == s then
                table.remove(slips, i)
                drawSlips()
                return
            end
        end
    end)
end

function M.refresh()
    if not view then return end
    scale = fitScale()
    local layout = view.mode == 'log' and logLayout() or view.mode == 'choice' and choiceLayout()
        or boardLayout()
    if element then
        element.layout = layout
        element:update()
    else
        element = ui.create(layout)
    end
end

function M.isOpen()
    return element ~= nil
end

-- data: board view from global.lua. Keeps the selection across updates when it still exists.
function M.show(mode, data, h)
    local opening = element == nil
    local keep = view and view.mode == mode and view.selected or nil
    local same = view and view.data and view.data.key == data.key
    view = { mode = mode, data = data, selected = keep, page = same and view.page or nil,
        filter = same and view.filter or nil }
    handlers = h
    if not findSelected() then
        local first = (data.notices and data.notices[1]) and { kind = 'notice', id = data.notices[1].id }
            or (data.contracts and data.contracts[1]) and { kind = 'contract', id = data.contracts[1].id } or nil
        view.selected = first
    end
    if opening then
        ambient.playSound('scroll')
        scale = fitScale()
        print(string.format('[Odd Jobs] board window %s (%s), design %dx%d at scale %.2f', M.VERSION, mode, W, H, scale))
    end
    if not toolkit then
        toolkit = M.toolkitCheck(I.UIToolkit)
        print('[Odd Jobs] notice scrolling: ' .. (toolkit.ok and 'mouse wheel, ' or 'arrows only, ') .. toolkit.why)
        if not toolkit.ok then
            ui.showMessage('Odd Jobs: long notices scroll with the mouse wheel with UIToolkit ' .. M.TOOLKIT_MIN
                .. ' or newer (' .. toolkit.why .. '). Until then, click ^ and v beside the text.')
        end
    end
    M.refresh()
end

function M.close(silent)
    if element then
        element:destroy()
        element = nil
        if not silent then ambient.playSound('book close') end
    end
    view = nil
end

-- Exposed for tests: the scale the window would use for a layer of this size.
function M.scaleFor(lw, lh)
    return scaleOf(lw, lh)
end

return M
