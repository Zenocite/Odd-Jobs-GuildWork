---@omw-context player
-- Loose recovery items: a resting spot on furniture (or open floor by a wall) for global.lua to put
-- a contract item on. global.lua sends the furniture worth trying, best first; each is tried with
-- rays down onto its top, a standing point on the navmesh beside it, and a sight line from eye
-- height. Runs as a coroutine resumed from onFrame (castRenderingRay is only allowed there),
-- pausing every C.RAYS_PER_FRAME rays. Once per loose contract, on first entry.

local core = require('openmw.core')
local nearby = require('openmw.nearby')
local self = require('openmw.self')
local util = require('openmw.util')

local C = require('scripts.ojb.config')

local v3 = util.vector3
local L = C.LOOSE
local SOLID = nearby.COLLISION_TYPE.World + nearby.COLLISION_TYPE.Door + nearby.COLLISION_TYPE.HeightMap
local WALK = nearby.NAVIGATOR_FLAGS.Walk + nearby.NAVIGATOR_FLAGS.OpenDoor + nearby.NAVIGATOR_FLAGS.UsePathgrid

local M = {}

-- { id, cands, entrance, anchor, small, on, exterior, rays, frameRays, frames, ms, maxMs, tried, navMissing, co }
local job

local function budget()
    job.rays = job.rays + 1
    job.frameRays = job.frameRays + 1
    if job.frameRays > C.RAYS_PER_FRAME then coroutine.yield() end
end

local function ray(a, b, ignore)
    budget()
    return nearby.castRay(a, b, { collisionType = SOLID, ignore = ignore })
end

local function seen(a, b)
    budget()
    return nearby.castRenderingRay(a, b, { ignore = self })
end

local function vec(t) return v3(t.x, t.y, t.z) end

local function underWater(z)
    local cell = self.cell
    return cell and cell.hasWater and cell.waterLevel and z < cell.waterLevel + 10
end

local function standNear(p)
    local s = nearby.findNearestNavMeshPosition(p, {
        searchAreaHalfExtents = v3(L.STAND_REACH, L.STAND_REACH, 250), includeFlags = WALK })
    if not s then
        job.navMissing = job.navMissing + 1
        return nil
    end
    local flat = v3(s.x - p.x, s.y - p.y, 0):length()
    if flat > L.STAND_REACH then return nil end
    return s
end

-- Whether an eye at `stand` sees the point: nothing solid and nothing drawn in between.
local function visible(stand, point, on)
    local eye = stand + v3(0, 0, L.EYE)
    local target = point + v3(0, 0, 4)
    local total = (target - eye):length()
    local r = ray(eye, target, self)
    if r.hit and (r.hitPos - eye):length() < total - 12 and r.hitObject ~= on then return false end
    local s = seen(eye, target)
    if s.hit and (s.hitPos - eye):length() < total - 12 and s.hitObject ~= on then return false end
    return true
end

-- A flat top on `obj` at (x, y): the hit, or nil and why.
local function topAt(obj, x, y, floorZ)
    local from = v3(x, y, floorZ + L.MAX_SURFACE + 2)
    local r = ray(from, v3(x, y, floorZ - 5))
    if not r.hit then return nil, 'nothing under' end
    if r.hitObject ~= obj then return nil, 'something else on top' end
    if not r.hitNormal or r.hitNormal.z < L.FLAT then return nil, 'not flat' end
    local h = r.hitPos.z - floorZ
    if h < L.MIN_SURFACE then return nil, 'too low' end
    return r.hitPos
end

-- One piece of furniture: { obj, word, depth, light }. Returns a spot or nil and why.
local function tryFurniture(c)
    local obj = c.obj
    if not obj:isValid() then return nil, 'gone' end
    local box = obj:getBoundingBox()
    local stand = standNear(box.center)
    if not stand then return nil, 'no standing ground beside it' end
    if underWater(stand.z) then return nil, 'in water' end
    local hx, hy = box.halfSize.x, box.halfSize.y
    if hx < 10 or hy < 10 then return nil, 'too small to hold anything' end
    -- The centre first, then halfway to each side: the side nearest the stander is likeliest seen.
    local offs = { { 0, 0 }, { 0.45, 0 }, { -0.45, 0 }, { 0, 0.45 }, { 0, -0.45 } }
    local why = 'no flat top'
    for _, o in ipairs(offs) do
        local x, y = box.center.x + o[1] * hx, box.center.y + o[2] * hy
        local p, w = topAt(obj, x, y, stand.z)
        if p then
            local ok = true
            for _, e in ipairs({ { L.EDGE, 0 }, { -L.EDGE, 0 }, { 0, L.EDGE }, { 0, -L.EDGE } }) do
                local q = topAt(obj, p.x + e[1], p.y + e[2], stand.z)
                if not q or math.abs(q.z - p.z) > 2 then ok = false why = 'too near the edge' break end
            end
            if ok then
                local up = ray(p + v3(0, 0, 2), p + v3(0, 0, L.CLEAR_ABOVE))
                if up.hit then
                    why = 'no room above'
                elseif underWater(p.z) then
                    why = 'in water'
                elseif not visible(stand, p, obj) then
                    why = 'not seen from eye height'
                else
                    return { pos = p, on = obj, word = c.word, stand = stand, height = p.z - stand.z }
                end
            end
        else
            why = w or why
        end
    end
    return nil, why
end

-- Open floor by a wall near the anchor, for items too big to lose. Returns a spot or nil.
local DIRS = {}
for i = 0, 7 do DIRS[#DIRS + 1] = v3(math.cos(i * math.pi / 4), math.sin(i * math.pi / 4), 0) end

local function tryFloor()
    local entrance = vec(job.entrance)
    local anchor = vec(job.anchor)
    for _ = 1, L.FLOOR_TRIES do
        if job.rays >= L.MAX_RAYS then
            job.tried[#job.tried + 1] = string.format('floor: gave up after %d rays', job.rays)
            return nil
        end
        local p = nearby.findRandomPointAroundCircle(anchor, L.FLOOR_RADIUS, { includeFlags = WALK })
        if not p then
            job.navMissing = job.navMissing + 1
        elseif (p - entrance):length() >= job.minDepth and not underWater(p.z) then
            local knee = p + v3(0, 0, 20)
            local walls, nearest, nearI = 0, nil, nil
            local hits = {}
            for i, d in ipairs(DIRS) do
                local r = ray(knee, knee + d * L.WALL_NEAR)
                hits[i] = r.hit
                if r.hit then
                    walls = walls + 1
                    local dist = (r.hitPos - knee):length()
                    if not nearest or dist < nearest then nearest, nearI = dist, i end
                end
            end
            -- A wall on one side and open space opposite: by the wall, not across a passage.
            local nearDir = nearI and DIRS[nearI]
            local roomy = nearI and not hits[(nearI + 3) % 8 + 1]
                and not ray(knee, knee - nearDir * L.OPEN_ACROSS).hit
            if roomy and walls <= 5 then
                local spot = knee + nearDir * math.max(0, nearest - L.WALL_GAP)
                local g = ray(spot, spot - v3(0, 0, 80))
                if g.hit and g.hitNormal and g.hitNormal.z >= L.FLOOR_FLAT then
                    local stand = spot - nearDir * 120
                    local s = standNear(v3(stand.x, stand.y, g.hitPos.z))
                    if s and visible(s, g.hitPos, g.hitObject) then
                        return { pos = g.hitPos, on = g.hitObject, word = walls >= 3 and 'floor in a corner'
                            or 'floor by a wall', stand = s, height = 0 }
                    end
                end
            end
        end
    end
    return nil
end

-- Rays are checked between candidates, so a search ends at most one candidate (about 40 rays on
-- furniture, 13 on the floor) past its cap. Furniture stops at FURNITURE_RAYS, leaving the floor
-- room before MAX_RAYS.
local function search()
    for i, c in ipairs(job.cands) do
        if job.rays >= L.FURNITURE_RAYS then
            job.tried[#job.tried + 1] = string.format('furniture: gave up after %d rays, %d of %d tried', job.rays,
                i - 1, #job.cands)
            break
        end
        local spot, why = tryFurniture(c)
        if spot then
            spot.depth = c.depth
            spot.light = c.light
            return spot
        end
        job.tried[#job.tried + 1] = (c.obj.recordId or '?') .. ': ' .. tostring(why)
    end
    if not job.small then
        local spot = tryFloor()
        if spot then
            spot.depth = (spot.pos - vec(job.entrance)):length()
            return spot
        end
        job.tried[#job.tried + 1] = 'floor: no open floor by a wall that is seen'
    end
    return nil
end

local function answer(spot, err)
    local out = {
        id = job.id, rays = job.rays, frames = job.frames, ms = job.ms, maxMs = job.maxMs, tried = job.tried,
        error = err,
    }
    if spot then
        out.ok = true
        out.pos = { x = spot.pos.x, y = spot.pos.y, z = spot.pos.z }
        out.on, out.word, out.depth, out.height, out.light = spot.on, spot.word, spot.depth, spot.height, spot.light
    else
        -- Nothing found because the navmesh wasn't built yet is worth another try later.
        out.retry = job.navMissing > 0 and #job.tried <= job.navMissing + 1
    end
    core.sendGlobalEvent('OJB_LooseSpot', out)
    job = nil
end

function M.start(e)
    job = {
        id = e.id, cands = e.cands or {}, entrance = e.entrance, anchor = e.anchor, small = e.small,
        minDepth = e.minDepth or L.MIN_DEPTH, cell = e.cell, exterior = e.exterior,
        rays = 0, frameRays = 0, frames = 0, ms = 0, maxMs = 0, tried = {}, navMissing = 0,
    }
    job.co = coroutine.create(search)
end

function M.active() return job ~= nil end

function M.step()
    -- Rays only see the loaded cells; global.lua asks again on the next visit if the player left.
    -- An exterior search (a lost ledger in town) holds while the player stays outdoors.
    local here = self.cell
    if not here or (job.exterior and not here.isExterior) or (not job.exterior and here.name ~= job.cell) then
        job = nil
        return
    end
    job.frameRays = 0
    local t0 = core.getRealTime()
    -- resume hands back the search's error instead of raising it: answered as no spot, with the
    -- error, so the item goes in a container rather than the search running again.
    local alive, spot = coroutine.resume(job.co)
    local ms = (core.getRealTime() - t0) * 1000
    job.frames, job.ms = job.frames + 1, job.ms + ms
    if ms > job.maxMs then job.maxMs = ms end
    if not alive then
        print(C.LOG_TAG .. 'loose spot search failed: ' .. tostring(spot))
        answer(nil, tostring(spot))
        return
    end
    if coroutine.status(job.co) == 'dead' then answer(spot) end
end

return M
