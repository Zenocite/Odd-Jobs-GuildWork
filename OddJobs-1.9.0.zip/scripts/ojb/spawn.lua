---@omw-context local
-- Odd Jobs: the tracking script on every actor a job made or changed (spawner.lua attaches it).
-- Equipping and AI only work on self, so global.lua asks for them here with OJB_Do. Reports its
-- death and, each time its cell loads, its job and generation, so a spawn whose job is gone is
-- removed by the global script (remove() is global only).

local core = require('openmw.core')
local self = require('openmw.self')
local types = require('openmw.types')
local util = require('openmw.util')
local I = require('openmw.interfaces')

local Actor = types.Actor
local SLOT = Actor.EQUIPMENT_SLOT
local ARMOR_SLOT = {
    [types.Armor.TYPE.Helmet] = SLOT.Helmet, [types.Armor.TYPE.Cuirass] = SLOT.Cuirass,
    [types.Armor.TYPE.LPauldron] = SLOT.LeftPauldron, [types.Armor.TYPE.RPauldron] = SLOT.RightPauldron,
    [types.Armor.TYPE.Greaves] = SLOT.Greaves, [types.Armor.TYPE.Boots] = SLOT.Boots,
    [types.Armor.TYPE.LGauntlet] = SLOT.LeftGauntlet, [types.Armor.TYPE.RGauntlet] = SLOT.RightGauntlet,
    [types.Armor.TYPE.Shield] = SLOT.CarriedLeft, [types.Armor.TYPE.LBracer] = SLOT.LeftGauntlet,
    [types.Armor.TYPE.RBracer] = SLOT.RightGauntlet,
}

-- owner: the job's id; gen: spawn rules generation; ours: made by Odd Jobs (else an original actor
-- the job only changed); surrender: health share at which the leader gives up.
local state = { owner = nil, gen = 0, ours = true, surrender = nil, gaveUp = false, reported = false,
    strip = false, tier = nil, stripped = false }

local function report(name, extra)
    local e = { actor = self.object, owner = state.owner }
    for k, v in pairs(extra or {}) do e[k] = v end
    core.sendGlobalEvent(name, e)
end

local function slotFor(item)
    if item.type == types.Weapon then
        local t = types.Weapon.record(item).type
        if t == types.Weapon.TYPE.Arrow or t == types.Weapon.TYPE.Bolt then return SLOT.Ammunition end
        return SLOT.CarriedRight
    elseif item.type == types.Armor then
        return ARMOR_SLOT[types.Armor.record(item).type]
    end
    return nil
end

local function equip(ids)
    local inv = Actor.inventory(self)
    local eq = Actor.getEquipment(self)
    for _, id in ipairs(ids) do
        local item = inv:find(id)
        local slot = item and slotFor(item)
        if slot then eq[slot] = item end
    end
    Actor.setEquipment(self, eq)
end

local function giveUp()
    state.gaveUp = true
    Actor.stats.ai.fight(self).base = 0
    I.AI.removePackages('Combat')
    report('OJB_Surrender')
end

-- The leader who makes an offer: a blow that would take them under the line leaves them on it.
-- Runs before armour and the built-in damage handler (handlers run newest first).
local function onHit(attack)
    if not state.surrender or state.gaveUp or not attack.successful then return end
    local dmg = attack.damage and attack.damage.health
    if not dmg or dmg <= 0 then return end
    local h = Actor.stats.dynamic.health(self)
    local line = h.base * state.surrender
    if h.current - dmg > line then return end
    attack.damage.health = math.max(0, h.current - line)
    giveUp()
end
if I.Combat then I.Combat.addOnHitHandler(onHit) end

local function startAi(p)
    I.AI.removePackages(p.type)
    I.AI.startPackage(p)
end

-- What the job asks of this actor. Each field is optional.
local function act(d)
    if d.health then
        local h = Actor.stats.dynamic.health(self)
        h.base = h.base * d.health
        h.current = h.base
    end
    -- A low tier template can still carry a very high weapon skill. Cut it down to the tier's line.
    -- Setters on a stat proxy only work from this actor's own script.
    if d.skill and d.skillAt then
        local fn = Actor.stats.skills[d.skill]
        local stat = fn and fn(self)
        if stat and stat.base > d.skillAt then stat.base = d.skillAt end
    end
    if d.spells then
        for _, id in ipairs(d.spells) do Actor.spells(self):add(id) end
    end
    if d.equip then equip(d.equip) end
    if d.fight then Actor.stats.ai.fight(self).base = d.fight end
    if d.surrender then state.surrender, state.gaveUp = d.surrender, false end
    if d.stopSurrender then state.surrender = nil end
    if d.kill then Actor.stats.dynamic.health(self).current = 0 end
    if d.attack and d.attack:isValid() then startAi({ type = 'Combat', target = d.attack }) end
    if d.follow and d.follow:isValid() then startAi({ type = 'Follow', target = d.follow }) end
    if d.travel then startAi({ type = 'Travel', destPosition = util.vector3(d.travel.x, d.travel.y, d.travel.z) }) end
    if d.wander then startAi({ type = 'Wander', distance = d.wander }) end
    if d.calm then I.AI.removePackages('Combat') end
end

return {
    engineHandlers = {
        onInit = function(data)
            data = data or {}
            state.owner, state.gen, state.ours = data.owner, data.gen or 0, data.ours ~= false
            state.strip, state.tier = data.strip == true, data.tier
            if data.act then act(data.act) end
        end,
        onSave = function() return state end,
        onLoad = function(data)
            if data then state = data end
        end,
        onActive = function()
            -- First time this actor's cell is active, the template's items are in the inventory.
            -- Ask global to take off ammunition, enchantments and gear above the tier. remove()
            -- is global only, so it cannot be done here.
            local strip = state.strip and not state.stripped
            if strip then state.stripped = true end
            report('OJB_SpawnActive', { gen = state.gen, ours = state.ours, strip = strip or nil, tier = state.tier })
        end,
    },
    eventHandlers = {
        OJB_Do = act,
        Died = function()
            if state.reported then return end
            state.reported = true
            report('OJB_SpawnDied')
        end,
    },
}
