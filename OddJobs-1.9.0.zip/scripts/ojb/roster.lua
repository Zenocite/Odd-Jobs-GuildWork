---@omw-context runtime
-- Pure: who a job puts in the world. Names from the game's own people, templates from the spawn
-- catalog (data/spawns.lua) by group and level, gear and spells for roles. Every id here was read
-- from the load order (tools/probe_records.py), none invented.

local SPAWNS = require('scripts.ojb.data.spawns')

local M = {}

-- Races whose people have family names in the catalog; others go by a first name alone.
function M.name(race, female, rnd)
    local r = SPAWNS.names[race or ''] or SPAWNS.names['dark elf']
    local firsts = female and r.f or r.m
    if not firsts or #firsts == 0 then firsts = r.m or r.f end
    local first = firsts[rnd(#firsts)]
    if r.last and #r.last > 0 then return first .. ' ' .. r.last[rnd(#r.last)] end
    return first
end

-- Groups drawn from another group's templates: grave robbers are bandits who dig, pirates are
-- smugglers who take the cargo by force.
M.SAME = { graverobber = 'bandit', pirate = 'smuggler' }
-- The dead a necromancer raises: never ghosts (a family's own) or draugr (Nordic barrow dead).
M.RAISED = { skeleton = true, bonewalker = true, bonelord = true }

-- People templates of a group (bandit, smuggler, necromancer, warlock, cultist, graverobber) from
-- the catalog, nearest to `level` first; `have(req)` says whether the master is loaded.
function M.people(group, level, have)
    local out = {}
    for _, e in ipairs(SPAWNS.people[M.SAME[group] or group] or {}) do
        if have(e[5]) then out[#out + 1] = { level = e[1], id = e[2], female = e[3], race = e[4] } end
    end
    table.sort(out, function(a, b)
        local da, db = math.abs(a.level - level), math.abs(b.level - level)
        if da ~= db then return da < db end
        return a.id < b.id
    end)
    return out
end

-- Creatures of a group between lo and hi levels; the strongest under lo when none fit. 'raised':
-- the undead families in RAISED. family: only that family.
function M.creatures(group, lo, hi, have, family)
    local out, best = {}, nil
    local raised = group == 'raised'
    for _, e in ipairs(SPAWNS.creatures[raised and 'undead' or group] or {}) do
        if have(e[5]) and (not raised or M.RAISED[e[4]]) and (not family or e[4] == family) then
            local c = { level = e[1], id = e[2], name = e[3], family = e[4] }
            if c.level >= lo and c.level <= hi then out[#out + 1] = c
            elseif c.level < lo and (not best or c.level > best.level) then best = c end
        end
    end
    if #out == 0 and best then out[1] = best end
    return out
end

function M.pick(list, rnd, near)
    if #list == 0 then return nil end
    return list[rnd(math.min(#list, near or #list))]
end

-- Gear by step: 1 plain, 2 good, 3 fine. Never above orcish and dwarven, so a kill doesn't drop a
-- fortune; the reward is the pay, training and the poster's items.
M.GEAR = {
    { weapon = { 'steel longsword', 'steel war axe', 'steel mace', 'steel spear' },
        armor = { 'steel_cuirass', 'steel_helm', 'steel_greaves', 'steel_boots' }, shield = 'steel_shield' },
    { weapon = { 'silver longsword', 'dwarven shortsword', 'dwarven war axe', 'dwarven mace' },
        armor = { 'bonemold_cuirass', 'bonemold_helm', 'bonemold_greaves', 'bonemold_pauldron_l', 'bonemold_pauldron_r' },
        shield = 'steel_shield' },
    { weapon = { 'dwarven claymore', 'dwarven war axe', 'dwarven halberd', 'dwarven mace' },
        armor = { 'orcish_cuirass', 'orcish_helm', 'orcish_greaves', 'orcish_boots', 'orcish_pauldron_left',
            'orcish_pauldron_right' }, shield = 'dwemer_shield' },
}

-- Roles in a dangerous band. Each has a tell the player can see: robe and staff, a bow, a summon.
M.ROLES = {
    healer = { weapon = 'silver staff', spells = { 'hearth heal', 'heal companion', "balyna's soothing balm" } },
    archer = { bows = { 'long bow', 'steel longbow', 'bonemold long bow' },
        arrows = { 'iron arrow', 'steel arrow', 'silver arrow' }, count = 40 },
    summoner = { spells = { [1] = 'summon scamp', [2] = 'summon skeletal minion', [3] = 'summon clanfear' },
        undead = { [1] = 'summon skeletal minion', [2] = 'summon least bonewalker', [3] = 'summon greater bonewalker' } },
    battlemage = { spells = { 'fireball', 'shockball', 'shield' } },
    guard = {},
}

-- Champion traits: what they do, and the line someone who saw them would say. Each has a counter
-- the player can buy or make.
M.TRAITS = {
    warded = { spells = { 'reflect_20' }, said = 'Spells came back off {him}.' },
    hardy = { spells = { 'resist magicka_25' }, said = 'A mage who tried says spells barely touch {him}.' },
    burning = { spells = { 'fire bite', 'fireball' }, said = 'The ones who got out had burns on their hands.' },
    frost = { spells = { 'frostbite', 'frost bolt' }, said = 'Frost clings to {him}, even in a warm room.' },
    storm = { spells = { 'spark', 'shockball' }, said = 'The air around {him} crackles.' },
    shielded = { spells = { 'shield' }, said = '{He} shrugs off a blade that would drop anyone else.' },
}
M.TRAIT_KEYS = { 'warded', 'hardy', 'burning', 'frost', 'storm', 'shielded' }

return M
