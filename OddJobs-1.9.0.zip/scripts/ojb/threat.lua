---@omw-context runtime
-- Pure: how hard a contract group is, and who fills it. Scores come from data/strength.lua
-- (measured from the load order by tools/build_strength.py). No engine calls.
-- Contract groups only. Champion bands, the open world and twists still use danger.band
-- until they move onto this picker.

local C = require('scripts.ojb.config')
local TI = require('scripts.ojb.tier')
local ROSTER = require('scripts.ojb.roster')
local ST = require('scripts.ojb.data.strength')
local GEAR = require('scripts.ojb.gear')

local M = {}
local TH = C.THREAT

-- Races a pirate or smuggler crew may also take from the bandit catalog. Gear, not the record, says
-- they are sailors. Quest tribes are not in that catalog as a faction filter; these four are the
-- ones that read as a crew.
M.WIDE = { ['dark elf'] = true, nord = true, redguard = true, imperial = true }

function M.scale(s)
    s = tonumber(s) or 1
    if s < 0.5 then return 0.5 end
    if s > 1.5 then return 1.5 end
    return s
end

function M.npcCaps(tier, scale)
    local cap = TH.CAPS[tier] or TH.CAPS.normal
    scale = M.scale(scale)
    local lo = math.max(1, math.floor(cap.npc[1] * scale + 0.5))
    local hi = math.max(lo, math.floor(cap.npc[2] * scale + 0.5))
    return lo, hi
end

function M.creatureCap(tier, scale)
    local cap = TH.CAPS[tier] or TH.CAPS.normal
    return math.max(1, math.floor(cap.creature * M.scale(scale) + 0.5))
end

-- nil: this body is over the tier's health line and must not be picked.
-- The skill used in the score is already clamped to the tier.
-- gear, when the contract has already dressed this person: { wc, ar } from those pieces.
-- The template's own weapon and suit are not used then, because the spawner takes them off.
function M.score(id, level, tier, creature, gear)
    local capH = TH.HEALTH[tier] or TH.HEALTH.normal
    local capS = TH.SKILL[tier] or TH.SKILL.normal
    if creature then
        local st = ST.creature[id:lower()]
        local h = st and st.h or (20 + level * 5)
        if h > capH then return nil end
        return (h / 8 + level * 0.3) * (TH.WEIGHT or 1)
    end
    local st = ST.npc[id:lower()]
    local h = st and st.h or (30 + level * 5)
    if h > capH then return nil end
    local sk = math.min(st and st.sk or (20 + level), capS)
    local wc = gear and gear.wc or (st and st.wc) or 4
    local ar = gear and gear.ar or (st and st.ar) or 0
    local body = h / 8 + level * 0.4 + wc * sk / 40 + ar / 8 + ((st and st.sp) or 0)
    return body * TH.NPC * (TH.WEIGHT or 1)
end

-- Another head of the same race and sex, read from a real NPC record. The contract leader's
-- copied record is given this once, so a playtest can see whether OpenMW 0.51 honours the
-- head field. Nil when this template has no such neighbour.
function M.otherHead(id)
    local st = ST.npc[id:lower()]
    if not st or not st.head or st.head == '' then return nil end
    local best
    for oid, row in pairs(ST.npc) do
        if oid ~= id:lower() and row.race == st.race and row.f == st.f and row.head and row.head ~= ''
            and row.head ~= st.head then
            if not best or oid < best then best = oid end
        end
    end
    return best and ST.npc[best].head or nil
end

function M.clampOf(id, tier)
    local st = ST.npc[id:lower()]
    local cap = TH.SKILL[tier] or TH.SKILL.normal
    if st and st.skn and st.sk > cap then return st.skn, cap end
end

local function peopleOf(group, level, have, widen)
    local list = ROSTER.people(group, level, have)
    if widen and (group == 'smuggler' or group == 'pirate') then
        local extra = {}
        for _, t in ipairs(ROSTER.people('bandit', level, have)) do
            if M.WIDE[t.race] then extra[#extra + 1] = t end
        end
        for _, t in ipairs(extra) do list[#list + 1] = t end
        table.sort(list, function(a, b)
            local da, db = math.abs(a.level - level), math.abs(b.level - level)
            if da ~= db then return da < db end
            return a.id < b.id
        end)
    end
    return list
end

-- o: tier, theme, scale, rnd, have, level, recent (id list), widen,
--    makeLeader(group, level, traits, step, chosen), kit(role, step, undead).
-- Returns a band, or nil when the theme has nobody the budget can hold.
function M.contract(o)
    local tier, th, rnd = o.tier, o.theme, o.rnd
    local scale = M.scale(o.scale)
    local band = TH.BUDGET[tier] or TH.BUDGET.normal
    local budget = (band[1] + (band[2] - band[1]) * rnd()) * scale
    local level = o.level
    local lim = TI.band(tier)
    local step = tier == 'elite' and (level >= 28 and 3 or 2) or tier == 'dangerous' and (level >= 18 and 2 or 1) or 1
    local recent = {}
    for _, id in ipairs(o.recent or {}) do recent[tostring(id):lower()] = true end
    local used = {}
    local spent = 0
    local b = { tier = tier, group = th.people, beasts = th.beasts, members = {}, state = 'wait',
        level = level, budget = budget, threat = 0 }
    local npcLo, npcHi = 0, 0
    if th.people then npcLo, npcHi = M.npcCaps(tier, scale) end

    local function mark(id) used[id:lower()] = true end
    local function npcN()
        return (b.champion and 1 or 0) + (b.lieutenant and 1 or 0) + (function()
            local n = 0
            for _, m in ipairs(b.members) do if not m.creature then n = n + 1 end end
            return n
        end)()
    end

    local function choose(group, room, cheap)
        local near = {}
        for _, t in ipairs(peopleOf(group, level, o.have, o.widen)) do
            if not used[t.id:lower()] then
                local s = M.score(t.id, t.level, tier, false)
                if s and s <= room then
                    near[#near + 1] = { t = t, s = s, fresh = not recent[t.id:lower()] }
                    -- A widened pirate or smuggler list has to look past the first handful of
                    -- sailors, or the bandits of a fitting race never get a turn.
                    if #near >= (o.widen and 24 or 12) then break end
                end
            end
        end
        local pool = {}
        for _, e in ipairs(near) do if e.fresh then pool[#pool + 1] = e end end
        if #pool == 0 then pool = near end
        if #pool == 0 then return nil end
        table.sort(pool, function(a, c)
            if a.s ~= c.s then
                if cheap then return a.s < c.s end
                return a.s > c.s
            end
            return a.t.id < c.t.id
        end)
        local take = cheap and pool[1] or pool[rnd(math.min(3, #pool))]
        return take
    end

    local function addPerson(group, room, cheap, asLeader, traits)
        local pick = choose(group, room, cheap)
        if not pick then return false end
        mark(pick.t.id)
        spent = spent + pick.s
        local skill, at = M.clampOf(pick.t.id, tier)
        if asLeader then
            local who = o.makeLeader(group, level, traits or 0, step, pick.t)
            if not who then return false end
            who.skillName, who.skillAt, who.threat, who.level = skill, at, pick.s, pick.t.level
            if asLeader == 'second' then b.lieutenant = who else b.champion = who end
        else
            b.members[#b.members + 1] = { id = pick.t.id, skillName = skill, skillAt = at, threat = pick.s,
                level = pick.t.level }
        end
        return true
    end

    local function cheapSum(group, n)
        local costs = {}
        for _, t in ipairs(peopleOf(group, level, o.have, o.widen)) do
            if not used[t.id:lower()] then
                local s = M.score(t.id, t.level, tier, false)
                if s then costs[#costs + 1] = s end
            end
        end
        table.sort(costs)
        local sum = 0
        for i = 1, math.min(n, #costs) do sum = sum + costs[i] end
        return sum
    end

    -- A tomb notice promises raised dead, so their cost is set aside before anyone is hired.
    -- The master is the strongest bonelord under the health line; one more body comes with him.
    local reserve = 0
    if th.beasts == 'raised' and (tier == 'dangerous' or tier == 'elite') then
        local lordCost, lordId
        for _, lord in ipairs(ROSTER.creatures('raised', 1, lim[2], o.have, 'bonelord')) do
            local s = M.score(lord.id, lord.level, tier, true)
            if s and (not lordCost or s > lordCost) then lordCost, lordId = s, lord.id:lower() end
        end
        local other
        for _, cr in ipairs(ROSTER.creatures('raised', lim[1], lim[2], o.have)) do
            local s = M.score(cr.id, cr.level, tier, true)
            if s and cr.id:lower() ~= lordId and (not other or s < other) then other = s end
        end
        reserve = (lordCost or 0) + (other or 0)
    end

    if th.people and tier ~= 'easy' then
        local traits = (tier == 'dangerous' or tier == 'elite') and (C.DANGER.TRAITS[tier] or 0) or 0
        -- Leave enough for the cheapest way to reach the tier's minimum, then let the leader
        -- be the strongest person who still fits in what is left.
        local leaderRoom = budget - reserve - cheapSum(th.people, math.max(0, npcLo - 1))
        if leaderRoom < 1 then leaderRoom = (budget - reserve) / math.max(1, npcLo) end
        if not addPerson(th.people, leaderRoom, false, 'leader', traits) then
            if not addPerson(th.people, math.max(1, budget - reserve), true, 'leader', traits) then return nil end
        end
        if tier == 'elite' and npcN() < npcHi then
            local rest = math.max(0, npcLo - npcN() - 1)
            local room = budget - spent - reserve - cheapSum(th.people, rest)
            if room < 1 then room = (budget - spent - reserve) / math.max(1, npcLo - npcN()) end
            addPerson(th.people, room, true, 'second', 1)
        end
    end

    local guard = 0
    while th.people and npcN() < npcHi and guard < 16 do
        guard = guard + 1
        local have = npcN()
        local cheap = have < npcLo
        local room = budget - spent - reserve
        if room <= 0 then break end
        local share = cheap and room / math.max(1, npcLo - have) or room
        if share <= 0 then break end
        if not addPerson(th.people, share, cheap, nil) then
            if not cheap or not addPerson(th.people, room, true, nil) then break end
        end
    end

    local function addCreature(cr, master)
        local s = M.score(cr.id, cr.level, tier, true)
        if not s or spent + s > budget then return false end
        if used[cr.id:lower()] then return false end
        mark(cr.id)
        spent = spent + s
        b.members[#b.members + 1] = { id = cr.id, creature = true, name = cr.name, master = master or nil,
            threat = s, level = cr.level }
        return true
    end

    local beastHi = M.creatureCap(tier, scale)
    local beastN = 0
    local function beasts()
        beastN = 0
        for _, m in ipairs(b.members) do if m.creature then beastN = beastN + 1 end end
        return beastN
    end
    if th.beasts and beasts() < beastHi then
        local lo, hi = lim[1], lim[2]
        if tier == 'easy' then hi = math.min(hi, TH.EASY_CREATURE) end
        if th.beasts == 'raised' and (tier == 'dangerous' or tier == 'elite') then
            local lords = ROSTER.creatures('raised', 1, lim[2], o.have, 'bonelord')
            table.sort(lords, function(a, c) return a.level > c.level end)
            for _, lord in ipairs(lords) do if addCreature(lord, true) then break end end
        end
        local want = beastHi
        if th.people and th.beasts == 'raised' then want = math.min(beastHi, 2)
        elseif th.people and th.share then want = math.min(beastHi, math.max(1, math.floor(math.max(1, npcN() - 1) * th.share + 0.5)))
        elseif th.people then want = math.min(beastHi, (tier == 'easy' or tier == 'normal') and 1 or (C.DANGER.CREATURES[tier] or 1))
        end
        local cl = ROSTER.creatures(th.beasts, lo, hi, o.have)
        local guardC = 0
        while beasts() < want and guardC < 12 do
            guardC = guardC + 1
            local options = {}
            for _, cr in ipairs(cl) do
                if not used[cr.id:lower()] then
                    local s = M.score(cr.id, cr.level, tier, true)
                    if s and spent + s <= budget then options[#options + 1] = cr end
                end
            end
            if #options == 0 then break end
            addCreature(options[rnd(#options)])
        end
    end

    if npcN() == 0 and beasts() == 0 then return nil end

    local roles = {}
    if th.people and tier == 'dangerous' then roles = { 'healer', rnd(2) == 1 and 'archer' or 'summoner' }
    elseif th.people and tier == 'elite' then roles = { 'healer', 'archer', 'summoner', 'guard' }
    elseif th.people and tier ~= 'easy' and npcN() >= 3 then roles = { 'archer' } end
    local undead = th.people == 'necromancer'
    for _, m in ipairs(b.members) do
        if not m.creature and #roles > 0 then
            m.role = table.remove(roles, 1)
            m.kit = o.kit(m.role, step, undead)
        end
    end
    -- Worn gear replaces the template suit. Score the weapon and armour they actually carry.
    GEAR.dress(b, rnd)
    local function dressed(who, id)
        if who and who.gear then who.threat = M.score(id, who.level or level, tier, false, who.gear) end
    end
    if b.champion then dressed(b.champion, b.champion.template) end
    if b.lieutenant then dressed(b.lieutenant, b.lieutenant.template) end
    for _, m in ipairs(b.members) do if not m.creature then dressed(m, m.id) end end
    local function total()
        local s, factor = 0, 1
        if b.champion then s = s + (b.champion.threat or 0) end
        if b.lieutenant then s = s + (b.lieutenant.threat or 0) end
        for _, m in ipairs(b.members) do
            s = s + (m.threat or 0)
            if m.role == 'healer' then factor = factor * TH.HEALER
            elseif m.role == 'summoner' then factor = factor * TH.SUMMONER end
        end
        return s * factor
    end
    local sheds = 0
    while total() > budget and #b.members > 0 and sheds < 16 do
        sheds = sheds + 1
        local drop
        for i = #b.members, 1, -1 do
            local m = b.members[i]
            if not m.creature and not m.role and not m.master then drop = i break end
        end
        if not drop then
            for i = #b.members, 1, -1 do
                local m = b.members[i]
                if not m.creature and not m.master then drop = i break end
            end
        end
        -- The notice already said the dead were raised. Two of them stay while a person can go.
        if not drop then
            local raisedN = 0
            for _, m in ipairs(b.members) do if m.creature and th.beasts == 'raised' then raisedN = raisedN + 1 end end
            for i = #b.members, 1, -1 do
                local m = b.members[i]
                if not m.master and not (m.creature and th.beasts == 'raised' and raisedN <= 2) then drop = i break end
            end
        end
        if not drop then break end
        table.remove(b.members, drop)
    end
    b.threat = total()
    if o.remember then
        local ids = {}
        if b.champion then ids[#ids + 1] = b.champion.template end
        if b.lieutenant then ids[#ids + 1] = b.lieutenant.template end
        for _, m in ipairs(b.members) do if not m.creature then ids[#ids + 1] = m.id end end
        o.remember(ids)
    end
    return b
end

return M
