---@omw-context global
-- Odd Jobs: open world jobs, out on the roads and beaches between towns. Each type is its own
-- feature switch, and each notice has a difficulty tier (C.TIER) drawn from the tiers its type
-- comes in (TYPES[t].tiers), weighted by tier.weight for the board's size, region and poster:
--   wildCaravan    a broken cart by a road: the takings from its strongbox. Nobody about; raiders by
--                  a fire; a raiding band with a champion.
--   wildRoadblock  a bandit camp by a road: the leader's signet. Three thugs; a leader and five; a
--                  fortified camp with archers and a champion; a warband with a battlemage.
--   wildBeast      a beast taking herds: kill it. A hungry predator; a named beast; a legendary one
--                  whose skull is a trophy for the player to keep.
--   wildGuar       a lost pack guar: walk it home, or bring back its pack if something got to it
--   wildSmuggler   a smugglers' crate left on a beach at night: its goods to the Watch. A lookout
--                  who keeps out of a fight; guards who fight.
--   wildWreck      wreckage on a beach after a storm: the ship's ledger. Wreckers picking it over.
--   wildGather     an alchemist wants fresh ingredients that grow wild in a named region
--   wildPatrol     Legion fort boards: a patrol ambushed on the road; its supply crate. The ambushers
--                  gone; still there; a band with a champion.
--   wildTraveller  someone who left on the road and has not arrived: dead with a letter on them,
--                  hiding hurt, or held by bandits. Walk them home, or bring back their ring.
--   wildDrive      a herder's guar to walk from outside town to a camp on the road, with something
--                  waiting near the camp; paid for each guar delivered.
--   wildGraverobber diggers at a tomb door after dark. F.quest leaves main-quest tombs out.
--   wildMachine    a Dwemer sphere or spider that wandered out of a ruin onto the road.
--   wildSummon     an atronach loose near a Telvanni tower.
--   wildRitual     cultists at a ring of candles after dark; late, and what they called arrives.
--   wildTax        Legion: a tax chest missing on the road.
--   wildPirateCove a pirate camp on the beach.
--   wildPirate     a named pirate captain raiding boats from a coastal hideout; proof is his hat.
-- Sites come from data/wild.lua (road and beach points read from the load order). Nothing exists
-- out there until the player comes within WILD.NEAR: then spots.lua finds flat, dry, open ground
-- reachable on foot from the road point, and everything goes through spawner.lua (saved list,
-- tracking script, caps by the job's tier). Needs Tamriel Data and Tamriel Rebuilt (WILD.REQUIRES).

local core = require('openmw.core')
local types = require('openmw.types')
local util = require('openmw.util')
local world = require('openmw.world')

local C = require('scripts.ojb.config')
local R = require('scripts.ojb.rewards')
local TI = require('scripts.ojb.tier')
local Q = require('scripts.ojb.req')
local ROSTER = require('scripts.ojb.roster')
local ST = require('scripts.ojb.story')
local FR = require('scripts.ojb.fresh')
local FQ = require('scripts.ojb.foes')
local DM = require('scripts.ojb.danger')
local DATA = require('scripts.ojb.data.wild')
local PLACES = require('scripts.ojb.data.places')
local N = require('scripts.ojb.names')

local WC = C.WILD
local M = {}

local function pick(list, rnd) return list[rnd(#list)] end

local function fill(s, a)
    return (s:gsub('{(%w+)}', function(k)
        local v = a[k]
        if v == nil then error('wild slot {' .. k .. '} has no value in: ' .. s) end
        return tostring(v)
    end))
end

local function cap(s) return (s:gsub('^%l', string.upper)) end

-- Who posts open world work. Their own people, so a board's other notices keep their names.
M.FOLK = {
    caravan = { { 'Dalyn', 'Sarethi', 'caravaner' }, { 'Ervesa', 'Llorayn', 'caravaner', f = true },
        { 'Tidros', 'Uvalen', 'trader' }, { 'Nalvyna', 'Hledas', 'trader', f = true } },
    herd = { { 'Garas', 'Morvani', 'herder' }, { 'Ulvesa', 'Drothan', 'herder', f = true },
        { 'Mivul', 'Fendaren', 'farmer' }, { 'Sedura', 'Romari', 'farmer', f = true } },
    sea = { { 'Hloren', 'Vaas', 'fisherman' }, { 'Belyne', 'Othrelas', 'fisher', f = true },
        { 'Rilvin', 'Andarys', 'boatwright' }, { 'Teldra', 'Seran', 'trader', f = true } },
    watch = { { 'Captain', 'of the Watch' } },
    healer = { { 'Ilmeni', 'Dren', 'alchemist', f = true }, { 'Feldyn', 'Hlarys', 'alchemist' },
        { 'Navani', 'Sadas', 'healer', f = true }, { 'Ralds', 'Veloth', 'healer' } },
    family = { { 'Dalvilu', 'Indaram', f = true }, { 'Fothas', 'Llervu' }, { 'Mivanu', 'Selothan', f = true },
        { 'Tanur', 'Rethan' } },
}

M.SHIPS = { 'Grey Gull', 'Swift Kagouti', 'Saint Roris', 'Ebon Wind', 'Morning Star', 'Salt Rose', 'Good Haul',
    'Fair Odai' }
M.BEAST_NAMES = { 'Old Scar', 'Greytooth', 'Blackhide', 'Split-Ear', 'the Widow', 'Old Hunger', 'Ash Back',
    'Long Tooth' }
-- Beasts of Morrowind's wilds that make sense taking herds.
M.BEAST_FAMILIES = { kagouti = true, alit = true, ['nix-hound'] = true, shalk = true, velk = true,
    parastylus = true }

-- Notice lines. Rumours and what the poster saw or heard; never how the job works. A list keyed by
-- tier (easy, normal, dangerous, elite) is that tier's; a missing tier falls back to normal.
M.LINES = {
    caravan = {
        title = { 'Cart lost on the road', 'Wrecked cart, takings missing', 'Strongbox left on the road' },
        body = {
            'My cart went over on the road two nights ago, and the guar with it. I had to leave everything. There is a strongbox with the week\'s takings in it, still lashed to the back.',
            'We were hit on the road and ran for it. When I looked back, the cart was on its side and the strongbox was still on it. The guar did not get up again.',
            'One of my carts was due in two days ago. A herder found it tipped over by the road, with the load spilled and the guar dead in its harness. The strongbox was not opened.',
        },
        sign = { 'Look for the broken cart by the road.', 'You will see the cart from the road, tipped on its side.' },
        raiders = { 'Whoever did it may still be camped close by. You might see the smoke from their fire.',
            'The ones who hit us did not go far. Watch for a campfire near the road.' },
        band = { 'These were no common thieves. They answer to {Leader}, and they are camped close by.',
            'It was a proper raiding party, led by someone they called {Leader}. Their fire is still burning by the road.' },
        quiet = { 'Nobody has been back for it that I know of.', 'Get there before the scavengers do.' },
        ask = { 'Bring back what is in the box and I will pay you for it.', 'Bring me the takings. The cart can rot.' },
        plain = 'A broken cart by the road. Bring back the takings from its strongbox.',
        plainRaiders = 'Raiders may be camped nearby.',
        plainBand = 'A raiding party under {Leader} is camped nearby.',
    },
    roadblock = {
        title = { 'Bandits on the road', 'Camp on the road, reward offered', 'Toll thieves by the road' },
        body = {
            easy = {
                'Three thugs have taken to stopping people on the road and asking for coin. The loudest of them goes by {Leader}.',
                'A few toughs sit by the road and take a toll from anyone who looks easy. {Leader} does the talking.',
            },
            normal = {
                '{Leader} and a few others have put up a camp by the road and stop anyone who passes. They took a toll off my brother and gave him a beating with it.',
                'There is a camp by the road now, and the people in it want coin from everyone who comes by. The one who does the talking is called {Leader}.',
                'Nobody I know will take the road any more. {Leader} sits by a fire next to it with {count} others and takes what {he} likes from travellers.',
            },
            dangerous = {
                '{Leader} has dug in by the road with a proper camp, fenced, with heads on stakes to warn people off. {He} has {count} with {him}.',
                'The camp by the road is no toll post any more. {Leader} has put up a fence and keeps {count} armed with {him}, and they shoot from behind it.',
            },
            elite = {
                'A warband has taken the road under {Leader}. There are {count} of them, more than the Watch will face.',
                '{Leader} has gathered a warband by the road, {count} strong. Caravans turn back rather than meet them.',
            },
        },
        sign = {
            easy = { 'Their fire is easy to see from the road after dark.' },
            normal = { 'Their fire is easy to see from the road after dark.', 'You will see their tent from the road.' },
            dangerous = { 'The heads on stakes by the road are hard to miss.', 'You will see the fence from the road.' },
            elite = { 'You will see their tents and fires from the road.' },
        },
        ask = { 'Bring me {Leader}\'s signet and the road is ours again.', 'Bring back {his} signet as proof.' },
        plain = {
            easy = 'Three thugs by the road, led by {Leader}. Bring back {his} signet.',
            normal = 'A bandit camp by the road, led by {Leader}, with {count} others. Bring back {his} signet.',
            dangerous = 'A fortified bandit camp by the road, led by {Leader}, with {count} others. Bring back {his} signet.',
            elite = 'A warband by the road, led by {Leader}, {count} strong. Bring back {his} signet.',
        },
        guild = {
            easy = { 'Travellers say a handful of thugs under {Leader} take a toll on the road. The guild has been asked to see them off.' },
            normal = {
                'Travellers say {Leader} and {count} others have a camp by the road and take a toll from anyone who passes. The guild has been asked to clear it.',
                'A bandit called {Leader} has set up by the road with {count} others. Caravans pay to pass or turn back. The guild wants it ended.',
            },
            dangerous = { 'A bandit called {Leader} has fortified a camp by the road and holds it with {count} others. The Guild has been paid to end it.' },
            elite = { 'The guild has been asked to break a warband on the road. {Leader} leads it, {count} strong.' },
        },
        guildAsk = { 'Bring back {Leader}\'s signet as proof and the guild pays.', 'Return with {his} signet to be paid.' },
        legion = {
            'Bandits under {Leader} are stopping traffic on the road, and the fort has nobody to spare. Travellers put them at {count}.',
            'The road past the fort is not safe. {Leader} and {count} others keep a camp beside it.',
        },
        legionAsk = { 'Bring back {Leader}\'s signet and the Legion will pay.', 'Return with {his} signet as proof.' },
    },
    beast = {
        title = {
            normal = { '{aFamily} taking stock', 'Hungry {family} near the road' },
            dangerous = { '{aFamily} called {Name}', 'Big {family} taking herds', '{Name} is back' },
            elite = { '{Name}, the old {family}', 'The {family} they call {Name}' },
        },
        body = {
            normal = {
                'Something has been coming down to the herds at night. The herders found the tracks of {aFamily}, a big one, and hungry by the look of what it left.',
                'We lost a guar last week and another two nights ago. It is {aFamily}, and it is not going to stop on its own.',
            },
            dangerous = {
                'Something has been taking our guar off the hills. The herders say it is {aFamily}, bigger than any they have seen, and they call it {Name}.',
                'There is {aFamily} the size of a cart out there, and it has had three of my animals this month. The hunters call it {Name}.',
                'Folk say {aFamily} they call {Name} has been killing stock along the road. My neighbour lost two guar to it last week.',
            },
            elite = {
                'Herders have talked about {Name} for years: {aFamily} older and bigger than any other, that no hunter has brought down. It is taking herds near the road again.',
                'There is {aFamily} the herders call {Name}, and they say it was old when their grandparents were young. Hunters have gone after it. It is still out there.',
            },
        },
        sign = {
            normal = { 'It comes back to the same ground, so look near the road.' },
            dangerous = { 'It moves about, so you may have to look for it.', 'Follow the road and keep your eyes open. It does not hide.' },
            elite = { 'You will know it when you see it. Nothing else out there is that size.' },
        },
        trophy = { 'Whoever brings it down will want to keep its skull.', 'Its skull would hang in any hall in Vvardenfell.' },
        ask = { 'Kill it and come back to me.', 'Put it down and I will pay what I can.' },
        plain = {
            normal = 'A hungry {family} near the road. Kill it.',
            dangerous = 'An oversized {family} named {Name} roams near the road. Kill it.',
            elite = 'A legendary {family} named {Name} roams near the road. Kill it.',
        },
        guild = {
            normal = { 'The herders have asked the guild to deal with {aFamily} that has been taking their guar near the road.' },
            dangerous = {
                'The herders have come to the guild about {aFamily} they call {Name}. It has killed stock along the road and is bigger than any they have seen.',
                'The herders have put up a bounty through the guild for {aFamily} called {Name}. It has been taking guar near the road.',
            },
            elite = { 'The guild has taken a bounty on {Name}, {aFamily} the herders have feared for longer than anyone remembers.' },
        },
        guildAsk = { 'Kill it and report back to the guild.', 'Put it down and the guild pays the bounty.' },
    },
    guar = {
        title = { 'Lost guar', 'Pack guar wandered off', 'Guar missing from the herd' },
        body = {
            'My pack guar slipped its rope and wandered off with its load still on. A traveller saw a guar with a pack on its back by the road.',
            'One of my guar got loose in the night. It is old and slow and will not have gone far. It still has its pack on.',
            'My guar ran off when something spooked it on the road. I could not catch it, and my legs are not what they were.',
        },
        sign = { 'It is gentle and will follow anyone who scratches its neck.', 'It knows the way home, it just needs someone to walk with.' },
        worst = { 'If something got to it first, bring back the pack at least.', 'If it is dead, I still want the pack it carried.' },
        ask = { 'Walk it back to town and I will pay you.', 'Bring it home and you will have my thanks and my coin.' },
        plain = 'A lost pack guar near the road. Walk it back to town, or bring back its pack.',
    },
    smuggler = {
        title = { 'Smugglers on the shore', 'Watch notice: contraband', 'Drop on the beach' },
        body = {
            'Fishermen have seen a boat come in close to the shore after dark and leave again before morning. We think a crate is left on the beach for a buyer to collect.',
            'Somebody is using the beach as a drop. A crate comes ashore at night and is gone by noon.',
            'A boat with no lights has been seen off the coast at night, more than once. Someone ashore has been seen carrying a crate up from the water.',
        },
        sign = { 'Go down there after dark and look along the shore.', 'The drop is made at night, so go then.' },
        guard = {
            normal = { 'They leave someone to watch for the buyer. Whoever it is would sooner run than fight.',
                'Someone keeps an eye on the crate until the buyer comes, but keeps out of trouble.' },
            dangerous = { 'They leave armed men with it now, and they do not run.',
                'The last fisherman who went close was shot at from the dunes.' },
        },
        ask = { 'Bring us what is in the crate and the Watch will pay.', 'Bring the goods here and you will be paid for your trouble.' },
        plain = 'A smugglers\' crate is left on the beach at night. Bring its goods to the Watch.',
        plainGuard = { normal = 'A lookout watches it.', dangerous = 'Armed guards watch it.' },
    },
    wreck = {
        title = { 'Ship lost in the storm', 'Wreckage washed up', 'Ledger lost at sea' },
        body = {
            'The storm last week took the {Ship} off the coast. Pieces of her have washed up on the beach. Her captain kept a ledger, and I need it back, wet or dry.',
            'The {Ship} went down in the storm. My share of her cargo went with her, but her ledger may have come ashore with the rest of the wreckage. It says who owes what.',
            'After the storm, planks and crates from the {Ship} turned up on the shore. Her ledger was in the captain\'s cabin. If it washed up, it is mine by right of salvage.',
        },
        sign = { 'Look along the shore for planks and broken crates on the sand.', 'The wreckage is spread along the beach.' },
        wreckers = { 'Wreckers have been seen picking over the beach. They will not want to share.',
            'Some rough types have been going through the wreckage. Watch yourself.' },
        ask = { 'Bring me the ledger and I will pay well.', 'Bring it back here and the reward is yours.' },
        plain = 'Wreckage on the beach after a storm. Find the ledger of the {Ship} among it.',
        plainWreckers = 'Wreckers are picking it over.',
    },
    gather = {
        title = { 'Fresh {item} wanted', '{Item} needed, fresh', 'Wanted: {item}, picked fresh' },
        body = {
            'I need {count} for a remedy, and they have to be fresh. The dried stock in the shops will not do. They grow wild in {region}.',
            'A patient of mine needs a draught that only works with fresh {item}. I need {count}. They grow along the roads in {region}.',
            'My stores are empty and I need {count} before the week is out. They grow wild in {region}, if you know where to look.',
        },
        ask = { 'Bring them to me and I will pay a fair price.', 'Pick them and bring them here.' },
        plain = 'Gather {count} in {region} and bring them back.',
        guild = 'The guild needs {count} for a study. They grow wild in {region}. The dried stock in the shops will not do.',
    },
    patrol = {
        title = { 'Patrol ambushed on the road', 'Legion supply crate lost', 'Road patrol attacked' },
        legion = {
            'A patrol out of the fort was ambushed on the road. A herder saw the bodies and came to tell us. The supply crate they carried is still out there.',
            'Our road patrol was due back two days ago. A trader passing by saw their cart on its side and soldiers lying beside it. The supply crate was with them.',
            'The road patrol was attacked and cut down. The crate of supplies they were bringing in has not been recovered.',
        },
        sign = { 'Look for an overturned cart by the road.', 'You will see the cart from the road, and the bodies by it.' },
        gone = { 'Whoever did it took what they could carry and left.', 'The ambushers have not been seen since.' },
        still = { 'Those who did it may still be picking over what is left.', 'Expect the ambushers to be close by.' },
        band = { 'This was no band of thieves. They answer to someone called {Leader}, and they are still out there.',
            'Travellers have seen {Leader} on that road since, with {count} armed behind {him}.' },
        legionAsk = { 'Bring the crate back to the fort and you will be paid.', 'Recover the crate. The Legion pays for its own.' },
        plain = 'A Legion patrol was ambushed by the road. Bring its supply crate back to the fort.',
        plainStill = 'The ambushers may still be there.',
        plainBand = 'A band under {Leader} is still there.',
    },
    traveller = {
        title = { '{Traveller} has not arrived', 'Word wanted of {Traveller}', 'Traveller overdue on the road' },
        body = {
            'My {kin}, {Traveller}, left on the road a week ago and has not arrived. {He} was walking, on {his} own.',
            '{Traveller} set out on the road and should have been in the next town days ago. Nobody on the road has seen {him}.',
            'My {kin} {Traveller} left with a pilgrim\'s pack and a walking stick, and we have heard nothing since.',
        },
        sign = { '{He} would have kept to the road, so look along it for {his} pack.',
            'If {he} stopped anywhere, it would have been near the road.' },
        trouble = { 'There has been bandit trouble on that road lately, and that is what frightens me.',
            'Travellers have been robbed on that road this month, and I fear the worst.' },
        ask = { 'Bring {him} home if you can. If not, bring me {his} ring so we know.',
            'Please find {him}. If the worst has happened, bring me {his} ring so we know.' },
        plain = '{Traveller} left on the road and has not arrived. Bring {him} home, or {his} ring.',
        plainTrouble = 'There has been bandit trouble on that road.',
    },
    drive = {
        title = { 'Guar to drive', 'Herder needs a hand with guar', 'Guar to take out to the camp' },
        body = {
            'I have {count} guar to get out to my camp by the road, and something has been prowling near it. I will not take them out alone.',
            'My herd camp is out on the road, and these {count} guar need to get there. Something has been seen near the camp.',
            'I need {count} guar walked out to my camp on the road. My hand quit after something went for him near the camp.',
        },
        lurk = {
            easy = { 'It is probably only a scavenger, but I would rather not lose one.' },
            normal = { 'The tracks are big. Keep the guar close.' },
            dangerous = { 'Whatever it is took a grown guar off the camp last week. More than one, by the tracks.' },
        },
        sign = { 'The guar are waiting outside town. They will walk with whoever takes them.',
            'You will find them by the road out of town.' },
        ask = { 'Get them to the camp and I will pay for each one that arrives.', 'I pay for every guar that reaches the camp.' },
        plain = 'Walk {count} guar from outside town to a herder\'s camp by the road. Something lurks near the camp.',
    },
    graverobber = {
        title = { 'Diggers at the tomb', 'The tomb door forced', 'Bones on the steps' },
        body = {
            'Someone has been opening a tomb at night. The family found the door forced and bones on the steps.',
            'Folk saw lanterns at a tomb door after dark, and heard digging. The ancestors are not at rest.',
            'A herder passing at dusk saw people at a tomb door with picks, and they did not look like priests.',
        },
        sign = { 'Go after dark and catch them at it.', 'They come at night. You will see their lights from the road.' },
        ask = { 'Drive them off, and bring back the hat their leader wears so we know.',
            'Catch them at it. The hat the loudest one wears will do as proof.' },
        guild = {
            'Someone has been opening a tomb at night. The Temple wants them caught at it.',
        },
        guildAsk = { 'Bring back the hat their leader wears.', 'The hat is proof enough.' },
        plain = 'Grave robbers at a tomb door after dark. Bring back the hat their leader wears.',
    },
    machine = {
        title = { 'A machine on the road', 'Something metal on the road', 'A sphere out of the ruin' },
        body = {
            'A Dwemer machine has come out of the ruin on its own and is rolling up and down the road, knocking down anyone who walks past.',
            'Herders will not take the road by the old ruin. Something metal came out of it and will not go back in.',
            'A sphere, or a spider of brass, left the ruin and is on the road. It does not care who it hits.',
        },
        sign = { 'You will hear it before you see it.', 'Follow the road by the ruin.' },
        ask = { 'Break it before it kills someone.', 'Put it down and the road is ours again.' },
        guild = {
            'A Dwemer machine has left the ruin and is on the road. The guild has been asked to break it.',
        },
        guildAsk = { 'Break it and report back.', 'Put it down. The guild pays.' },
        plain = 'A Dwemer machine is loose on the road by a ruin. Break it.',
    },
    summon = {
        title = { 'A small matter, handled quietly', 'Something got away', 'An apprentice\'s mistake' },
        body = {
            'An atronach got away from my apprentice and is wandering the hills, setting the grass alight. Put it down before anyone important hears of it.',
            'A summoning went wrong. The thing is still out there, near the tower, and I would rather it were not.',
            'Something I called up walked off. It is loose near the tower. Discretion is half the fee.',
        },
        sign = { 'You will see the scorch marks from the road.', 'It has not gone far from the tower.' },
        ask = { 'Put it down, and say nothing of who asked.', 'Handle it quietly and I will pay.' },
        guild = {
            'An atronach is loose near a Telvanni tower. The Guild would rather this were handled before it becomes a complaint.',
        },
        guildAsk = { 'Put it down. The Guild will not ask whose it was.', 'Handle it quietly.' },
        plain = 'An atronach is loose near a Telvanni tower. Put it down.',
    },
    ritual = {
        title = { 'Candles on the hill', 'Lights in a ring', 'Chanting after dark' },
        body = {
            'Herders have seen lights in a ring on the hill, and people in robes chanting after dark. Whatever they are calling, I do not want it to arrive.',
            'Someone has laid a ring of candles out by the road and has been at it two nights running. The words are not Velothi.',
            'Folk heard chanting from the hill after dark, and saw a ring of lights. Go tonight.',
        },
        sign = { 'Go tonight. If you are late, go armed for worse.', 'You will see the candles from the road after dark.' },
        ask = { 'Stop them before they finish.', 'Break the ring and see that none of them walk away.' },
        plain = 'Cultists at a ring of candles after dark. Stop them before they finish.',
    },
    tax = {
        title = { 'Tax chest missing', 'The tax wagon did not arrive', 'Chest lost on the road' },
        legion = {
            'The tax chest did not arrive at the next fort. The wagon is on its side by the road.',
            'A tax wagon went over on the road. The chest is still there, if the scavengers have not found it.',
            'The chest from the last collection is missing. A herder saw the wagon on its side by the road.',
        },
        sign = { 'Look for the wagon on its side.', 'You will see the cart from the road.' },
        still = { 'Whoever hit it may still be close by.', 'Expect someone to be picking it over.' },
        legionAsk = { 'Bring the chest back with its seal unbroken.', 'Recover the chest. The Legion pays.' },
        plain = 'A tax wagon is on its side by the road. Bring the chest back to the fort.',
    },
    piratecove = {
        title = { 'Pirates on the shore', 'A camp on the beach', 'Boats taken at night' },
        body = {
            'A pirate crew has taken the beach our boats used to land on. They keep a fire going and take what they like from anyone who puts in.',
            'Fishermen will not land on that stretch any more. Pirates have a camp there, and they are not hiding it.',
            'Someone has put up a camp on the beach and calls the cove theirs. The fishing boats have started going elsewhere.',
        },
        sign = { 'You will see their fire from the water.', 'Look along the shore after dark.' },
        ask = { 'Clear them out, and bring back the hat their captain wears.',
            'Drive them off. The hat the one in charge wears will do as proof.' },
        plain = 'Pirates have a camp on the beach. Bring back the hat their captain wears.',
    },
    pirate = {
        title = { '{Leader} on the coast', 'A pirate in the bay', 'Boats taken, captain named' },
        body = {
            'A pirate they call {Leader} has been taking the catch off our boats for a month. {He} keeps a crew on the coast.',
            '{Leader} has been stopping fishing boats and taking the catch. {He} hides on the shore with {count} others.',
            'The boats will not go out. {Leader} waits off the point and takes what {he} wants.',
        },
        sign = { 'Look along the coast for their fire.', 'Their boats are pulled up on the sand.' },
        ask = { 'Bring me the hat {he} wears, so I know {he} is done.',
            'The hat {he} wears will do as proof. Do not bring me anything else of {him}.' },
        plain = '{Leader} is raiding boats from a hideout on the coast. Bring back the hat {he} wears.',
    },
    found = {
        guar = 'The guar sniffs your hand and falls in behind you.',
        guarDead = 'Something got to the guar first. Its pack is still on it.',
        night = 'Nothing on the beach yet. The drop is made after dark.',
        void = 'Whatever you were sent to find is gone. The job is off, and nobody holds it against you.',
        travDead = 'You find {Traveller} by the road. {He} has been dead some days. There is a letter in {his} coat, and {his} ring is on {his} hand.',
        travHiding = '{Traveller} is hurt, but alive, and has been hiding from whatever was on the road. {He} will walk back with you.',
        travTaken = '{Traveller} is held at the camp, tied but unhurt.',
        travFreed = '{Traveller} is free, and will walk back with you.',
        travDied = '{Traveller} is dead. {His} ring is all you can bring back now.',
        letter = 'I left the road to get out of sight, and I could not get back to it. If this is found, tell my family I tried to get home.',
        driveStart = 'The herder\'s guar are waiting by the road. They fall in behind you.',
        driveLost = 'None of the guar made it. The job is off, and nobody holds it against you.',
        called = 'The chanting stopped, and something answered it. Whatever they called is here now.',
    },
}

-- Props, the first one loaded wins. Tamriel Data's where it has one.
local PROPS = {
    cart = { 'T_De_Set_Cart_01', 'furn_guarcart00' },
    wheel = { 'T_De_Var_Cartwheel_01' },
    crate = { 'crate_01_empty', 'crate_02_empty' },
    chest = { 'chest_small_01_empty', 'chest_small_02' },
    fire = { 'Furn_De_Firepit_F', 'furn_de_firepit' },
    tent = { 'T_De_Set_X_Tent_01', 'ex_ashl_tent_01' },
    plank = { 'T_Com_Var_PlankBrokenA_01', 'T_Com_Var_PlankBrokenA_02', 'T_Com_Var_PlankBrokenA_03',
        'T_Com_Var_PlankBrokenA_04', 'ex_ship_plank' },
    guar = { 'guar_pack' },
    fence = { 'T_De_Set_X_WoodFence_01_128', 'T_De_Set_X_WoodFence_02_128' },
    stake = { 'T_Com_Var_StakeHeadDun_01', 'T_Com_Var_StakeHeadDun_02' },
    bedroll = { 'T_Com_Furn_Bedroll_01', 'active_de_bedroll' },
    sack = { 'com_sack_00' },
    candle = { 'light_com_candle_16', 'light_de_candle_01', 'light_com_candle_01' },
}
local PROP_TYPES = { 'Static', 'Container', 'Light', 'Activator', 'Creature' }
local CONTRABAND = { { 'potion_skooma_01', 2, 4 }, { 'ingred_moon_sugar_01', 3, 6 } }
local NOT_GATHERED = { ingred_pearl_01 = true }
-- The patrol's dead: generic Legion soldiers from the load order (vanilla, then Tamriel Rebuilt).
local LEGION = { 'Imperial Guard', 'imperial archer', 'TR_m1_imp_archer', 'TR_m2_imp_archer' }
-- Missing travellers: vanilla pilgrims with no script and no faction, renamed. f: female.
local TRAVELLERS = { { 'gols nilvon' }, { 'farvam faram' }, { 'mibdinahaz addunipu' }, { 'orvona vadryon', f = true },
    { 'artisa arelas', f = true }, { 'erirvase drinith', f = true } }
local TROPHY_BASE = 'misc_skull00'

-- guild: boards other than town boards that post the type (fighters guild, mages guild, legion).
-- notTown: town boards never post it. weight: its share when a board picks a type, against 1.
-- tiers: the tiers it comes in and their weight against each other, before tier.weight; gathering
-- takes its tier from what the plants are worth. share: how far up the tier's pay band it sits.
-- band: for dangerous and elite, the band's people group and roles (danger.lua band opts).
local TYPES = {
    caravan = { feature = 'wildCaravan', site = 'roads', kind = 'recovery', share = 0.7, folk = 'caravan', weight = 2,
        tiers = { easy = 1, normal = 1, dangerous = 0.5 },
        band = { people = 'bandit', roles = { 'archer' } } },
    roadblock = { feature = 'wildRoadblock', site = 'roads', kind = 'bounty', share = 0.6, folk = 'caravan',
        guild = { 'fighters guild', 'legion' }, tiers = { easy = 0.8, normal = 1, dangerous = 0.8, elite = 0.6 },
        band = { people = 'bandit', roles = { 'archer', 'archer', 'healer' },
            eliteRoles = { 'battlemage', 'archer', 'archer', 'healer', 'guard' } } },
    beast = { feature = 'wildBeast', site = 'roads', kind = 'nest', share = 0.7, folk = 'herd',
        guild = { 'fighters guild' }, tiers = { normal = 1, dangerous = 0.8, elite = 0.6 } },
    guar = { feature = 'wildGuar', site = 'roads', kind = 'nest', share = 0.4, folk = 'herd', tiers = { easy = 1 } },
    smuggler = { feature = 'wildSmuggler', site = 'beach', kind = 'recovery', share = 0.6, folk = 'watch',
        night = true, tiers = { easy = 1, normal = 0.8, dangerous = 0.4 },
        band = { people = 'smuggler', roles = { 'archer' }, followers = { 2, 3 } } },
    wreck = { feature = 'wildWreck', site = 'beach', kind = 'recovery', share = 0.6, folk = 'sea',
        storm = true, tiers = { easy = 1, normal = 0.5 } },
    gather = { feature = 'wildGather', site = 'roads', kind = 'recovery', folk = 'healer',
        guild = { 'mages guild' }, tiers = { easy = 1 } },
    patrol = { feature = 'wildPatrol', site = 'roads', kind = 'recovery', share = 0.6, guild = { 'legion' },
        notTown = true, tiers = { easy = 0.6, normal = 1, dangerous = 0.7 },
        band = { people = 'bandit', roles = { 'archer', 'healer' } } },
    traveller = { feature = 'wildTraveller', site = 'roads', kind = 'recovery', share = 0.6, folk = 'family',
        tiers = { easy = 1, normal = 0.8, dangerous = 0.4 },
        band = { people = 'bandit', roles = { 'archer' }, followers = { 3, 4 } } },
    drive = { feature = 'wildDrive', site = 'roads', kind = 'nest', share = 0.5, folk = 'herd', maxCells = WC.DRIVE.MAX_CELLS,
        tiers = { easy = 1, normal = 1, dangerous = 0.4 } },
    graverobber = { feature = 'wildGraverobber', site = 'tomb', kind = 'bounty', share = 0.5, folk = 'family',
        night = true, tiers = { easy = 1, normal = 1, dangerous = 0.5 },
        band = { people = 'graverobber', roles = { 'archer' }, followers = { 2, 3 } } },
    machine = { feature = 'wildMachine', site = 'dwemer', kind = 'nest', share = 0.6, folk = 'herd',
        guild = { 'fighters guild' }, tiers = { easy = 1, normal = 1, dangerous = 0.6 } },
    summon = { feature = 'wildSummon', site = 'telvanni', kind = 'nest', share = 0.5, folk = 'healer',
        guild = { 'mages guild' }, tiers = { easy = 1, normal = 1, dangerous = 0.5 } },
    ritual = { feature = 'wildRitual', site = 'roads', kind = 'bounty', share = 0.6, folk = 'family',
        night = true, tiers = { easy = 0.8, normal = 1, dangerous = 0.6 },
        band = { people = 'cultist', roles = { 'summoner' }, followers = { 3, 4 } } },
    tax = { feature = 'wildTax', site = 'roads', kind = 'recovery', share = 0.6, guild = { 'legion' },
        notTown = true, tiers = { easy = 1, normal = 1, dangerous = 0.4 } },
    piratecove = { feature = 'wildPirateCove', site = 'beach', kind = 'bounty', share = 0.6, folk = 'sea',
        tiers = { easy = 1, normal = 1, dangerous = 0.5 },
        band = { people = 'pirate', roles = { 'archer' }, followers = { 3, 4 } } },
    pirate = { feature = 'wildPirate', site = 'beach', kind = 'bounty', share = 0.6, folk = 'sea',
        tiers = { normal = 1, dangerous = 0.8 },
        band = { people = 'pirate', roles = { 'archer', 'healer' }, followers = { 4, 5 } } },
}
M.TYPES = TYPES
M.ORDER = { 'caravan', 'roadblock', 'beast', 'guar', 'smuggler', 'wreck', 'gather', 'patrol', 'traveller', 'drive',
    'graverobber', 'machine', 'summon', 'ritual', 'tax', 'piratecove', 'pirate' }
-- Tests append x,y,z triples; F.quest has already left main-quest tombs and ruins out of places.lua.
M.EXTRA = { tomb = {}, dwemer = {}, telvanni = {} }
-- Beasts lurking near a guar drive's camp, by tier.
local LURKERS = { easy = 1, normal = 2, dangerous = 3 }

-- "Fire Petal" -> "Fire Petals"; plants sold by weight are counted in handfuls.
local COUNTED = { Root = true, Petal = true, Anther = true, Bulb = true, Yam = true, Pod = true, Spine = true,
    Stalk = true, Cap = true, Flower = true, Seed = true }
function M.plural(name)
    local last = name:match('(%a+)$') or ''
    if name:match('s$') then return name, true end
    if last == 'Leaf' then return (name:gsub('Leaf$', 'Leaves')), true end
    if last:match('rry$') then return (name:gsub('y$', 'ies')), true end
    if COUNTED[last] then return name .. 's', true end
    return name, false
end

-- A region as said in a sentence after "in": a name ending in a land word takes "the" ("Ascadian
-- Isles Region" -> "the Ascadian Isles", "Sea of Ghosts Region" -> "the Sea of Ghosts"); a proper
-- name or a possessive doesn't ("Molag Mar", "Azura's Coast", "Sheogorad").
local LAND = { Isles = true, Coast = true, Lands = true, Ashlands = true, Grazelands = true, Gash = true,
    Forest = true, Woods = true, Plains = true, Vales = true, Valley = true, Mountains = true, Hills = true,
    Highlands = true, Ocean = true, Sea = true, Scar = true, Spine = true, Marsh = true, Marshes = true,
    Wastes = true, Peaks = true, Bay = true, Reach = true }
function M.regionText(name)
    if not name or name == '' then return nil end
    local base = name:match('^(.-) [Rr]egion$') or name
    if base:find("'s ", 1, true) then return base end
    local head, last = base:match('^(%a+) of '), base:match('(%a+)$')
    if (head and LAND[head]) or (last and LAND[last]) then return 'the ' .. base end
    return base
end

-- A line list for a tier: a plain list is every tier's; one keyed by tier falls back to normal.
local function forTier(list, tier)
    if type(list) ~= 'table' or list[1] ~= nil then return list end
    return list[tier] or list.normal
end

-- ctx: twists' ctx plus complete(c, player), siteDirections(key, x, y, door), DG (danger.lua),
-- makeBook(name, text).
function M.new(ctx)
    local W = {}
    local rnd = ctx.rnd
    local warned = false

    local function S() return ctx.S() end

    -- The load order is fixed for the session; read on first use, after global.lua filled ctx.
    local missing
    function W.missing()
        if missing then return missing end
        missing = {}
        for _, f in ipairs(WC.REQUIRES) do
            if not ctx.hasFile(f) then missing[#missing + 1] = f end
        end
        if #missing > 0 then
            ctx.say('open world jobs are off: %s not in the load order', table.concat(missing, ', '))
        end
        return missing
    end

    local function exists(id)
        for _, t in ipairs(PROP_TYPES) do
            if types[t] and types[t].records[id] then return true end
        end
        return false
    end
    local function prop(kind)
        for _, id in ipairs(PROPS[kind] or {}) do
            if exists(id) then return id end
        end
        return nil
    end
    local function npcs(list)
        local out = {}
        for _, e in ipairs(list) do
            local id = type(e) == 'table' and e[1] or e
            if types.NPC.records[id] then out[#out + 1] = e end
        end
        return out
    end

    local function distCells(ax, ay, bx, by)
        local dx, dy = (ax - bx) / C.CELL, (ay - by) / C.CELL
        return math.sqrt(dx * dx + dy * dy)
    end

    local function siteKey(x, y) return math.floor(x) .. ',' .. math.floor(y) end

    -- Extra sites from places.lua, filled once per W. Key: site kind (tomb/dwemer/telvanni).
    -- Lifetime: this W (one per session). Invalidation: none; places.lua is static. Absence:
    -- an empty EXTRA list means no site of that kind in range, and posting skips it.
    local placed
    local function listFor(site)
        if site == 'roads' then return DATA.roads end
        if site == 'beach' then return DATA.beach end
        if not placed then
            placed = true
            for _, p in ipairs(PLACES) do
                if not FQ.quest(p.n) then
                    local into
                    if p.tomb then into = M.EXTRA.tomb
                    elseif p.k == 'dwemer' then into = M.EXTRA.dwemer
                    elseif p.n:find('^Tel ') then into = M.EXTRA.telvanni
                    end
                    if into then
                        into[#into + 1], into[#into + 2], into[#into + 3] = p.x, p.y, p.z or 0
                    end
                end
            end
        end
        return M.EXTRA[site]
    end

    local function isNight()
        local h = (core.getGameTime() / 3600) % 24
        return h >= 20 or h < 5
    end

    local function stormy(x, y)
        local cell = world.getExteriorCell(math.floor(x / C.CELL), math.floor(y / C.CELL))
        if not cell then return false end
        local w = core.weather.getCurrent(cell)
        return w and (w.isStorm or w.rainEffect ~= nil)
    end

    -- Points of one list in reach of the board, not used by a job in the last REUSE_DAYS.
    -- A missing list (no tomb/ruin/tower of that kind loaded) is none in reach.
    local function sitesNear(list, ox, oy, maxCells)
        local used = S().wildSites or {}
        local cut = ctx.now() - C.REUSE_DAYS
        local out = {}
        if not list then return out end
        for i = 1, #list - 2, 3 do
            local x, y, z = list[i], list[i + 1], list[i + 2]
            local d = distCells(ox, oy, x, y)
            if d >= WC.MIN_CELLS and d <= (maxCells or WC.MAX_CELLS) and (used[siteKey(x, y)] or -1e9) < cut then
                out[#out + 1] = { x = x, y = y, z = z }
            end
        end
        return out
    end

    local function remember(site)
        local s = S()
        s.wildSites = s.wildSites or {}
        s.wildSites[siteKey(site.x, site.y)] = ctx.now()
        local cut = ctx.now() - C.REUSE_DAYS
        for k, day in pairs(s.wildSites) do
            if day < cut then s.wildSites[k] = nil end
        end
    end

    local function person(folk, used)
        local list = {}
        for _, p in ipairs(M.FOLK[folk]) do
            if not used.names[p[2]] then list[#list + 1] = p end
        end
        if #list == 0 then return nil end
        local p = pick(list, rnd)
        local from = p[3] and (p[1] .. ' ' .. p[2] .. ', ' .. p[3]) or (p[1] .. ' ' .. p[2])
        return { first = p[1], last = p[2], trade = p[3], female = p.f == true, from = from }
    end

    local function newId()
        local s = S()
        local id = s.nextId
        s.nextId = s.nextId + 1
        return id
    end

    local function payFor(id, value, diff, poster, trade, player)
        local skill, price
        if C.GUILDS[poster] then skill, price = ctx.trainingFor(player, poster) end
        local reward = R.split(value, diff, price, id, R.poolFor(poster, trade))
        return reward, reward.training and skill or nil
    end

    local function countText(n)
        local lo = math.max(1, n - 1)
        return ST.number(lo) .. ' or ' .. ST.number(n)
    end

    -- The tier of a new notice of type t: the type's tiers a board of this size posts, the rules
    -- allow and the feature switches have on, weighted by tier.weight. Elite work is posted by guilds
    -- only, and only while the region has no elite work open or resting (danger.lua eliteIn).
    local function tierFor(t, key, player, poster, region)
        local T = TYPES[t]
        local size, level, on = ctx.sizeOf(key), ctx.playerLevel(player), ctx.featureOn
        local list, total = {}, 0
        for _, tier in ipairs(TI.ORDER) do
            local w = T.tiers[tier]
            local ok = w ~= nil and TI.postsAt(tier, size) and TI.allowed(tier, level, ctx.rules)
            if ok and tier == 'dangerous' then ok = on.dangerous ~= false end
            if ok and tier == 'elite' then
                -- Elite roadblocks stay at Fighters Guild halls; other elite wild work still needs a guild.
                local guildOk = t == 'roadblock' and poster == 'fighters guild' or t ~= 'roadblock' and C.GUILDS[poster]
                ok = on.elite ~= false and guildOk and ctx.DG.eliteIn(region) < C.DANGER.ELITE_PER_REGION
            end
            if ok then
                w = w * TI.weight(tier, region, poster, size)
                if w > 0 then
                    list[#list + 1] = { tier, w }
                    total = total + w
                end
            end
        end
        if total <= 0 then return nil end
        local r = rnd() * total
        for _, e in ipairs(list) do
            r = r - e[2]
            if r <= 0 then return e[1] end
        end
        return list[#list][1]
    end

    -- The band for a dangerous or elite site, from danger.lua with the type's roles.
    local function bandFor(t, tier)
        local B = TYPES[t].band
        if not B then return nil end
        local roles = tier == 'elite' and B.eliteRoles or B.roles
        return ctx.DG.band(tier, { people = B.people }, nil, { roles = roles, followers = B.followers })
    end

    local function bandSize(b)
        return #b.members + (b.champion and 1 or 0) + (b.lieutenant and 1 or 0)
    end

    -- The band's tells, as danger.lua words them: one line per role, the champion's traits, the
    -- lieutenant. a: slots, with the champion's pronouns.
    local function tells(b, a)
        local out, seen, told = {}, {}, {}
        for _, m in ipairs(b.members) do
            local L = m.role and DM.LINES.role[m.role]
            if L and not seen[m.role] then
                seen[m.role] = true
                told[#told + 1] = fill(pick(L, rnd), a)
            end
        end
        if #told > 0 then
            local list = #told == 1 and told[1] or (table.concat(told, ', ', 1, #told - 1) .. ' and ' .. told[#told])
            out[#out + 1] = fill(pick(DM.LINES.survivors, rnd), { list = list })
        end
        for _, k in ipairs(b.champion and b.champion.traits or {}) do out[#out + 1] = fill(ROSTER.TRAITS[k].said, a) end
        if b.lieutenant then out[#out + 1] = fill(pick(DM.LINES.lieutenant, rnd), a) end
        return out
    end

    -- The words of one notice. voice: nil (a townsperson), 'guild' or 'legion', each with its own
    -- body and ask lines where the type has them. extra: lines after the sign, before the ask.
    local function words(t, tier, a, extra, voice)
        local L = M.LINES[t]
        local bodies = forTier(voice and L[voice] or L.body, tier)
        local body = { fill(pick(bodies, rnd), a) }
        local sign = forTier(L.sign, tier)
        if sign then body[#body + 1] = fill(pick(sign, rnd), a) end
        for _, s in ipairs(extra or {}) do body[#body + 1] = fill(s, a) end
        body[#body + 1] = fill(pick(voice and L[voice .. 'Ask'] or L.ask, rnd), a)
        local joined = table.concat(body, ' ')
        return fill(pick(forTier(L.title, tier), rnd), a), ST.shorten({ body = joined, plain = joined }).body
    end

    -- Whether board posters (postersOf) put up open world work of type t.
    local function postsType(posters, t)
        if posters[1] == 'town' then return TYPES[t].notTown ~= true end
        for _, p in ipairs(posters) do
            for _, g in ipairs(TYPES[t].guild or {}) do
                if p == g then return true end
            end
        end
        return false
    end

    -- The poster of type t on a board: 'town' on a town board, else the board's poster the type names.
    local function posterOf(posters, t)
        if posters[1] == 'town' then return 'town' end
        for _, p in ipairs(posters) do
            for _, g in ipairs(TYPES[t].guild or {}) do
                if p == g then return p end
            end
        end
        return nil
    end

    -- One notice of type t at a site, or nil and why.
    local function noticeFor(t, key, player, site, used)
        local T = TYPES[t]
        local level = ctx.playerLevel(player)
        local posters = ctx.postersOf(key) or { 'town' }
        local poster = posterOf(posters, t)
        if not poster then return nil, 'not work this board posts' end
        local voice = (poster == 'legion' and 'legion') or (poster ~= 'town' and 'guild') or nil
        local who
        if poster == 'town' then
            who = person(T.folk, used)
            if not who then return nil, 'no poster free' end
        end
        local region = ctx.regionName(site.x, site.y)
        local tier = tierFor(t, key, player, poster, region)
        if not tier then return nil, 'no tier this board posts' end
        local a = {}
        for k, v in pairs(ST.pronouns(false)) do a[k] = v end
        local id = newId()
        -- Spawns come from the tier's band, not the player's level; `level` stays for the words.
        local lvl = TI.levelIn(tier, rnd)
        local n = { id = id, wild = { type = t, x = site.x, y = site.y, z = site.z, beach = T.site == 'beach', lvl = lvl },
            kind = T.kind, poster = poster, place = 'wild:' .. id, level = level, diff = tier,
            expireDays = math.random(C.EXPIRE_DAYS[1], C.EXPIRE_DAYS[2]) + (tier == 'elite' and 4 or tier == 'dangerous' and 2 or 0) }
        local w = n.wild
        local L = M.LINES[t]
        local title, body, plain, door
        local b
        if T.band and (tier == 'dangerous' or tier == 'elite') then
            b = bandFor(t, tier)
            if not b or not b.champion then return nil, 'no band for ' .. T.band.people end
            w.band, w.lvl = b, b.level
            for k, v in pairs(ST.pronouns(b.champion.female)) do a[k] = v end
            a.Leader, a.Second = b.champion.name, b.lieutenant and b.lieutenant.name
            a.count = countText(bandSize(b) - 1)
        end
        if t == 'caravan' then
            local extra
            if b then
                extra = { pick(L.band, rnd) }
                for _, s in ipairs(tells(b, a)) do extra[#extra + 1] = s end
                plain = L.plain .. ' ' .. fill(L.plainBand, a)
            else
                w.raiders = tier == 'normal' and (2 + rnd(2) - 1) or 0
                extra = { pick(w.raiders > 0 and L.raiders or L.quiet, rnd) }
                plain = L.plain .. (w.raiders > 0 and (' ' .. L.plainRaiders) or '')
            end
            w.raiders = w.raiders or 0
            title, body = words(t, tier, a, extra)
            n.itemName, n.itemPhrase, n.plural = who.last .. "'s Takings", who.last .. "'s takings", true
            door = 'The broken cart'
        elseif t == 'roadblock' then
            local extra
            if b then
                w.leader = { template = b.champion.template, name = b.champion.name, female = b.champion.female }
                extra = tells(b, a)
            else
                local list = ROSTER.people('bandit', TI.band(tier)[2], ctx.have)
                local lead = ROSTER.pick(list, rnd, 4)
                if not lead then return nil, 'no bandits in the catalog' end
                local name = ROSTER.name(lead.race, lead.female, rnd)
                w.leader = { template = lead.id, name = name, female = lead.female == true }
                w.followers = tier == 'easy' and 2 or 5
                for k, v in pairs(ST.pronouns(lead.female == true)) do a[k] = v end
                a.Leader, a.count = name, countText(w.followers)
            end
            title, body = words(t, tier, a, extra, voice)
            plain = fill(forTier(L.plain, tier), a)
            n.itemName, n.itemPhrase = w.leader.name .. "'s Signet", w.leader.name .. "'s signet"
            door = 'The camp'
        elseif t == 'beast' then
            local fams = {}
            local lim = TI.band(tier)
            for _, cr in ipairs(ROSTER.creatures('beast', lim[1], lim[2], ctx.have)) do
                if M.BEAST_FAMILIES[cr.family] then fams[#fams + 1] = cr end
            end
            if #fams == 0 then
                for _, cr in ipairs(ROSTER.creatures('beast', 1, 99, ctx.have)) do
                    if M.BEAST_FAMILIES[cr.family] and cr.level <= lim[2] then fams[#fams + 1] = cr end
                end
            end
            if #fams == 0 then return nil, 'no beast fits' end
            local cr = pick(fams, rnd)
            local name = tier ~= 'normal' and pick(M.BEAST_NAMES, rnd) or nil
            w.beast = { template = cr.id, name = name and cap(name) or cr.name, said = name, family = cr.family }
            a.Name, a.family, a.aFamily = name or cr.family, cr.family, ST.a(cr.family)
            local extra = tier == 'elite' and { pick(L.trophy, rnd) } or nil
            title, body = words(t, tier, a, extra, voice)
            title = cap(title)
            plain = fill(forTier(L.plain, tier), a)
            door = 'Its hunting ground'
        elseif t == 'guar' then
            w.dead = rnd() < 0.3
            title, body = words(t, tier, a, { pick(L.worst, rnd) })
            plain = L.plain
            w.packName = who.last .. "'s Guar Pack"
            door = 'The road where it was seen'
        elseif t == 'smuggler' then
            local extra
            if b then
                extra = { pick(L.guard.dangerous, rnd) }
                for _, s in ipairs(tells(b, a)) do extra[#extra + 1] = s end
            elseif tier == 'normal' then
                w.guards = 1
                extra = { pick(L.guard.normal, rnd) }
            end
            w.guards = w.guards or 0
            title, body = words(t, tier, a, extra)
            plain = L.plain .. ((b or tier == 'normal') and (' ' .. forTier(L.plainGuard, tier)) or '')
            n.itemName, n.itemPhrase, n.plural = 'Smuggled Goods', 'smuggled goods', true
            door = 'The beach'
            who = { from = 'Captain of the Watch', last = 'Watch' }
        elseif t == 'wreck' then
            local ship = pick(M.SHIPS, rnd)
            a.Ship = ship
            w.wreckers = tier == 'normal' and (2 + rnd(2) - 1) or 0
            title, body = words(t, tier, a, w.wreckers > 0 and { pick(L.wreckers, rnd) } or nil)
            plain = fill(L.plain, a) .. (w.wreckers > 0 and (' ' .. L.plainWreckers) or '')
            n.itemName, n.itemPhrase = 'Ledger of the ' .. ship, 'ledger of the ' .. ship
            door = 'The wreckage'
        elseif t == 'gather' then
            -- The region id is already cached by regionName (one load per grid cell, ever). This
            -- used to call getExteriorCell again for the same cell.
            local rid = ctx.regionId and ctx.regionId(site.x, site.y)
            local flora = rid and DATA.flora[rid:lower()]
            local rtext = M.regionText(region)
            if not flora or not rtext then return nil, 'no wild plants known there' end
            local open = {}
            for _, f in ipairs(flora) do
                local r = types.Ingredient.records[f[1]]
                if r and not NOT_GATHERED[f[1]:lower()] then open[#open + 1] = { id = f[1], name = f[2], value = r.value or 1 } end
            end
            if #open == 0 then return nil, 'no plants loaded' end
            local f = pick(open, rnd)
            local many, counted = M.plural(f.name)
            many = N.lower(many)
            local num = WC.GATHER[1] + rnd(WC.GATHER[2] - WC.GATHER[1] + 1) - 1
            local count = counted and (ST.number(num) .. ' ' .. many) or (ST.number(num) .. ' handfuls of ' .. many)
            a.count, a.region, a.item, a.Item = count, rtext, many, cap(many)
            if poster == 'mages guild' then
                title = fill(pick(L.title, rnd), a)
                body = fill(L.guild, a) .. ' ' .. fill(pick(L.ask, rnd), a)
            else
                title, body = words(t, tier, a)
            end
            plain = fill(L.plain, a)
            w.ingredient, w.count = f.id, num
            n.itemName, n.itemPhrase, n.plural = cap(many), many, true
            local value = Q.each(f.value, C.REQ.PREMIUM.common[2]) * num + C.REQ.FEE.common
            tier = value > WC.GATHER_NORMAL and 'normal' or 'easy'
            n.diff, w.lvl, n.value = tier, TI.levelIn(tier, rnd), math.min(value, TI.cap(tier))
            door = 'The nearest good patch'
        elseif t == 'patrol' then
            if #npcs(LEGION) == 0 then return nil, 'no Legion soldiers in the load order' end
            local extra
            if b then
                extra = { pick(L.band, rnd) }
                for _, s in ipairs(tells(b, a)) do extra[#extra + 1] = s end
                plain = L.plain .. ' ' .. fill(L.plainBand, a)
            else
                w.ambushers = tier == 'normal' and 3 or 0
                extra = { pick(tier == 'normal' and L.still or L.gone, rnd) }
                plain = L.plain .. (tier == 'normal' and (' ' .. L.plainStill) or '')
            end
            w.ambushers = w.ambushers or 0
            w.fallen = 2 + rnd(2) - 1
            title, body = words(t, tier, a, extra, 'legion')
            n.itemName, n.itemPhrase = 'Legion Supply Crate', 'Legion supply crate'
            door = 'The overturned cart'
        elseif t == 'traveller' then
            local list = npcs(TRAVELLERS)
            if #list == 0 then return nil, 'no travellers in the load order' end
            local tpl = pick(list, rnd)
            local female = tpl.f == true
            local name = ROSTER.name('dark elf', female, rnd)
            w.traveller = { template = tpl[1], name = name, female = female }
            w.fate = tier == 'easy' and (rnd() < 0.5 and 'dead' or 'hiding') or 'taken'
            w.captors = tier == 'normal' and 3 or 0
            if b then w.captors = 0 end
            local ta = {}
            for k, v in pairs(ST.pronouns(female)) do ta[k] = v end
            ta.Traveller, ta.kin = name, female and 'sister' or 'brother'
            title, body = words(t, tier, ta, tier ~= 'easy' and { pick(L.trouble, rnd) } or nil)
            plain = fill(L.plain, ta) .. (tier ~= 'easy' and (' ' .. L.plainTrouble) or '')
            w.ringName = name .. "'s Ring"
            door = 'The road ' .. (female and 'she' or 'he') .. ' took'
        elseif t == 'drive' then
            local k = WC.DRIVE.GUAR[1] + rnd(WC.DRIVE.GUAR[2] - WC.DRIVE.GUAR[1] + 1) - 1
            w.herdSize, w.lurkers = k, LURKERS[tier] or 1
            a.count = ST.number(k)
            title, body = words(t, tier, a, { pick(forTier(L.lurk, tier), rnd) })
            plain = fill(L.plain, a)
            door = 'The herder\'s camp'
        elseif t == 'graverobber' or t == 'ritual' or t == 'piratecove' or t == 'pirate' then
            local extra
            local group = T.band.people
            if b then
                w.leader = { template = b.champion.template, name = b.champion.name, female = b.champion.female }
                extra = tells(b, a)
            else
                local list = ROSTER.people(group, TI.band(tier)[2], ctx.have)
                local lead = ROSTER.pick(list, rnd, 4)
                if not lead then return nil, 'no ' .. group .. ' in the catalog' end
                local name = ROSTER.name(lead.race, lead.female, rnd)
                w.leader = { template = lead.id, name = name, female = lead.female == true }
                w.followers = (T.band.followers and T.band.followers[1] or 2)
                    + (tier == 'easy' and 0 or 2)
                for k, v in pairs(ST.pronouns(lead.female == true)) do a[k] = v end
                a.Leader, a.count = name, countText(w.followers)
            end
            title, body = words(t, tier, a, extra, voice)
            plain = fill(forTier(L.plain, tier), a)
            n.itemName, n.itemPhrase = w.leader.name .. "'s Hat", w.leader.name .. "'s hat"
            door = t == 'ritual' and 'The ring of candles' or t == 'graverobber' and 'The tomb door' or 'The camp on the shore'
        elseif t == 'machine' or t == 'summon' then
            local group = t == 'machine' and 'dwemer' or 'daedra'
            local family = t == 'machine' and 'centurions' or 'atronachs'
            local lim = TI.band(tier)
            local fams = ROSTER.creatures(group, lim[1], lim[2], ctx.have, family)
            if #fams == 0 then fams = ROSTER.creatures(group, lim[1], lim[2], ctx.have) end
            if #fams == 0 then return nil, 'no ' .. group .. ' fits' end
            local cr = pick(fams, rnd)
            w.beast = { template = cr.id, name = cr.name, family = cr.family }
            a.Name, a.family, a.aFamily = cr.name, cr.family or group, ST.a(cr.family or group)
            title, body = words(t, tier, a, nil, voice)
            plain = fill(forTier(L.plain, tier), a)
            door = t == 'machine' and 'The road by the ruin' or 'The hills by the tower'
        elseif t == 'tax' then
            w.raiders = tier ~= 'easy' and (2 + rnd(2) - 1) or 0
            local extra = w.raiders > 0 and { pick(L.still, rnd) } or nil
            title, body = words(t, tier, a, extra, 'legion')
            plain = L.plain .. (w.raiders > 0 and (' ' .. L.still[1]) or '')
            n.itemName, n.itemPhrase = 'Imperial Tax Chest', 'tax chest'
            door = 'The wrecked wagon'
        end
        n.title, n.body, n.plain = cap(title), body, cap(plain)
        if poster == 'legion' then
            n.from = S().boards[key] and S().boards[key].signer or 'The Quartermaster'
        else
            n.from = who and who.from or (poster == 'mages guild' and 'Steward of the Mages Guild')
                or (poster == 'fighters guild' and 'Steward of the Fighters Guild') or 'A neighbour'
        end
        n.where = ctx.siteDirections(key, site.x, site.y, door)
        n.value = n.value or TI.value(n.diff, T.share or 0.6, nil, nil, rnd())
        n.reward, n.skill = payFor(id, n.value, n.diff, poster, who and who.trade, player)
        n.seal = C.DANGER.SEAL[n.diff]
        n.region, w.region = region, region
        return n
    end

    function W.switchedOn(n)
        return not n.wild or ctx.featureOn[TYPES[n.wild.type].feature] ~= false
    end

    -- At a board roll: up to want open world notices (board.lua room). A board with none up posts
    -- one WILD.CHANCE of the time; one that already has one, another WILD.SECOND of the time.
    function W.post(key, player, notices, want)
        local up = 0
        for _, x in ipairs(notices) do if x.wild then up = up + 1 end end
        for _ = 1, want or 1 do
            if rnd() >= (up == 0 and WC.CHANCE or WC.SECOND) then return end
            if not W.postOne(key, player, notices) then return end
            up = up + 1
        end
    end

    -- One open world notice; true when one went up.
    function W.postOne(key, player, notices)
        if #W.missing() > 0 then
            if not warned then
                warned = true
                ctx.tell(player, 'Odd Jobs: open world jobs need Tamriel Rebuilt and Tamriel Data, and are off.')
            end
            return
        end
        local ox, oy = ctx.boardOrigin(key)
        if not ox then return end
        local posters = ctx.postersOf(key) or { 'town' }
        local open, total = {}, 0
        local fresh = { last = S().boards[key] and S().boards[key].lastKind, done = S().doneKinds or {},
            finished = S().finished or 0, at = S().freshAt or {}, now = ctx.now() }
        for _, t in ipairs(M.ORDER) do
            if ctx.featureOn[TYPES[t].feature] ~= false and postsType(posters, t) then
                if TYPES[t].night and not isNight() then
                    -- Night work is posted at night, not rolled in daylight.
                elseif TYPES[t].storm and not stormy(ox, oy) then
                    -- Storm work waits for rain.
                else
                    local w = (TYPES[t].weight or 1) * FR.weight(t, fresh)
                    if w > 0 then
                        open[#open + 1] = { t = t, w = w }
                        total = total + w
                    end
                end
            end
        end
        if total <= 0 then return end
        local used = ctx.usedOn(key)
        local why
        for _ = 1, 3 do
            local r, t = rnd() * total, open[#open].t
            for _, e in ipairs(open) do
                r = r - e.w
                if r <= 0 then t = e.t break end
            end
            local sites = sitesNear(listFor(TYPES[t].site), ox, oy, TYPES[t].maxCells)
            -- Roads and beaches have a farther list in the wild data; tomb doors and ruins do not.
            local far = DATA[TYPES[t].site]
            if far and #sites < WC.FEW and not TYPES[t].maxCells then
                sites = sitesNear(far, ox, oy, WC.FAR_CELLS)
            end
            if #sites > 0 then
                local site = pick(sites, rnd)
                local n
                n, why = noticeFor(t, key, player, site, used)
                if n then
                    remember(site)
                    notices[#notices + 1] = n
                    local b = S().boards[key]
                    if b then b.lastKind = t end
                    ctx.DG.elitePosted(n)
                    ctx.say('%s: open world notice %d (%s, %s) at %d, %d, in %s', key, n.id, t, n.diff, site.x, site.y,
                        tostring(n.region))
                    return true
                end
            else
                why = 'no ' .. TYPES[t].site .. ' point in reach'
            end
            ctx.log('%s: no %s notice (%s)', key, t, tostring(why))
        end
    end

    -- Taking a wild notice: the contract, with its items made now and nothing in the world yet.
    function W.take(n, key)
        local w = n.wild
        local cw = {}
        for k, v in pairs(w) do cw[k] = v end
        cw.state, cw.asks = 'wait', 0
        local c = {
            id = n.id, kind = n.kind, poster = n.poster, place = n.place, board = key,
            title = n.title, body = n.body, plain = n.plain, where = n.where, from = n.from,
            level = n.level, value = n.value, reward = n.reward, skill = n.skill, diff = n.diff, seal = n.seal,
            region = n.region, takenAt = ctx.now(), expiresAt = ctx.now() + n.expireDays, state = 'active',
            px = w.x, py = w.y, itemName = n.itemName, itemPhrase = n.itemPhrase, plural = n.plural, wild = cw,
        }
        local t = w.type
        if t == 'caravan' or t == 'smuggler' then
            c.item = ctx.makeItem('ojb_goods', n.itemName)
        elseif t == 'roadblock' then
            c.item = ctx.makeItem(C.SIGNET_BASE, n.itemName)
        elseif t == 'wreck' then
            c.item = ctx.makeItem('ojb_ledger', n.itemName)
        elseif t == 'patrol' then
            c.item = ctx.makeItem('ojb_goods', n.itemName)
        elseif t == 'guar' then
            cw.pack = ctx.makeItem('ojb_goods', w.packName)
        elseif t == 'gather' then
            cw.state = 'made'
        elseif t == 'beast' and n.diff == 'elite' then
            local base = types.Miscellaneous.records[TROPHY_BASE]
            if base then
                local s = S()
                s.madeRecords = (s.madeRecords or 0) + 1
                cw.trophy = world.createRecord(types.Miscellaneous.createRecordDraft({ template = base,
                    name = 'Skull of ' .. (w.beast.said or w.beast.name), value = WC.TROPHY })).id
            end
        elseif t == 'traveller' then
            cw.ring = ctx.makeItem('ojb_ring_family', w.ringName)
            if w.fate == 'dead' then
                c.item, c.itemName, c.itemPhrase = cw.ring, w.ringName, w.ringName
                cw.letter = ctx.makeBook(w.traveller.name .. "'s Letter", M.LINES.found.letter)
            end
        elseif t == 'drive' then
            cw.pen = 'wait'
        elseif t == 'graverobber' or t == 'ritual' or t == 'piratecove' or t == 'pirate' then
            c.item = ctx.makeItem('ojb_hat', n.itemName)
        elseif t == 'tax' then
            c.item = ctx.makeItem('ojb_goods', n.itemName)
        end
        S().contracts[c.id] = c
        ctx.say('contract %d taken: open world %s (%s) at %d, %d', c.id, t, tostring(c.diff), w.x, w.y)
        return c
    end

    local function fail(c, player, why, line)
        ctx.tell(player, line or M.LINES.found.void)
        ctx.dropContract(c, why)
        player:sendEvent('OJB_Contracts', { held = ctx.heldCount() })
    end

    local function down(o)
        return not o or not o:isValid() or o.count == 0 or (types.Actor.objectIsInstance(o) and types.Actor.isDead(o))
    end

    local function yawAt() return rnd() * 2 * math.pi end

    local function at(spot) return { x = spot.x, y = spot.y, z = spot.z } end

    -- The spawner's cap for this job: a dangerous or elite site gets that tier's, the rest 'wild'.
    local function capOf(c)
        return (c.diff == 'dangerous' or c.diff == 'elite') and c.diff or 'wild'
    end

    local function placeProp(c, id, spot, role)
        if not id or not spot then return nil end
        return ctx.SP.prop(c.id, { id = id, cell = '', pos = at(spot), yaw = yawAt(), tier = 'wild', role = role })
    end

    local function actorSpec(id, spot, role, act, items)
        return { id = id, cell = '', pos = at(spot), yaw = yawAt(), role = role, act = act or { fight = 100 },
            items = items or {} }
    end

    local function people(group, level, n, spots, from, role, act)
        local list = ROSTER.people(group, level, ctx.have)
        local specs = {}
        for i = 1, n do
            local t = ROSTER.pick(list, rnd, 6)
            local spot = spots[from + i - 1]
            if not t or not spot then break end
            local a = {}
            for k, v in pairs(act or { fight = 100 }) do a[k] = v end
            specs[#specs + 1] = actorSpec(t.id, spot, role or 'follower', a)
        end
        return specs
    end

    local function kitSpec(id, spot, role, k, extra)
        local s = actorSpec(id, spot, role)
        for _, it in ipairs(k and k.items or {}) do s.items[#s.items + 1] = it end
        for _, it in ipairs(extra or {}) do s.items[#s.items + 1] = it end
        if k and #k.spells > 0 then s.act.spells = k.spells end
        if k and #k.equip > 0 then s.act.equip = k.equip end
        return s
    end

    -- A band at spots[from...]: the champion now, carrying `carry`, the lieutenant now, the rest
    -- queued. Returns the champion (nil when it could not be made) and the next free spot.
    local function makeBand(c, b, spots, from, carry)
        local capT = capOf(c)
        local leader
        local i = from
        if b.champion and spots[i] then
            local ch = b.champion
            local id = ctx.SP.record(ch.template, ch.name, types.NPC)
            local s = id and kitSpec(id, spots[i], 'leader', ch.kit, carry)
            if s and not b.contract then s.act.health = C.DANGER.HEALTH end
            if s and ch.skillName then s.act.skill, s.act.skillAt = ch.skillName, ch.skillAt end
            if s and b.contract then s.strip = true end
            leader = s and ctx.SP.actor(c.id, capT, s)
            i = i + 1
            if b.lieutenant and spots[i] then
                local lt = b.lieutenant
                local lid = ctx.SP.record(lt.template, lt.name, types.NPC)
                local ls = lid and kitSpec(lid, spots[i], 'lieutenant', lt.kit)
                if ls and b.contract then ls.strip = true end
                if ls and lt.skillName then ls.act.skill, ls.act.skillAt = lt.skillName, lt.skillAt end
                if ls then ctx.SP.actor(c.id, capT, ls) end
                i = i + 1
            end
        end
        local specs = {}
        for _, m in ipairs(b.members) do
            if not spots[i] then break end
            local s = kitSpec(m.id, spots[i], m.role or (m.creature and 'beast' or 'follower'), m.kit)
            if b.contract then s.strip = true end
            if m.skillName then s.act.skill, s.act.skillAt = m.skillName, m.skillAt end
            specs[#specs + 1] = s
            i = i + 1
        end
        ctx.SP.queue(c.id, capT, specs)
        return leader, i
    end

    -- A container of our own, named, so "Strongbox" reads right; the template if drafts fail.
    local function namedChest(name)
        local base = prop('chest')
        if not base then return nil end
        local key = base .. '|' .. name
        local recs = S().recs or {}
        S().recs = recs
        if recs[key] then return recs[key] end
        local tpl = types.Container.records[base]
        local saved = S()
        saved.madeRecords = (saved.madeRecords or 0) + 1
        local id = world.createRecord(types.Container.createRecordDraft({ template = tpl, name = name })).id
        recs[key] = id
        return id
    end

    -- An item lying loose in the world (the wreck's ledger, the patrol's crate); removed with the job.
    local function loose(c, id, spot)
        local item = world.createObject(id)
        item:teleport('', util.vector3(spot.x, spot.y, spot.z + 4), { rotation = util.transform.rotateZ(yawAt()) })
        c.wild.loose = item
        return item
    end

    -- Lurkers and drive beasts: predators of the tier's band.
    local function predators(tier, n)
        local lim = TI.band(tier)
        local list = {}
        for _, cr in ipairs(ROSTER.creatures('beast', lim[1], lim[2], ctx.have)) do
            if M.BEAST_FAMILIES[cr.family] then list[#list + 1] = cr end
        end
        if #list == 0 then list = ROSTER.creatures('beast', lim[1], lim[2], ctx.have) end
        local out = {}
        for i = 1, n do out[i] = list[1] and pick(list, rnd) or nil end
        return out
    end

    -- How many spots each type asks for, and the fewest it can be made with. Spots are used in
    -- order of need (the job's item and its holder first), so a short answer drops scenery.
    local function wanted(c)
        local w, t = c.wild, c.wild.type
        local b = w.band
        if t == 'caravan' then
            return 5 + (b and (1 + bandSize(b)) or w.raiders > 0 and (w.raiders + 1) or 0), 3
        elseif t == 'roadblock' then
            if b then return 2 + bandSize(b) + (c.diff == 'elite' and 8 or 6), 2 end
            return 2 + w.followers + (c.diff == 'easy' and 1 or 2), 2
        elseif t == 'smuggler' then
            return 1 + (b and bandSize(b) or w.guards), 1
        elseif t == 'wreck' then
            return 6 + w.wreckers, 2
        elseif t == 'patrol' then
            return 2 + w.fallen + (b and bandSize(b) or w.ambushers), 2
        elseif t == 'traveller' then
            return 3 + (b and bandSize(b) or w.captors), 1
        elseif t == 'drive' then
            return 2 + w.lurkers, 1
        elseif t == 'graverobber' or t == 'ritual' or t == 'piratecove' or t == 'pirate' then
            if b then return 2 + bandSize(b) + (t == 'ritual' and 6 or 3), 2 end
            return 2 + (w.followers or 2) + (t == 'ritual' and 6 or 2), 2
        elseif t == 'tax' then
            return 5 + (w.raiders or 0), 3
        end
        return 1, 1
    end

    local function make(c, player, spots)
        local w, t = c.wild, c.wild.type
        local level = w.lvl or ctx.playerLevel(player)
        local capT = capOf(c)
        local b = w.band
        if t == 'caravan' then
            placeProp(c, prop('cart'), spots[1], 'cart')
            local box = placeProp(c, namedChest('Strongbox') or prop('chest'), spots[2], 'strongbox')
            if not box then return false end
            world.createObject(c.item):moveInto(types.Container.content(box))
            placeProp(c, prop('crate'), spots[3], 'crate')
            placeProp(c, prop('wheel'), spots[4], 'wheel')
            local guar = prop('guar')
            if guar and spots[5] then
                ctx.SP.actor(c.id, capT, actorSpec(guar, spots[5], 'dead guar', { fight = 0, kill = true }))
            end
            if spots[6] and (b or w.raiders > 0) then
                placeProp(c, prop('fire'), spots[6], 'fire')
                if b then makeBand(c, b, spots, 7)
                else ctx.SP.queue(c.id, capT, people('bandit', level, w.raiders, spots, 7)) end
            end
        elseif t == 'roadblock' then
            placeProp(c, prop('fire'), spots[1], 'fire')
            local leader, i
            if b then
                leader, i = makeBand(c, b, spots, 2, { c.item })
            else
                local L = w.leader
                local id = ctx.SP.record(L.template, L.name, types.NPC)
                leader = id and spots[2] and ctx.SP.actor(c.id, capT, actorSpec(id, spots[2], 'leader', { fight = 100 }, { c.item }))
                if leader then
                    ctx.SP.queue(c.id, capT, people('bandit', level, w.followers, spots, 3))
                end
                i = 3 + w.followers
            end
            if not leader then return false end
            c.leader = leader
            local scenery = { 'crate' }
            if c.diff ~= 'easy' then scenery[#scenery + 1] = 'tent' end
            if b then
                for _, k in ipairs({ 'tent', 'fence', 'fence', 'fence', 'stake' }) do scenery[#scenery + 1] = k end
                if c.diff == 'elite' then scenery[#scenery + 1], scenery[#scenery + 2] = 'fire', 'stake' end
            end
            for _, k in ipairs(scenery) do
                if not spots[i] then break end
                placeProp(c, prop(k), spots[i], k)
                i = i + 1
            end
        elseif t == 'beast' or t == 'machine' or t == 'summon' then
            local B = w.beast
            local id = ctx.SP.record(B.template, B.name, types.Creature)
            local tune = WC.BEAST[c.diff] or WC.BEAST.normal
            local beast = id and ctx.SP.actor(c.id, capT, actorSpec(id, spots[1], 'beast',
                { fight = 100, health = tune.health, wander = 1200 }, w.trophy and { w.trophy } or nil))
            if not beast then return false end
            if t == 'beast' and tune.scale ~= 1 then beast:setScale(tune.scale) end
            c.leader = beast
        elseif t == 'graverobber' or t == 'ritual' or t == 'piratecove' or t == 'pirate' then
            local group = TYPES[t].band.people
            if t == 'ritual' then
                for i = 1, 4 do
                    if spots[i] then placeProp(c, prop('candle'), spots[i], 'candle') end
                end
            else
                placeProp(c, prop('fire'), spots[1], 'fire')
            end
            local leader, i
            local start = t == 'ritual' and 5 or 2
            if b then
                leader, i = makeBand(c, b, spots, start, { c.item })
            else
                local L = w.leader
                local id = ctx.SP.record(L.template, L.name, types.NPC)
                leader = id and spots[start] and ctx.SP.actor(c.id, capT, actorSpec(id, spots[start], 'leader', { fight = 100 }, { c.item }))
                if leader then
                    ctx.SP.queue(c.id, capT, people(group, level, w.followers, spots, start + 1))
                end
                i = start + 1 + (w.followers or 0)
            end
            if not leader then return false end
            c.leader = leader
            w.madeAt = ctx.now()
            if t ~= 'ritual' then
                for _, k in ipairs({ 'crate', 'tent' }) do
                    if not spots[i] then break end
                    placeProp(c, prop(k), spots[i], k)
                    i = i + 1
                end
            end
        elseif t == 'tax' then
            placeProp(c, prop('cart'), spots[1], 'cart')
            local box = placeProp(c, namedChest('Tax Chest') or prop('chest'), spots[2], 'strongbox')
            if not box then return false end
            world.createObject(c.item):moveInto(types.Container.content(box))
            placeProp(c, prop('crate'), spots[3], 'crate')
            placeProp(c, prop('wheel'), spots[4], 'wheel')
            if spots[5] and (w.raiders or 0) > 0 then
                placeProp(c, prop('fire'), spots[5], 'fire')
                ctx.SP.queue(c.id, capT, people('bandit', level, w.raiders, spots, 6))
            end
        elseif t == 'guar' then
            local id = prop('guar')
            local act = w.dead and { fight = 0, kill = true } or { fight = 0, wander = 400 }
            local guar = id and ctx.SP.actor(c.id, capT, actorSpec(id, spots[1], 'guar', act, { w.pack }))
            if not guar then return false end
            c.leader = guar
        elseif t == 'smuggler' then
            local crate = placeProp(c, prop('crate'), spots[1], 'drop')
            if not crate then return false end
            local inv = types.Container.content(crate)
            world.createObject(c.item):moveInto(inv)
            for _, cb in ipairs(CONTRABAND) do
                if exists(cb[1]) or (types.Potion.records[cb[1]] or types.Ingredient.records[cb[1]]) then
                    world.createObject(cb[1], cb[2] + rnd(cb[3] - cb[2] + 1) - 1):moveInto(inv)
                end
            end
            if b then makeBand(c, b, spots, 2)
            elseif w.guards > 0 then
                ctx.SP.queue(c.id, capT, people('smuggler', level, w.guards, spots, 2, 'lookout', { fight = 30 }))
            end
        elseif t == 'wreck' then
            loose(c, c.item, spots[1])
            for i = 2, 4 do placeProp(c, pick(PROPS.plank, rnd), spots[i], 'plank') end
            placeProp(c, prop('crate'), spots[5], 'crate')
            placeProp(c, prop('crate'), spots[6], 'crate')
            if w.wreckers > 0 then ctx.SP.queue(c.id, capT, people('smuggler', level, w.wreckers, spots, 7)) end
        elseif t == 'patrol' then
            loose(c, c.item, spots[1])
            placeProp(c, prop('cart'), spots[2], 'cart')
            local soldiers = npcs(LEGION)
            local i = 3
            for _ = 1, w.fallen do
                if not spots[i] or #soldiers == 0 then break end
                ctx.SP.actor(c.id, capT, actorSpec(pick(soldiers, rnd), spots[i], 'dead soldier', { fight = 0, kill = true }))
                i = i + 1
            end
            if b then makeBand(c, b, spots, i)
            elseif w.ambushers > 0 then ctx.SP.queue(c.id, capT, people('bandit', level, w.ambushers, spots, i)) end
        elseif t == 'traveller' then
            local T = w.traveller
            local id = ctx.SP.record(T.template, T.name, types.NPC)
            local items = { w.ring }
            local act = { fight = 0, calm = true }
            if w.fate == 'dead' then
                act = { fight = 0, kill = true }
                items[#items + 1] = w.letter
            elseif w.fate == 'hiding' then
                act.health = 0.5
            end
            local p = id and ctx.SP.actor(c.id, capT, actorSpec(id, spots[1], 'traveller', act, items))
            if not p then return false end
            c.leader = p
            placeProp(c, prop(w.fate == 'dead' and 'sack' or 'bedroll'), spots[2], 'camp')
            if w.fate == 'taken' then
                placeProp(c, prop('fire'), spots[3], 'fire')
                if b then makeBand(c, b, spots, 4)
                else ctx.SP.queue(c.id, capT, people('bandit', level, w.captors, spots, 4, 'captor')) end
            end
        elseif t == 'drive' then
            placeProp(c, prop('tent'), spots[1], 'tent')
            placeProp(c, prop('fire'), spots[2], 'fire')
            local specs = {}
            for i, cr in ipairs(predators(c.diff, w.lurkers)) do
                if not spots[2 + i] then break end
                specs[#specs + 1] = actorSpec(cr.id, spots[2 + i], 'lurker', { fight = 100, wander = 600 })
            end
            ctx.SP.queue(c.id, capT, specs)
        end
        w.state = 'made'
        ctx.say('contract %d: open world %s (%s) made from %d spots', c.id, t, tostring(c.diff), #spots)
        return true
    end

    local function nearSite(c, player)
        local cell = player.cell
        if not cell or not cell.isExterior then return false end
        local p = player.position
        local dx, dy = p.x - c.wild.x, p.y - c.wild.y
        return dx * dx + dy * dy < WC.NEAR * WC.NEAR
    end

    local function night()
        return isNight()
    end

    local ASKS = 6
    local function ask(c, player)
        local w = c.wild
        if w.state == 'asked' and not ctx.SP.waiting('wild:' .. c.id) then w.state = 'wait' end
        if w.state ~= 'wait' or not nearSite(c, player) then return end
        if (w.type == 'smuggler' or TYPES[w.type].night) and not night() then
            if not w.toldNight then
                w.toldNight = true
                ctx.tell(player, M.LINES.found.night)
            end
            return
        end
        if w.asks >= ASKS then fail(c, player, 'no ground for the site') return end
        local n, least = wanted(c)
        w.state, w.asks = 'asked', w.asks + 1
        local anchor = { x = w.x, y = w.y, z = w.z }
        ctx.SP.ask(player, 'wild:' .. c.id, { outdoor = true, beach = w.beach, road = anchor, anchors = { anchor },
            radius = w.beach and WC.SPOT_RADIUS or 500, n = n, away = 300 }, function(e)
            if ctx.S().contracts[c.id] ~= c or c.state ~= 'active' then return end
            local spots = e.spots or {}
            if #spots < least then
                w.state = 'wait'
                ctx.log('contract %d: %d spots of %d needed for the %s (%s)', c.id, #spots, least, w.type,
                    tostring(e.tried))
                return
            end
            if not make(c, player, spots) then
                ctx.SP.release(c.id)
                w.state = 'wait'
            end
        end)
    end

    -- Whether every actor of the job but the traveller is down.
    local function captorsDown(c)
        for _, e in ipairs(ctx.SP.list(c.id)) do
            if e.kind == 'actor' and e.role ~= 'traveller' and not down(e.obj) then return false end
        end
        return true
    end

    local function closeTo(a, b, d)
        return a.cell == b.cell and (a.position - b.position):length() < d
    end

    local function home(c, obj)
        local ox, oy = ctx.boardOrigin(c.board)
        if not ox then return false end
        local dx, dy = obj.position.x - ox, obj.position.y - oy
        return dx * dx + dy * dy < WC.GUAR_HOME * WC.GUAR_HOME
    end

    -- The traveller: found dead (their ring is the job from the start), hiding, or held until the
    -- captors are down; then walked home. Dying on the way makes the ring the job, for half.
    local function travellerStep(c, player, inv)
        local w, p = c.wild, c.leader
        local a = { Traveller = w.traveller.name }
        for k, v in pairs(ST.pronouns(w.traveller.female)) do a[k] = v end
        if c.item then
            if w.fate == 'dead' and p and p:isValid() and not w.toldFound and closeTo(p, player, 400) then
                w.toldFound = true
                ctx.tell(player, fill(M.LINES.found.travDead, a))
            end
            if inv:countOf(c.item) > 0 then ctx.complete(c, player) end
            return
        end
        if not p or not p:isValid() or types.Actor.isDead(p) then
            c.item, c.itemName, c.itemPhrase, w.share = w.ring, w.ringName, w.ringName, 0.5
            ctx.tell(player, fill(M.LINES.found.travDied, a))
            return
        end
        if not w.following then
            if not closeTo(p, player, 400) then return end
            if w.fate == 'taken' and not captorsDown(c) then
                if not w.toldFound then
                    w.toldFound = true
                    ctx.tell(player, fill(M.LINES.found.travTaken, a))
                end
                return
            end
            w.following = true
            ctx.SP.tell(p, { follow = player })
            ctx.tell(player, fill(w.fate == 'taken' and M.LINES.found.travFreed or M.LINES.found.travHiding, a))
        end
        if home(c, p) then ctx.complete(c, player) end
    end

    -- The drive's guar: made by the player outside town, then walked to the camp, which is made when
    -- the player comes near it. Done when every living guar is at the camp; paid for those.
    local function driveStep(c, player)
        local w = c.wild
        if w.pen == 'asked' and not ctx.SP.waiting('wild:' .. c.id .. ':pen') then w.pen = 'wait' end
        if w.pen == 'wait' then
            local cell = player.cell
            local ox, oy = ctx.boardOrigin(c.board)
            if not ox or not cell or not cell.isExterior then return end
            local dx, dy = player.position.x - ox, player.position.y - oy
            if dx * dx + dy * dy > WC.DRIVE.START * WC.DRIVE.START then return end
            local id = prop('guar')
            if not id then fail(c, player, 'no guar in the load order') return end
            w.pen = 'asked'
            local pos = player.position
            ctx.SP.ask(player, 'wild:' .. c.id .. ':pen', { outdoor = true, anchors = { { x = pos.x, y = pos.y, z = pos.z } },
                radius = 600, n = w.herdSize, away = 250 }, function(e)
                if ctx.S().contracts[c.id] ~= c or c.state ~= 'active' then return end
                local spots = e.spots or {}
                if #spots == 0 then w.pen = 'wait' return end
                w.herd = {}
                for i = 1, math.min(#spots, w.herdSize) do
                    local g = ctx.SP.actor(c.id, capOf(c), actorSpec(id, spots[i], 'drove guar', { fight = 0 }))
                    if g then
                        w.herd[#w.herd + 1] = g
                        ctx.SP.tell(g, { follow = player })
                    end
                end
                w.herdSize, w.pen = #w.herd, 'made'
                ctx.tell(player, M.LINES.found.driveStart)
            end)
            return
        end
        if w.pen ~= 'made' then return end
        if w.state ~= 'made' then ask(c, player) end
        local alive, there = 0, 0
        for _, g in ipairs(w.herd or {}) do
            if not down(g) then
                alive = alive + 1
                local dx, dy = g.position.x - w.x, g.position.y - w.y
                if g.cell and g.cell.isExterior and dx * dx + dy * dy < WC.DRIVE.CAMP * WC.DRIVE.CAMP then there = there + 1 end
            end
        end
        if alive == 0 then fail(c, player, 'every guar dead', M.LINES.found.driveLost) return end
        if w.state == 'made' and there == alive then
            w.share = there / math.max(1, w.herdSize)
            ctx.complete(c, player)
        end
    end

    -- From global.lua's contract check, every poll while contracts are held.
    function W.step(c, player)
        if c.state ~= 'active' then return end
        local w = c.wild
        local inv = types.Actor.inventory(player)
        if w.type == 'gather' then
            if inv:countOf(w.ingredient) >= w.count then ctx.complete(c, player) end
            return
        end
        if w.type == 'drive' then return driveStep(c, player) end
        if w.state ~= 'made' then
            ask(c, player)
            if w.state ~= 'made' then return end
        end
        local t = w.type
        if t == 'roadblock' or t == 'graverobber' or t == 'piratecove' or t == 'pirate' then
            if down(c.leader) and inv:countOf(c.item) > 0 then ctx.complete(c, player) end
        elseif t == 'ritual' then
            if not w.called and w.madeAt and (ctx.now() - w.madeAt) >= WC.RITUAL_DAYS then
                w.called = true
                local lim = TI.band(c.diff)
                local list = ROSTER.creatures('daedra', lim[1], lim[2], ctx.have, 'atronachs')
                if #list == 0 then list = ROSTER.creatures('daedra', lim[1], lim[2], ctx.have) end
                local cr = list[1]
                if cr then
                    local id = ctx.SP.record(cr.id, cr.name, types.Creature)
                    if id then
                        ctx.SP.actor(c.id, capOf(c), actorSpec(id, { x = w.x, y = w.y, z = w.z }, 'called',
                            { fight = 100, wander = 800 }))
                    end
                end
                ctx.tell(player, M.LINES.found.called)
            end
            if down(c.leader) and inv:countOf(c.item) > 0 then ctx.complete(c, player) end
        elseif t == 'beast' or t == 'machine' or t == 'summon' then
            if down(c.leader) then ctx.complete(c, player) end
        elseif t == 'traveller' then
            travellerStep(c, player, inv)
        elseif t == 'guar' then
            local g = c.leader
            if not c.item and g and g:isValid() and types.Actor.isDead(g) then
                c.item, c.itemName, c.itemPhrase, c.kind = w.pack, w.packName, w.packName:lower(), 'recovery'
                c.wild.share = 0.5
                ctx.tell(player, M.LINES.found.guarDead)
            end
            if c.item then
                if inv:countOf(c.item) > 0 then ctx.complete(c, player) end
            elseif g and g:isValid() and g.count > 0 then
                local d = (g.position - player.position):length()
                if not w.following and d < 300 and g.cell == player.cell then
                    w.following = true
                    ctx.SP.tell(g, { follow = player })
                    ctx.tell(player, M.LINES.found.guar)
                end
                if w.following and home(c, g) then ctx.complete(c, player) end
            end
        elseif inv:countOf(c.item) > 0 then
            ctx.complete(c, player)
        end
    end

    -- Hand-in: gathered plants are counted and taken; the rest goes through the core's item check.
    -- Returns false when the player no longer carries enough; else true and the share of the pay.
    function W.handInItems(c, inv)
        local w = c.wild
        if w.type ~= 'gather' then return true, w.share or 1 end
        if inv:countOf(w.ingredient) < w.count then return false end
        local left = w.count
        while left > 0 do
            local x = inv:find(w.ingredient)
            if not x then break end
            local k = math.min(left, x.count)
            x:remove(k)
            left = left - k
        end
        return true, 1
    end

    -- A contract ending any way: a loose item (ledger, supply crate), if it still lies out there.
    function W.dropped(c)
        local lo = c.wild and c.wild.loose
        if lo and lo:isValid() and lo.count > 0 then lo:remove() end
    end

    function W.featureOf(n) return n.wild and TYPES[n.wild.type].feature end

    return W
end

return M
