---@omw-context load
-- Records made once at startup, as if a plugin defined them; nothing here is stored in saves.
-- Notices are activators with the vanilla note and parchment meshes, so clicking any paper opens
-- the board. The fallback board's planks are activators too; its posts are statics.
-- Contract items are bases: global.lua makes each contract's own named copy at take time.

local content = require('openmw.content')

local statics = content.statics.records
local activators = content.activators.records

activators.ojb_notice_parch1 = { model = 'meshes/m/text_parchment_01.nif', name = 'Notices' }
activators.ojb_notice_parch2 = { model = 'meshes/m/text_parchment_02.nif', name = 'Notices' }
activators.ojb_notice_note1 = { model = 'meshes/m/text_note_01.nif', name = 'Notices' }
activators.ojb_notice_note2 = { model = 'meshes/m/text_note_02.nif', name = 'Notices' }
-- Each notice's paper on a wall or board, by its look and shape (paper.lua wallOf).
for _, look in ipairs(require('scripts.ojb.paper').WALL_LOOKS) do
    for _, shape in ipairs({ 'p', 'n' }) do
        activators['ojb_notice_' .. look .. '_' .. shape] = {
            model = 'meshes/ojb/wall_' .. look .. '_' .. shape .. '.nif', name = 'Notices' }
    end
end
activators.ojb_board_vanilla = { model = 'meshes/x/ex_de_shack_plank_02.nif', name = 'Notice Board' }
statics.ojb_post = { model = 'meshes/f/furn_de_shack_post.nif' }

local miscs = content.miscs.records
local books = content.books.records

local function misc(id, name, model, icon, weight)
    miscs[id] = { name = name, model = model, icon = icon, value = 1, weight = weight }
end

misc('ojb_signet', "Bandit Leader's Signet", 'meshes/c/c_ring_common03.nif', 'icons/c/tx_ring_common03.dds', 0.1)
-- Saves from the first test build hold these ids.
for i = 1, 3 do
    misc('ojb_signet_' .. i, "Bandit Leader's Signet", 'meshes/c/c_ring_common03.nif',
        'icons/c/tx_ring_common03.dds', 0.1)
end
misc('ojb_ring_family', 'Family Ring', 'meshes/c/c_ring_extravagant_1.nif', 'icons/c/tx_ring_extravagant01.dds', 0.1)
misc('ojb_amulet_family', 'Family Amulet', 'meshes/c/amulet_extravagant_1.nif', 'icons/c/tx_amulet_extrav1.dds', 0.5)
misc('ojb_urn_family', 'Ancestral Urn', 'meshes/m/misc_pot_redware_04.nif', 'icons/m/tx_pot_redware_04.dds', 3)
misc('ojb_cup_family', 'Silver Cup', 'meshes/m/misc_silverware_cup_01.nif', 'icons/m/misc_silverware_cup_01.dds', 1)
misc('ojb_goods', 'Caravan Goods', 'meshes/m/misc_com_basket_01.nif', 'icons/m/misc_com_basket_01.dds', 5)
misc('ojb_samples', 'Sample Flask', 'meshes/m/misc_redware_flask.nif', 'icons/m/misc_redware_flask.dds', 1)
misc('ojb_banner', 'Company Pennant', 'meshes/m/misc_cloth10.nif', 'icons/m/misc_cloth00.dds', 1)
misc('ojb_band', 'Wedding Band', 'meshes/c/c_ring_common01.nif', 'icons/c/tx_ring_common01.dds', 0.1)
misc('ojb_seal', 'Seal Ring', 'meshes/c/c_ring_expensive_1.nif', 'icons/c/tx_ring_expensive01.dds', 0.1)
misc('ojb_locket', 'Silver Locket', 'meshes/c/amulet_expensive_1.nif', 'icons/c/tx_amulet_expens1.dds', 0.5)
misc('ojb_token', "Pilgrim's Token", 'meshes/c/amulet_common_1.nif', 'icons/c/tx_amulet_com1.dds', 0.2)
misc('ojb_puzzlebox', 'Puzzle Box', 'meshes/m/misc_dwrv_ark_cube00.nif', 'icons/m/misc_dwrv_ark_cube00.dds', 2)
misc('ojb_lute', 'Lute', 'meshes/m/misc_de_lute_01.nif', 'icons/m/tx_de_lute_01.dds', 3)
misc('ojb_drum', 'Guarskin Drum', 'meshes/m/misc_de_drum_02.nif', 'icons/m/tx_de_drum_01.dds', 3)
misc('ojb_writing', 'Writing Set', 'meshes/m/misc_inkwell.nif', 'icons/m/misc_inkwell.dds', 1)
misc('ojb_knife', 'Fishing Knife', 'meshes/m/misc_com_wood_knife.nif', 'icons/m/misc_com_wood_knife.dds', 1)
misc('ojb_goblet', 'Goblet', 'meshes/m/misc_de_goblet_01.nif', 'icons/m/misc_de_goblet_01.dds', 1)
misc('ojb_coin', 'Dwemer Coin', 'meshes/m/misc_dwrv_coin00.nif', 'icons/m/misc_dwrv_coin00.dds', 0.1)
misc('ojb_hat', "Captain's Hat", 'meshes/m/misc_cloth10.nif', 'icons/m/misc_cloth00.dds', 0.5)
-- A key (Detect Key shows it), though it opens nothing.
miscs.ojb_key = { name = 'House Key', model = 'meshes/m/key_standard_01.nif', icon = 'icons/m/tx_key_standard_01.dds',
    value = 1, weight = 0.1, isKey = true }

local function book(id, name, model, icon, text, isScroll)
    books[id] = {
        name = name, model = model, icon = icon, text = text, value = 1, weight = 1,
        isScroll = isScroll or false,
    }
end

book('ojb_ledger', 'Ledger', 'meshes/m/text_octavo_01.nif', 'icons/m/tx_octavo_01.dds',
    '<DIV ALIGN="LEFT"><FONT FACE="Magic Cards">Columns of sums in a careful hand: kwama eggs, saltrice, '
    .. 'a debt marked paid twice. The owner will want this back.<BR>')
book('ojb_journal', 'Journal', 'meshes/m/text_octavo_02.nif', 'icons/m/tx_octavo_02.dds',
    '<DIV ALIGN="LEFT"><FONT FACE="Magic Cards">Weather, prices, a cousin\'s wedding, and on the last '
    .. 'page a hurried line about noises below the floor. The owner will want this back.<BR>')
book('ojb_letter', 'Letters', 'meshes/m/text_scroll_01.nif', 'icons/m/tx_scroll_01.dds',
    '<DIV ALIGN="LEFT"><FONT FACE="Magic Cards">A bundle tied with string. Whatever they say, they '
    .. 'aren\'t meant for you.<BR>', true)
book('ojb_prayer', 'Prayer Book', 'meshes/m/text_octavo_03.nif', 'icons/m/tx_octavo_03.dds',
    '<DIV ALIGN="LEFT"><FONT FACE="Magic Cards">The Temple\'s daily prayers, worn soft at the corners. '
    .. 'Names of the family dead are written inside the cover, the newest in a different ink.<BR>')
book('ojb_tome', 'Guild Tome', 'meshes/m/text_octavo_01.nif', 'icons/m/tx_octavo_01.dds',
    '<DIV ALIGN="LEFT"><FONT FACE="Magic Cards">A guild library stamp on the flyleaf, and notes on the '
    .. 'conjuration of lesser daedra in three different hands.<BR>')
book('ojb_notes', "Apprentice's Notes", 'meshes/m/text_parchment_02.nif', 'icons/m/tx_parchment_02.dds',
    '<DIV ALIGN="LEFT"><FONT FACE="Magic Cards">Sketches of a ward circle, crossed out and redrawn. '
    .. 'At the bottom: "ask the steward about the third sigil".<BR>', true)
book('ojb_chart', 'Star Chart', 'meshes/m/text_paper_roll_01.nif', 'icons/m/tx_paper_roll_01.dds',
    '<DIV ALIGN="LEFT"><FONT FACE="Magic Cards">The sky over Vvardenfell in late Frostfall, every star '
    .. 'pricked through with a pin. A guild stamp in the corner.<BR>', true)
