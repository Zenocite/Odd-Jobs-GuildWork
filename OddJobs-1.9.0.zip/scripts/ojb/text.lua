---@omw-context global
-- Pure: place names, distances, item names and reward lines. Notice stories are in story.lua.

local M = {}

local function titleCase(s)
    return (s:gsub("(%a)([%w']*)", function(a, b) return a:upper() .. b end))
end
M.titleCase = titleCase

-- The surname in a poster line: 'Sedris Hlaren, caravaner' -> 'Hlaren'.
function M.surname(from)
    local name = (from or ''):match('^([^,]+)') or ''
    return name:match('(%S+)%s*$') or name
end

---------------------------------------------------------------------------------------------------
-- Place names. Cells are named "Town, Place" or just "Place"; notices read them as people would.

local PLURAL_WORDS = {
    sewers = true, ruins = true, caverns = true, catacombs = true, tunnels = true, mines = true,
    depths = true, vaults = true, halls = true, cellars = true, crypts = true, underworks = true,
    canals = true, warrens = true, barrows = true, docks = true, chambers = true, caves = true,
}
-- Words that don't make a name proper; a sub-place made only of these is a common noun.
local COMMON = {
    sewers = true, sewer = true, underworks = true, cellar = true, cellars = true, basement = true,
    mine = true, mines = true, crypt = true, crypts = true, vault = true, vaults = true, catacombs = true,
    tunnels = true, tunnel = true, cave = true, caves = true, cavern = true, caverns = true, ruins = true,
    canals = true, warehouse = true, storehouse = true, tower = true, abandoned = true, old = true,
    lower = true, upper = true, flooded = true, deep = true, docks = true, shack = true, hut = true,
    grotto = true, depths = true, warrens = true, egg = true, kwama = true, level = true, inner = true,
    outer = true, underground = true, top = true, bottom = true, middle = true, keep = true, shrine = true, sanctum = true, chapel = true, halls = true, hall = true, entrance = true,
    dungeon = true,
}

local function allCommon(s)
    for w in s:gmatch('%a+') do
        if not COMMON[w:lower()] then return false end
    end
    return true
end
M.allCommon = allCommon

function M.isPlural(name)
    local last = name:match('(%a+)%s*$') or ''
    return PLURAL_WORDS[last:lower()] == true
end

-- { text, plural }: "Morandano, Sewers" -> "the Morandano sewers", plural. The town joins with "at",
-- since titles and sentences already put "in" before the place.
function M.placeName(cell)
    local town, sub = cell:match('^([^,]+),%s*(.+)$')
    local last = (sub or cell):match('(%a+)%s*$') or ''
    local plural = PLURAL_WORDS[last:lower()] == true
    if not town then
        return { text = cell, plural = plural }
    end
    if allCommon(sub) then
        if not sub:find(' ') then
            return { text = 'the ' .. town .. ' ' .. sub:lower(), plural = plural }
        end
        return { text = 'the ' .. sub:lower() .. ' at ' .. town, plural = plural }
    end
    return { text = sub .. ' at ' .. town, plural = plural }
end

---------------------------------------------------------------------------------------------------
-- Distance

-- How far it feels on foot. Walking covers about a cell in half a game hour at timescale 30.
function M.howFar(cells)
    if cells < 1.5 then return 'less than an hour on foot' end
    if cells < 4 then return 'an hour or two on foot' end
    if cells < 8 then return 'a few hours on foot' end
    return 'most of a day on foot'
end

-- A game unit is taken as 1.42 cm (64 to the yard), so a cell is about 117 m.
local METRES_PER_UNIT = 0.0142

function M.distanceWords(units)
    local m = units * METRES_PER_UNIT
    if m < 60 then return 'close by' end
    if m < 950 then return string.format('about %d m', math.floor(m / 50 + 0.5) * 50) end
    return string.format('about %.1f km', m / 1000)
end

-- How notices give directions (the "How notices give directions" setting): 'exact' (distance in
-- metres and a bearing), 'rough' (plain words on the same walking scale as howFar), 'off' (only
-- the written directions). CLOSE: under about 250 m it's just "close by", so the player looks.
local CELL = 8192
local CLOSE = 250 / METRES_PER_UNIT

local function roughBand(units)
    local cells = units / CELL
    if units < CLOSE then return 'close' end
    if cells < 4 then return 'walk' end
    if cells < 8 then return 'hours' end
    if cells < 14 then return 'few' end
    return 'far'
end

-- A few words for the board's hover line, or nil when directions are off.
local ROUGH_SHORT = { close = 'close by', walk = 'a short walk', hours = 'an hour or two away',
    few = 'a good few hours away', far = 'a long way off' }
function M.distanceFor(mode, units)
    if mode == 'off' or not units then return nil end
    if mode == 'exact' then return M.distanceWords(units) end
    return ROUGH_SHORT[roughBand(units)]
end

-- The line under "The way" from where the player stands, or nil when directions are off.
-- dir: a compass point; past: a landmark on the way, for far places; door: true when measured
-- from the door outside this interior; pick: 1 or 2, which of the close-by lines.
function M.fromYou(mode, units, dir, past, door, pick)
    if mode == 'off' or not units then return nil end
    if mode == 'exact' then
        local words = M.distanceWords(units)
        if door then return string.format('From the door outside: %s to the %s.', words, dir) end
        return string.format('%s to the %s of you.', (words:gsub('^%l', string.upper)), dir)
    end
    local band = roughBand(units)
    local s
    if band == 'close' then
        s = pick == 2 and 'Around here somewhere' or 'Somewhere close by. You will have to look'
    elseif band == 'walk' then
        s = 'A short walk to the ' .. dir
    elseif band == 'hours' then
        s = 'An hour or two on foot to the ' .. dir
    elseif band == 'few' then
        s = 'A good few hours ' .. dir
    else
        s = 'A long way ' .. dir .. (past and (', past ' .. past) or '')
    end
    if door and band ~= 'close' then s = 'Once outside, ' .. s:gsub('^%u', string.lower) end
    return s .. '.'
end

---------------------------------------------------------------------------------------------------
-- Contract items

-- The item's own name: 'Hlaren Family Ring', 'Almas Thirr Guild Tome'.
function M.itemName(kind, surname, town)
    local owner = kind.owned == 'family' and surname or town
    return titleCase(owner .. ' ' .. kind.noun)
end

-- The same in a sentence: 'Hlaren family ring'.
function M.itemPhrase(kind, surname, town)
    local owner = kind.owned == 'family' and surname or town
    return owner .. ' ' .. kind.noun
end

-- reward: { gold, items = {id = n}, training, mult }. itemNames: id -> display name.
-- Plurals for the reward line's counted goods; potion and scroll names read fine as they are.
local PLURAL = { Arrow = 'Arrows', Bolt = 'Bolts', Egg = 'Eggs', Gem = 'Gems', Hide = 'Hides', Comberry = 'Comberries',
    Leaf = 'Leaves', Plumes = 'Plumes', Skin = 'Skins', Probe = 'Probes', Lockpick = 'Lockpicks', Hammer = 'Hammers' }

local function counted(n, name)
    if n <= 1 then return name end
    local head, last = name:match('^(.-)(%a+)$')
    if last and PLURAL[last] then name = head .. PLURAL[last] end
    return string.format('%d %s', n, name)
end

function M.reward(reward, itemNames, skillName)
    local parts = { string.format('%d gold', reward.gold) }
    local names = {}
    for id, n in pairs(reward.items or {}) do
        names[#names + 1] = counted(n, itemNames and itemNames[id] or id)
    end
    table.sort(names)
    for _, nm in ipairs(names) do
        parts[#parts + 1] = nm
    end
    if reward.training then
        local who = reward.trainer and ('a lesson with ' .. reward.trainer) or 'a session with the guild trainer'
        local n = reward.sessions or 1
        if n > 1 then
            local words = { 'one', 'two', 'three', 'four', 'five' }
            who = (words[n] or tostring(n)) .. (reward.trainer and (' lessons with ' .. reward.trainer)
                or ' sessions with the guild trainer')
        end
        parts[#parts + 1] = who .. (skillName and (' (' .. skillName .. ')') or '')
    end
    if #parts == 1 then return parts[1] end
    local last = table.remove(parts)
    return table.concat(parts, ', ') .. ' and ' .. last
end

-- The banner when the contract item turns up in the player's pack.
function M.foundMessage(itemPhrase, returnTo, plural)
    local what = itemPhrase:find("'s ") and itemPhrase or ('the ' .. itemPhrase)
    return string.format('You found %s. Return %s to %s.', what, plural and 'them' or 'it', returnTo)
end

M.WARN_MORAG_TONG = 'Word is the Morag Tong have business in those parts. Watch your back.'

-- The contract log, once the player has seen the place, when it held far more or less than the
-- notice made out.
M.GAP = {
    worse = {
        'Worse in there than the notice let on.',
        'Whoever wrote the notice never went inside. There are more of them than it said.',
        'More of them in there than anyone told me. The pay looks thin now.',
    },
    quieter = {
        'Quieter in there than the notice let on.',
        'Less in there than the notice made out. Someone was frightened of shadows.',
        'Not half as bad in there as the notice said.',
    },
}

return M
