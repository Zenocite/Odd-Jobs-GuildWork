---@omw-context runtime
-- Pure: board placement maths on plain numbers. Yaw follows OpenMW objects: util.transform.rotateZ(yaw)
-- turns local +y to (sin yaw, cos yaw), so yaw 0 faces north and yaw pi/2 faces east.

local C = require('scripts.ojb.config')

local M = {}

-- Where a contract's band waits: up to n of pts, those at least `away` from every foe first,
-- deepest from `from` (where the player came in) among them; then the rest, farthest from the foes
-- first. Points chosen stand CONTRACT.SPREAD apart on the floor plan. pts, foes, from: { x, y, z }.
function M.awayFrom(pts, foes, from, away, n)
    local spread = C.CONTRACT.SPREAD
    local scored = {}
    for _, p in ipairs(pts) do
        local near = math.huge
        for _, f in ipairs(foes) do
            local dx, dy, dz = p.x - f.x, p.y - f.y, p.z - f.z
            near = math.min(near, dx * dx + dy * dy + dz * dz)
        end
        local dx, dy, dz = p.x - from.x, p.y - from.y, p.z - from.z
        scored[#scored + 1] = { p = p, near = math.sqrt(near), deep = dx * dx + dy * dy + dz * dz }
    end
    table.sort(scored, function(a, b)
        local fa, fb = a.near >= away, b.near >= away
        if fa ~= fb then return fa end
        if fa then return a.deep > b.deep end
        return a.near > b.near
    end)
    local out = {}
    for _, s in ipairs(scored) do
        local ok = true
        for _, o in ipairs(out) do
            local dx, dy = s.p.x - o.x, s.p.y - o.y
            if dx * dx + dy * dy < spread * spread then ok = false break end
        end
        if ok then out[#out + 1] = { x = s.p.x, y = s.p.y, z = s.p.z } end
        if #out >= n then break end
    end
    return out
end

-- Board space (+x right, +y back, +z up) to world, for a board at (ox, oy, oz) turned by yaw.
function M.toWorld(ox, oy, oz, yaw, lx, ly, lz)
    local s, c = math.sin(yaw), math.cos(yaw)
    return ox + lx * c + ly * s, oy - lx * s + ly * c, oz + lz
end

-- The yaw that turns the board's front (local -y) to face the direction (fx, fy).
function M.yawFacing(fx, fy)
    return math.atan2(-fx, -fy)
end

-- Spots beside a door, best first. door: the exterior door; arrival: where walking out of it puts
-- you (the matching interior door's destination). Returns nil when the two coincide.
function M.candidates(door, arrival)
    local fx, fy = arrival.x - door.x, arrival.y - door.y
    local len = math.sqrt(fx * fx + fy * fy)
    if len < 1 then
        return nil
    end
    fx, fy = fx / len, fy / len
    local push = math.max(len, 100)
    local bx, by = door.x + fx * push, door.y + fy * push
    local rx, ry = fy, -fx
    local yaw = M.yawFacing(fx, fy)
    local out = {}
    for _, o in ipairs(C.SPOT_OFFSETS) do
        out[#out + 1] = {
            x = bx + rx * o[1] + fx * o[2],
            y = by + ry * o[1] + fy * o[2],
            z = arrival.z,
            yaw = yaw,
        }
    end
    return out
end

-- Corners of a w x d footprint at (x, y), in order front-left, front-right, back-right, back-left.
function M.corners(x, y, yaw, w, d)
    local hw, hd = w / 2, d / 2
    local out = {}
    for _, p in ipairs({ { -hw, -hd }, { hw, -hd }, { hw, hd }, { -hw, hd } }) do
        local wx, wy = M.toWorld(x, y, 0, yaw, p[1], p[2], 0)
        out[#out + 1] = { x = wx, y = wy }
    end
    return out
end

-- Where each part of a style goes: list of {rec, active, x, y, z, yaw, plank}.
function M.layout(variant, x, y, z, yaw)
    local out = {}
    for _, p in ipairs(variant.parts) do
        local wx, wy, wz = M.toWorld(x, y, z, yaw, p.x, p.y, p.z)
        out[#out + 1] = { rec = p.rec, active = p.active, x = wx, y = wy, z = wz, yaw = yaw, plank = p.plank }
    end
    return out
end

-- Paper slot i on a board or wall cluster, or nil past the last slot. Papers sit a little
-- further out each slot so overlapping ones never share a plane.
function M.paper(variant, i, x, y, z, yaw)
    local s = variant.slots[i]
    if not s or not variant.paper then
        return nil
    end
    local wx, wy, wz = M.toWorld(x, y, z, yaw, s[1], variant.paper.y - 0.2 * (i - 1), s[2])
    return { rec = s.rec, x = wx, y = wy, z = wz, yaw = yaw, tilt = s.tilt or 0 }
end

-- How many papers show for n open notices; room: papers the wall has room for, when on a wall.
function M.paperCount(variant, n, room)
    local most = math.min(#variant.slots, room or #variant.slots)
    return math.min(most, math.max(variant.minPapers or 0, n))
end

-- Probe points for pinned notices beside a door. door: { x, y, z, half } with half the door's
-- half width along its wall; out: unit vector from the door to the street. Returns points OUT in
-- front of the wall, nearest the door first, alternating sides.
function M.wallProbes(door, out)
    local W = C.WALL
    local rx, ry = -out.y, out.x
    local start = math.min(door.half or 50, W.DOOR_HALF_MAX) + W.HALF_W + W.EDGE_GAP
    local list = {}
    for _, extra in ipairs(W.LATERAL) do
        for _, side in ipairs({ 1, -1 }) do
            local along = side * (start + extra)
            list[#list + 1] = {
                x = door.x + rx * along + out.x * W.OUT,
                y = door.y + ry * along + out.y * W.OUT,
                side = side, along = along,
            }
        end
    end
    return list
end

-- Sample offsets {right, up} over one paper's patch, centre first: three by three, 13 x 17 apart.
function M.paperSamples()
    local W = C.WALL
    local out = { { 0, 0 } }
    for _, u in ipairs({ -1, 0, 1 }) do
        for _, r in ipairs({ -1, 0, 1 }) do
            if r ~= 0 or u ~= 0 then out[#out + 1] = { r * W.PAPER_HW, u * W.PAPER_HH } end
        end
    end
    return out
end

-- Probe points for a board backed against the wall: past the door's edge by BOARD_EDGE plus half
-- the board, both sides, nearest first.
function M.boardProbes(door, out, w)
    local rx, ry = -out.y, out.x
    local start = math.min(door.half or 50, C.WALL.DOOR_HALF_MAX) + C.BOARD_EDGE + w / 2
    local list = {}
    for _, extra in ipairs(C.BOARD_LATERAL) do
        for _, side in ipairs({ 1, -1 }) do
            local along = side * (start + extra)
            list[#list + 1] = {
                x = door.x + rx * along + out.x * C.WALL.OUT,
                y = door.y + ry * along + out.y * C.WALL.OUT,
                side = side, along = along,
            }
        end
    end
    return list
end

-- Whether any of the points is in the walk to the door: a strip DOOR_PATH out from it, the door's
-- width plus DOOR_PATH_MARGIN each side. door: { x, y, half }; out: unit vector to the street.
function M.inDoorPath(door, out, pts)
    local half = math.min(door.half or 50, C.WALL.DOOR_HALF_MAX) + C.DOOR_PATH_MARGIN
    for _, p in ipairs(pts) do
        local dx, dy = p.x - door.x, p.y - door.y
        local along = dx * out.x + dy * out.y
        local lat = -dx * out.y + dy * out.x
        if along > -20 and along < C.DOOR_PATH and math.abs(lat) < half then return true end
    end
    return false
end

-- Eight-point compass word for the direction from (ax, ay) to (bx, by); +y is north.
local POINTS = { 'north', 'northeast', 'east', 'southeast', 'south', 'southwest', 'west', 'northwest' }
function M.bearing(ax, ay, bx, by)
    local a = math.atan2(bx - ax, by - ay)
    local i = math.floor((a / (2 * math.pi)) * 8 + 0.5) % 8
    return POINTS[i + 1]
end

function M.distCells(ax, ay, bx, by)
    local dx, dy = bx - ax, by - ay
    return math.sqrt(dx * dx + dy * dy) / C.CELL
end

-- Whether an interior is somewhere the public goes (a shop, guild, temple, tavern, hall) rather
-- than a home or store, from its name alone: "Town, Somebody's House" is private, "Town, Bivale
-- Teneran: Clothier" is not.
local PRIVATE = { 'house', 'manor', 'shack', 'hut', 'residence', 'home', 'quarters', 'basement', 'cellar',
    'storage', 'storeroom', 'sewer', 'attic', 'loft', 'bunk', 'shed', 'stable', 'barracks', 'tomb', 'crypt',
    'cistern', 'underworks', 'vault', 'dungeon', 'prison', 'cell' }
function M.isPublic(dest)
    local sub = dest:lower():match('^[^,]+,%s*(.+)$')
    if not sub then return false end
    for _, w in ipairs(PRIVATE) do
        if sub:find('%f[%a]' .. w .. '%f[%A]') or sub:find('%f[%a]' .. w .. 's%f[%A]') then return false end
    end
    return true
end

-- The LIGHT.NEAR lights of `list` nearest (x, y) within LIGHT.RANGE, nearest first.
function M.nearestLights(list, x, y)
    local L = C.LIGHT
    local near = {}
    for _, l in ipairs(list or {}) do
        local d = math.sqrt((l.x - x) ^ 2 + (l.y - y) ^ 2)
        if d < L.RANGE then near[#near + 1] = { x = l.x, y = l.y, z = l.z, r = l.r, d = d } end
    end
    table.sort(near, function(a, b) return a.d < b.d end)
    for i = #near, L.NEAR + 1, -1 do near[i] = nil end
    for _, l in ipairs(near) do l.d = nil end
    return near
end

-- How good a spot the check found beside one door. spot.style: wall, backed or open; spot.along:
-- distance from the door along the wall.
function M.spotScore(spot)
    local S = C.SCORE
    local score = S[spot.style] or S.open
    if spot.style == 'wall' or spot.style == 'surface' then score = score + S.perPaper * #(spot.slots or {}) end
    if spot.lit then score = score + S.lit end
    if spot.dark then score = score - S.recess end
    return score - S.perUnit * (spot.along or 0)
end

-- How far a door stands off its street, up or down, from the player's check; nil when not measured.
function M.offStreet(e)
    return e and e.up and math.abs(e.up) or nil
end

-- How much a door looks like the main public entrance. e (from the player's check): open (0..1),
-- reach ('level', 'stairs', 'upper', 'unreachable', 'unknown'), up (above its street). d (from
-- global): front (public doors in front), centre (distance to the middle of the town's public
-- doors), main (named as the main door), lowest (the least any door of the same building stands
-- off its street). Returns the score and its parts, { {label, points}, ... }, for the log.
function M.entranceScore(e, d)
    local E = C.ENTRANCE
    local parts = {}
    local function add(label, pts)
        parts[#parts + 1] = { label, pts }
        return pts
    end
    local s = 0
    s = s + add(string.format('open space %d%%', math.floor((e.open or 0) * 100 + 0.5)), E.open * (e.open or 0))
    local front = d.front or 0
    s = s + add(string.format('public doors in front %d', front), math.min(E.publicMax, E.perPublic * front))
    if d.centre then
        s = s + add(string.format('%.0f from the town centre', d.centre), -math.min(E.centreMax, d.centre / E.centreUnit))
    end
    local off = M.offStreet(e)
    if off and d.lowest then
        local over = off - d.lowest
        if over > E.higherFree then
            s = s + add(string.format('%.0f higher off the street than this building\'s lowest door', over),
                -E.higherPer * (over - E.higherFree))
        end
    end
    if e.reach == 'upper' then
        s = s + add(string.format('%.0f off the street, long way round', e.up or 0), E.upper)
    elseif e.reach == 'unreachable' then
        s = s + add(string.format('%.0f off the street, no way up', e.up or 0), E.unreachable)
    elseif e.reach == 'unknown' then
        s = s + add('navmesh not ready', E.unknown)
    elseif e.reach == 'stairs' then
        add(string.format('steps up %.0f', e.up or 0), 0)
    end
    if d.main then s = s + add('named main door', E.main) end
    return s, parts
end

-- Whether a door other than a building's best one also carries its notices: walked to straight
-- from the street ('level' or 'stairs'; 'unknown' only when barely off it) and no more than
-- SECOND_OVER above the building's lowest door. Returns ok and, when not, why.
function M.streetLevel(e, lowest)
    local E = C.ENTRANCE
    local off = M.offStreet(e)
    local reach = e.reach or 'unknown'
    if reach == 'upper' or reach == 'unreachable' then return false, 'an upper floor or balcony' end
    if reach == 'unknown' and (not off or off > E.STEP) then return false, 'walk from the street not measured' end
    if off and lowest and off - lowest > E.SECOND_OVER then
        return false, string.format('%.0f above the building\'s lowest door', off - lowest)
    end
    return true
end

function M.partsText(parts)
    local out = {}
    for _, p in ipairs(parts) do out[#out + 1] = string.format('%s %+.0f', p[1], p[2]) end
    return table.concat(out, ', ')
end

-- Public doors in front of a door: within range, inside the half turned PUBLIC_DOT towards `out`.
-- list: { {x, y, dest}, ... }; own: this door's interior, left out.
function M.publicInFront(x, y, out, list, own)
    local E = C.ENTRANCE
    local n = 0
    for _, p in ipairs(list) do
        if p.dest ~= own then
            local vx, vy = p.x - x, p.y - y
            local d = math.sqrt(vx * vx + vy * vy)
            if d > 1 and d < E.PUBLIC_RANGE and (vx * out.x + vy * out.y) / d > E.PUBLIC_DOT then n = n + 1 end
        end
    end
    return n
end

-- Whether a record id or mesh path contains any of `words`.
function M.hasWord(s, words)
    s = (s or ''):lower()
    for _, w in ipairs(words) do
        if s:find(w, 1, true) then return true end
    end
    return false
end

return M
