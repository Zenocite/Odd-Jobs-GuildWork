---@omw-context global
-- Odd Jobs: boards, notices and contracts. Everything that touches the world happens here; the
-- player script checks board spots with rays, draws the windows and sends back what was clicked.

local async = require('openmw.async')
local core = require('openmw.core')
local types = require('openmw.types')
local util = require('openmw.util')
local world = require('openmw.world')
local I = require('openmw.interfaces')
local time = require('openmw_aux.time')

local C = require('scripts.ojb.config')
local R = require('scripts.ojb.rewards')
local TI = require('scripts.ojb.tier')
local REP = require('scripts.ojb.rep')
local G = require('scripts.ojb.geom')
local T = require('scripts.ojb.text')
local D = require('scripts.ojb.directions')
local F = require('scripts.ojb.foes')
local P = require('scripts.ojb.pick')
local ST = require('scripts.ojb.story')
local PLACES = require('scripts.ojb.data.places')
local TOWNS = require('scripts.ojb.data.towns')
local LANDMARKS = require('scripts.ojb.data.landmarks')
local SUP = require('scripts.ojb.data.supply')

local DAY = 86400
local GOLD = 'gold_001'
local LEVELLED = types.LevelledCreature

local S              -- saved state, see fresh()
local debugOn = false
local boardsOn = true
local plainNotices = false
-- Feature switches from the player's settings (config.FEATURES); on until the settings arrive.
local featureOn = {}
for _, f in ipairs(C.FEATURES) do featureOn[f] = true end
local function log(fmt, ...)
    if debugOn then
        print(C.LOG_TAG .. string.format(fmt, ...))
    end
end

-- Placement decisions and contract milestones: a line each, a few per session, always logged so a
-- report from a player's openmw.log says where every board went and why.
local function say(fmt, ...)
    print(C.LOG_TAG .. string.format(fmt, ...))
end

-- Debug: how long each of our jobs takes, real time. Always measured. Anything at or over
-- SLOW_TICK_MS is logged immediately (the hitch that matches the 2 second poll). The footprint
-- setting sums them every PROFILE_SECONDS.
local jobStats = {}  -- name -> { n, total ms, max ms } since the last footprint line
local function timed(name, fn, ...)
    local t0 = core.getRealTime()
    local a, b, c = fn(...)
    local ms = (core.getRealTime() - t0) * 1000
    if debugOn or featureOn.profile then
        local s = jobStats[name]
        if not s then
            s = { n = 0, total = 0, max = 0 }
            jobStats[name] = s
        end
        s.n, s.total = s.n + 1, s.total + ms
        if ms > s.max then s.max = ms end
    end
    if ms >= C.SLOW_TICK_MS then say('slow: %s took %.1f ms', name, ms) end
    return a, b, c
end

-- Cells this script has had the engine load with getAll. The engine keeps a loaded cell's
-- references for the rest of the session (its WorldModel never unloads a CellStore), so the
-- footprint line reports how many. Keyed by cell id; lives as long as the script.
local touchedCells, touchedCount = {}, 0
local function touch(cell)
    local id = cell.id
    if not touchedCells[id] then
        touchedCells[id] = true
        touchedCount = touchedCount + 1
    end
    return cell
end

local function now()
    return core.getGameTime() / DAY
end

local function thePlayer()
    return world.players[1]
end

local function tell(player, msg)
    player:sendEvent('OJB_Message', msg)
end

-- Load order is fixed for the session, so this is read once.
local FILES = {}
for _, f in ipairs(core.contentFiles.list) do
    FILES[f:lower()] = true
end
local function hasFile(name)
    return FILES[name] == true
end

local HM = hasFile('harshmeasures.omwaddon')

-- Harsh Measures keeps its state in MWScript globals; read on demand, never changed.
local function hmVar(name)
    if not HM then
        return 0
    end
    return world.mwscript.getGlobalVariables(thePlayer())[name] or 0
end

local AVAIL = {}
for _, p in ipairs(PLACES) do
    if hasFile(p.req) and not F.quest(p.n) and not C.TIER.KEEP_OUT[p.n] then
        AVAIL[#AVAIL + 1] = p
    end
end
-- key -> { town, def }, for every board whose town is in the load order.
local DEFS = {}
local DEF_KEYS = {}
for _, town in ipairs(TOWNS) do
    if not town.req or hasFile(town.req) then
        for _, def in ipairs(town.boards) do
            DEFS[def.key] = { town = town, def = def }
            DEF_KEYS[#DEF_KEYS + 1] = def.key
        end
    end
end

-- Trading company offices carry a board of their own, at the office door, with company
-- requisitions only. key -> supply.companies entry.
local COMPANY = {}
for _, co in ipairs(SUP.companies) do
    for _, town in ipairs(TOWNS) do
        if town.key == co.town and (not town.req or hasFile(town.req)) and hasFile(co.req) then
            local key = co.town .. '_' .. co.short
            DEFS[key] = { town = town, def = { key = key, posters = { 'company' }, near = co.near, doors = { co.cell } } }
            DEF_KEYS[#DEF_KEYS + 1] = key
            COMPANY[key] = co
        end
    end
end

-- Requisitions and the theft ledger (reqs.lua). reqCtx is filled in at the end of
-- this file, once every helper it names exists.
local reqCtx = {}
local RQ = require('scripts.ojb.reqs').new(reqCtx)

-- Spawns under the Harsh Measures rules (spawner.lua) and the story turns on taken jobs
-- (twists.lua). One context for both, filled in at the end of this file too (this chunk is near
-- Lua's 200 local limit, so their helpers live on it).
-- rules: progress rules from the settings. New in town and the fourth slot go by contracts
-- finished; the old level rules only with levelGates; hideAbove keeps work far over the player's
-- level off the boards.
local twCtx = { rnd = math.random, rules = { newDone = C.EARLY.DONE, perkDone = C.PERK.DONE,
    earlyLevel = C.EARLY.LEVEL, perkLevel = C.PERK.LEVEL, levelGates = false, hideAbove = false,
    directions = 'rough', groupSize = C.THREAT.GROUP_SIZE } }
local SP = require('scripts.ojb.spawner').new(twCtx)
local TW = require('scripts.ojb.twists').new(twCtx)
local DG = require('scripts.ojb.danger').new(twCtx)
twCtx.DG = DG
twCtx.WL = require('scripts.ojb.wild').new(twCtx)
twCtx.SY = require('scripts.ojb.strays').new(twCtx)
twCtx.BD = require('scripts.ojb.board')
twCtx.NW = require('scripts.ojb.news')
twCtx.AD = require('scripts.ojb.ads')
twCtx.FR = require('scripts.ojb.fresh')

local function fresh()
    return {
        v = C.STATE_VERSION,
        built = C.VERSION, -- mod version that wrote this state; any other redoes placement
        boards = {},       -- key -> board state
        contracts = {},    -- id -> contract
        nextId = 1,
        done = {},         -- game day of each completed contract, for the repeat multiplier
        repGiven = {},     -- faction -> rank -> reputation granted by contracts at that rank
        trainingAt = {},   -- faction -> game day of the last training reward
        used = {},         -- place name -> game day a contract last used it
        posted = {},       -- place name -> game day a notice last named it (REPOST_DAYS, pruned)
        tour = 0,
    }
end

-- Runtime only, rebuilt on load.
local byObject = {}        -- clickable board part or paper object id -> board key
local waiting = nil        -- { key, at } while a spot check is out with the player
local refreshQueue = {}
local refreshing = nil     -- { key, cands, i }
local touring = nil        -- { i, pause, results } while I.OddJobs.tour() runs

---------------------------------------------------------------------------------------------------
-- Names and small helpers

local nameCache = {}
local function itemName(id)
    if nameCache[id] then return nameCache[id] end
    for _, t in ipairs({ types.Potion, types.Repair, types.Probe, types.Lockpick, types.Miscellaneous, types.Book,
        types.Weapon, types.Clothing, types.Ingredient, types.Armor, types.Apparatus, types.Light }) do
        local r = t.records[id]
        if r then
            nameCache[id] = r.name
            return r.name
        end
    end
    return id
end

local function itemNames(items)
    local out = {}
    for id in pairs(items or {}) do
        out[id] = itemName(id)
    end
    return out
end

local function skillName(id)
    local r = id and core.stats.Skill.records[id]
    return r and r.name or nil
end

-- Region names by exterior cell grid. Key "gx,gy"; lives for the session (load order is fixed);
-- never invalidated; a cell without a region is stored as false. One getExteriorCell per place
-- instead of one per notice.
local regionCache = {}
local function regionName(x, y)
    local gx, gy = math.floor(x / C.CELL), math.floor(y / C.CELL)
    local k = gx .. ',' .. gy
    local hit = regionCache[k]
    if hit == nil then
        local cell = world.getExteriorCell(gx, gy)
        local id = cell and cell.region or false
        local r = id and core.regions.records[id]
        hit = { id = id, name = r and r.name or false }
        regionCache[k] = hit
    end
    return hit.name or nil
end

local function vec(t)
    return util.vector3(t.x, t.y, t.z)
end

local function playerLevel(player)
    return types.Actor.stats.level(player).current
end

local function isMember(player, faction)
    return types.NPC.getFactionRank(player, faction) > 0 and not types.NPC.isExpelled(player, faction)
end

local function heldCount()
    local n = 0
    for _ in pairs(S.contracts) do n = n + 1 end
    return n
end

-- The player as the progress rules see them. done: contracts finished in all (S.finished); saves
-- from before that count began start where they stood, so a player whose level already gave the
-- fourth slot keeps it.
local function who(player)
    local rules, level = twCtx.rules, player and playerLevel(player) or 1
    if S.finished == nil then S.finished = level >= C.PERK.LEVEL and C.PERK.DONE or #S.done end
    return { done = S.finished, level = level, levelGates = rules.levelGates, newDone = rules.newDone,
        earlyLevel = rules.earlyLevel, perkDone = rules.perkDone, perkLevel = rules.perkLevel }
end

local function maxHeld(player)
    return R.maxHeld(who(player))
end

local function recentDone()
    local cut, n, keep = now() - C.REPEAT_WINDOW_DAYS, 0, {}
    for _, d in ipairs(S.done) do
        if d >= cut then
            n = n + 1
            keep[#keep + 1] = d
        end
    end
    S.done = keep
    return n
end

---------------------------------------------------------------------------------------------------
-- Board objects

local function rotationFor(part)
    local r = util.transform.rotateZ(part.yaw)
    if part.plank then
        -- Plank meshes run along +y and lie flat; this stands them on edge across the board.
        r = r * util.transform.rotate(-2 * math.pi / 3, util.vector3(1, 1, 1):normalize())
    elseif part.tilt then
        -- Parchment lies face up; standing it short of upright leans its top back by `lean`.
        r = r * util.transform.rotate(part.tilt, util.vector3(0, -1, 0))
            * util.transform.rotate(C.HALF_PI - (part.lean or 0), util.vector3(1, 0, 0))
    end
    return r
end

local function spawn(part)
    local obj = world.createObject(part.rec)
    obj:teleport('', util.vector3(part.x, part.y, part.z), { rotation = rotationFor(part) })
    return obj
end

-- An object in a cell whose references aren't loaded isn't valid until they are; getAll on its
-- cell loads them. Anything still out of reach goes on S.orphans and is removed from nearTick once
-- it turns valid.
local function removeAll(list, at)
    local loaded = false
    for _, o in ipairs(list or {}) do
        if not o:isValid() and at and not loaded then
            touch(world.getExteriorCell(math.floor(at.x / C.CELL), math.floor(at.y / C.CELL))):getAll(types.Activator)
            loaded = true
        end
        if o:isValid() then
            if o.count > 0 then o:remove() end
        else
            S.orphans = S.orphans or {}
            S.orphans[#S.orphans + 1] = o
        end
    end
end

local function sweepOrphans()
    if not S.orphans or #S.orphans == 0 then return end
    local keep = {}
    for _, o in ipairs(S.orphans) do
        if o:isValid() then
            if o.count > 0 then o:remove() end
        else
            keep[#keep + 1] = o
        end
    end
    S.orphans = keep
end

-- A board's notices hang at every interior it names (each tavern of a town): b.sites[interior] =
-- { status = 'pending' | 'placed' | 'skipped', style, parts, papers, spot, door, doorId, score,
-- label, others }. The site itself is at the interior's best door; others[doorId] holds the same
-- for each other street-level door of it (second = true, fewer papers). b.status sums them up:
-- 'placed' when any site is, else 'pending' while doors are left to check, else 'skipped';
-- 'nodoor' and 'virtual' as before.
local function placedSites(b)
    local out = {}
    for dest, site in pairs(b.sites or {}) do
        if site.status == 'placed' then
            out[#out + 1] = { dest = dest, site = site, order = '' }
            for id, sub in pairs(site.others or {}) do
                out[#out + 1] = { dest = dest, site = sub, order = id }
            end
        end
    end
    table.sort(out, function(a, c)
        if a.dest ~= c.dest then return a.dest < c.dest end
        return a.order < c.order
    end)
    return out
end

-- Whatever may hold board objects: each site and its other doors, and the board itself in saves
-- from before sites.
local function holders(b)
    local list = { b }
    for _, site in pairs(b.sites or {}) do
        list[#list + 1] = site
        for _, sub in pairs(site.others or {}) do list[#list + 1] = sub end
    end
    return list
end

-- Papers follow the number of open notices; on a wall at least one stays up so the place to hand
-- work in never disappears. Every paper opens the board.
-- Each paper shows one notice: site.meta[j] = { slot, id } beside site.papers[j] (both dense).
-- A paper whose notice is gone comes down. Empty slots take notices not yet shown only when fill
-- is set (refresh, posting, expiry): a taken or handed-in notice leaves its gap until then.
-- Papers from older saves carry no meta and are tied to notices in board order.
local function syncSite(key, site, fill)
    local v = C.VARIANTS[site.style]
    if not v then return end
    local b = S.boards[key]
    local notices = b.notices or {}
    site.papers, site.meta = site.papers or {}, site.meta or {}
    local slots = site.spot.slots
    local want = G.paperCount(v, #notices, slots and #slots)
    if site.second then want = math.min(want, C.SECOND_PAPERS) end
    local live = {}
    for _, n in ipairs(notices) do live[n.id] = true end
    local shown, used, papers, meta = {}, {}, {}, {}
    local decoLeft = math.max(0, want - #notices)
    for j, o in ipairs(site.papers) do
        local m = site.meta[j] or { slot = j }
        if m.id == nil and not m.deco then
            for _, n in ipairs(notices) do
                if not shown[n.id] then m.id = n.id break end
            end
            if m.id == nil then m.deco = true end
        end
        local keep
        if m.deco then
            keep = decoLeft > 0
            if keep then decoLeft = decoLeft - 1 end
        else
            keep = live[m.id] and not shown[m.id]
        end
        if keep and #papers < want and not used[m.slot] then
            papers[#papers + 1], meta[#meta + 1] = o, m
            if m.id then shown[m.id] = true end
            used[m.slot] = true
        else
            byObject[o.id] = nil
            removeAll({ o }, site.spot)
        end
    end
    site.papers, site.meta = papers, meta
    if not fill then return end
    local most = slots and #slots or G.paperCount(v, math.huge, nil)
    for _, n in ipairs(notices) do
        if #site.papers >= want then break end
        if not shown[n.id] then
            local slot
            for i = 1, most do
                if not used[i] then slot = i break end
            end
            if not slot then break end
            local p = slots and slots[slot] or G.paper(v, slot, site.spot.x, site.spot.y, site.spot.z, site.spot.yaw)
            if p then
                local rec, size = require('scripts.ojb.paper').wallOf(n)
                local o = spawn(setmetatable({ rec = rec }, { __index = p }))
                o:setScale(size)
                site.papers[#site.papers + 1], site.meta[#site.meta + 1] = o, { slot = slot, id = n.id }
                byObject[o.id] = key
            end
            shown[n.id], used[slot] = true, true
        end
    end
    -- A style's minimum papers (variant.minPapers) stand even with few notices: plain papers.
    for i = 1, most do
        if #site.papers >= want then break end
        if not used[i] then
            local p = slots and slots[i] or G.paper(v, i, site.spot.x, site.spot.y, site.spot.z, site.spot.yaw)
            if p then
                local o = spawn(p)
                site.papers[#site.papers + 1], site.meta[#site.meta + 1] = o, { slot = i, deco = true }
                byObject[o.id] = key
            end
            used[i] = true
        end
    end
end


-- keepGaps: a notice just came off the board (taken, handed in, out of date); its paper comes down
-- and nothing goes up in its place until the next refresh.
local function syncPapers(key, keepGaps)
    local b = S.boards[key]
    if b and b.stray then return twCtx.SY.sync(key) end
    if not b or b.status ~= 'placed' then return end
    for _, s in ipairs(placedSites(b)) do
        syncSite(key, s.site, not keepGaps)
        RQ.dropCrate(s.site)
    end
end


local function fillSite(key, site, kind, spot)
    local b = S.boards[key]
    site.style = kind
    site.parts = {}
    for _, part in ipairs(G.layout(C.VARIANTS[kind], spot.x, spot.y, spot.z, spot.yaw)) do
        local obj = spawn(part)
        site.parts[#site.parts + 1] = obj
        if part.active then byObject[obj.id] = key end
    end
    site.spot = { x = spot.x, y = spot.y, z = spot.z, yaw = spot.yaw, slots = spot.slots }
    site.status = 'placed'
    site.papers, site.meta = {}, {}
    b.status = 'placed'
    syncSite(key, site, true)
end

local function placeBoard(key, dest, kind, spot)
    local b = S.boards[key]
    b.sites = b.sites or {}
    local site = b.sites[dest] or {}
    b.sites[dest] = site
    fillSite(key, site, kind, spot)
end

local function takeDown(holder)
    for _, o in ipairs(holder.parts or {}) do byObject[o.id] = nil end
    for _, o in ipairs(holder.papers or {}) do byObject[o.id] = nil end
    RQ.dropCrate(holder)
    removeAll(holder.parts, holder.spot)
    removeAll(holder.papers, holder.spot)
    holder.parts, holder.papers, holder.meta, holder.spot = nil, nil, nil, nil
end

local function unplaceSite(key, dest)
    local site = S.boards[key].sites[dest]
    for _, sub in pairs(site.others or {}) do takeDown(sub) end
    site.others = nil
    takeDown(site)
    site.status = 'pending'
end

-- Every site, and the single board older saves kept on the board itself (b.parts, b.papers).
local function unplace(key, status)
    local b = S.boards[key]
    if not b then return end
    for _, holder in ipairs(holders(b)) do takeDown(holder) end
    b.sites, b.door, b.style, b.label, b.doorId, b.score = {}, nil, nil, nil, nil, nil
    b.status = status or 'pending'
end

-- Probing: Door.destCell throws "Cell does not exist" for a door whose target cell no plugin in
-- the load order defines (TR has some, pointing at cells from projects not released yet).
-- Such a door is treated as leading nowhere.
local function destCellOf(door)
    local ok, cell = pcall(types.Door.destCell, door)
    if ok then return cell end
    return nil
end

local function skippedDoor(d)
    return not d.enabled or G.hasWord(d.recordId, C.SKIP_DOORS) or G.hasWord(types.Door.record(d).model, C.SKIP_DOORS)
end

-- The town's public doors (shops, guilds, temple, taverns) round each board, for the entrance score.
-- Key: board key; lives for the session (doors don't move once the load order is fixed); an empty
-- list is kept, so a town without any is looked up once.
local publicDoors = {}

-- Window statics round each board, as world boxes { id, cx, cy, cz, hx, hy, hz }, for the player's
-- paper check. Key: board key; lives for the session, like publicDoors; an empty list is kept.
local windowsAt = {}
-- Enabled, non-negative lights round each board, { x, y, z, r }, filled with windowsAt by the
-- same getAll walk; same key and lifetime.
local lightsAt = {}
-- Whether a static record is a window, by id or mesh. Key: record id; lives for the session
-- (records don't change once loaded); a record that isn't a window is kept as false.
local windowRecord = {}
local function isWindowStatic(obj)
    local id = obj.recordId
    local w = windowRecord[id]
    if w == nil then
        w = G.hasWord(id, C.WINDOW_WORDS) or G.hasWord(types.Static.record(obj).model, C.WINDOW_WORDS)
        windowRecord[id] = w
    end
    return w
end

-- Every exterior door near the board's town into one of its interiors, as { door, dest, rank }:
-- rank is the interior's place in def.doors (0 first), and an interior with two doors gives both.
-- Also fills publicDoors[key] from the same getAll calls.
local function findDoors(def, key, townName)
    -- One scan per board for the session. Doors do not move, and a second getAll would load the
    -- same nine cells again. publicDoors[key].found holds the list; an empty list is kept.
    if key and publicDoors[key] and publicDoors[key].found then return publicDoors[key].found end
    local want = {}
    for i, name in ipairs(def.doors) do want[name:lower()] = i - 1 end
    local prefix = townName and townName:lower() .. ','
    local gx, gy = math.floor(def.near[1] / C.CELL), math.floor(def.near[2] / C.CELL)
    local out, public = {}, {}
    local windows = key and not windowsAt[key] and {} or nil
    local lights = windows and {} or nil
    for dx = -1, 1 do
        for dy = -1, 1 do
            local cell = touch(world.getExteriorCell(gx + dx, gy + dy))
            if windows then
                for _, s in ipairs(cell:getAll(types.Static)) do
                    if s.enabled and isWindowStatic(s) then
                        local box = s:getBoundingBox()
                        local c, h = box.center, box.halfSize
                        windows[#windows + 1] = { id = s.recordId, cx = c.x, cy = c.y, cz = c.z, hx = h.x, hy = h.y, hz = h.z }
                    end
                end
                for _, l in ipairs(cell:getAll(types.Light)) do
                    local rec = l.enabled and types.Light.record(l)
                    if rec and not rec.isOffByDefault and not rec.isNegative and (rec.radius or 0) > 0 then
                        local p = l.position
                        lights[#lights + 1] = { x = p.x, y = p.y, z = p.z, r = rec.radius }
                    end
                end
            end
            for _, d in ipairs(cell:getAll(types.Door)) do
                if types.Door.isTeleport(d) and not skippedDoor(d) then
                    local dest = destCellOf(d)
                    local low = dest and dest.name:lower()
                    local rank = low and want[low]
                    if rank then out[#out + 1] = { door = d, dest = dest, rank = rank } end
                    if prefix and low and low:sub(1, #prefix) == prefix and G.isPublic(dest.name) then
                        public[#public + 1] = { x = d.position.x, y = d.position.y, dest = dest.name }
                    end
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.rank < b.rank end)
    if key then
        local cx, cy = 0, 0
        for _, p in ipairs(public) do cx, cy = cx + p.x, cy + p.y end
        publicDoors[key] = { list = public, found = out,
            cx = #public > 0 and cx / #public or nil, cy = #public > 0 and cy / #public or nil }
    end
    if windows then windowsAt[key], lightsAt[key] = windows, lights end
    return out
end

local function boardDoors(key)
    local d = DEFS[key]
    return findDoors(d.def, key, d.town.name)
end

-- A door's name in saved state: its interior and where it stands.
local function doorId(door, dest)
    return string.format('%s@%d,%d', dest.name, math.floor(door.position.x), math.floor(door.position.y))
end

-- Once per board (and again after a version that changes placement): where its doors are, so
-- nearTick knows when the player is close enough to check each one.
local function lookupDoors(key)
    local b, def = S.boards[key], DEFS[key].def
    b.doorList, b.checked, b.sites = {}, b.checked or {}, b.sites or {}
    local names = {}
    for _, d in ipairs(boardDoors(key)) do
        local p = d.door.position
        local main = false
        for _, m in ipairs(def.main or {}) do
            local mx, my = p.x - m[1], p.y - m[2]
            if mx * mx + my * my < C.ENTRANCE.mainRadius ^ 2 then main = true end
        end
        b.doorList[#b.doorList + 1] = { id = doorId(d.door, d.dest), x = p.x, y = p.y, z = p.z, rank = d.rank,
            dest = d.dest.name, main = main }
        b.sites[d.dest.name] = b.sites[d.dest.name] or { status = 'pending' }
        names[#names + 1] = string.format('%s at %.0f, %.0f', d.dest.name, p.x, p.y)
    end
    if #b.doorList == 0 then
        b.status = 'nodoor'
        -- The scan is cached, so this does not load the nine cells again. Another look waits.
        b.hold = { t = core.getGameTime() + C.SEARCH_BACKOFF, x = def.near[1], y = def.near[2] }
        say('%s: none of its doors (%s) exist in this load order; no notices here', key,
            table.concat(def.doors, ', '))
    else
        say('%s: %d door%s to try: %s', key, #b.doorList, #b.doorList == 1 and '' or 's', table.concat(names, '; '))
    end
end

-- Door ids of this board not checked yet and close enough to the player for rays to see.
local function doorsToCheck(b, pos)
    local ids, n = {}, 0
    local r2 = C.SPOT_REACH * C.SPOT_REACH
    local now, away2
    b.checked = b.checked or {}
    for _, d in ipairs(b.doorList or {}) do
        local ch = b.checked[d.id]
        -- A failed check waits out its backoff, or until the player has moved away, then one more try.
        if ch and not ch.ok and ch.held then
            if not now then now, away2 = core.getGameTime(), C.SEARCH_AWAY * C.SEARCH_AWAY end
            local hx, hy = pos.x - (ch.x or pos.x), pos.y - (ch.y or pos.y)
            if now >= (ch.t or 0) or hx * hx + hy * hy >= away2 then
                b.checked[d.id] = nil
                ch = nil
            end
        end
        local dx, dy = pos.x - d.x, pos.y - d.y
        if not ch and dx * dx + dy * dy < r2 then
            ids[d.id] = true
            n = n + 1
        end
    end
    return ids, n
end

-- Doors not checked yet, of the whole board or of one interior.
local function doorsLeft(b, dest)
    local n = 0
    for _, d in ipairs(b.doorList or {}) do
        if not b.checked[d.id] and (not dest or d.dest == dest) then n = n + 1 end
    end
    return n
end

local function doorById(b, id)
    for _, d in ipairs(b.doorList or {}) do
        if d.id == id then return d end
    end
    return nil
end

-- Where walking out of `door` puts the player: the matching interior door's destination.
local function findArrival(door, dest)
    for _, d in ipairs(touch(dest):getAll(types.Door)) do
        if types.Door.isTeleport(d) then
            local out = destCellOf(d)
            if out and out.isExterior then
                local p = types.Door.destPosition(d)
                if (p - door.position):length() < 600 then
                    return { x = p.x, y = p.y, z = p.z }
                end
            end
        end
    end
    return nil
end

-- The door's middle and its half width along the wall. A door's position is its hinge, so the
-- bounding box gives the middle; the box is axis aligned, so on a slanted wall the width is an
-- overestimate (capped by DOOR_HALF_MAX in geom).
local function doorShape(door, out)
    local box = door:getBoundingBox()
    local c, hs = box.center, box.halfSize
    local rx, ry = -out.y, out.x
    return {
        x = c.x, y = c.y, z = c.z - hs.z,
        half = math.abs(hs.x * rx) + math.abs(hs.y * ry),
    }
end

-- Which way is the street: from the door to where you come out, or both ways along the door's
-- own facing when the way back out isn't found.
local function streetDirs(door, arrival)
    if arrival then
        local dx, dy = arrival.x - door.position.x, arrival.y - door.position.y
        local len = math.sqrt(dx * dx + dy * dy)
        if len > 1 then return { { x = dx / len, y = dy / len } } end
    end
    local yaw = door.rotation:getYaw()
    local fx, fy = math.sin(yaw), math.cos(yaw)
    return { { x = fx, y = fy }, { x = -fx, y = -fy } }
end

local function boardSpots(door, arrival, outs)
    local d = { x = door.position.x, y = door.position.y, z = door.position.z }
    local list = {}
    for _, o in ipairs(outs) do
        local a = arrival or { x = d.x + o.x * 120, y = d.y + o.y * 120, z = d.z }
        for _, s in ipairs(G.candidates(d, a) or {}) do list[#list + 1] = s end
        if arrival then break end
    end
    return list
end

-- Sends the player script the doors in `ids` to check. Finding where each door lets out loads its
-- interior's references (one getAll per door), the same as one door did before.
local function requestSpot(key, player, ids)
    local b = S.boards[key]
    local pub = publicDoors[key] or { list = {} }
    local doors, names = {}, {}
    for _, d in ipairs(boardDoors(key)) do
        local id = doorId(d.door, d.dest)
        local entry = doorById(b, id)
        if ids[id] and entry then
            local arrival = entry.arrivalAt
            if not arrival and not entry.arrivalMiss then
                arrival = findArrival(d.door, d.dest)
                if arrival then entry.arrivalAt = arrival else entry.arrivalMiss = true end
            end
            local outs = streetDirs(d.door, arrival)
            local shape = doorShape(d.door, outs[1])
            local p = d.door.position
            entry.front = G.publicInFront(p.x, p.y, outs[1], pub.list, d.dest.name)
            if pub.cx then
                entry.centre = math.sqrt((p.x - pub.cx) ^ 2 + (p.y - pub.cy) ^ 2)
            end
            local near = {}
            for _, w in ipairs(windowsAt[key] or {}) do
                if math.abs(w.cx - p.x) < C.WINDOW_NEAR and math.abs(w.cy - p.y) < C.WINDOW_NEAR then near[#near + 1] = w end
            end
            doors[#doors + 1] = {
                id = id, outs = outs, spots = boardSpots(d.door, arrival, outs), arrival = arrival,
                door = { x = shape.x, y = shape.y, z = shape.z, half = shape.half }, windows = near,
                lights = G.nearestLights(lightsAt[key], p.x, p.y),
            }
            names[#names + 1] = string.format('%s (%d window object%s near)', d.dest.name, #near, #near == 1 and '' or 's')
        end
    end
    if #doors == 0 then
        -- The saved doors are not in the scan. Mark them so the next poll does not load the cells again.
        local pos = player.position
        for id in pairs(ids) do
            b.checked[id] = b.checked[id] or { ok = false, held = true, failed = 'not in the door scan',
                t = core.getGameTime() + C.SEARCH_BACKOFF, x = pos.x, y = pos.y }
        end
        return
    end
    local v = C.VARIANTS.board
    waiting = { key = key, at = core.getRealTime(), ids = ids }
    log('%s: looking beside the door%s to %s', key, #doors == 1 and '' or 's', table.concat(names, ', '))
    player:sendEvent('OJB_CheckSpots', { key = key, w = v.w, d = v.d, h = v.h, doors = doors })
end

local function placeAt(key, id)
    local b = S.boards[key]
    local d, ch = doorById(b, id), b.checked[id]
    timed('place board', placeBoard, key, d.dest, ch.kind, ch.spot)
    local site = b.sites[d.dest]
    site.door = { x = d.x, y = d.y, z = d.z, dest = d.dest }
    site.label, site.doorId, site.score = ch.spot.label, id, ch.score
    say('%s: %s beside the door to %s at %.0f, %.0f: %s, score %.0f', key,
        ch.kind == 'wall' and string.format('%d notices pinned on the wall', #(ch.spot.slots or {}))
            or 'free-standing board',
        d.dest, d.x, d.y, ch.spot.label, ch.score)
    for i, on in ipairs(ch.spot.on or {}) do
        say('%s:   paper %d on %s', key, i, on)
    end
    if ch.kind == 'wall' and ch.spot.patches == 1 then
        say('%s: one patch only (%s)', key, ch.spot.single or 'no second stretch of wall passed')
    end
end

-- The same notices at another street-level door of the building, with fewer papers.
local function placeSecond(key, id)
    local b = S.boards[key]
    local d, ch = doorById(b, id), b.checked[id]
    local site = b.sites[d.dest]
    site.others = site.others or {}
    local sub = { second = true }
    site.others[id] = sub
    timed('place board', fillSite, key, sub, ch.kind, ch.spot)
    sub.door = { x = d.x, y = d.y, z = d.z, dest = d.dest }
    sub.label, sub.doorId, sub.score = ch.spot.label, id, ch.score
    say('%s: also at the door to %s at %.0f, %.0f: %s, up to %d papers of the same notices', key, d.dest, d.x, d.y,
        ch.kind == 'wall' and 'pinned on the wall' or 'free-standing board', C.SECOND_PAPERS)
end

-- Every other door of the interior that is street level gets the notices too; one that no longer
-- qualifies (or has become the best door) loses them.
local function syncSeconds(key, b, dest, lowest)
    local site = b.sites[dest]
    if not site or site.status ~= 'placed' then return end
    site.others = site.others or {}
    for id, sub in pairs(site.others) do
        local ch = b.checked[id]
        local ok = id ~= site.doorId and ch and ch.ok and G.streetLevel(ch.entrance or {}, lowest)
        if not ok then
            takeDown(sub)
            site.others[id] = nil
            if ch then ch.second = false end
        end
    end
    for _, d in ipairs(b.doorList) do
        local ch = b.checked[d.id]
        if d.dest == dest and d.id ~= site.doorId and ch and ch.ok and not site.others[d.id] then
            local ok, why = G.streetLevel(ch.entrance or {}, lowest)
            ch.second = ok
            ch.notSecond = not ok and why or nil
            if ok then placeSecond(key, d.id) end
        end
    end
end

-- Every checked door of one interior, best first, with why it won or lost.
local function logDoors(key, b, dest, winnerId)
    local list = {}
    for _, d in ipairs(b.doorList) do
        if d.dest == dest and b.checked[d.id] then list[#list + 1] = d end
    end
    table.sort(list, function(a, c)
        return (b.checked[a.id].score or -1e9) > (b.checked[c.id].score or -1e9)
    end)
    local win = winnerId and b.checked[winnerId]
    for _, d in ipairs(list) do
        local ch = b.checked[d.id]
        local verdict
        if not ch.ok then
            verdict = 'no spot'
        elseif d.id == winnerId then
            verdict = 'won, full set of notices'
        elseif win and ch.second then
            verdict = string.format('street level, also carries notices (%.0f behind the best)', win.score - ch.score)
        elseif win then
            verdict = string.format('lost by %.0f, no notices: %s', win.score - ch.score, ch.notSecond or 'not street level')
        else
            verdict = 'not used'
        end
        say('%s:   door at %.0f, %.0f: %s%s', key, d.x, d.y,
            ch.ok and string.format('score %.0f (%s, %s %+.0f; %s)', ch.score, ch.spot.label, 'spot', ch.spotScore,
                ch.why) or ('no spot; ' .. (ch.why or '')),
            ' - ' .. verdict)
    end
end

-- Scores every checked door of one interior against the others: spot plus entrance, where the
-- entrance part compares each door's height off its street with the building's lowest door.
local function scoreDoors(b, dest)
    local lowest
    for _, d in ipairs(b.doorList) do
        local ch = b.checked[d.id]
        local off = d.dest == dest and ch and G.offStreet(ch.entrance)
        if off and (not lowest or off < lowest) then lowest = off end
    end
    for _, d in ipairs(b.doorList) do
        local ch = b.checked[d.id]
        if d.dest == dest and ch then
            local ent, parts = G.entranceScore(ch.entrance or {},
                { front = d.front, centre = d.centre, main = d.main, lowest = lowest })
            ch.why = ch.failed or G.partsText(parts)
            ch.score = ch.ok and (ch.spotScore + ent) or nil
        end
    end
    return lowest
end

-- Decide one interior after a check: the best door found so far gets its notices; a door checked
-- later moves them only when it scores C.BETTER_BY more, so they don't hop between doors.
local function decideSite(key, b, dest)
    b.sites = b.sites or {}
    local site = b.sites[dest] or { status = 'pending' }
    b.sites[dest] = site
    local lowest = scoreDoors(b, dest)
    if site.status == 'placed' and site.doorId and b.checked[site.doorId] then
        site.score = b.checked[site.doorId].score or site.score
    end
    local bestId, best
    for _, d in ipairs(b.doorList) do
        local ch = b.checked[d.id]
        if d.dest == dest and ch and ch.ok and (not best or ch.score > best.score) then bestId, best = d.id, ch end
    end
    if site.status == 'placed' then
        if bestId and bestId ~= site.doorId and best.score >= (site.score or -1e9) + C.BETTER_BY then
            say('%s: a better spot at %s (score %.0f against %.0f); moving its notices', key, dest, best.score,
                site.score or 0)
            unplaceSite(key, dest)
            placeAt(key, bestId)
        end
        syncSeconds(key, b, dest, lowest)
        logDoors(key, b, dest, site.doorId)
    elseif bestId then
        placeAt(key, bestId)
        syncSeconds(key, b, dest, lowest)
        logDoors(key, b, dest, bestId)
    elseif doorsLeft(b, dest) == 0 then
        site.status = 'skipped'
        say('%s: no spot beside any door of %s; that one is skipped', key, dest)
        logDoors(key, b, dest, nil)
    else
        say('%s: no spot beside the doors of %s checked so far; %d more when you come near them', key, dest,
            doorsLeft(b, dest))
    end
end

-- Check every door again: skipped interiors become pending; placed ones keep their notices.
local function resetChecks(b)
    b.checked = {}
    for _, site in pairs(b.sites or {}) do
        if site.status == 'skipped' then site.status = 'pending' end
    end
    if b.status == 'skipped' then b.status = 'pending' end
end

local function sumUp(b)
    if #placedSites(b) > 0 then
        b.status = 'placed'
    elseif doorsLeft(b) > 0 then
        b.status = 'pending'
    else
        b.status = 'skipped'
    end
end

-- Results for each door checked: its spot score plus how much it looks like the main entrance.
local function onSpotResult(e)
    if twCtx.SY.owns(e.key) then return twCtx.SY.onSpots(e) end
    local asked = waiting and waiting.key == e.key and waiting.ids or {}
    if waiting and waiting.key == e.key then waiting = nil end
    local b = S.boards[e.key]
    if not b or not b.doorList or (b.status ~= 'pending' and b.status ~= 'placed') then return end
    local touched = {}
    for _, r in ipairs(e.results or {}) do
        local d = doorById(b, r.id)
        if d then
            touched[d.dest] = true
            local tried = r.tried or {}
            local entrance = r.entrance or {}
            if r.ok then
                b.checked[r.id] = { ok = true, kind = r.kind, spot = r.spot, spotScore = G.spotScore(r.spot),
                    entrance = entrance }
                log('%s: beside the door to %s at %.0f, %.0f: %s after %d rejected%s', e.key, d.dest, d.x, d.y,
                    r.spot.label, #tried, #tried > 0 and (' (' .. table.concat(tried, '; ') .. ')') or '')
            else
                local pos = thePlayer() and thePlayer().position
                b.checked[r.id] = { ok = false, entrance = entrance, held = true,
                    t = core.getGameTime() + C.SEARCH_BACKOFF, x = pos and pos.x or d.x, y = pos and pos.y or d.y }
                say('%s: no wall or board spot beside the door to %s at %.0f, %.0f. Tried: %s', e.key, d.dest, d.x,
                    d.y, table.concat(tried, '; '))
            end
        end
    end
    if e.error then
        local pos = thePlayer() and thePlayer().position
        for id in pairs(asked) do
            local d = doorById(b, id)
            b.checked[id] = b.checked[id] or { ok = false, held = true, failed = 'spot check failed',
                t = core.getGameTime() + C.SEARCH_BACKOFF,
                x = pos and pos.x or (d and d.x or 0), y = pos and pos.y or (d and d.y or 0) }
            if d then touched[d.dest] = true end
        end
        say('%s: spot check failed (%s); those doors are skipped', e.key, e.error)
    end
    log('%s: spot check cost %d rays over %d frames, %.1f ms in all, %.1f ms the slowest frame', e.key,
        e.rays or 0, e.frames or 0, e.ms or 0, e.maxMs or 0)
    if (e.maxMs or 0) > C.SLOW_MS then
        log('slow: spot check for %s took %.1f ms in one frame (over %d ms)', e.key, e.maxMs, C.SLOW_MS)
    end
    local dests = {}
    for dest in pairs(touched) do dests[#dests + 1] = dest end
    table.sort(dests)
    for _, dest in ipairs(dests) do decideSite(e.key, b, dest) end
    sumUp(b)
end

---------------------------------------------------------------------------------------------------
-- What's in a place right now

local function recordOf(actor)
    if actor.type == types.NPC then return types.NPC.record(actor) end
    return types.Creature.record(actor)
end

local function isPassive(a, rec)
    return G.hasWord(a.recordId, C.PASSIVE) or G.hasWord(rec.name, C.PASSIVE)
end

local function isHostileAlive(a)
    if not a.enabled or a.count == 0 or types.Actor.isDead(a) then return false end
    local rec = recordOf(a)
    if rec.isEssential or isPassive(a, rec) then return false end
    return types.Actor.stats.ai.fight(a).modified >= C.HOSTILE_FIGHT
end

-- Harsh Measures' Morag Tong assassins are placed next to the player with ids starting 'cybmtass';
-- they're never part of a job even if one turns up inside a dungeon.
local function isOurs(a)
    return not a.recordId:find('^cybmtass')
end

local function noScript(rec)
    return rec.mwscript == nil or rec.mwscript == ''
end

local function near(a, p, r)
    local dx, dy, dz = a.position.x - p.x, a.position.y - p.y, a.position.z - p.z
    return dx * dx + dy * dy + dz * dz < r * r
end

local function creatureGroup(rec)
    local t = rec.type
    if t == types.Creature.TYPE.Undead then return 'undead' end
    if t == types.Creature.TYPE.Daedra then return 'daedra' end
    return 'beast'
end

-- Every hostile NPC counts as people here; F.INTRUDERS treats all people groups alike.
local function actorTargetable(place, a)
    if not place.tomb then return true end
    if a.type == types.NPC then return true end
    return F.INTRUDERS[creatureGroup(types.Creature.record(a))] == true
end

-- Whether a levelled placeholder can turn into something a job here may target.
local function levelledTargetable(place, id, depth)
    if not place.tomb then return true end
    if (depth or 0) > 4 then return false end
    local rec = LEVELLED.records[id]
    if not rec then
        local c = types.Creature.records[id]
        return c ~= nil and F.INTRUDERS[creatureGroup(c)] == true
    end
    for _, e in ipairs(rec.creatures) do
        if levelledTargetable(place, e.id, (depth or 0) + 1) then return true end
    end
    return false
end

-- Live state of a place, read when a contract is taken and while the player is inside it.
-- hostiles: everything hostile (a recovery item can be on any of them). targets / pending: what a
-- cull counts, which in a tomb leaves out its own dead.
local function inspect(place)
    local cell = touch(world.getCellByName(place.n))
    local info = { hostiles = {}, targets = {}, npcs = {}, pending = {}, containers = {} }
    for _, a in ipairs(cell:getAll(types.NPC)) do
        if a.type ~= types.Player and isOurs(a) and isHostileAlive(a) then
            info.hostiles[#info.hostiles + 1] = a
            info.targets[#info.targets + 1] = a
            if noScript(types.NPC.record(a)) then info.npcs[#info.npcs + 1] = a end
        end
    end
    local creatures = cell:getAll(types.Creature)
    for _, a in ipairs(creatures) do
        if isHostileAlive(a) then
            info.hostiles[#info.hostiles + 1] = a
            if actorTargetable(place, a) then info.targets[#info.targets + 1] = a end
        end
    end
    -- A levelled placeholder counts only until what it holds has spawned, alive or dead. Tamriel
    -- Rebuilt's levelled lists hold NPCs as well as creatures.
    if LEVELLED then
        local npcs = cell:getAll(types.NPC)
        for _, l in ipairs(cell:getAll(LEVELLED)) do
            local spawned = false
            for _, list in ipairs({ creatures, npcs }) do
                for _, a in ipairs(list) do
                    if near(a, l.position, 200) then spawned = true break end
                end
                if spawned then break end
            end
            if l.enabled and not spawned and levelledTargetable(place, l.recordId) then
                info.pending[#info.pending + 1] = { x = l.position.x, y = l.position.y, z = l.position.z }
            end
        end
    end
    for _, c in ipairs(cell:getAll(types.Container)) do
        local rec = types.Container.record(c)
        if c.enabled and noScript(rec) and not rec.isRespawning and not rec.isOrganic
            and not c.owner.recordId and not c.owner.factionId then
            info.containers[#info.containers + 1] = c
        end
    end
    info.count = #info.targets + #info.pending
    return info
end

local function strongest(list)
    local best, lv
    for _, a in ipairs(list) do
        local l = types.Actor.stats.level(a).current
        if not lv or l > lv then best, lv = a, l end
    end
    return best
end


-- What this board already shows or has given out: item kinds, posters' surnames and titles, so
-- no two notices on one board share any of them.
local function usedOn(key)
    local kinds, names, titles, bodies = {}, {}, {}, {}
    local b = S.boards[key]
    for _, body in ipairs(b and b.recent or {}) do bodies[#bodies + 1] = body end
    for _, n in ipairs(b and b.notices or {}) do
        if n.itemKind then kinds[n.itemKind] = true end
        if n.from then names[T.surname(n.from)] = true end
        titles[n.title] = true
        bodies[#bodies + 1] = n.body
    end
    for _, c in pairs(S.contracts) do
        if c.board == key then
            if c.itemKind then kinds[c.itemKind] = true end
            if c.from then names[T.surname(c.from)] = true end
            titles[c.title] = true
        end
    end
    return { kinds = kinds, names = names, titles = titles, bodies = bodies }
end

local function shuffled(list)
    local out = {}
    for i, x in ipairs(list) do out[i] = x end
    for i = #out, 2, -1 do
        local j = math.random(i)
        out[i], out[j] = out[j], out[i]
    end
    return out
end

local function itemKindByKey(key)
    for _, list in pairs(C.ITEM_KINDS) do
        for _, k in ipairs(list) do
            if k.key == key then return k end
        end
    end
    return nil
end

-- A record of the contract's own, so the item has a name nothing else in the world shares. Saved
-- with the game; one small record per recovery or bounty taken. A template keeps everything but the
-- name: a key stays a key (Detect Key), an enchanted ring keeps its enchantment (Detect Enchantment).
local function makeItem(baseId, name, slip)
    local base = types.Book.records[baseId]
    if base then
        local text = base.text
        if slip then text = text .. '<BR><BR>A slip tucked inside: ' .. slip .. '<BR>' end
        S.madeRecords = (S.madeRecords or 0) + 1
        return world.createRecord(types.Book.createRecordDraft({ template = base, name = name, text = text })).id
    end
    for _, T in ipairs({ types.Miscellaneous, types.Clothing, types.Weapon }) do
        base = T.records[baseId]
        if base then
            S.madeRecords = (S.madeRecords or 0) + 1
            return world.createRecord(T.createRecordDraft({ template = base, name = name })).id
        end
    end
    return baseId
end

local function inContract(placeName)
    for _, c in pairs(S.contracts) do
        if c.place == placeName then return true end
    end
    return false
end

---------------------------------------------------------------------------------------------------
-- Rewards

-- The guild skill a training reward would work on, and what a trainer would charge for it.
local function trainingFor(player, faction)
    if not C.GUILDS[faction] then return nil end
    if now() - (S.trainingAt[faction] or -1e9) < C.TRAINING_COOLDOWN_DAYS then return nil end
    local rec = core.factions.records[faction]
    if not rec then return nil end
    local best, bestV
    for _, sk in ipairs(rec.skills) do
        local stat = types.NPC.stats.skills[sk]
        if stat then
            local v = stat(player).base
            if v < C.TRAINING_SKILL_CAP and (not bestV or v > bestV) then best, bestV = sk, v end
        end
    end
    if not best then return nil end
    return best, bestV * (core.getGMST('iTrainingMod') or 10)
end

local function rewardText(reward, skill)
    return T.reward(reward, itemNames(reward.items), skillName(skill))
end

---------------------------------------------------------------------------------------------------
-- Notices

local function boardOrigin(key)
    local b = S.boards[key]
    local first = b and placedSites(b)[1]
    if first and first.site.door then return first.site.door.x, first.site.door.y end
    local d = DEFS[key] or DEFS[b and b.originKey or '']
    if d then return d.def.near[1], d.def.near[2] end
    return nil
end

local function postersOf(key)
    local d = DEFS[key]
    if d then return d.def.posters end
    return S.boards[key].posters
end

local function candidatesFor(key, player)
    local ox, oy = boardOrigin(key)
    if not ox then return {} end
    local level = playerLevel(player)
    -- cybTombs: 0 never accused, 1-4 accused and not yet settled (Temple and Redoran refuse service),
    -- 5 settled by donation.
    local tombState = HM and hmVar('cybTombs') or 0
    local tombsBlocked = tombState >= 1 and tombState <= 4
    local cut = now() - C.REUSE_DAYS
    for name, day in pairs(S.used) do
        if day < cut then S.used[name] = nil end
    end
    local recentCut = now() - C.REPOST_DAYS
    local recent = {}
    for name, day in pairs(S.posted) do
        if day < recentCut then S.posted[name] = nil else recent[name] = true end
    end
    local poster = postersOf(key)[1]
    local size = twCtx.sizeOf(key)
    local contracts = featureOn.contractGroups
    local sealed = false
    local onBoard = {}
    for _, x in ipairs(S.boards[key] and S.boards[key].notices or {}) do
        if x.seal then sealed = true end
        if x.pk then onBoard[x.pk] = (onBoard[x.pk] or 0) + 1 end
    end
    local out = {}
    for _, p in ipairs(AVAIL) do
        local dist = G.distCells(ox, oy, p.x, p.y)
        if dist <= C.RADIUS_CELLS and (S.used[p.n] or -1e9) < cut and not inContract(p.n)
            and not (tombsBlocked and p.tomb) and contracts then
            -- The job brings its own group: the tier is drawn, and the place only has to have room.
            local _, _, occupants = R.statsAt(p.t, level)
            local region = regionName(p.x, p.y)
            local tier = TI.contractTier({ size = size, level = level, rules = twCtx.rules, region = region,
                poster = poster, occupants = occupants, kind = p.k, dist = dist, sealed = sealed, on = featureOn,
                eliteRoom = DG.eliteIn(region) < C.DANGER.ELITE_PER_REGION }, math.random)
            if tier then
                out[#out + 1] = { place = p, dist = dist, rating = { tier = tier, contract = true, occupants = occupants },
                    region = region, w = TI.weight(tier, region, poster, size) }
            end
        elseif dist <= C.RADIUS_CELLS and (S.used[p.n] or -1e9) < cut and not inContract(p.n)
            and not (tombsBlocked and p.tomb) then
            local rating = TI.ratePlace(p, dist)
            if not rating.excluded and TI.postsAt(rating.tier, size) and TI.allowed(rating.tier, level, twCtx.rules) then
                local region = regionName(p.x, p.y)
                if rating.tier ~= 'elite' or DG.eliteIn(region) < C.DANGER.ELITE_PER_REGION then
                    out[#out + 1] = { place = p, dist = dist, rating = rating, region = region,
                        w = TI.weight(rating.tier, region, poster, size) }
                end
            end
        end
    end
    return P.spread(out, C.CANDIDATES_PER_REFRESH, recent, nil, onBoard)
end

local function directionsTo(key, p)
    local ox, oy = boardOrigin(key)
    local d = DEFS[key] or DEFS[S.boards[key].originKey]
    local region = regionName(p.x, p.y)
    return D.describe({
        town = { name = d.town.name, x = ox, y = oy }, place = p, region = region,
        landmarks = LANDMARKS.landmarks, travel = LANDMARKS.travel, have = hasFile,
        door = ST.area(p, region).door,
    })
end

local function freeItemKinds(poster, used)
    local out = {}
    for _, k in ipairs(shuffled(C.ITEM_KINDS[poster] or C.ITEM_KINDS.town)) do
        if not used.kinds[k.key] then out[#out + 1] = k end
    end
    return out
end

-- The kinds to try for this place, P.kind's choice first; a kind with no story that fits the
-- place and its foes falls through to the next. A water place is cleared only when P.kind drew it.
-- fresh: last posted kind on this board, kinds finished, and when; nil treats every kind as new.
local function kindsToTry(poster, sinfo, have, watery, fresh)
    local first = P.kind(poster, sinfo, have, nil, watery, fresh)
    if not first then return {} end
    local out = { first }
    for _, k in ipairs(C.KINDS[poster] or C.KINDS.town) do
        if k ~= first and (have[k] or 0) < 2 and not (watery and k == 'nest') then out[#out + 1] = k end
    end
    return out
end

-- cand.kind: only that kind (a follow-up), else P.kind's choice and the rest.
local function makeNotice(key, cand, player, poster, have)
    local p = cand.place
    local region = cand.region or regionName(p.x, p.y)
    local rating = cand.rating or TI.ratePlace(p, cand.dist)
    -- Re-checked here: one refresh can hold two elite candidates from the same region, and two
    -- sealed ones for the same board.
    if rating.tier == 'elite' and DG.eliteIn(region) >= C.DANGER.ELITE_PER_REGION then return nil end
    local diff = rating.tier
    if rating.contract and (diff == 'dangerous' or diff == 'elite') then
        for _, x in ipairs(S.boards[key].notices or {}) do
            if x.seal then diff = 'normal' end
        end
    end
    local level = playerLevel(player)
    local danger, loot, foes = R.statsAt(p.t, level)
    local sinfo, band
    if rating.contract then
        band = DG.contractBand(p, diff)
        if not band then
            log('%s: no %s group fits %s (%s)', key, diff, p.n, p.k)
            return nil
        end
        local ch = band.champion
        local targets = DG.composition(band)
        sinfo = { hostiles = DG.size(band), targets = targets,
            boss = ch and { name = ch.name, female = ch.female, group = band.group } or nil }
        danger = band.danger
    else
        sinfo = P.info(p, level, foes)
    end
    -- Temple voice on a town board: a tomb, a daedric shrine, or the place's own dead or daedra.
    if poster == 'town' then
        local top = sinfo.targets and sinfo.targets[1]
        if p.tomb or p.k == 'daedric' or (top and (top.group == 'undead' or top.group == 'daedra'
            or top.group == 'raised')) then
            poster = 'temple'
        end
    end
    local used = usedOn(key)
    local d = DEFS[key] or DEFS[S.boards[key].originKey]
    local text, kind
    local hold = math.random() < C.LOOSE.CHANCE and 'loose' or 'chest'
    local guardians = F.guardians(p, level)
    for _, k in ipairs(cand.kind and { cand.kind } or kindsToTry(poster, sinfo, have, F.watery(p),
        { last = S.boards[key] and S.boards[key].lastKind, done = S.doneKinds or {},
            finished = S.finished or 0, at = S.freshAt or {}, now = now() })) do
        if k ~= 'bounty' or sinfo.boss or sinfo.band then
            local why
            text, why = ST.build({
                kind = k, poster = poster, place = p, level = level, danger = danger,
                hostiles = band and (sinfo.hostiles + guardians) or foes, guardians = guardians, targets = sinfo.targets,
                boss = k == 'bounty' and sinfo.boss or nil, town = d.town.name, region = regionName(p.x, p.y),
                where = directionsTo(key, p), freeItems = freeItemKinds(poster, used), used = used,
                hold = hold, rnd = math.random,
            })
            if text then kind = k break end
            log('%s: no %s notice for %s (%s)', key, k, p.n, why)
        end
    end
    if not text then return nil end
    if band then
        local lines, plain = DG.contractLines(band, diff)
        text = DG.tellBeforeAsk(text, lines, plain)
    end
    local dist01 = math.min(1, cand.dist / C.DISTANCE_FULL_CELLS)
    local id = S.nextId
    local reward, value, skill
    if band and (diff == 'dangerous' or diff == 'elite') then
        -- Sealed work pays as the sealed bands do: sessions at the tier and a curated piece.
        reward, value, skill = DG.pay(id, diff, dist01, poster, text.trade, player, band.within)
    else
        value = TI.value(diff, band and band.within or rating.within, dist01, not band and p.t[2][2] or nil, math.random())
        local price
        if C.GUILDS[poster] then skill, price = trainingFor(player, poster) end
        reward = R.split(value, diff, price, id, R.poolFor(poster, text.trade))
        skill = reward.training and skill or nil
    end
    local boss = not band and kind == 'bounty' and sinfo.boss or nil
    local warn
    if HM and p.mt and hmVar('cybHouseWar') == 1 then warn = T.WARN_MORAG_TONG end
    S.nextId = S.nextId + 1
    have[kind] = (have[kind] or 0) + 1
    S.posted[p.n] = now()
    local n = {
        id = id, kind = kind, poster = poster, place = p.n, pk = p.k or 'cave', level = level, value = value,
        reward = reward, skill = reward.training and skill or nil, boss = boss and boss.id,
        itemKind = text.item and text.item.key, itemName = text.itemName, itemPhrase = text.itemPhrase,
        title = text.title, body = text.body, plain = text.plain, where = text.where,
        from = poster == 'legion' and (S.boards[key].signer or DEFS[key] and DEFS[key].def.signer) or text.from,
        trade = text.trade, warn = warn, expireDays = math.random(C.EXPIRE_DAYS[1], C.EXPIRE_DAYS[2]),
        hold = kind == 'recovery' and text.hold or nil, on = text.on,
        diff = diff, seal = C.DANGER.SEAL[diff], typical = math.floor(TI.typicalDanger(p) + 0.5),
        region = region, band = band, contract = band and true or nil,
    }
    DG.multi(n, text, diff)
    DG.elitePosted(n)
    return n
end

-- Each place looked at is one getCellByName plus getAll calls, which load that interior's
-- references (not its meshes) into the engine's cell store; the line says how many it took.
local function finishRefresh(job, looked)
    local b = S.boards[job.key]
    local up, t = 0, now()
    for _, n in ipairs(b.notices) do
        if not job.before[n.id] then
            twCtx.BD.stamp(n, t, math.random, job.first)
            up = up + 1
        end
    end
    b.refreshedAt = t
    b.change = (up > 0 or job.down > 0) and { day = math.floor(t), up = up, down = job.down } or b.change
    syncPapers(job.key)
    say('%s: %d notices up (%d new, %d down), %d places looked at', job.key, #b.notices, up, job.down, looked)
end

-- News, a notice or a shop ad for the board's spare room (board.lua newsRoom). Town boards mix shop
-- ads (C.BOARD.AD_SHARE), townsfolk's flavour notices and town news; guild halls, forts and
-- companies post their own news (news.lua). A fort's tavern ad comes from its town's publicans.
local function fillNews(job)
    local key = job.key
    local b, d = S.boards[key], DEFS[key]
    if not d then return end
    local BD, NW, AD = twCtx.BD, twCtx.NW, twCtx.AD
    local tkey = d.town.key
    for _ = 1, BD.newsRoom(b.notices, job.target) do
        local used, n = usedOn(key), nil
        local shops = (SUP.towns[tkey] or {}).shops or {}
        local townish = job.kind == 'town' or job.kind == 'village'
        local adShare = townish and C.BOARD.AD_SHARE or job.kind == 'fort' and C.BOARD.AD_SHARE / 2 or 0
        if #shops > 0 and math.random() < adShare then
            local taken = {}
            for _, ob in pairs(S.boards) do
                for _, x in ipairs(ob.notices or {}) do
                    if x.shop then taken[x.shop.npc] = true end
                end
            end
            local list = {}
            for _, s in ipairs(shops) do
                if types.NPC.records[s.id] and (job.kind ~= 'fort' or s.trade:lower():find('publican', 1, true)) then
                    list[#list + 1] = s
                end
            end
            local ox, oy = boardOrigin(key)
            local EM = I.EconomyMarket
            n = ox and AD.make({ shops = list, ox = ox, oy = oy, town = d.town.name, used = taken,
                closed = S.closedShops, itemName = itemName, have = function(id) return itemName(id) ~= id end,
                rnd = math.random, cheap = EM and EM.version == 1 and EM.plentiful and EM.plentiful(d.town.name) or nil })
        end
        if not n and townish and math.random() < 0.5 then
            n = ST.flavour({ town = d.town.name, used = used, rnd = math.random })
            if n then n.kind = 'flavour' end
        end
        if not n then
            local posters = postersOf(key)
            local kind = job.kind == 'fort' and 'legion' or job.kind == 'guild' and posters[math.random(#posters)]
                or job.kind == 'village' and 'town' or job.kind
            n = NW.pick({ kind = kind, town = d.town.name, fort = d.town.name, signer = b.signer or d.def.signer, used = used,
                rnd = math.random })
            if n then n.kind = 'news' end
        end
        if not n then break end
        n.id, n.flavour, n.poster = S.nextId, true, n.poster or postersOf(key)[1]
        S.nextId = S.nextId + 1
        b.notices[#b.notices + 1] = n
    end
end


-- Paid jobs on a board: what the job cap and C.SLOTS count. Requisitions and flavour don't.
local function paidJobs(b)
    local n = 0
    for _, x in ipairs(b.notices or {}) do
        if x.kind ~= 'req' and not x.flavour then n = n + 1 end
    end
    return n
end

local function refreshStep(job, player)
    local b = S.boards[job.key]
    if job.quiet then
        finishRefresh(job, 0)
        return true
    end
    job.i = job.i + 1
    local cand = job.cands[job.i]
    if not cand or twCtx.BD.count(b.notices, 'job') >= job.wantJobs then
        fillNews(job)
        timed('stray notice', twCtx.SY.refreshed, job, player)
        finishRefresh(job, job.i - 1)
        return true
    end
    local posters = postersOf(job.key)
    local poster = posters[(#b.notices % #posters) + 1]
    local n = makeNotice(job.key, cand, player, poster, job.have)
    if n then
        b.notices[#b.notices + 1] = n
        b.lastKind = n.kind
    end
    return false
end

-- Bloodmoon's werewolf attack on Fort Frostmoth: BM_CariusGone starts at 10 when the player comes
-- back to the attacked fort, and BM_Smugglers 100 is the same return. Neither is ever undone.
function twCtx.fortAttacked(player)
    local q = types.Player.quests(player)
    local gone, smug = q['bm_cariusgone'], q['bm_smugglers']
    return (gone and gone.stage >= 10) or (smug and smug.stage >= 100) or false
end

-- Whether an NPC of a fort is alive in its cell. One getCellByName and getAll(types.NPC), at most
-- once per fort roll; the cell is in the load order whenever the fort board's doors are. Found dead
-- is remembered (S.fortDead, by record id, never cleared) and not looked for again; found disabled
-- counts as gone this roll (Bloodmoon disables Carius in the attack); not found at all counts as
-- alive, so a plugin moving or renaming the NPC never closes a fort.
function twCtx.fortAlive(id, cellName)
    S.fortDead = S.fortDead or {}
    if S.fortDead[id] then return false end
    for _, a in ipairs(touch(world.getCellByName(cellName)):getAll(types.NPC)) do
        if a.recordId == id then
            if types.Actor.isDead(a) then S.fortDead[id] = true return false end
            return a.enabled
        end
    end
    return true
end

-- A fort board's signer for this roll, or nil and why the board is closed.
function twCtx.fortSigner(key, player)
    local def = DEFS[key].def
    if def.siege and player and twCtx.fortAttacked(player) then return nil, 'siege' end
    if not def.qm or twCtx.fortAlive(def.qm[1], def.qm[2]) then return def.signer end
    local s = def.standIn
    if s and twCtx.fortAlive(s[1], s[2]) then return s[3] end
    return nil, 'noqm'
end

-- A closed fort keeps one notice saying so, and nothing else; held work still comes back here.
function twCtx.closeFort(key, b, why)
    local keep, down = nil, 0
    for _, n in ipairs(b.notices) do
        if n.closed == why then keep = n
        else
            RQ.discard(n)
            down = down + 1
        end
    end
    if not keep then
        keep = twCtx.NW.closed(why, { fort = DEFS[key].town.name })
        keep.id, keep.flavour, keep.poster = S.nextId, true, 'legion'
        S.nextId = S.nextId + 1
    end
    if not b.closed then say('%s: closed (%s)', key, why) end
    b.notices, b.closed = { keep }, why
    return down
end

-- A roll: notices whose stay ran out come down (board.lua), then requisitions, dangerous and open
-- world notices, place jobs and news fill the gaps up to this roll's mix. A requisition answers
-- for itself (reqs.lua keeps); a chain's follow-up stays CHAIN_KEEP_DAYS.
local function startRefresh(key, player)
    local b = S.boards[key]
    local BD, t = twCtx.BD, now()
    b.notices = b.notices or {}
    local first = #b.notices == 0
    for _, n in ipairs(b.notices) do
        if not n.postedAt then n.postedAt = b.refreshedAt or t end
    end
    if DEFS[key] and DEFS[key].def.qm then
        local signer, why = twCtx.fortSigner(key, player)
        if not signer then
            local before = {}
            for _, n in ipairs(b.notices) do before[n.id] = true end
            local down = twCtx.closeFort(key, b, why)
            return { key = key, quiet = true, before = before, down = down, first = first }
        end
        if b.signer and b.signer ~= signer then
            for _, n in ipairs(b.notices) do
                if n.from == b.signer then n.from = signer end
            end
            say('%s: %s now signs for the fort', key, signer)
        end
        b.signer = signer
        if b.closed then
            b.notices, b.closed = {}, nil
        end
    end
    local stay, down = BD.roll(b.notices, t, function(n)
        if n.kind == 'req' then return RQ.keeps(n) end
        if n.chainStep and t - n.postedAt < C.TWIST.CHAIN_KEEP_DAYS then return true end
        return nil
    end)
    local recent = b.recent or {}
    for _, n in ipairs(down) do
        recent[#recent + 1] = n.body
        RQ.discard(n)
    end
    while #recent > C.RECENT_BODIES do table.remove(recent, 1) end
    b.recent, b.notices = recent, stay
    DG.eliteSweep()
    local before, have = {}, {}
    for _, n in ipairs(stay) do
        before[n.id] = true
        if BD.family(n) == 'job' then have[n.kind] = (have[n.kind] or 0) + 1 end
    end
    local kind = BD.kindOf(postersOf(key), COMPANY[key], DEFS[key] and DEFS[key].def.village)
    local target = BD.target(kind, math.random)
    local w = who(player)
    local cap = R.jobCap(w, recentDone())
    b.busy = cap < R.jobCap(w, 0) or nil
    timed('requisitions', RQ.fill, key, player)
    if kind == 'town' then timed('lost ledger search', RQ.tryLost, key, player) end
    if not COMPANY[key] then
        timed('dangerous and reinfested notices', DG.post, key, player, b.notices, BD.room(b.notices, target, cap).paid)
        timed('open world notices', twCtx.WL.post, key, player, b.notices, BD.room(b.notices, target, cap).wild)
    end
    local addJobs = BD.jobsRoom(b.notices, target, cap)
    local wantJobs = BD.count(b.notices, 'job') + addJobs
    return { key = key, cands = addJobs > 0 and candidatesFor(key, player) or {}, i = 0, have = have, cap = cap,
        wantJobs = wantJobs, target = target, kind = kind, before = before, down = #down, first = first }
end

local function refreshDue(b)
    return now() - (b.refreshedAt or -1e9) >= C.BOARD.ROLL_DAYS
end

-- One timer chain at most: pumpArmed is true while a pumpRefresh call is scheduled.
local pumpArmed = false
local pumpRefresh

local function armPump()
    if pumpArmed then return end
    pumpArmed = true
    async:newUnsavableSimulationTimer(0.1, pumpRefresh)
end

pumpRefresh = function()
    pumpArmed = false
    local player = thePlayer()
    if not refreshing then
        local key = table.remove(refreshQueue, 1)
        if not key then return end
        refreshing = startRefresh(key, player)
    end
    if timed('refresh step', refreshStep, refreshing, player) then
        refreshing = nil
    end
    if refreshing or #refreshQueue > 0 then armPump() end
end

local function queueRefresh(key)
    if refreshing and refreshing.key == key then return end
    for _, k in ipairs(refreshQueue) do
        if k == key then return end
    end
    refreshQueue[#refreshQueue + 1] = key
    armPump()
end

-- Used when a window opens on a board whose notices aren't ready: finish now. Notices come from
-- the place data, so this loads no cells.
local function refreshNow(key, player)
    local job
    if refreshing and refreshing.key == key then
        job = refreshing
        refreshing = nil
    else
        for i, k in ipairs(refreshQueue) do
            if k == key then table.remove(refreshQueue, i) break end
        end
        job = startRefresh(key, player)
    end
    timed('refresh (window opened)', function()
        while not refreshStep(job, player) do end
    end)
    if #refreshQueue > 0 then armPump() end
end

---------------------------------------------------------------------------------------------------
-- Contracts

local function townOf(key)
    local d = DEFS[key] or DEFS[S.boards[key] and S.boards[key].originKey or '']
    return d and d.town.name or '?'
end

local function canHandInAt(c, key, guild)
    if c.state ~= 'done' then return false end
    if not guild and TW.ownerTown(c) and TW.ownerTown(c) == townOf(key) then return true end
    if C.GUILDS[c.poster] then
        if guild == c.poster then return true end
        for _, p in ipairs(postersOf(key) or {}) do
            if p == c.poster then return true end
        end
        return false
    end
    return c.board == key
end

local function returnTo(c)
    if C.GUILDS[c.poster] then
        return 'any ' .. ((core.factions.records[c.poster] or {}).name or 'guild') .. ' notices or steward'
    end
    return 'the notices in ' .. townOf(c.board)
end

local function placeByName(name)
    for _, p in ipairs(AVAIL) do
        if p.n == name then return p end
    end
    return nil
end

-- Where the player stands for "how far from here": their position outdoors, or where the first
-- door out of this interior leads. nil when no door here goes straight outside.
local function playerGround(player)
    local cell = player.cell
    if not cell then return nil end
    if cell.isExterior then return { x = player.position.x, y = player.position.y } end
    for _, d in ipairs(cell:getAll(types.Door)) do
        if types.Door.isTeleport(d) then
            local dest = destCellOf(d)
            if dest and dest.isExterior then
                local p = types.Door.destPosition(d)
                return { x = p.x, y = p.y, inside = true }
            end
        end
    end
    return nil
end

local function fromHere(c, player, ground)
    if not player then return nil end
    if player.cell and player.cell.name == c.place then return 'You are there now.' end
    local px, py = c.px, c.py
    if not px then
        local p = placeByName(c.place)
        if not p then return nil end
        px, py = p.x, p.y
    end
    local mode = twCtx.rules.directions
    if not ground or mode == 'off' then return nil end
    local dx, dy = px - ground.x, py - ground.y
    local dir = G.bearing(ground.x, ground.y, px, py)
    local past
    if mode ~= 'exact' then
        -- '\0' stands for no name: an empty one would rule out every landmark as overlapping it.
        local via = D.onTheWay(LANDMARKS.landmarks, ground.x, ground.y, px, py, 1.5, c.board and townOf(c.board) or '\0',
            c.place or '\0', hasFile)
        past = via and T.placeName(via.n).text
    end
    return T.fromYou(mode, math.sqrt(dx * dx + dy * dy), dir, past, ground.inside, c.id % 2 + 1)
end

-- Before the player has been inside: the notice as posted, in the detail setting's version.
-- After: the plain version and what was really there.
local function contractBody(c)
    local body = plainNotices and c.plain or c.body
    if c.details then body = (c.plain or c.body) .. ' ' .. c.details end
    if c.short then body = body .. ' Fewer than you were told.' end
    local more = TW.logLines(c)
    return more and (body .. ' ' .. more) or body
end

local function contractView(c, key, guild, player, ground)
    local PA = require('scripts.ojb.paper')
    -- How far along an active contract is, in a few words for the contracts strip. c.details is
    -- noted on the first visit; c.fallen when the place is checked with the player in it.
    local progress
    if c.state == 'active' then
        if c.kind == 'nest' and c.fallen and c.targets and #c.targets > 0 then
            progress = string.format('%d of %d', math.min(c.fallen, #c.targets), #c.targets)
        elseif c.kind == 'bounty' and c.leaderDown then
            progress = 'leader down'
        else
            progress = not c.details and 'not started' or c.kind == 'recovery' and 'searching' or 'under way'
        end
    end
    return {
        style = PA.styleOf({ kind = c.kind, poster = c.poster, trade = c.trade, title = c.title,
            pool = c.reward and c.reward.pool, wild = c.wild and c.wild.type }),
        id = c.id, title = c.title, body = contractBody(c), where = c.where, from = c.from, warn = c.warn,
        state = c.state, kind = c.kind, place = c.place, seal = c.seal, tier = c.tier or (c.seal and c.diff) or nil,
        diff = TI.of(c), marks = TI.MARKS[TI.of(c)],
        reward = rewardText(c.reward, c.skill),
        daysLeft = math.max(0, math.floor(c.expiresAt - now() + 0.5)),
        handIn = key and canHandInAt(c, key, guild) or false,
        returnTo = TW.ownerTown(c) and (returnTo(c) .. ', or to its owner at the notices in ' .. TW.ownerTown(c))
            or returnTo(c),
        itemName = c.itemName,
        here = fromHere(c, player, ground),
        progress = progress,
    }
end

local function boardView(key, guild)
    local PA = require('scripts.ojb.paper')
    local b = S.boards[key]
    local player = thePlayer()
    local notices = {}
    local ox, oy = boardOrigin(key)
    local today = now()
    -- What every paper carries whatever its kind: its paper, days up and how far its place is.
    local function papered(view, n)
        view.style = PA.styleOf({ kind = view.kind, poster = n.poster, trade = n.trade, title = n.title,
            pool = n.reward and n.reward.pool, wild = n.wild and n.wild.type, flavour = view.flavour })
        view.age = math.max(0, today - (n.postedAt or today))
        local px, py = n.wild and n.wild.x, n.wild and n.wild.y
        if not px and n.place then
            local p = placeByName(n.place)
            px, py = p and p.x, p and p.y
        end
        if px and ox then view.dist = T.distanceFor(twCtx.rules.directions, math.sqrt((px - ox) ^ 2 + (py - oy) ^ 2)) end
        notices[#notices + 1] = view
    end
    for _, n in ipairs(b.notices or {}) do
        if n.flavour then
            local shop = n.shop
            if shop then
                local names = {}
                for _, s in ipairs(shop.stock or {}) do names[#names + 1] = s.name end
                shop = { name = shop.name, keeper = shop.keeper, trade = shop.trade, where = shop.where, stock = names,
                    closed = S.closedShops and S.closedShops[shop.npc] or nil }
            end
            papered({ id = n.id, title = n.title, body = n.body, from = n.from,
                kind = n.kind == 'ad' and 'ad' or n.kind == 'news' and 'news' or 'flavour', flavour = true, shop = shop }, n)
        elseif n.kind == 'req' then
            local status, ready, sheet = 'Bring the goods here to be paid.', false, nil
            if player then status, ready, sheet = RQ.status(player, n, key) end
            papered({ id = n.id, title = n.title, body = n.body, from = n.from, kind = 'req', req = true,
                reward = rewardText(n.reward, n.skill), status = status, ready = ready, sheet = sheet,
                grade = n.grade, sub = n.sub, poster = n.poster, total = n.value, fee = n.fee }, n)
        else
            papered({
                id = n.id, title = n.title, body = plainNotices and n.plain or n.body, where = n.where, from = n.from,
                warn = n.warn, seal = n.seal, tier = n.tier or (n.seal and n.diff) or nil, wild = n.wild and n.wild.type or nil,
                diff = TI.of(n), marks = TI.MARKS[TI.of(n)],
                kind = n.kind, reward = rewardText(n.reward, n.skill), days = n.expireDays,
                guild = C.GUILDS[n.poster] and n.poster or nil,
            }, n)
        end
    end
    local contracts = {}
    local ground = player and playerGround(player)
    for _, c in pairs(S.contracts) do
        contracts[#contracts + 1] = contractView(c, key, guild, player, ground)
    end
    table.sort(contracts, function(a, b2) return a.id < b2.id end)
    local d = DEFS[key]
    local title
    if guild then
        title = (core.factions.records[guild] or {}).name or 'Guild'
        title = title .. ': ' .. townOf(key)
    else
        title = 'Notices: ' .. (d and d.town.name or townOf(key))
    end
    local max = maxHeld(player)
    local note
    if max > C.MAX_HELD and not S.perkNoted then
        note = 'Word of your work has got around. You can carry a fourth job at a time now.'
        S.perkNoted = true
    end
    return {
        key = key, guild = guild, title = title, notices = notices, contracts = contracts,
        company = COMPANY[key] and COMPANY[key].name or nil,
        held = heldCount(), max = max, busy = b.busy, note = note,
        change = twCtx.BD.changeLine(b.change, math.floor(now())),
    }
end

local function sendBoard(player, key, guild)
    player:sendEvent('OJB_ShowBoard', boardView(key, guild))
end

local function cleanupWorldItem(c)
    if not c.item then return end
    local player = thePlayer()
    local inv = types.Actor.inventory(player)
    local held = inv:find(c.item)
    if held then held:remove() end
    local lo = c.loose and c.loose.obj
    if lo and not held then
        if not lo:isValid() then touch(world.getCellByName(c.place)):getAll(types.Miscellaneous) end
        if lo:isValid() and lo.count > 0 then lo:remove() end
    end
    if c.holder then
        if not c.holder:isValid() then touch(world.getCellByName(c.place)):getAll(types.Container) end
        if c.holder:isValid() then
            local hinv = c.holder.type == types.Container and types.Container.content(c.holder)
                or types.Actor.inventory(c.holder)
            local it = hinv:find(c.item)
            if it then it:remove() end
        end
    end
end

local function dropContract(c, why)
    cleanupWorldItem(c)
    DG.dropped(c, why)
    twCtx.WL.dropped(c)
    SP.release(c.id)
    S.contracts[c.id] = nil
    DG.eliteSweep()
    log('contract %d (%s, %s) %s', c.id, c.kind, c.place, why)
end

-- The bounty's leader carries a signet of the contract's own, named for them.
local function makeLeader(c, leader)
    local leaderName = types.NPC.record(leader).name
    c.itemName = leaderName .. "'s Signet"
    c.itemPhrase = leaderName .. "'s signet"
    c.item = makeItem(C.SIGNET_BASE, c.itemName)
    world.createObject(c.item):moveInto(types.Actor.inventory(leader))
    c.leader, c.holder, c.targets = leader, leader, { leader }
    c.leaderPending = nil
end

local function take(player, key, noticeId, guild)
    local b = S.boards[key]
    if not b then return end
    local n, idx
    for i, x in ipairs(b.notices or {}) do
        if x.id == noticeId then n, idx = x, i end
    end
    if not n or n.flavour or n.kind == 'req' then return end
    if heldCount() >= maxHeld(player) then
        tell(player, string.format('You already hold %d contracts. Finish or abandon one first.', maxHeld(player)))
        return
    end
    if C.GUILDS[n.poster] and not isMember(player, n.poster) then
        tell(player, 'This work is for members of the Guild.')
        return
    end
    if n.wild then
        twCtx.WL.take(n, b.handIn or key)
        table.remove(b.notices, idx)
        syncPapers(key, true)
        player:sendEvent('OJB_Contracts', { held = heldCount() })
        sendBoard(player, key, guild)
        return
    end
    local place = placeByName(n.place)
    -- The first getAll on the dungeon makes the engine read its references; logged on its own so
    -- the footprint line shows how much of taking a contract that is.
    local info = place and timed('read the place (first look loads its cell)', inspect, place)
    local live = info and (n.kind == 'recovery' and #info.hostiles or info.count) or 0
    local least = C.MIN_FOES[n.kind] or 1
    if live < least and not n.band then
        say('notice %d (%s at %s) taken down: %d hostile left, the job needs %d', n.id, n.kind, n.place, live, least)
        table.remove(b.notices, idx)
        syncPapers(key, true)
        tell(player, 'Someone has already seen to that one. You take the notice down.')
        return
    end
    local c = {
        id = n.id, kind = n.kind, poster = n.poster, place = n.place, board = b.handIn or key,
        title = n.title, body = n.body, plain = n.plain, where = n.where, from = n.from, warn = n.warn,
        level = n.level, value = n.value, reward = n.reward, skill = n.skill,
        takenAt = now(), expiresAt = now() + n.expireDays, state = 'active',
        px = place.x, py = place.y, itemKind = n.itemKind, chainStep = n.chainStep,
        diff = n.diff, seal = n.seal, typical = n.typical, region = n.region, trade = n.trade,
    }
    local banded = DG.take(c, n)
    if banded then say('contract %d: a %s band waits at %s', c.id, c.tier, c.place) end
    if banded and n.kind ~= 'recovery' then
        -- The band is the job: its targets and leader are made on the first visit.
    elseif n.kind == 'nest' then
        c.targets = info.targets
        c.pending = #info.pending > 0 and info.pending or nil
    elseif n.kind == 'bounty' then
        local leader
        for _, a in ipairs(info.npcs) do
            if a.recordId == n.boss then leader = a end
        end
        leader = leader or strongest(info.npcs)
        if leader then
            makeLeader(c, leader)
        elseif #info.pending > 0 then
            -- Nobody has spawned yet: the leader is picked from the levelled spawns on arrival.
            c.targets, c.pending, c.leaderPending = {}, info.pending, true
            c.itemPhrase = "their leader's signet"
        else
            tell(player, 'That notice is out of date. You take it down.')
            table.remove(b.notices, idx)
            syncPapers(key, true)
            return
        end
    else
        -- A chest or sack, else a person; never a creature, which could not carry it. With nowhere
        -- in the place, one of the band carries it.
        local holder = info.containers[math.random(math.max(1, #info.containers))] or strongest(info.npcs)
        local bandPeople = banded and (n.band.champion ~= nil or (function()
            for _, m in ipairs(n.band.members) do if not m.creature then return true end end
            return false
        end)())
        if not holder and bandPeople then c.bandCarries = true end
        if not holder and not c.bandCarries then
            tell(player, 'That notice is out of date. You take it down.')
            table.remove(b.notices, idx)
            syncPapers(key, true)
            return
        end
        local kind = itemKindByKey(n.itemKind) or C.ITEM_KINDS.town[1]
        c.itemName = n.itemName or T.titleCase(kind.noun)
        c.itemPhrase = n.itemPhrase or kind.noun
        c.plural = kind.plural
        c.item = makeItem(kind.base, c.itemName, 'return to ' .. returnTo(c) .. '.')
        if c.bandCarries then
            -- Made with the band on the first visit (danger.lua makeBand).
        elseif n.hold == 'loose' then
            -- Placed on first entry, when the player script can cast rays there; the holder is
            -- the fallback if no spot passes.
            c.loose = { state = 'wait', tries = 0, fallback = holder, on = n.on, small = C.LOOSE.SMALL[kind.key] }
        else
            local dest = holder.type == types.Container and types.Container.content(holder)
                or types.Actor.inventory(holder)
            world.createObject(c.item):moveInto(dest)
            c.holder = holder
            DG.spread(c, n, info)
        end
    end
    S.contracts[c.id] = c
    TW.roll(c, info)
    S.used[c.place] = now()
    table.remove(b.notices, idx)
    syncPapers(key, true)
    say('contract %d taken: %s at %s, %d targets, item %s "%s" %s', c.id, c.kind, c.place,
        c.targets and #c.targets or 0, tostring(c.item), tostring(c.itemName),
        c.loose and 'to lie loose (placed on first entry)' or ('in ' .. (c.holder and c.holder.recordId or '-')))
    player:sendEvent('OJB_Contracts', { held = heldCount() })
    sendBoard(player, key, guild)
end

local function down(obj)
    return not obj:isValid() or not obj.enabled or obj.count == 0 or types.Actor.isDead(obj)
end

-- Levelled placeholders turn into real creatures when the cell first loads; adopt whatever stands
-- where each placeholder was.
local function resolvePending(c, player)
    if not c.pending then return end
    local found = 0
    local have = {}
    local place = placeByName(c.place) or { tomb = false }
    for _, t in ipairs(c.targets) do have[t.id] = true end
    local people = {}
    for _, list in ipairs({ player.cell:getAll(types.Creature), player.cell:getAll(types.NPC) }) do
        for _, a in ipairs(list) do
            if a.type ~= types.Player and not have[a.id] and isHostileAlive(a) and actorTargetable(place, a) then
                for i, p in ipairs(c.pending) do
                    if near(a, p, 200) then
                        c.targets[#c.targets + 1] = a
                        have[a.id] = true
                        table.remove(c.pending, i)
                        found = found + 1
                        if a.type == types.NPC and noScript(types.NPC.record(a)) then people[#people + 1] = a end
                        break
                    end
                end
            end
        end
    end
    log('contract %d: %d levelled spawns adopted, %d placeholders left empty', c.id, found, #c.pending)
    c.pending = nil
    if c.leaderPending then
        local leader = strongest(people)
        if leader then
            makeLeader(c, leader)
            say('contract %d: %s leads them', c.id, types.NPC.record(leader).name)
        else
            dropContract(c, 'no leader spawned')
            tell(player, 'Whoever led them is long gone. The job is off, and nobody holds it against you.')
            player:sendEvent('OJB_Contracts', { held = heldCount() })
        end
    end
end

local function complete(c, player)
    c.state = 'done'
    say('contract %d complete (%s)', c.id, c.kind)
    DG.completed(c, player)
    if c.itemPhrase then
        tell(player, T.foundMessage(c.itemPhrase, returnTo(c), c.plural))
    else
        tell(player, 'Done: ' .. c.title .. '. Go back to ' .. returnTo(c) .. ' to be paid.')
    end
    player:sendEvent('OJB_Contracts', { held = heldCount() })
end

-- The first time the player is inside: the plain truth for the contract log. Live targets for a
-- clearing or bounty (after levelled spawns are adopted), every hostile in the cell for a recovery.
local function noteDetails(c, player)
    if c.details then return end
    local place = placeByName(c.place)
    if not place then return end
    local count, found = 0, 0
    for _, list in ipairs({ player.cell:getAll(types.Creature), player.cell:getAll(types.NPC) }) do
        for _, a in ipairs(list) do
            if a.type ~= types.Player and isHostileAlive(a) then
                found = found + types.Actor.stats.level(a).current
                if c.kind == 'recovery' then count = count + 1 end
            end
        end
    end
    if c.kind ~= 'recovery' then
        for _, t in ipairs(c.targets or {}) do
            if not down(t) then count = count + 1 end
        end
    end
    local leader = c.leader and c.leader:isValid() and types.NPC.record(c.leader).name or nil
    c.details = ST.contractDetails(place, c.level, count, leader, c.kind == 'recovery')
    -- Levelled lists resolve on the player's level, so a place can hold more or less than it was
    -- rated for. Bands are spawned to their tier and never differ.
    local gap = not c.band and TI.gap(c.typical, found)
    if gap then c.details = c.details .. ' ' .. T.GAP[gap][c.id % #T.GAP[gap] + 1] end
    say('contract %d: rated danger %s (%s), found %d%s', c.id, tostring(c.typical), tostring(c.diff), found,
        gap and (', ' .. gap) or '')
    log('contract %d: details noted: %s', c.id, tostring(c.details))
end

---------------------------------------------------------------------------------------------------
-- Loose recovery items. On first entry the furniture of the cell is ranked here (deep inside, near
-- the foes, lit) and the player script tries the best of it with rays; the item is put on the spot
-- it finds, checked SETTLE_SECONDS later, and moved into the fallback holder if anything is wrong.

-- Which furniture word a record matches, by id then model. Key: record id; lives for the session
-- (records don't change once loaded); a record that isn't furniture is kept as false.
local furnitureCache = {}
local function furnitureWord(obj)
    local id = obj.recordId
    local hit = furnitureCache[id]
    if hit ~= nil then return hit or nil end
    local rec = obj.type.records[id]
    local names = { id:lower(), (rec and rec.model or ''):lower() }
    hit = false
    for _, s in ipairs(names) do
        local bad = false
        for _, w in ipairs(C.LOOSE.NOT_WORDS) do
            if s:find(w, 1, true) then bad = true break end
        end
        if not bad then
            for _, w in ipairs(C.LOOSE.WORDS) do
                if s:find(w, 1, true) then hit = w break end
            end
        end
        if hit then break end
    end
    furnitureCache[id] = hit
    return hit or nil
end

local function dist(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

-- The way in: the teleport door in this cell nearest the player (they have just come through it).
local function entranceOf(cell, player)
    local best, bd
    for _, d in ipairs(cell:getAll(types.Door)) do
        if types.Door.isTeleport(d) then
            local dd = dist(d.position, player.position)
            if not bd or dd < bd then best, bd = d, dd end
        end
    end
    return best and best.position or player.position
end

-- Where the foes are: the leader, else the middle of the hostiles deepest in.
local function anchorOf(c, cell, entrance)
    if c.leader and c.leader:isValid() then return c.leader.position end
    local deep, far, farD = {}, nil, -1
    for _, list in ipairs({ cell:getAll(types.Creature), cell:getAll(types.NPC) }) do
        for _, a in ipairs(list) do
            if a.type ~= types.Player and isHostileAlive(a) then
                local d = dist(a.position, entrance)
                if d >= C.LOOSE.MIN_DEPTH then deep[#deep + 1] = a.position end
                if d > farD then far, farD = a.position, d end
            end
        end
    end
    if #deep == 0 then return far or entrance end
    local x, y, z = 0, 0, 0
    for _, p in ipairs(deep) do x, y, z = x + p.x, y + p.y, z + p.z end
    return util.vector3(x / #deep, y / #deep, z / #deep)
end

-- Five getAll calls on the cell the player is in, once per loose contract.
local function askLoose(c, player)
    local L = C.LOOSE
    local cell = player.cell
    local entrance = entranceOf(cell, player)
    local anchor = anchorOf(c, cell, entrance)
    local lights = {}
    for _, l in ipairs(cell:getAll(types.Light)) do lights[#lights + 1] = l.position end
    local found, deepest = {}, 0
    for _, t in ipairs({ types.Static, types.Container, types.Activator }) do
        for _, o in ipairs(cell:getAll(t)) do
            local word = o.enabled and furnitureWord(o)
            if word then
                local d = dist(o.position, entrance)
                found[#found + 1] = { obj = o, word = word, depth = d }
                if d > deepest then deepest = d end
            end
        end
    end
    local minDepth = math.max(math.min(L.MIN_DEPTH, deepest * 0.5), deepest * L.DEEP_SHARE)
    local cands = {}
    for _, f in ipairs(found) do
        if f.depth >= minDepth then
            local lit = false
            for _, lp in ipairs(lights) do
                if dist(lp, f.obj.position) < L.LIGHT_NEAR then lit = true break end
            end
            f.light = lit
            -- The surface the notice names is tried before any other.
            f.score = f.depth / math.max(1, deepest) - 0.5 * math.min(1, dist(f.obj.position, anchor) / 2000)
                + (lit and 0.2 or 0) + ((c.loose.on and f.word == c.loose.on) and 2 or 0) + math.random() * 0.15
            cands[#cands + 1] = f
        end
    end
    table.sort(cands, function(a, b) return a.score > b.score end)
    local send = {}
    for i = 1, math.min(L.CANDIDATES, #cands) do
        local f = cands[i]
        send[i] = { obj = f.obj, word = f.word, depth = f.depth, light = f.light }
    end
    c.loose.state, c.loose.entrance = 'asked', { x = entrance.x, y = entrance.y, z = entrance.z }
    c.loose.askedAt = core.getSimulationTime()
    log('contract %d: looking for a loose spot: %d furniture in the cell, %d deep enough (from %.0f), %d sent',
        c.id, #found, #cands, minDepth, #send)
    player:sendEvent('OJB_FindLoose', {
        id = c.id, cell = c.place, cands = send, small = c.loose.small, minDepth = minDepth,
        entrance = { x = entrance.x, y = entrance.y, z = entrance.z },
        anchor = { x = anchor.x, y = anchor.y, z = anchor.z },
    })
end

local function looseToFallback(c, why)
    local L = c.loose
    if L.obj and L.obj:isValid() then L.obj:remove() end
    L.obj = nil
    local holder = L.fallback
    if holder and holder:isValid() then
        local dest = holder.type == types.Container and types.Container.content(holder)
            or types.Actor.inventory(holder)
        world.createObject(c.item):moveInto(dest)
        c.holder = holder
    end
    L.state = 'container'
    say('contract %d: no loose spot (%s); the item is in %s instead', c.id, why,
        c.holder and c.holder.recordId or 'nothing (the holder is gone)')
end

-- Still where it was put, resting on the surface: placed. The first check also sets the item's
-- bottom on the surface, since a mesh's origin isn't always its base.
local function verifyLoose(c)
    local L = c.loose
    if not L or (L.state ~= 'settling' and L.state ~= 'settled once') then return end
    local o = L.obj
    if not o or not o:isValid() or not o.cell or o.cell.name ~= c.place or o.count == 0 then
        if types.Actor.inventory(thePlayer()):countOf(c.item) > 0 then
            L.state = 'placed'
            return
        end
        looseToFallback(c, 'the item went missing after it was placed')
        return
    end
    local box = o:getBoundingBox()
    local bottom = box.center.z - box.halfSize.z
    local drift = math.sqrt((o.position.x - L.at.x) ^ 2 + (o.position.y - L.at.y) ^ 2)
    if drift > 3 then
        looseToFallback(c, string.format('it moved %.0f after it was placed', drift))
        return
    end
    local gap = L.at.z - bottom
    if L.state == 'settling' and math.abs(gap) > 0.5 then
        o:teleport(c.place, util.vector3(o.position.x, o.position.y, o.position.z + gap + 0.5),
            { rotation = o.rotation })
        L.state = 'settled once'
        async:newUnsavableSimulationTimer(C.LOOSE.SETTLE_SECONDS, function() verifyLoose(c) end)
        return
    end
    if math.abs(gap) > 4 and L.state == 'settled once' then
        looseToFallback(c, string.format('it sits %.0f off the surface', gap))
        return
    end
    L.state = 'placed'
    log('contract %d: loose item settled', c.id)
end

local function onLooseSpot(e)
    if type(e.id) == 'string' then return RQ.lostSpot(e) end
    local c = S.contracts[e.id]
    if not c or not c.loose or c.loose.state ~= 'asked' or c.state ~= 'active' then return end
    local L = c.loose
    log('contract %d: loose search: %d rays, %d frames, %.1f ms (worst frame %.1f); %d tried before',
        c.id, e.rays or 0, e.frames or 0, e.ms or 0, e.maxMs or 0, #(e.tried or {}))
    for _, t in ipairs(e.tried or {}) do log('  rejected %s', t) end
    if not e.ok then
        L.tries = L.tries + 1
        if e.retry and L.tries < C.LOOSE.TRIES then
            L.state = 'wait'
            log('contract %d: navmesh not ready, will look again', c.id)
            return
        end
        looseToFallback(c, e.error or 'no furniture or floor passed')
        return
    end
    local player = thePlayer()
    local at = util.vector3(e.pos.x, e.pos.y, e.pos.z)
    local obj = world.createObject(c.item)
    obj:teleport(c.place, at + util.vector3(0, 0, 1),
        { rotation = util.transform.rotateZ(math.random() * 2 * math.pi) })
    L.obj, L.at, L.state = obj, { x = at.x, y = at.y, z = at.z }, 'settling'
    say('contract %d: item lies loose on %s (%s), %.0f above the floor, %.0f from the entrance%s, in %s',
        c.id, e.on and e.on.recordId or 'the floor', e.word or '?', e.height or 0, e.depth or 0,
        e.light and ', near a light' or '', c.place)
    if L.on and e.word ~= L.on then
        say('contract %d: the notice says %s, but no %s here passed; it lies on the %s', c.id, L.on, L.on, e.word or 'floor')
    end
    async:newUnsavableSimulationTimer(C.LOOSE.SETTLE_SECONDS, function() verifyLoose(c) end)
end

local function looseStep(c, player, here)
    local L = c.loose
    if not L then return end
    -- An answer lost to leaving the cell or a reload (the player script's search isn't saved).
    if L.state == 'asked' and (not here or core.getSimulationTime() - (L.askedAt or 0) > C.LOOSE.ANSWER_SECONDS) then
        L.state = 'wait'
    end
    if not here then return end
    if L.state == 'wait' then
        askLoose(c, player)
    elseif L.state == 'settling' or L.state == 'settled once' then
        -- A save and load between placing and the check drops the timer; check on the next poll.
        verifyLoose(c)
    end
end

local function checkContract(c, player)
    if c.state ~= 'active' then return end
    if c.wild then return timed('open world job', twCtx.WL.step, c, player) end
    local here = player.cell and player.cell.name == c.place
    local inv = types.Actor.inventory(player)
    if not timed('dangerous band', DG.step, c, player, here) then return end
    if here and c.kind == 'recovery' then noteDetails(c, player) end
    if c.kind == 'recovery' and c.loose and inv:countOf(c.item) == 0 then looseStep(c, player, here) end
    if c.kind == 'recovery' then
        if not timed('twists', TW.step, c, player, here) then return end
        DG.partsStep(c, player, inv)
        if inv:countOf(c.item) >= DG.need(c) then complete(c, player) end
        return
    end
    if not here then
        if not TW.step(c, player, false) then return end
        if c.kind == 'bounty' and c.leaderDown and not DG.holds(c) and inv:countOf(c.item) > 0 then complete(c, player) end
        return
    end
    resolvePending(c, player)
    if S.contracts[c.id] ~= c then return end
    noteDetails(c, player)
    if not timed('twists', TW.step, c, player, true) then return end
    if c.kind == 'nest' then
        -- Every target is checked (not just to the first standing) so the log can say how many fell.
        local fallen = 0
        for _, t in ipairs(c.targets) do
            if down(t) then fallen = fallen + 1 end
        end
        c.fallen = fallen
        if TW.holdsCompletion(c) or DG.holds(c) then return end
        if fallen < #c.targets then return end
        complete(c, player)
    else
        c.leaderDown = c.leaderDown or down(c.leader)
        if c.leaderDown and not DG.holds(c) and inv:countOf(c.item) > 0 then complete(c, player) end
    end
end

local function checkAll(player)
    for _, c in pairs(S.contracts) do
        checkContract(c, player)
    end
end

local function expireOld(player)
    local t = now()
    for _, c in pairs(S.contracts) do
        if c.state == 'active' and t > c.expiresAt then
            tell(player, 'Too late now: ' .. c.title .. '.')
            dropContract(c, 'expired')
        end
    end
end

local function grantRep(player, c)
    local f = c.poster
    if not C.GUILDS[f] or not core.factions.records[f] then return 0 end
    local rank = types.NPC.getFactionRank(player, f)
    local reqs = {}
    for i, r in ipairs(core.factions.records[f].ranks) do reqs[i] = r.factionReputation end
    S.repGiven[f] = S.repGiven[f] or {}
    local given = S.repGiven[f][rank] or 0
    local give = REP.allowed(reqs, rank, given, (C.REP[c.kind] or 1) * DG.repFactor(c))
    if give > 0 then
        types.NPC.modifyFactionReputation(player, f, give)
        S.repGiven[f][rank] = given + give
    end
    log('contract %d: reputation +%d in %s (rank %d, %d of %d allowed at this rank)', c.id, give, f, rank,
        given + give, math.floor(math.max(0, (reqs[rank + 1] or 0) - (reqs[rank] or 0)) / 2))
    return give
end

local function handIn(player, key, contractId, guild)
    local c = S.contracts[contractId]
    if not c or not canHandInAt(c, key, guild) then return end
    local inv = types.Actor.inventory(player)
    local partShare = 1
    if not guild and TW.ownerTown(c) == townOf(key) then
        if not TW.returnToOwner(c, player) then
            c.state = 'active'
            tell(player, "You don't have it with you any more.")
        else
            S.done[#S.done + 1] = now()
            S.finished = who(player).done + 1
            do
                local k = twCtx.FR.kindOf(c)
                if k then
                    S.doneKinds = S.doneKinds or {}
                    S.freshAt = S.freshAt or {}
                    S.doneKinds[k] = true
                    S.freshAt[k] = now()
                end
            end
            SP.release(c.id)
            S.contracts[c.id] = nil
            DG.eliteSweep()
            player:sendEvent('OJB_Contracts', { held = heldCount() })
        end
        sendBoard(player, key, guild)
        return
    end
    if c.item then
        local it = inv:find(c.item)
        if not it then
            c.state = 'active'
            tell(player, "You don't have it with you any more.")
            sendBoard(player, key, guild)
            return
        end
        partShare = DG.handInItems(c, inv, it)
    end
    if c.wild then
        local ok, share = twCtx.WL.handInItems(c, inv)
        if not ok then
            c.state = 'active'
            tell(player, "You don't have them with you any more.")
            sendBoard(player, key, guild)
            return
        end
        partShare = partShare * share
    end
    local reward = c.reward
    local skill = c.skill
    if reward.training then
        local s2 = trainingFor(player, c.poster)
        if s2 ~= skill then
            reward = R.split(reward.value, TI.of(c), nil, c.id, reward.pool)
            skill = nil
        end
    end
    local tw = TW.handIn(c, player, TI.cap(TI.of(c)) - reward.gold)
    tw.share = tw.share * partShare
    if tw.share ~= 1 or tw.bonus > 0 then
        local r2 = {}
        for k, v in pairs(reward) do r2[k] = v end
        r2.gold = math.floor(reward.gold * tw.share / 5 + 0.5) * 5 + tw.bonus
        reward = r2
    end
    if reward.gold > 0 then
        world.createObject(GOLD, reward.gold):moveInto(inv)
    end
    for id, n in pairs(reward.items or {}) do
        world.createObject(id, n):moveInto(inv)
    end
    player:sendEvent('OJB_Sound', { reward.gold > 0 and 'Item Gold Up' or 'Item Misc Up' })
    if reward.training and skill then
        S.trainingAt[c.poster] = now()
        for _ = 1, DG.sessions(reward, player, skill) do player:sendEvent('OJB_Train', { skill = skill }) end
    end
    local rep = grantRep(player, c)
    S.done[#S.done + 1] = now()
    S.finished = who(player).done + 1
    do
        local k = twCtx.FR.kindOf(c)
        if k then
            S.doneKinds = S.doneKinds or {}
            S.freshAt = S.freshAt or {}
            S.doneKinds[k] = true
            S.freshAt[k] = now()
        end
    end
    SP.release(c.id)
    S.contracts[c.id] = nil
    DG.eliteSweep()
    log('contract %d paid: %d gold, %d supplies, training %s', c.id, reward.gold, reward.supplies or 0,
        tostring(reward.training and skill))
    local msg = 'Paid: ' .. rewardText(reward, skill) .. '.'
    if rep > 0 then msg = msg .. ' Your standing in the guild improves.' end
    if #tw.lines > 0 then msg = table.concat(tw.lines, ' ') .. ' ' .. msg end
    tell(player, msg)
    sendBoard(player, key, guild)
end


local function abandon(player, key, contractId, guild)
    local c = S.contracts[contractId]
    if not c then return end
    dropContract(c, 'abandoned')
    tell(player, 'You give up on: ' .. c.title .. '.')
    if key then sendBoard(player, key, guild) end
end

---------------------------------------------------------------------------------------------------
-- Opening boards

local function openBoard(player, key, guild)
    local b = S.boards[key]
    expireOld(player)
    checkAll(player)
    if refreshDue(b) or (refreshing and refreshing.key == key) then
        refreshNow(key, player)
    end
    sendBoard(player, key, guild)
end

-- Guild work from a steward: the guild's own board in this hall's town, or a list kept indoors
-- where the guild has no board outside (Vivec's halls, for example).
local function guildBoardFor(faction, cellName)
    local low = (cellName or ''):lower()
    local townName = low:match('^([^,]+),')
    local townKey
    for _, key in ipairs(DEF_KEYS) do
        local d = DEFS[key]
        for _, p in ipairs(d.def.posters) do
            if p == faction then
                for _, door in ipairs(d.def.doors) do
                    if door:lower() == low then return key end
                end
            end
        end
        if townName and d.town.name:lower() == townName then townKey = townKey or key end
    end
    for _, key in ipairs(DEF_KEYS) do
        local d = DEFS[key]
        if townName and d.town.name:lower() == townName then
            for _, p in ipairs(d.def.posters) do
                if p == faction then return key end
            end
        end
    end
    if not townKey then return nil end
    local vkey = 'v_' .. faction:gsub(' ', '_') .. '_' .. DEFS[townKey].town.key
    if not S.boards[vkey] then
        S.boards[vkey] = { status = 'virtual', notices = {}, refreshedAt = -1e9, originKey = townKey,
            posters = { faction } }
    end
    return vkey
end

---------------------------------------------------------------------------------------------------
-- Periodic: board spots near the player, notices coming due, targets dying in a job's cell.
-- Every 2 s: three engine reads for the player, plus up to ~15 death checks while in a job cell.

local lastCell = nil

-- Walking into a shop interior from supply.lua: its shopkeeper dead or gone closes the shop for
-- ads (S.closedShops, by NPC record id): an ad already up says so on its card, and no new ad
-- names it. The cell is the player's own, so its objects are loaded; one getAll(types.NPC) per
-- entry into a shop's cell, none elsewhere.
local shopCells
function twCtx.checkShop(cell)
    if not shopCells then
        shopCells = {}
        for _, t in pairs(SUP.towns) do
            for _, s in ipairs(t.shops or {}) do
                shopCells[s.cell] = shopCells[s.cell] or {}
                shopCells[s.cell][s.id] = true
            end
        end
    end
    local want = shopCells[cell.name]
    if not want then return end
    local alive = {}
    for _, a in ipairs(cell:getAll(types.NPC)) do
        if want[a.recordId] and not types.Actor.isDead(a) then alive[a.recordId] = true end
    end
    for id in pairs(want) do
        S.closedShops = S.closedShops or {}
        S.closedShops[id] = (not alive[id]) or nil
    end
end

local function nearTick()
    local player = thePlayer()
    if not player or not player.cell then return end
    if waiting and core.getRealTime() - waiting.at > 15 then
        local b = S.boards[waiting.key]
        local pos = player.position
        if b then
            b.checked = b.checked or {}
            for id in pairs(waiting.ids or {}) do
                if not b.checked[id] then
                    b.checked[id] = { ok = false, held = true, failed = 'no answer',
                        t = core.getGameTime() + C.SEARCH_BACKOFF, x = pos.x, y = pos.y }
                end
            end
        end
        say('board %s: no answer from the spot check; waiting before another look', waiting.key)
        waiting = nil
    end
    -- A placed board is taken down when the player next comes near it, so its cell is already
    -- loaded; doing them all at once would make the engine load every board town's cell.
    if S.migrate then
        S.migrate = nil
        for _, b in pairs(S.boards) do
            if b.status == 'placed' then
                b.replace = true
            elseif b.status ~= 'virtual' then
                b.status = 'pending'
            end
        end
        say('version %s: placement and notices changed since this save was made; every board is placed '
            .. 'again as you come near it', C.VERSION)
    end
    timed('near upkeep', function()
        sweepOrphans()
        SP.sweep()
        RQ.settleBook(player)
        if boardsOn then twCtx.SY.tick(player) end
    end)
    if player.cell.isExterior then
        local pos = player.position
        local r2 = C.NEAR_BOARD_UNITS * C.NEAR_BOARD_UNITS
        local look2 = C.DOOR_LOOKUP_UNITS * C.DOOR_LOOKUP_UNITS
        timed('near boards', function()
        for _, key in ipairs(DEF_KEYS) do
            local b, def = S.boards[key], DEFS[key].def
            local off = (COMPANY[key] and not featureOn.companyReqs) or (def.village and not featureOn.villageBoards)
            local dx, dy = pos.x - def.near[1], pos.y - def.near[2]
            local close = dx * dx + dy * dy < r2
            for _, d in ipairs(b.doorList or {}) do
                local ex, ey = pos.x - d.x, pos.y - d.y
                if ex * ex + ey * ey < r2 then close = true break end
            end
            if close and b.replace then
                b.replace = nil
                timed('take board down', unplace, key, 'pending')
            end
            if b.status == 'nodoor' and b.hold then
                local hx, hy = pos.x - b.hold.x, pos.y - b.hold.y
                if core.getGameTime() >= b.hold.t or hx * hx + hy * hy >= C.SEARCH_AWAY * C.SEARCH_AWAY then
                    b.hold, b.status, b.doorList = nil, 'pending', nil
                end
            end
            if boardsOn and not off and not b.replace and (b.status == 'pending' or b.status == 'placed') then
                if not b.doorList then
                    local tx, ty = pos.x - def.near[1], pos.y - def.near[2]
                    if tx * tx + ty * ty < look2 then timed('door lookup', lookupDoors, key) end
                end
                if b.doorList and not waiting then
                    local ids, n = doorsToCheck(b, pos)
                    if n > 0 then timed('spot request', requestSpot, key, player, ids) end
                end
            end
            if close and not off and b.status == 'placed' and refreshDue(b) then
                queueRefresh(key)
            end
        end
        end)
    end
    timed('near contracts', function()
        for _, c in pairs(S.contracts) do
            if c.state == 'active' and player.cell.name == c.place then
                checkContract(c, player)
            end
        end
    end)
    -- Walking into a guild hall: that guild's list is refreshed in the background, so asking the
    -- steward doesn't post every notice in one frame. Once per cell entered.
    local cellName = player.cell.name
    if cellName ~= lastCell then
        lastCell = cellName
        if not player.cell.isExterior then
            twCtx.checkShop(player.cell)
            for faction in pairs(C.GUILDS) do
                if isMember(player, faction) then
                    local key = guildBoardFor(faction, cellName)
                    local b = key and S.boards[key]
                    if b and b.status == 'virtual' and refreshDue(b) then queueRefresh(key) end
                end
            end
        end
    end
end

---------------------------------------------------------------------------------------------------
-- Save, load, reconcile

local function reconcile()
    -- A save from any other version of the mod: every board is placed again (towns an older build
    -- skipped get looked at once more) and its notices written afresh.
    if (S.v or 1) < C.STATE_VERSION or S.built ~= C.VERSION then
        say('save made with %s, this is %s: boards are placed again and notices rewritten',
            S.built or ('state ' .. tostring(S.v or 1)), C.VERSION)
        S.built = C.VERSION
        S.migrate = true
        for _, b in pairs(S.boards) do
            b.refreshedAt = -1e9
            b.doorList, b.checked = nil, nil
        end
        S.v = C.STATE_VERSION
    end
    S.posted = S.posted or {}
    for _, key in ipairs(DEF_KEYS) do
        local b = S.boards[key]
        if not b then
            S.boards[key] = { status = 'pending', notices = {}, refreshedAt = -1e9 }
        elseif b.status == 'nodoor' then
            b.status, b.doorList = 'pending', nil
        end
    end
    for key, b in pairs(S.boards) do
        if not DEFS[key] and b.status ~= 'virtual' then
            say('%s: its town is no longer in the load order, removing its board', key)
            unplace(key, 'gone')
            S.boards[key] = nil
        end
    end
    byObject = {}
    for key, b in pairs(S.boards) do
        if b.status == 'placed' then
            for _, holder in ipairs(holders(b)) do
                for _, o in ipairs(holder.parts or {}) do
                    if o.recordId:find('^ojb_board') then byObject[o.id] = key end
                end
                for _, o in ipairs(holder.papers or {}) do byObject[o.id] = key end
            end
        end
    end
    twCtx.SY.reconcile()
end

local function applySettings(s)
    debugOn = s.debug == true
    featureOn.profile = s.profile == true
    plainNotices = s.detail == 'plain'
    reqCtx.soulMode = s.soulValues == 'rebalanced' and 'rebalanced' or 'vanilla'
    twCtx.rules.directions = (s.directions == 'exact' or s.directions == 'off') and s.directions or 'rough'
    for _, f in ipairs(C.FEATURES) do featureOn[f] = s[f] ~= false end
    twCtx.rules.newDone = tonumber(s.newDone) or C.EARLY.DONE
    twCtx.rules.perkDone = featureOn.slotsPerk and (tonumber(s.slotsDone) or C.PERK.DONE) or false
    twCtx.rules.earlyLevel = tonumber(s.earlyLevel) or C.EARLY.LEVEL
    twCtx.rules.perkLevel = tonumber(s.slotsLevel) or C.PERK.LEVEL
    twCtx.rules.levelGates = s.levelGates == true
    twCtx.rules.hideAbove = s.hideAbove == true
    local gsz = tonumber(s.groupSize) or C.THREAT.GROUP_SIZE
    if gsz < 0.5 then gsz = 0.5 elseif gsz > 1.5 then gsz = 1.5 end
    twCtx.rules.groupSize = gsz
    local wasOn = boardsOn
    boardsOn = s.boards ~= false
    if wasOn and not boardsOn then
        for key, b in pairs(S.boards) do
            if b.status == 'placed' then unplace(key) end
        end
        log('boards hidden')
    end
    if S and (not boardsOn or not featureOn.strays) then twCtx.SY.clearAll() end
    if S and not featureOn.companyReqs then
        for key in pairs(COMPANY) do
            local b = S.boards[key]
            if b and b.status == 'placed' then
                unplace(key)
                b.notices = {}
            end
        end
    end
    -- Requisitions of a kind switched off come down now.
    if S then
        for key, b in pairs(S.boards) do
            local keep, changed = {}, false
            for _, n in ipairs(b.notices or {}) do
                if n.kind == 'req' and not RQ.switchedOn(n) then
                    RQ.discard(n)
                    changed = true
                else
                    keep[#keep + 1] = n
                end
            end
            if changed then
                b.notices = keep
                syncPapers(key)
            end
        end
    end
end

---------------------------------------------------------------------------------------------------
-- Debug commands from the console (player interface I.OddJobs)

local function debugLines(player, lines)
    player:sendEvent('OJB_DebugLines', lines)
end

-- Stand in front of one site's notices.
local function standAt(player, key, dest, site)
    local yaw = site.spot.yaw
    local fx, fy = -math.sin(yaw), -math.cos(yaw)
    local back = site.style == 'wall' and 200 or 260
    local z = site.style == 'wall' and site.spot.z - C.WALL.CENTRE_HEIGHT + 20 or site.spot.z + 20
    local pos = util.vector3(site.spot.x + fx * back, site.spot.y + fy * back, z)
    player:teleport('', pos, { rotation = util.transform.rotateZ(yaw), onGround = true })
    debugLines(player, { string.format('%s: %s at %s (%s); standing in front of it', key,
        site.style == 'wall' and 'pinned on the wall' or 'free-standing board', dest, site.label or '?') })
end

-- site: which placed site to stand at (1 first), or nil for the first door not checked yet.
local function visit(player, key, site)
    local b = S.boards[key]
    if not b or not DEFS[key] then
        debugLines(player, { 'no board called ' .. tostring(key) })
        return
    end
    local placed = placedSites(b)
    if #placed > 0 and (site or doorsLeft(b) == 0 or not b.doorList) then
        local s = placed[((site or 1) - 1) % #placed + 1]
        standAt(player, key, s.dest, s.site)
        return
    end
    -- The first door not checked yet, so a tour reaches every door of a board in turn.
    local door, dest
    local all = boardDoors(key)
    for _, d in ipairs(all) do
        if not (b.checked and b.checked[doorId(d.door, d.dest)]) then
            door, dest = d.door, d.dest
            break
        end
    end
    if not door and all[1] then door, dest = all[1].door, all[1].dest end
    if not door then
        debugLines(player, { key .. ': none of its doors exist in this load order' })
        return
    end
    local arrival = findArrival(door, dest) or { x = door.position.x, y = door.position.y, z = door.position.z }
    local dx, dy = arrival.x - door.position.x, arrival.y - door.position.y
    player:teleport('', util.vector3(arrival.x, arrival.y, arrival.z + 20),
        { rotation = util.transform.rotateZ(math.atan2(dx, dy)), onGround = true })
    if b.status == 'skipped' then
        resetChecks(b)
        debugLines(player, { key .. ': was skipped (no wall or board spot); checking again now. Watch the log.' })
    else
        debugLines(player, { key .. ': ' .. b.status .. '; at the door to ' .. dest.name .. ', the spot check runs now' })
    end
end

local function boardLine(i, key)
    local b = S.boards[key]
    local how = b.status
    local placed = placedSites(b)
    if #placed > 0 then
        local parts = {}
        for _, s in ipairs(placed) do
            parts[#parts + 1] = string.format('%s: %s %s, score %.0f', s.dest:gsub('^[^,]+,%s*', ''),
                s.site.style == 'wall' and 'wall' or 'board', s.site.label or '?', s.site.score or 0)
        end
        for dest, site in pairs(b.sites or {}) do
            if site.status ~= 'placed' then
                parts[#parts + 1] = string.format('%s: %s', dest:gsub('^[^,]+,%s*', ''), site.status)
            end
        end
        how = table.concat(parts, '; ')
    end
    return string.format('%2d %-22s notices %d  %s', i, key, #(b.notices or {}), how)
end

-- I.OddJobs.tour(seconds): every board in turn. At each door it waits for the spot check, then
-- stands in front of whatever was placed for `seconds` (time for a screenshot), then moves on.
-- The summary goes to the console and openmw.log.
local function tourStep()
    local t = touring
    if not t then return end
    local player = thePlayer()
    local key = DEF_KEYS[t.i]
    local b = key and S.boards[key]
    if t.phase == 'check' then
        -- Every door in reach answered: on to the board's next unchecked door, until all are checked.
        local left = b.doorList and doorsLeft(b) or 0
        if (left > 0 or not b.doorList) and core.getRealTime() - t.start < 60 and b.status ~= 'nodoor' then
            if b.doorList and not waiting then
                local _, n = doorsToCheck(b, player.position)
                if n == 0 then visit(player, key) end
            end
            async:newUnsavableSimulationTimer(0.5, tourStep)
            return
        end
        t.phase, t.site = 'look', 1
    end
    if t.phase == 'look' then
        local placed = placedSites(b)
        if t.site <= #placed then
            visit(player, key, t.site)
            t.site = t.site + 1
            async:newUnsavableSimulationTimer(t.pause, tourStep)
            return
        end
    end
    if key then
        t.results[#t.results + 1] = boardLine(t.i, key)
        say('tour %s', t.results[#t.results])
    end
    t.i = t.i + 1
    key = DEF_KEYS[t.i]
    if not key or (t.last and t.i > t.last) then
        debugLines(player, { 'tour finished:' })
        debugLines(player, t.results)
        touring = nil
        return
    end
    b = S.boards[key]
    if b.status == 'skipped' then resetChecks(b) end
    if b.status == 'nodoor' then b.status, b.doorList = 'pending', nil end
    t.phase, t.start = 'check', core.getRealTime()
    visit(player, key)
    async:newUnsavableSimulationTimer(1, tourStep)
end

local function debugCommand(player, cmd)
    local name, arg = cmd.name, cmd.arg
    if name == 'list' then
        local lines = { string.format('%d boards, Harsh Measures %s', #DEF_KEYS, HM and 'detected' or 'not installed') }
        for i, key in ipairs(DEF_KEYS) do
            lines[#lines + 1] = boardLine(i, key)
        end
        debugLines(player, lines)
    elseif name == 'tour' then
        if touring then
            touring = nil
            debugLines(player, { 'tour stopped' })
            return
        end
        local from, to = 1, #DEF_KEYS
        if type(arg) == 'table' then from, to = arg.from or 1, arg.to or #DEF_KEYS end
        touring = { i = from - 1, last = to, pause = cmd.pause or 6, results = {}, phase = 'next' }
        debugLines(player, { string.format('touring boards %d to %d, %d s at each; I.OddJobs.tour() again stops it',
            from, to, touring.pause) })
        tourStep()
    elseif name == 'visit' then
        local key = tonumber(arg) and DEF_KEYS[tonumber(arg)] or arg
        visit(player, key)
    elseif name == 'next' then
        S.tour = S.tour % #DEF_KEYS + 1
        visit(player, DEF_KEYS[S.tour])
    elseif name == 'recheck' then
        local key = tonumber(arg) and DEF_KEYS[tonumber(arg)] or arg
        if S.boards[key] then
            unplace(key)
            S.boards[key].checked = {}
            debugLines(player, { key .. ': removed; every door is checked again when you are near it' })
        end
    elseif name == 'refresh' then
        for _, b in pairs(S.boards) do b.refreshedAt = -1e9 end
        debugLines(player, { 'every board will post fresh notices next time' })
    elseif name == 'contracts' then
        local lines = {}
        for _, c in pairs(S.contracts) do
            lines[#lines + 1] = string.format('%d %s %s at %s, %s, expires in %.1f days', c.id, c.kind, c.state,
                c.place, c.title, c.expiresAt - now())
        end
        if #lines == 0 then lines[1] = 'no contracts held' end
        debugLines(player, lines)
    elseif name == 'removeall' then
        twCtx.SY.clearAll()
        for key in pairs(S.boards) do unplace(key, 'pending') end
        for _, c in pairs(S.contracts) do dropContract(c, 'removed by command') end
        SP.releaseAll()
        boardsOn = false
        debugLines(player, { 'all boards and contracts removed; turn "Show boards" off before uninstalling' })
    end
end

---------------------------------------------------------------------------------------------------

I.Activation.addHandlerForType(types.Activator, function(obj, actor)
    local key = byObject[obj.id]
    if not key then return end
    if actor.type == types.Player then
        timed('open board', openBoard, actor, key, nil)
    end
    return false
end)

---------------------------------------------------------------------------------------------------
-- Debug footprint: what this script holds and has made the engine hold. Lua memory itself can't
-- be read from a mod script (OpenMW's sandbox has no collectgarbage). A Lua tab in the F10
-- window was not in the Cod3x annotations, so it is not verified here.

local history = {}   -- count name -> values of the last FOOTPRINT_GROWTH + 1 lines
local lastFootprint = -1e9

local function footprint()
    local objects, placed, notices = 0, 0, 0
    for _, b in pairs(S.boards) do
        for _, holder in ipairs(holders(b)) do
            objects = objects + #(holder.parts or {}) + #(holder.papers or {})
        end
        placed = placed + #placedSites(b)
        notices = notices + #(b.notices or {})
    end
    local clickable, reqs = 0, 0
    for _ in pairs(byObject) do clickable = clickable + 1 end
    for _, b in pairs(S.boards) do reqs = reqs + RQ.openReqs(b) end
    local stolen = RQ.stolenRecords()
    local sp = SP.counts()
    local function nkeys(t)
        local n = 0
        if type(t) ~= 'table' then return 0 end
        for _ in pairs(t) do n = n + 1 end
        return n
    end
    local function bytes(v, depth, seen)
        if depth > 5 or v == nil then return 0 end
        local ty = type(v)
        if ty == 'string' then return #v end
        if ty ~= 'table' then return 8 end
        if seen[v] then return 0 end
        seen[v] = true
        local n = 0
        for k, x in pairs(v) do n = n + bytes(k, depth + 1, seen) + bytes(x, depth + 1, seen) end
        return n
    end
    local counts = {
        { 'cells loaded by Odd Jobs', touchedCount }, { 'board objects', objects },
        { 'clickable ids', clickable }, { 'orphans', #(S.orphans or {}) }, { 'notices', notices },
        { 'contracts', heldCount() }, { 'refresh queue', #refreshQueue },
        { 'requisitions open', reqs }, { 'theft ledger records', stolen },
        { 'spawns alive', sp.alive }, { 'spawned props', sp.props }, { 'spawn jobs', sp.jobs },
        { 'corpses waiting', sp.corpses }, { 'spawn retries', sp.retry }, { 'spawn records', sp.records },
        { 'tracking scripts', sp.scripts }, { 'item records made', S.madeRecords or 0 },
        { 'recent faces', #(S.seenFaces or {}) }, { 'used places', nkeys(S.used) },
        { 'posted places', nkeys(S.posted) }, { 'cleared places', nkeys(S.cleared) },
        { 'fresh kinds', nkeys(S.freshAt) }, { 'finished log', #(S.done or {}) },
        { 'returning', #(S.returning or {}) }, { 'wild sites', nkeys(S.wildSites) },
        { 'saved bytes', bytes(S, 0, {}) },
    }
    local parts = {}
    for _, c in ipairs(counts) do parts[#parts + 1] = string.format('%s %d', c[1], c[2]) end
    local jobs = {}
    for name, s in pairs(jobStats) do
        jobs[#jobs + 1] = string.format('%s %dx avg %.2f max %.2f ms', name, s.n, s.total / s.n, s.max)
    end
    table.sort(jobs)
    jobStats = {}
    say('footprint: lua memory unavailable; %s; %d sites with notices, pump %s, spot check %s; jobs: %s',
        table.concat(parts, ', '), placed,
        pumpArmed and 'armed' or 'idle', waiting and ('waiting on ' .. waiting.key) or 'idle',
        #jobs > 0 and table.concat(jobs, '; ') or 'none')
    for _, c in ipairs(counts) do
        local h = history[c[1]] or {}
        history[c[1]] = h
        h[#h + 1] = c[2]
        if #h > C.FOOTPRINT_GROWTH + 1 then table.remove(h, 1) end
        local rising = #h == C.FOOTPRINT_GROWTH + 1
        for i = 2, #h do
            if h[i] <= h[i - 1] then rising = false end
        end
        if rising then
            say('warning: %s went up at each of the last %d footprint lines (%d to %d)', c[1], C.FOOTPRINT_GROWTH,
                h[1], h[#h])
        end
    end
end

-- Not time.runRepeatedly: it schedules the next call after fn returns, so one error (a broken door
-- in some town) stopped every board for the rest of the session. The error is still logged.
local function nearLoop()
    async:newUnsavableSimulationTimer(C.NEAR_POLL_SECONDS * time.second, nearLoop)
    timed('near tick', nearTick)
    local every = featureOn.profile and C.PROFILE_SECONDS or C.FOOTPRINT_SECONDS
    if (debugOn or featureOn.profile) and core.getRealTime() - lastFootprint >= every then
        lastFootprint = core.getRealTime()
        footprint()
    end
end
async:newUnsavableSimulationTimer(1, nearLoop)

reqCtx.S = function() return S end
reqCtx.DEFS, reqCtx.COMPANY, reqCtx.featureOn = DEFS, COMPANY, featureOn
reqCtx.now, reqCtx.log, reqCtx.say, reqCtx.tell, reqCtx.hasFile = now, log, say, tell, hasFile
reqCtx.itemName, reqCtx.playerLevel, reqCtx.postersOf, reqCtx.rewardText = itemName, playerLevel, postersOf, rewardText
reqCtx.townOf, reqCtx.grantRep, reqCtx.syncPapers = townOf, grantRep, syncPapers
reqCtx.placedSites, reqCtx.removeAll = placedSites, removeAll
reqCtx.makeItem, reqCtx.furnitureWord, reqCtx.sendBoard = makeItem, furnitureWord, sendBoard

-- A note or letter of a twist's own, one record each.
function twCtx.makeBook(name, text)
    local base = types.Book.records[C.TWIST.NOTE]
    S.madeRecords = (S.madeRecords or 0) + 1
    return world.createRecord(types.Book.createRecordDraft({ template = base, name = name, text = text })).id
end

-- Towns with a town board, one entry each, for a stolen piece's real owner.
function twCtx.boardTowns()
    local out, seen = {}, {}
    for _, key in ipairs(DEF_KEYS) do
        local d = DEFS[key]
        if not COMPANY[key] and d.def.posters[1] == 'town' and not seen[d.town.name] then
            seen[d.town.name] = true
            out[#out + 1] = { key = key, town = d.town.name, race = C.TWIST.TOWN_RACE[d.town.key],
                faction = C.TWIST.TOWN_FACTION[d.town.key] }
        end
    end
    return out
end

-- A chain's next step: a bounty on `placeName`, first on the board, with the letter's lead in front.
-- Pushes out the last job notice when the board is full; requisitions and other follow-ups stay.
function twCtx.postFollowUp(key, placeName, lead, step)
    local b, p, player = S.boards[key], placeByName(placeName), thePlayer()
    local ox, oy = boardOrigin(key)
    if not b or not p or not player or not ox then return nil end
    local n = makeNotice(key, { place = p, dist = G.distCells(ox, oy, p.x, p.y), kind = 'bounty' }, player,
        postersOf(key)[1], {})
    if not n then
        log('%s: no follow-up notice for %s', key, placeName)
        return nil
    end
    n.body = lead .. ' ' .. n.body
    if n.plain then n.plain = lead .. ' ' .. n.plain end
    require('scripts.ojb.story').shorten(n)
    n.chainStep, n.postedAt = step, now()
    b.notices = b.notices or {}
    if paidJobs(b) >= C.SLOTS then
        for i = #b.notices, 1, -1 do
            local x = b.notices[i]
            if x.kind ~= 'req' and not x.chainStep then
                RQ.discard(x)
                table.remove(b.notices, i)
                break
            end
        end
    end
    table.insert(b.notices, 1, n)
    syncPapers(key)
    say('%s: follow-up %d posted for %s (step %d)', key, n.id, placeName, step)
    return n
end

twCtx.S, twCtx.now, twCtx.log, twCtx.say, twCtx.tell = function() return S end, now, log, say, tell
twCtx.player, twCtx.SP, twCtx.featureOn = thePlayer, SP, featureOn
twCtx.have = function(req) return req == nil or hasFile(req:lower()) end
twCtx.playerLevel, twCtx.placeByName, twCtx.inContract, twCtx.townOf = playerLevel, placeByName, inContract, townOf
twCtx.places = function() return AVAIL end
twCtx.isHostileAlive, twCtx.dropContract, twCtx.heldCount = isHostileAlive, dropContract, heldCount
twCtx.usedOn, twCtx.directionsTo, twCtx.regionName, twCtx.boardOrigin = usedOn, directionsTo, regionName, boardOrigin
twCtx.regionId = function(x, y)
    regionName(x, y)
    local gx, gy = math.floor(x / C.CELL), math.floor(y / C.CELL)
    local hit = regionCache[gx .. ',' .. gy]
    return hit and hit.id or nil
end
twCtx.postersOf, twCtx.trainingFor, twCtx.makeItem, twCtx.targetsOf = postersOf, trainingFor, makeItem, F.targets
twCtx.hasFile, twCtx.complete = hasFile, complete
twCtx.byObject = function() return byObject end
twCtx.spawnPaper, twCtx.removeAll, twCtx.makeNotice, twCtx.touch = spawn, removeAll, makeNotice, touch
twCtx.lightsAt = function(key) return lightsAt[key] end
twCtx.sizeOf = function(key)
    local d = DEFS[key] or DEFS[S.boards[key] and S.boards[key].originKey or '']
    return TI.size(d and d.town.key, postersOf(key))
end
twCtx.spotBusy = function() return waiting ~= nil end
twCtx.siteDirections = function(key, x, y, door)
    local ox, oy = boardOrigin(key)
    local d = DEFS[key] or DEFS[S.boards[key].originKey]
    return D.describe({
        town = { name = d.town.name, x = ox, y = oy }, place = { n = '', x = x, y = y },
        region = regionName(x, y), landmarks = LANDMARKS.landmarks, travel = LANDMARKS.travel, have = hasFile,
        door = door,
    })
end

return {
    engineHandlers = {
        onInit = function()
            S = fresh()
            reconcile()
        end,
        onLoad = function(data)
            S = data or fresh()
            SP.forget()
            reconcile()
        end,
        onSave = function()
            return S
        end,
        onPlayerAdded = function(player)
            types.Player.addTopic(player, 'notices')
            types.Player.addTopic(player, 'guild work')
            player:sendEvent('OJB_Contracts', { held = heldCount() })
        end,
    },
    eventHandlers = {
        OJB_Settings = applySettings,
        OJB_SpotResult = onSpotResult,
        OJB_LooseSpot = onLooseSpot,
        OJB_Take = function(e) timed('take contract', take, e.player, e.key, e.notice, e.guild) end,
        OJB_HandIn = function(e) handIn(e.player, e.key, e.contract, e.guild) end,
        OJB_Abandon = function(e) abandon(e.player, e.key, e.contract, e.guild) end,
        OJB_ReqHandIn = function(e) timed('requisition hand in', RQ.handIn, e.player, e.key, e.notice, e.guild) end,
        OJB_ContainerClosed = RQ.containerClosed,
        OJB_SpawnSpots = SP.onSpots,
        OJB_SpawnActive = function(e)
            SP.onActive(e)
            if e.strip then SP.stripLoaded(e.actor, e.tier) end
        end,
        OJB_SpawnDied = function(e) log('spawn %s of %s died', e.actor and e.actor.recordId or '?', tostring(e.owner)) end,
        OJB_Surrender = TW.onSurrender,
        OJB_ChoiceMade = TW.onChoice,
        OJB_Check = function(e)
            expireOld(e.player)
            checkAll(e.player)
            if e.log then
                local list = {}
                local ground = playerGround(e.player)
                for _, c in pairs(S.contracts) do list[#list + 1] = contractView(c, nil, nil, e.player, ground) end
                table.sort(list, function(a, b) return a.id < b.id end)
                e.player:sendEvent('OJB_ShowLog', { contracts = list, held = heldCount(), max = maxHeld(e.player) })
            end
            e.player:sendEvent('OJB_Contracts', { held = heldCount() })
        end,
        OJB_Guild = function(e)
            local key = guildBoardFor(e.faction, e.player.cell and e.player.cell.name)
            if not key then
                tell(e.player, 'Nothing is posted here at the moment.')
                return
            end
            openBoard(e.player, key, e.faction)
        end,
        OJB_Debug = function(e) debugCommand(e.player, e) end,
    },
}
