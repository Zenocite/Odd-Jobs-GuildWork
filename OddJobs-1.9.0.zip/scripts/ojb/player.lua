---@omw-context player
-- The player half of Odd Jobs: checks board spots with rays (only physics and rendering live
-- here), draws the board and contract windows, opens guild work from dialogue, settings, the
-- contract log key, training rewards and the debug commands.

local ambient = require('openmw.ambient')
local async = require('openmw.async')
local core = require('openmw.core')
local input = require('openmw.input')
local nearby = require('openmw.nearby')
local self = require('openmw.self')
local storage = require('openmw.storage')
local types = require('openmw.types')
local ui = require('openmw.ui')
local util = require('openmw.util')
local I = require('openmw.interfaces')
local time = require('openmw_aux.time')

local C = require('scripts.ojb.config')
local G = require('scripts.ojb.geom')
local loose = require('scripts.ojb.loose')
local spots = require('scripts.ojb.spots')
local surface = require('scripts.ojb.surface')
local window = require('scripts.ojb.window')

local L10N = 'OddJobs'
local v3 = util.vector3

---------------------------------------------------------------------------------------------------
-- Settings

input.registerTrigger { key = 'OddJobsLog', l10n = L10N, name = 'logKey_name', description = 'logKey_desc' }

I.Settings.registerPage { key = 'OddJobs', l10n = L10N, name = 'page_name', description = 'page_desc' }

local function check(key, default)
    return { key = key, renderer = 'checkbox', name = key .. '_name', description = key .. '_desc', default = default ~= false }
end
local function number(key, default, lo, hi, integer)
    return { key = key, renderer = 'number', name = key .. '_name', description = key .. '_desc', default = default,
        argument = { integer = integer ~= false, min = lo, max = hi } }
end
local function choice(key, default, items)
    return { key = key, renderer = 'select', name = key .. '_name', description = key .. '_desc', default = default,
        argument = { l10n = L10N, items = items } }
end

-- The page, top to bottom: one storage section per group.
-- Every feature in config.FEATURES has its own switch in one of them.
local GROUPS = {
    { key = C.SETTINGS_SECTION, name = 'group_name', settings = {
        check('boards'), check('villageBoards'), choice('detail', 'rumours', { 'rumours', 'plain' }), check('strays'),
        number('newDone', C.EARLY.DONE, 0, 100), check('hideAbove', false) } },
    { key = 'SettingsOddJobsWork', name = 'work_name', settings = {
        check('dangerous'), check('elite'), check('multiPart'), check('reinfest'), check('returning'),
        check('contractGroups'), number('groupSize', C.THREAT.GROUP_SIZE, 0.5, 1.5, false),
        check('slotsPerk'), number('slotsDone', C.PERK.DONE, 0, 200) } },
    { key = 'SettingsOddJobsGoods', name = 'goods_name', settings = {
        check('requisitions'), check('companyReqs'), check('collectors'), check('lostLedgers'), check('reqTraining'),
        choice('soulValues', 'vanilla', { 'vanilla', 'rebalanced' }) } },
    { key = 'SettingsOddJobsWild', name = 'wild_name', settings = {
        check('wildCaravan'), check('wildRoadblock'), check('wildBeast'), check('wildGuar'), check('wildSmuggler'),
        check('wildWreck'), check('wildGather'), check('wildPatrol'), check('wildTraveller'), check('wildDrive'),
        check('wildGraverobber'), check('wildMachine'), check('wildSummon'), check('wildRitual'),
        check('wildTax'), check('wildPirateCove'), check('wildPirate') } },
    { key = 'SettingsOddJobsTwists', name = 'twists_name', settings = {
        check('twistOffer'), check('twistLied'), check('twistRival'), check('twistWorse'), check('twistChains') } },
    { key = 'SettingsOddJobsInterface', name = 'interface_name', settings = {
        choice('directions', 'rough', { 'exact', 'rough', 'off' }),
        { key = 'logKey', renderer = 'inputBinding', name = 'logKey_name', description = 'logKey_desc',
            default = 'OddJobsLogKey', argument = { type = 'trigger', key = 'OddJobsLog' } },
        check('debug', false), check('profile', false) } },
    { key = 'SettingsOddJobsOld', name = 'old_name', description = 'old_desc', settings = {
        check('levelGates', false), number('slotsLevel', C.PERK.LEVEL, 1, 100),
        number('earlyLevel', C.EARLY.LEVEL, 1, 100) } },
}
for i, g in ipairs(GROUPS) do
    I.Settings.registerGroup { key = g.key, page = 'OddJobs', l10n = L10N, name = g.name, description = g.description,
        order = i, permanentStorage = true, settings = g.settings }
end

-- Settings from before 1.8.9 sat in two sections (the first one, and C.FEATURES_SECTION). Copied
-- once into the group each one lives in now, so nobody's choices reset; the flag stops a second copy.
local sections = {}
for _, g in ipairs(GROUPS) do sections[#sections + 1] = storage.playerSection(g.key) end
local interfaceSettings = storage.playerSection('SettingsOddJobsInterface')
do
    local moved = storage.playerSection('SettingsOddJobsMoved')
    if not moved:get('v1') then
        local old = { storage.playerSection(C.SETTINGS_SECTION), storage.playerSection(C.FEATURES_SECTION) }
        for i, g in ipairs(GROUPS) do
            for _, st in ipairs(g.settings) do
                for _, o in ipairs(old) do
                    local v = o:get(st.key)
                    if v ~= nil and sections[i]:get(st.key) ~= v then sections[i]:set(st.key, v) end
                end
            end
        end
        moved:set('v1', true)
    end
end

-- Global scripts can't read player settings; they get a copy on load and on every change.
local profileOn = false
local function sendSettings()
    local s = {}
    for i, g in ipairs(GROUPS) do
        for _, st in ipairs(g.settings) do s[st.key] = sections[i]:get(st.key) end
    end
    profileOn = s.profile == true
    core.sendGlobalEvent('OJB_Settings', s)
end
for _, sec in ipairs(sections) do sec:subscribe(async:callback(sendSettings)) end

---------------------------------------------------------------------------------------------------
-- Notice spots. global.lua sends every door of a board within reach; beside each, papers on the
-- wall are tried first, then the board with its back to that wall, then the board on open ground
-- with something behind it. Windows never count as wall. Each door comes back with the patches
-- that passed, and a line for each one rejected, and how the door sits in the street.
-- A wall that has room spreads the papers across two or three patches. global.lua scores the
-- doors and picks one per interior. The result is cached: nothing here runs again for that board.
-- castRenderingRay (things drawn without collision: posters, plants, banners, signs) is only
-- allowed in onFrame and input handlers, so the whole search runs as a coroutine resumed from
-- onFrame, pausing to the next frame every C.RAYS_PER_FRAME rays. A wall probe costs about 3 rays
-- plus 23 per paper patch tried (9 physics, 9 rendering, 2 in front, 3 for sight). Once per board
-- per game, and again only after a version that changes placement.

local SOLID = nearby.COLLISION_TYPE.World + nearby.COLLISION_TYPE.Door + nearby.COLLISION_TYPE.HeightMap
local GROUND = nearby.COLLISION_TYPE.World + nearby.COLLISION_TYPE.HeightMap
local PAD = 10
local W = C.WALL
local UP = v3(0, 0, 1)

-- { key, doors, w, d, h, co, rays, frameRays, frames, ms, maxMs }, plus the door being searched:
-- door, outs, spots, z, tried.
local job

local function budget()
    job.rays = job.rays + 1
    job.frameRays = job.frameRays + 1
    if job.frameRays > C.RAYS_PER_FRAME then coroutine.yield() end
end

local function ray(a, b, mask)
    budget()
    return nearby.castRay(a, b, { collisionType = mask or SOLID })
end

local function seen(a, b)
    budget()
    return nearby.castRenderingRay(a, b, { ignore = self })
end

local function groundAt(x, y, z)
    local r = ray(v3(x, y, z + 250), v3(x, y, z - 350), GROUND)
    if not r.hit then return nil end
    return r.hitPos.z, r.hitObject
end

local function nameOf(obj)
    return obj and obj.recordId or 'terrain'
end

local function isActor(obj)
    return obj and types.Actor.objectIsInstance(obj)
end

-- Windows, glass and shutters by record id or mesh. Key: record id; lives for the session (records
-- don't change once loaded); a record that isn't a window is kept as false.
local windowCache = {}
local function isWindow(obj)
    if not obj then return false end
    local id = obj.recordId
    local hit = windowCache[id]
    if hit == nil then
        local rec = obj.type and obj.type.record and obj.type.record(obj)
        hit = G.hasWord(id, C.WINDOW_WORDS) or (rec ~= nil and G.hasWord(rec.model, C.WINDOW_WORDS))
        windowCache[id] = hit
    end
    return hit
end

local function isSoft(obj)
    return obj ~= nil and obj.recordId ~= nil and G.hasWord(obj.recordId, C.SOFT_WORDS)
end

-- Segments across the footprint at one height: front and back edges, both sides, both diagonals.
local function footprintSegments(s, w, d, z)
    local c = G.corners(s.x, s.y, s.yaw, w + 2 * PAD, d + 2 * PAD)
    local p = {}
    for i, q in ipairs(c) do p[i] = v3(q.x, q.y, z) end
    return { { p[1], p[2] }, { p[4], p[3] }, { p[1], p[4] }, { p[2], p[3] }, { p[1], p[3] }, { p[2], p[4] } }
end

-- In sight of someone coming out of the door: from any of three eyes a little out from it, and
-- on a raised entrance also from the street below its steps.
local function inSight(target, out)
    local rx, ry = -out.y, out.x
    local blocker
    local eyes = { { 120, job.z } }
    if job.streetZ then eyes[2] = { C.ENTRANCE.STREET_OUT, job.streetZ } end
    for _, e in ipairs(eyes) do
        for _, side in ipairs({ 0, 1, -1 }) do
            local eye = v3(job.door.x + out.x * e[1] + rx * side * 60, job.door.y + out.y * e[1] + ry * side * 60,
                e[2] + 110)
            local r = ray(eye, target)
            if not r.hit or (r.hitPos - target):length() <= 12 then return true end
            blocker = blocker or r.hitObject
        end
    end
    return false, nameOf(blocker)
end

-- The board on its footprint: flat ground, nothing overhead or through it, room to stand in front,
-- and in sight of the door. s: { x, y, z, yaw }.
local function physicalCheck(s, out)
    local w, d, h = job.w, job.d, job.h
    local pts = { { x = s.x, y = s.y } }
    local corners = G.corners(s.x, s.y, s.yaw, w, d)
    for _, q in ipairs(corners) do pts[#pts + 1] = q end
    if G.inDoorPath(job.door, out, corners) then return nil, 'in the way to the door' end
    local lo, hi, top = math.huge, -math.huge, nil
    for _, q in ipairs(pts) do
        local z, obj = groundAt(q.x, q.y, s.z)
        if not z then return nil, 'no ground' end
        if z > hi then top = obj end
        lo, hi = math.min(lo, z), math.max(hi, z)
    end
    if hi - lo > C.SPOT_MAX_SLOPE then return nil, string.format('slope %.0f under %s', hi - lo, nameOf(top)) end
    if math.abs(lo - s.z) > 150 then return nil, 'ground far from the door: ' .. nameOf(top) end
    local cell = self.cell
    if cell.hasWater and lo < cell.waterLevel + 20 then return nil, 'water' end

    for _, q in ipairs(pts) do
        local r = ray(v3(q.x, q.y, hi + 10), v3(q.x, q.y, lo + h + 40))
        if r.hit then return nil, 'overhead ' .. nameOf(r.hitObject) end
    end
    for _, hgt in ipairs(C.SPOT_RAY_HEIGHTS) do
        for _, seg in ipairs(footprintSegments(s, w, d, hi + hgt)) do
            local r = ray(seg[1], seg[2])
            if r.hit and not isSoft(r.hitObject) then return nil, 'clips ' .. nameOf(r.hitObject) end
        end
    end

    local fx, fy = -math.sin(s.yaw), -math.cos(s.yaw)
    local front = v3(s.x + fx * (d / 2 + PAD), s.y + fy * (d / 2 + PAD), hi + 60)
    local stand = v3(s.x + fx * C.SPOT_STAND_ROOM, s.y + fy * C.SPOT_STAND_ROOM, hi + 60)
    if ray(front, stand).hit then return nil, 'no room in front' end
    local standZ = groundAt(stand.x, stand.y, s.z)
    if not standZ or math.abs(standZ - lo) > 80 then return nil, 'drop in front' end

    local ok, behind = inSight(v3(front.x, front.y, lo + 100), out)
    if not ok then return nil, 'out of sight of the door, behind ' .. behind end
    return { x = s.x, y = s.y, z = lo, yaw = s.yaw, top = hi }
end

local function renderingCheck(s, spot)
    for _, hgt in ipairs(C.SPOT_RAY_HEIGHTS) do
        for _, seg in ipairs(footprintSegments(s, job.w, job.d, spot.top + hgt)) do
            local r = seen(seg[1], seg[2])
            -- People walk through the spot; they don't make it a bad one.
            if r.hit and not isActor(r.hitObject) and not isSoft(r.hitObject) then
                return 'clips ' .. nameOf(r.hitObject)
            end
        end
    end
    return nil
end

local function isDoor(obj) return obj ~= nil and obj.type == types.Door end
local surfaceCtx = { ray = function(a, b) return ray(a, b) end, seen = seen, nameOf = nameOf,
    isWindow = isWindow, isActor = isActor, isDoor = isDoor }

-- The ground under a probe: objects above the door's level (a hanging sign, its post, a crate) are
-- looked under, up to three, so they don't count as the ground the wall stands on.
local function streetGround(x, y)
    local gz, gobj = groundAt(x, y, job.z)
    for _ = 1, 3 do
        if not (gz and gobj and gz - job.z > W.GROUND_TOL) then break end
        local r = ray(v3(x, y, gz - 5), v3(x, y, job.z - 350), GROUND)
        if not r.hit then break end
        gz, gobj = r.hitPos.z, r.hitObject
    end
    return gz, gobj
end

-- The wall behind a probe point, facing the street. Returns { hit, n (unit, level), obj, gz } or nil, why.
-- p.face: a surface found facing the door's approach; looked for along it instead of the street
-- direction, and not held to the door's line.
local function findWall(p, height)
    local face = p.face or p.out
    local gz, gobj = streetGround(p.x, p.y)
    if not gz then return nil, 'no ground' end
    local street = job.streetZ and math.abs(gz - job.streetZ) <= W.GROUND_TOL
    if math.abs(gz - job.z) > W.GROUND_TOL and not street then
        return nil, string.format('ground %.0f off the door level (%s)', gz - job.z, nameOf(gobj))
    end
    local wall, why = surface.wallAt(surfaceCtx, v3(p.x, p.y, gz + height), v3(-face.x, -face.y, 0), W.REACH)
    if not wall then return nil, why end
    local n = wall.n
    if n.x * face.x + n.y * face.y < W.FACE_DOT then return nil, 'wall turned away from the street' end
    local setback = (wall.hit.x - job.door.x) * p.out.x + (wall.hit.y - job.door.y) * p.out.y
    if not p.face and math.abs(setback) > W.MAX_SETBACK then
        return nil, string.format('wall %.0f from the door line: %s', setback, nameOf(wall.obj))
    end
    wall.gz = gz
    return wall
end

-- Inside or within W.WINDOW_GAP of a window object's box (global.lua sends the boxes of window
-- statics near the door: { cx, cy, cz, hx, hy, hz }, world axis aligned). Returns its id or nil.
local function nearWindow(p)
    local g = W.WINDOW_GAP
    for _, w in ipairs(job.windows or {}) do
        if math.abs(p.x - w.cx) <= w.hx + g and math.abs(p.y - w.cy) <= w.hy + g and math.abs(p.z - w.cz) <= w.hz + g then
            return w.id
        end
    end
    return nil
end

-- The papers all on one flat face, and that face not jutting out of the wall (a bay window, an
-- oriel, a pillar): either side of the cluster, BAY_REACH out from its outer papers, the wall
-- behind is no more than BAY_DEPTH further back. Returns nil, or why. Two to three rays.
local function flatWall(slots, n3, right)
    local base = v3(slots[1].x, slots[1].y, slots[1].z)
    local lo, hi = math.huge, -math.huge
    for _, s in ipairs(slots) do
        local d = (v3(s.x, s.y, s.z) - base):dot(n3)
        lo, hi = math.min(lo, d), math.max(hi, d)
    end
    if hi - lo > W.PLANE_TOL then return string.format('papers not on one plane (%.0f apart)', hi - lo) end
    local minR, maxR, mid = math.huge, -math.huge, 0
    for _, s in ipairs(slots) do
        local r = (v3(s.x, s.y, s.z) - base):dot(right)
        minR, maxR = math.min(minR, r), math.max(maxR, r)
        mid = mid + s.z
    end
    mid = mid / #slots
    local deeper = 0
    for _, r in ipairs({ minR - W.BAY_REACH, maxR + W.BAY_REACH }) do
        local p = base + right * r
        local a = v3(p.x, p.y, mid) + n3 * 30
        local hit = ray(a, a - n3 * (30 + W.BAY_DEPTH + 60))
        local back = hit.hit and ((a - hit.hitPos):dot(n3) - 30) or math.huge
        if back > W.BAY_DEPTH then deeper = deeper + 1 end
    end
    if deeper == 2 then return 'papers on something jutting out of the wall (a bay window?)' end
    return nil
end

-- Papers on the wall at one probe point. Returns { x, y, z, yaw, obj, slots = { {x, y, z, yaw,
-- rec, tilt, lean}, ... } } with at least MIN_PAPERS papers, or nil, why, and the wall's object
-- when one was found. `only`: a set of object ids; any other wall is skipped before papers.
local function wallCheck(p, only)
    local wall, why = findWall(p, W.CENTRE_HEIGHT)
    if not wall then return nil, why end
    if only and not only[wall.obj.id] then
        return nil, 'not the door\'s building: ' .. nameOf(wall.obj), wall.obj
    end
    local n = wall.n
    local right = v3(-n.y, n.x, 0)
    local slots, skipped = {}, {}
    for i, s in ipairs(W.SLOTS) do
        if #slots >= W.PAPERS or #slots + #W.SLOTS - i + 1 < W.MIN_PAPERS then break end
        local c = wall.hit + right * s[1] + UP * s[2]
        local patch, miss = surface.patch(surfaceCtx, c, n, right, wall.obj)
        local win = patch and nearWindow(patch.pos)
        if win then
            patch, miss = nil, 'beside a window (' .. win .. ')'
        end
        if patch and inSight(patch.pos + patch.n * 6, p.out) then
            local i = #slots + 1
            local look = C.WALL_PAPERS[i]
            local at = patch.pos + patch.n3 * (0.6 + 0.2 * (i - 1))
            slots[i] = { x = at.x, y = at.y, z = at.z, yaw = G.yawFacing(patch.n.x, patch.n.y), rec = look.rec,
                tilt = look.tilt, lean = patch.lean, on = patch.on, n3 = patch.n3 }
        else
            miss = miss or 'out of sight'
            skipped[miss] = (skipped[miss] or 0) + 1
        end
    end
    if #slots < W.MIN_PAPERS then
        local parts = {}
        for k, v in pairs(skipped) do parts[#parts + 1] = string.format('%s x%d', k, v) end
        table.sort(parts)
        return nil, string.format('room for %d paper%s (%s) on %s, %.0f above the door', #slots,
            #slots == 1 and '' or 's', table.concat(parts, ', '), nameOf(wall.obj), wall.hit.z - job.z), wall.obj
    end
    local bad = flatWall(slots, slots[1].n3, right)
    if bad then return nil, bad .. ' on ' .. nameOf(wall.obj), wall.obj end
    local on = {}
    for i, s in ipairs(slots) do
        on[i] = string.format('%s at %.0f, %.0f, %.0f', s.on, s.x, s.y, s.z)
        s.n3, s.on = nil, nil
    end
    local mid = slots[1]
    return { x = mid.x, y = mid.y, z = mid.z, yaw = mid.yaw, slots = slots, on = on, obj = wall.obj,
        nx = n.x, ny = n.y }
end

-- Light and openness at papers facing (nx, ny). Lit: a light from job.lights (nearest first) within
-- reach of its radius with nothing between; the ray starts LIGHT.START off the light, outside its
-- own lantern. Open: clear share of a fan of level rays out from the papers. Papers sit on the
-- drawn wall, up to 30 behind its collision shell, so both work from LIGHT.OFF out. Up to 9 rays.
local function lightAt(pos, nx, ny)
    local L = C.LIGHT
    local face = v3(nx, ny, 0)
    local front = pos + face * L.OFF
    local lit = false
    for _, l in ipairs(job.lights or {}) do
        local lp = v3(l.x, l.y, l.z)
        local d = (lp - front):length()
        if d < l.r * L.REACH and d > L.START then
            local from = lp + (front - lp):normalize() * L.START
            if not ray(from, front).hit then
                lit = true
                break
            end
        end
    end
    local base, clear = math.atan2(nx, ny), 0
    local from = front
    for _, a in ipairs(L.OPEN_ANGLES) do
        local dir = v3(math.sin(base + a), math.cos(base + a), 0)
        local r = ray(from, from + dir * L.OPEN_LEN)
        clear = clear + (r.hit and (r.hitPos - from):length() or L.OPEN_LEN)
    end
    local open = clear / (#L.OPEN_ANGLES * L.OPEN_LEN)
    return lit, open
end

local function rateWall(spot)
    local lit, open = lightAt(v3(spot.x, spot.y, spot.z), spot.nx, spot.ny)
    spot.lit, spot.open = lit or nil, open
    spot.dark = (not lit and open < C.LIGHT.RECESS) or nil
    spot.nx, spot.ny = nil, nil
    return spot
end

-- The board's front against the street direction: false when turned sideways or backwards.
local function facesStreet(yaw, out)
    return -math.sin(yaw) * out.x - math.cos(yaw) * out.y >= C.BOARD_FACE_DOT
end

-- Behind a board at s (its back BOARD_SNUG off the backing): the gaps at both ends and the middle,
-- two heights. The middle must be backed low down and at most one end may overhang; the upper row
-- may find nothing (a low wall or fence), but every backing found within 120 must be close and not
-- inside the board. Returns the largest gap, or nil and why.
local function gapsBehind(s, z)
    local bx, by = math.sin(s.yaw), math.cos(s.yaw)
    local rx, ry = by, -bx
    local half = job.w / 2 - 6
    local worst, missedEnd = 0, 0
    for hi, h in ipairs(C.BOARD_GAP_HEIGHTS) do
        for li, lat in ipairs({ -half, 0, half }) do
            local a = v3(s.x + rx * lat, s.y + ry * lat, z + h)
            local r = ray(a, a + v3(bx, by, 0) * (job.d / 2 + 120))
            if r.hit then
                local gap = (r.hitPos - a):length() - job.d / 2
                if gap < 0 then return nil, 'its backing leans into it: ' .. nameOf(r.hitObject) end
                if gap > C.BOARD_GAP_MAX then return nil, string.format('gap of %.0f behind it', gap) end
                worst = math.max(worst, gap)
            elseif hi == 1 then
                if li == 2 then return nil, 'nothing behind its middle' end
                missedEnd = missedEnd + 1
                if missedEnd > 1 then return nil, 'nothing behind either end' end
            end
        end
    end
    return worst
end

-- A board facing n with its back on the backing at hit: its footprint is checked BOARD_WALL_GAP
-- plus PAD off, then it stands BOARD_SNUG off and every gap behind it is measured.
local function snugBoard(hit, n, gz, out)
    local yaw = G.yawFacing(n.x, n.y)
    if not facesStreet(yaw, out) then return nil, 'would face away from the street' end
    local check = job.d / 2 + PAD + C.BOARD_WALL_GAP
    local c = { x = hit.x + n.x * check, y = hit.y + n.y * check, z = gz, yaw = yaw }
    local spot, why = physicalCheck(c, out)
    if not spot then return nil, why end
    why = renderingCheck(c, spot)
    if why then return nil, why end
    local snug = job.d / 2 + C.BOARD_SNUG
    local s = { x = hit.x + n.x * snug, y = hit.y + n.y * snug, z = spot.z, yaw = yaw }
    local gap
    gap, why = gapsBehind(s, spot.z)
    if not gap then return nil, why end
    return { x = s.x, y = s.y, z = s.z, yaw = yaw, gap = gap }
end

-- The board with its back to the wall at a probe point.
local function backedCheck(p)
    local wall, why = findWall(p, 100)
    if not wall then return nil, why end
    return snugBoard(wall.hit, wall.n, wall.gz, p.out)
end

-- Open ground. With a wall, fence or rock within BACKED_REACH behind, the board is moved back
-- against it (turned to it) and comes back as backed; a spot that passes everything but that comes
-- back as the third value, for when nothing backed is found.
local function openCheck(s, out)
    if not facesStreet(s.yaw, out) then return nil, 'would face away from the street' end
    local spot, why = physicalCheck(s, out)
    if not spot then return nil, why end
    local bx, by = math.sin(s.yaw), math.cos(s.yaw)
    local from = v3(s.x, s.y, spot.z + 100)
    local back = ray(from, from + v3(bx, by, 0) * C.BACKED_REACH)
    why = renderingCheck(s, spot)
    if why then return nil, why end
    spot.top = nil
    if not back.hit then return nil, 'nothing behind it', spot end
    local n = back.hitNormal
    if math.abs(n.z) <= W.MAX_NORMAL_Z then
        local level = v3(n.x, n.y, 0):normalize()
        local snug, swhy = snugBoard(v3(back.hitPos.x, back.hitPos.y, spot.z), level, spot.z, out)
        if snug then return snug, nil, nil, true end
        why = 'not snug against ' .. nameOf(back.hitObject) .. ' (' .. swhy .. ')'
    else
        why = 'nothing upright behind it'
    end
    -- Something close behind that the board can't sit flat against would read as a gap: not free.
    return nil, why
end

local function reject(label, why)
    job.tried[#job.tried + 1] = label .. ': ' .. why
    if interfaceSettings:get('debug') then
        print(string.format('%s%s %s rejected: %s', C.LOG_TAG, job.key, label, why))
    end
end

local function sideLabel(kind, p)
    return string.format('%s %s %d', kind, p.side > 0 and 'right' or 'left', math.floor(math.abs(p.along)))
end

-- One door's search, best first. Returns ok, kind, spot; spot.style (wall, backed, open, free) and
-- spot.along (distance from the door) are what global.lua scores doors by.
-- Walls first, along the whole street front of the door's building (the object of the first wall
-- found beside the door), nearest the door first. Beside the door any wall will do; past the old
-- beside-the-door reach only the door's own building, and a spot on its own building wins over a
-- neighbour's nearer one. At most W.FACADE_RAYS rays per door on walls.
local function searchWalls()
    local nearReach = math.min(job.door.half or 50, W.DOOR_HALF_MAX) + W.HALF_W + W.EDGE_GAP
        + W.LATERAL[#W.LATERAL]
    local startRays = job.rays
    -- The door's building: what stands above the door, and the first wall found beside it.
    local home, homes, fallback = nil, {}, nil
    for _, out in ipairs(job.outs) do
        for _, h in ipairs(W.ABOVE_DOOR) do
            local w = surface.wallAt(surfaceCtx, v3(job.door.x + out.x * W.OUT, job.door.y + out.y * W.OUT, job.z + h),
                v3(-out.x, -out.y, 0), W.REACH)
            if w then
                homes[w.obj.id] = true
                home = home or w.obj
            end
        end
    end
    -- Both sides of the door, then along the front. A dark recess is kept only when nothing open
    -- was found. Patches within PATCH_GAP of one already chosen are the same stretch of wall.
    local found, stop, firstOpen = {}, false, nil
    local function apart(a, b)
        local dx, dy = a.x - b.x, a.y - b.y
        return dx * dx + dy * dy >= W.PATCH_GAP * W.PATCH_GAP
    end
    local function openPatches(list)
        local picked = {}
        for _, s in ipairs(list) do
            if not s.dark then
                local ok = true
                for _, p in ipairs(picked) do if not apart(s, p) then ok = false end end
                if ok then picked[#picked + 1] = s end
            end
        end
        return picked
    end
    for _, out in ipairs(job.outs) do
        if stop then break end
        for _, p in ipairs(surface.facadeProbes(job.door, out)) do
            p.out = out
            local far = math.abs(p.along) > nearReach + 1
            if far and not home then break end
            local label = sideLabel('wall', p)
            if job.rays - startRays > W.FACADE_RAYS then
                reject(label, string.format('gave up on walls after %d rays', job.rays - startRays))
                stop = true
                break
            end
            local spot, why, obj = wallCheck(p, far and homes or nil)
            obj = obj or (spot and spot.obj)
            if obj and not far and not home then
                homes[obj.id] = true
                home = obj
            end
            if spot then
                spot.label, spot.style, spot.along = label, 'wall', math.abs(p.along)
                local own = homes[spot.obj.id]
                spot.obj = nil
                rateWall(spot)
                if own then
                    spot.ord = #found + 1
                    found[#found + 1] = spot
                    if not spot.dark then firstOpen = firstOpen or math.abs(p.along) end
                    local along = math.abs(p.along)
                    -- With a patch already in hand, look a few metres along and then stop.
                    -- A first patch that is itself far (the near wall was windows) gets the same
                    -- look past it, so one clear stretch is not the only one tried.
                    local looked = firstOpen and ((firstOpen <= W.SPREAD and along > W.SPREAD)
                        or along > firstOpen + W.SPREAD)
                    if #openPatches(found) >= W.PATCHES or looked then
                        stop = true
                        break
                    end
                else
                    fallback = fallback or spot
                    reject(label, 'kept in reserve: not the door\'s building')
                end
            else
                reject(label, why)
            end
        end
    end
    local open, dark = {}, {}
    for _, s in ipairs(found) do
        if s.dark then dark[#dark + 1] = s else open[#open + 1] = s end
    end
    local pool = #open > 0 and open or dark
    -- The anchor stays the nearest stretch that passed, so one blocked paper does not walk the
    -- whole board down the street. Further stretches are added only when they stand clear of it,
    -- a lit one ahead of a dark corner.
    table.sort(pool, function(a, b)
        if a.along ~= b.along then return a.along < b.along end
        return a.ord < b.ord
    end)
    local picked = { pool[1] }
    local rest = {}
    for i = 2, #pool do rest[#rest + 1] = pool[i] end
    table.sort(rest, function(a, b)
        if (a.lit or false) ~= (b.lit or false) then return a.lit and not b.lit end
        if a.along ~= b.along then return a.along < b.along end
        return a.ord < b.ord
    end)
    for _, s in ipairs(rest) do
        local ok = true
        for _, p in ipairs(picked) do if not apart(s, p) then ok = false end end
        if ok then picked[#picked + 1] = s end
        if #picked >= W.PATCHES then break end
    end
    if #picked == 0 then return fallback end
    if #open > 0 then
        for _, s in ipairs(dark) do
            reject(s.label, string.format('a dark recess (%s is better lit or more open)', picked[1].label))
        end
    end
    local anchor = picked[1]
    local slots, notes = {}, {}
    local start = 1
    if #picked > 1 and job.key then
        local h = 0
        for i = 1, #job.key do h = (h * 33 + job.key:byte(i)) % 997 end
        start = h % #picked + 1
    end
    for n = 1, W.PER_PATCH do
        for k = 1, #picked do
            if #slots >= W.PAPERS then break end
            local patch = picked[(start + k - 2) % #picked + 1]
            if patch.slots[n] then
                slots[#slots + 1] = patch.slots[n]
                notes[#notes + 1] = patch.on and patch.on[n]
            end
        end
    end
    if #picked == 1 then
        for i = #slots + 1, math.min(W.PAPERS, #anchor.slots) do
            slots[#slots + 1] = anchor.slots[i]
            notes[#notes + 1] = anchor.on and anchor.on[i]
        end
        anchor.single = #open == 0 and 'every stretch in reach was a dark recess'
            or 'no second stretch of wall passed'
    end
    anchor.slots, anchor.on, anchor.patches = slots, notes, #picked
    return anchor
end

-- Surfaces facing the way people come to the door (a courtyard's side wall, a door frame, a
-- pillar, a post, a fence): a fan of level rays from where you step out, then the full paper check
-- on the FACING.TRIES hits nearest the door. Up to FACING.RAYS + TRIES paper checks of rays.
local function searchFacing()
    local F = C.FACING
    local out = job.outs[1]
    if not out then return nil end
    local a = job.arrival
    local ox, oy = a and a.x or job.door.x + out.x * 120, a and a.y or job.door.y + out.y * 120
    local gz = groundAt(ox, oy, job.z)
    if not gz then return nil end
    local eye = v3(ox, oy, gz + W.CENTRE_HEIGHT)
    local hits = {}
    for i = 0, F.RAYS - 1 do
        local ang = 2 * math.pi * i / F.RAYS
        local dir = v3(math.sin(ang), math.cos(ang), 0)
        if dir.x * out.x + dir.y * out.y > F.BACK_DOT then
            local r = ray(eye, eye + dir * F.REACH, nearby.COLLISION_TYPE.World)
            local n = r.hit and r.hitNormal
            if n and math.abs(n.z) <= W.MAX_NORMAL_Z and not isActor(r.hitObject) then
                local level = v3(n.x, n.y, 0):normalize()
                local dist = (r.hitPos - eye):length()
                if dist >= F.MIN and -(level:dot(dir)) >= F.DOT then
                    local dx, dy = r.hitPos.x - job.door.x, r.hitPos.y - job.door.y
                    hits[#hits + 1] = { hit = r.hitPos, n = level, obj = r.hitObject, door = math.sqrt(dx * dx + dy * dy) }
                end
            end
        end
    end
    table.sort(hits, function(x, y) return x.door < y.door end)
    local tried = {}
    for _, h in ipairs(hits) do
        if #tried >= F.TRIES then break end
        local near = false
        for _, t in ipairs(tried) do
            if (t.hit - h.hit):length() < F.SPREAD then near = true end
        end
        if not near then
            tried[#tried + 1] = h
            local p = { x = h.hit.x + h.n.x * W.OUT, y = h.hit.y + h.n.y * W.OUT, out = out,
                face = { x = h.n.x, y = h.n.y }, side = 1, along = h.door }
            local label = string.format('surface facing the way in, %s %.0f from the door', nameOf(h.obj), h.door)
            local spot, why = wallCheck(p)
            if spot then
                spot.label, spot.style, spot.along, spot.obj = label, 'surface', h.door, nil
                return rateWall(spot)
            end
            reject(label, why)
        end
    end
    return nil
end

local function searchDoor()
    local wall = searchWalls()
    if wall then return true, 'wall', wall end
    wall = searchFacing()
    if wall then return true, 'wall', wall end
    for _, out in ipairs(job.outs) do
        for _, p in ipairs(G.boardProbes(job.door, out, job.w)) do
            p.out = out
            local spot, why = backedCheck(p)
            local label = sideLabel('board against the wall', p)
            if spot then
                spot.label, spot.style, spot.along = label, 'backed', math.abs(p.along)
                return true, 'board', spot
            end
            reject(label, why)
        end
    end
    local free, freeAt
    for i, s in ipairs(job.spots) do
        local spot, why, unbacked, snugged = openCheck(s, job.outs[1])
        if spot then
            local dx, dy = spot.x - job.door.x, spot.y - job.door.y
            spot.label = 'board spot ' .. i .. (snugged and ' against the wall behind it' or '')
            spot.style, spot.along = snugged and 'backed' or 'open', math.sqrt(dx * dx + dy * dy)
            return true, 'board', spot
        end
        if unbacked and not free then free, freeAt = unbacked, i end
        reject('board spot ' .. i, why)
    end
    if free then
        local dx, dy = free.x - job.door.x, free.y - job.door.y
        free.label, free.style, free.along = 'board spot ' .. freeAt .. ' standing free', 'free',
            math.sqrt(dx * dx + dy * dy)
        return true, 'board', free
    end
    return false
end

local NAV = nearby.NAVIGATOR_FLAGS
local WALK = NAV.Walk + NAV.OpenDoor + NAV.UsePathgrid
local PATH = nearby.FIND_PATH_STATUS

-- How the door sits in the street, for global.lua's main-entrance score: open (share of a fan of
-- rays out from where you step out that runs FAN_LEN clear), up (door above the street STREET_OUT
-- out), and reach: 'level'; 'stairs' when it's STEP or more off the street but the navmesh walks
-- there directly; 'upper' when the walk is DETOUR times longer than straight; 'unreachable' with no
-- walk at all; 'unknown' when the navmesh isn't ready. FAN + 1 rays and at most one findPath.
local function measureEntrance(d)
    local E = C.ENTRANCE
    local out = job.outs[1]
    if not out then return { open = 0, reach = 'unknown' } end
    local a = d.arrival
    local from = a and v3(a.x, a.y, a.z) or v3(job.door.x + out.x * 120, job.door.y + out.y * 120, job.z)
    local sx, sy = job.door.x + out.x * E.STREET_OUT, job.door.y + out.y * E.STREET_OUT
    local g = ray(v3(sx, sy, job.z + 300), v3(sx, sy, job.z - 1500), GROUND)
    local streetZ = g.hit and g.hitPos.z or job.z
    local up = job.z - streetZ
    local reach = 'level'
    if math.abs(up) >= E.STEP then
        local street = v3(sx, sy, streetZ)
        local status, path = nearby.findPath(from, street, { includeFlags = WALK })
        local last = path and path[#path]
        if (status == PATH.Success or status == PATH.PartialPath) and last and (last - street):length() < 150 then
            local len, prev = 0, from
            for _, p in ipairs(path) do
                len = len + (p - prev):length()
                prev = p
            end
            reach = len <= (street - from):length() * E.DETOUR + E.DETOUR_PAD and 'stairs' or 'upper'
        elseif status == PATH.PartialPath or status == PATH.FindPathOverPolygonsFailed then
            reach = 'unreachable'
        else
            reach = 'unknown'
        end
        if reach == 'stairs' then job.streetZ = streetZ end
    end
    local eye = from + v3(0, 0, 100)
    local base = math.atan2(out.x, out.y)
    local total = 0
    for i = 0, E.FAN - 1 do
        local ang = base - E.FAN_HALF + 2 * E.FAN_HALF * i / (E.FAN - 1)
        local r = ray(eye, eye + v3(math.sin(ang), math.cos(ang), 0) * E.FAN_LEN)
        total = total + (r.hit and (r.hitPos - eye):length() or E.FAN_LEN)
    end
    return { open = total / (E.FAN * E.FAN_LEN), up = up, reach = reach }
end

-- Every door sent, in turn. Returns { {id, ok, kind, spot, tried, entrance}, ... }.
local function search()
    local results = {}
    for _, d in ipairs(job.doors) do
        job.door, job.z, job.outs, job.spots, job.tried = d.door, d.door.z, d.outs or {}, d.spots or {}, {}
        job.windows, job.lights, job.arrival = d.windows, d.lights, d.arrival
        job.streetZ = nil
        local entrance = measureEntrance(d)
        local ok, kind, spot = searchDoor()
        results[#results + 1] = { id = d.id, ok = ok, kind = kind, spot = spot, tried = job.tried, entrance = entrance }
    end
    return results
end

local function answer(results, err)
    core.sendGlobalEvent('OJB_SpotResult', {
        key = job.key, results = results, error = err,
        rays = job.rays, frames = job.frames, ms = job.ms, maxMs = job.maxMs,
    })
    job = nil
end

local function stepSpotCheck()
    -- Rays only see the loaded area; global.lua asks again later if the player walked off.
    if not self.cell or not self.cell.isExterior then
        job = nil
        return
    end
    job.frameRays = 0
    local t0 = core.getRealTime()
    -- resume hands back the search's error instead of raising it: answered as a skip of every door
    -- sent, with the error, so it's logged once instead of retried every 15 s.
    local alive, results = coroutine.resume(job.co)
    local ms = (core.getRealTime() - t0) * 1000
    job.frames, job.ms = job.frames + 1, job.ms + ms
    if ms > job.maxMs then job.maxMs = ms end
    if not alive then
        print(C.LOG_TAG .. job.key .. ' spot check failed: ' .. tostring(results))
        answer(nil, tostring(results))
        return
    end
    if coroutine.status(job.co) == 'dead' then answer(results) end
end

local function startSpotCheck(e)
    job = {
        key = e.key, doors = e.doors or {}, w = e.w, d = e.d, h = e.h, tried = {},
        rays = 0, frameRays = 0, frames = 0, ms = 0, maxMs = 0,
    }
    job.co = coroutine.create(search)
end

-- Stray notices (strays.lua): one paper on a post, pillar, stall, or the wall beside a house door,
-- away from the boards. Per candidate: its open side (the longest of 8 level rays out from a post,
-- or of the two along a door's facing), street-level ground STRAY.EYE out on that side, a level ray
-- from there onto the post or the wall BESIDE the door, one paper's patch on it, and a clear line
-- from standing height. About 30 rays a candidate, plus the light check on the one that passes.
local function pinStray(obj, door, gz, mid, best)
    local SC = C.STRAY
    local ex, ey = mid.x + best.x * SC.EYE, mid.y + best.y * SC.EYE
    local ez = groundAt(ex, ey, gz)
    if not ez or math.abs(ez - gz) > SC.STEP then return nil, 'no ground at street level in front' end
    local cell = self.cell
    if cell.hasWater and ez < cell.waterLevel + 20 then return nil, 'water in front' end
    local r = ray(v3(ex, ey, mid.z), mid - best * SC.OFF)
    local wall = r.hit and r.hitObject or nil
    local seenName = r.hit and nameOf(wall) or 'nothing'
    if door then
        if not wall or isDoor(wall) or isActor(wall) or math.abs((r.hitPos - mid):dot(best)) > SC.OFF * 2 then
            return nil, 'no wall beside the door: ' .. seenName
        end
    elseif wall ~= obj then
        return nil, 'in front of it: ' .. seenName
    end
    local n = r.hitNormal
    if math.abs(n.z) > W.MAX_NORMAL_Z then return nil, 'not upright' end
    local level = v3(n.x, n.y, 0):normalize()
    if level:dot(best) < C.FACING.DOT then return nil, 'face turned from the street' end
    local patch, why = surface.patch(surfaceCtx, r.hitPos, level, v3(-level.y, level.x, 0), wall)
    if not patch then return nil, why end
    local target = patch.pos + patch.n * 6
    local s = ray(v3(ex, ey, ez + 110), target)
    if s.hit and (s.hitPos - target):length() > 12 then return nil, 'out of sight from the street' end
    local look = C.WALL_PAPERS[1]
    local at = patch.pos + patch.n3 * 0.6
    local lit, open = lightAt(at, patch.n.x, patch.n.y)
    if not lit and open < C.LIGHT.RECESS then return nil, 'dark and closed in' end
    return { x = at.x, y = at.y, z = at.z, yaw = G.yawFacing(patch.n.x, patch.n.y), rec = look.rec,
        tilt = look.tilt, lean = patch.lean, lit = lit or nil, open = open,
        label = door and (nameOf(wall) .. ' beside a door') or nameOf(obj) }
end

local function strayCheck(obj)
    local SC = C.STRAY
    if not obj or not obj:isValid() then return nil, 'gone' end
    local p = obj.position
    local door = isDoor(obj)
    -- A post's own cap is the first thing straight down from above it; above a door is its lintel.
    budget()
    local top = door and p.z + 20 or p.z + 250
    local g = nearby.castRay(v3(p.x, p.y, top), v3(p.x, p.y, p.z - 350), { collisionType = GROUND, ignore = obj })
    if not g.hit then return nil, 'no ground' end
    local gz = g.hitPos.z
    job.z = gz
    local mid = v3(p.x, p.y, gz + W.CENTRE_HEIGHT)
    -- Posts: 8 ways round. Doors: the 4 ways square to the door, since which axis a door mesh
    -- faces along varies; the way out is open in front and has the house behind.
    local dirs, lens = {}, {}
    local yaw, n = door and obj.rotation:getYaw() or 0, door and 4 or 8
    for i = 0, n - 1 do
        local a = yaw + i * 2 * math.pi / n
        dirs[#dirs + 1] = v3(math.sin(a), math.cos(a), 0)
    end
    for i, dir in ipairs(dirs) do
        local from = mid + dir * SC.OFF
        local r = ray(from, from + dir * SC.OPEN)
        lens[i] = r.hit and (r.hitPos - from):length() or SC.OPEN
    end
    local best, bestLen, bestScore
    for i, dir in ipairs(dirs) do
        local score = lens[i] - (door and lens[(i + n / 2 - 1) % n + 1] or 0)
        if not bestScore or score > bestScore then best, bestLen, bestScore = dir, lens[i], score end
    end
    if bestLen < SC.OPEN * SC.OPEN_SHARE then return nil, 'no open street beside it' end
    if not door then return pinStray(obj, false, gz, mid, best) end
    local sz = groundAt(p.x + best.x * SC.OFF, p.y + best.y * SC.OFF, gz - 230)
    if sz then gz, mid = sz, v3(p.x, p.y, sz + W.CENTRE_HEIGHT) end
    local why
    for _, side in ipairs({ 1, -1 }) do
        local spot
        spot, why = pinStray(obj, true, gz, mid + v3(-best.y, best.x, 0) * (side * SC.BESIDE), best)
        if spot then return spot end
    end
    return nil, why
end

-- The first candidate that passes, and why each before it didn't.
local function searchStrays()
    local tried = {}
    for i, obj in ipairs(job.cands) do
        local spot, why = strayCheck(obj)
        if spot then return { spot = spot, tried = tried, index = i } end
        tried[#tried + 1] = nameOf(obj) .. ': ' .. tostring(why)
    end
    return { tried = tried }
end

-- Answered 'busy' when a board's check is running: global.lua asks again later.
local function startStrayCheck(e)
    if job then
        core.sendGlobalEvent('OJB_SpotResult', { key = e.key, busy = true })
        return
    end
    job = { key = e.key, cands = e.cands or {}, lights = e.lights, tried = {},
        rays = 0, frameRays = 0, frames = 0, ms = 0, maxMs = 0 }
    job.co = coroutine.create(searchStrays)
end

---------------------------------------------------------------------------------------------------
-- Windows. Interface mode is pushed on top of whatever was open, so a board opened from dialogue
-- drops back into the conversation when closed.

local current = { key = nil, guild = nil, choice = nil }

-- A choice window closed without an answer counts as its last option (the job as posted).
local function answerChoice(option)
    local ch = current.choice
    if not ch then return end
    current.choice = nil
    core.sendGlobalEvent('OJB_ChoiceMade', { player = self, id = ch.id, option = option or ch.default })
end

local function closeWindow()
    if not window.isOpen() then return end
    window.close()
    I.UI.removeMode('Interface')
    answerChoice(nil)
end

local handlers = {
    take = function(id)
        core.sendGlobalEvent('OJB_Take', { player = self, key = current.key, notice = id, guild = current.guild })
    end,
    handIn = function(id)
        core.sendGlobalEvent('OJB_HandIn', { player = self, key = current.key, contract = id, guild = current.guild })
    end,
    abandon = function(id)
        core.sendGlobalEvent('OJB_Abandon', { player = self, key = current.key, contract = id, guild = current.guild })
        if not current.key then core.sendGlobalEvent('OJB_Check', { player = self, log = true }) end
    end,
    handOver = function(id)
        core.sendGlobalEvent('OJB_ReqHandIn', { player = self, key = current.key, notice = id, guild = current.guild })
    end,
    choose = function(option)
        answerChoice(option)
        closeWindow()
    end,
    close = closeWindow,
}

local function open(mode, data)
    if not window.isOpen() then
        I.UI.addMode('Interface', { windows = {} })
    end
    window.show(mode, data, handlers)
end

input.registerTriggerHandler('OddJobsLog', async:callback(function()
    if window.isOpen() then
        closeWindow()
    elseif I.UI.getMode() == nil then
        core.sendGlobalEvent('OJB_Check', { player = self, log = true })
    end
end))

---------------------------------------------------------------------------------------------------
-- Guild work from a steward. OddJobs.esp's member lines have these info ids; anyone else gets
-- the "join first" line and nothing opens.

local MEMBER_INFO = { ojb_gw_fg_member = 'fighters guild', ojb_gw_mg_member = 'mages guild' }

local function guildOf(e)
    if e.infoId then return MEMBER_INFO[e.infoId:lower()] end
    -- Without an info id, read the same conditions the member lines use.
    if not e.actor or not types.NPC.objectIsInstance(e.actor) then return nil end
    for _, f in pairs(types.NPC.getFactions(e.actor)) do
        local id = f:lower()
        if C.GUILDS[id] and types.NPC.getFactionRank(self, id) > 0 and not types.NPC.isExpelled(self, id) then
            return id
        end
    end
    return nil
end

local function onDialogueResponse(e)
    if e.type ~= 'topic' or not e.recordId or e.recordId:lower() ~= 'guild work' then return end
    local faction = guildOf(e)
    if faction then
        core.sendGlobalEvent('OJB_Guild', { player = self, faction = faction })
    end
end

---------------------------------------------------------------------------------------------------
-- Contracts held: global.lua checks recovery items and expiry when asked. One event every
-- ITEM_POLL_SECONDS of simulation time, only while a contract is held.

local held = 0

time.runRepeatedly(function()
    if held > 0 then core.sendGlobalEvent('OJB_Check', { player = self }) end
end, C.ITEM_POLL_SECONDS * time.second, { initialDelay = C.ITEM_POLL_SECONDS * time.second })

---------------------------------------------------------------------------------------------------
-- Debug commands, from the console after `luap`: I.OddJobs.list(), I.OddJobs.visit(3), ...

local function debug(name, arg)
    core.sendGlobalEvent('OJB_Debug', { player = self, name = name, arg = arg })
end

-- onFrame time since the last footprint line. Only frames that did work are counted.
local frameWatch = { n = 0, total = 0, max = 0, at = -1e9 }

return {
    interfaceName = 'OddJobs',
    interface = {
        version = 1,
        list = function() debug('list') end,
        visit = function(key) debug('visit', key) end,
        next = function() debug('next') end,
        -- tour(seconds, from, to): every board (or numbers from..to), `seconds` in front of each.
        tour = function(seconds, from, to)
            core.sendGlobalEvent('OJB_Debug', { player = self, name = 'tour', pause = seconds,
                arg = { from = from, to = to } })
        end,
        recheck = function(key) debug('recheck', key) end,
        refresh = function() debug('refresh') end,
        contracts = function() debug('contracts') end,
        removeall = function() debug('removeall') end,
        log = function() core.sendGlobalEvent('OJB_Check', { player = self, log = true }) end,
    },
    engineHandlers = {
        onInit = sendSettings,
        onLoad = function()
            sendSettings()
            core.sendGlobalEvent('OJB_Check', { player = self })
        end,
        onFrame = function()
            local busy = job ~= nil or loose.active() or spots.active()
            if not busy and not profileOn then return end
            local t0 = core.getRealTime()
            if job then
                stepSpotCheck()
            elseif loose.active() then
                loose.step()
            elseif spots.active() then
                spots.step()
            end
            if busy then
                local ms = (core.getRealTime() - t0) * 1000
                frameWatch.n = frameWatch.n + 1
                frameWatch.total = frameWatch.total + ms
                if ms > frameWatch.max then frameWatch.max = ms end
            end
            if profileOn and t0 - frameWatch.at >= C.PROFILE_SECONDS then
                frameWatch.at = t0
                if frameWatch.n > 0 then
                    print(string.format('%splayer handlers: onFrame %dx avg %.2f max %.2f ms',
                        C.LOG_TAG, frameWatch.n, frameWatch.total / frameWatch.n, frameWatch.max))
                end
                frameWatch.n, frameWatch.total, frameWatch.max = 0, 0, 0
            end
        end,
    },
    eventHandlers = {
        OJB_Message = function(msg) window.slip(msg) end,
        -- Sounds for what global.lua did (paid, goods taken): vanilla sound record ids.
        OJB_Sound = function(ids)
            for _, id in ipairs(ids) do ambient.playSound(id) end
        end,
        OJB_CheckSpots = startSpotCheck,
        OJB_CheckStray = startStrayCheck,
        OJB_FindLoose = loose.start,
        OJB_FindSpawnSpots = spots.start,
        OJB_Choice = function(data)
            answerChoice(nil)
            local last = data.options[#data.options]
            current.key, current.guild = nil, nil
            current.choice = { id = data.id, default = last and last.id }
            open('choice', data)
        end,
        OJB_ShowBoard = function(data)
            current.key, current.guild = data.key, data.guild
            held = data.held or held
            open('board', data)
        end,
        OJB_ShowLog = function(data)
            current.key, current.guild = nil, nil
            held = data.held or held
            open('log', data)
        end,
        OJB_Contracts = function(e) held = e.held or 0 end,
        OJB_Train = function(e)
            I.SkillProgression.skillLevelUp(e.skill, I.SkillProgression.SKILL_INCREASE_SOURCES.Trainer)
        end,
        OJB_DebugLines = function(lines)
            for _, line in ipairs(lines) do ui.printToConsole(line, ui.CONSOLE_COLOR.Info) end
        end,
        UiModeChanged = function(e)
            if window.isOpen() and e.newMode ~= 'Interface' then
                window.close()
                answerChoice(nil)
            end
            -- The theft ledger counts what an owned container gave up once its window closes.
            if e.oldMode == 'Container' and e.newMode ~= 'Container' then
                core.sendGlobalEvent('OJB_ContainerClosed', { player = self })
            end
        end,
        DialogueResponse = onDialogueResponse,
    },
}
