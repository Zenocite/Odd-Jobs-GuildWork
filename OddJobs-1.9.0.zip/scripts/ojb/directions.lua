---@omw-context runtime
-- Pure: how to get from a board's town to a job, in words. Uses the named places and travel
-- services from data/landmarks.lua (built from the base masters); there's no road or river data
-- in the game files, so directions lean on named places and transport instead.

local T = require('scripts.ojb.text')

local M = {}

local CELL = 8192
local POINTS = { 'north', 'northeast', 'east', 'southeast', 'south', 'southwest', 'west', 'northwest' }

function M.bearing(ax, ay, bx, by)
    local a = math.atan2(bx - ax, by - ay)
    local i = math.floor((a / (2 * math.pi)) * 8 + 0.5) % 8
    return POINTS[i + 1]
end

local function cells(ax, ay, bx, by)
    local dx, dy = bx - ax, by - ay
    return math.sqrt(dx * dx + dy * dy) / CELL
end

local function lower(s) return (s or ''):lower() end

local function cap(s)
    return (s:gsub('^%l', string.upper))
end

-- Two names a reader could mix up: one holds the other ("Old Ebonheart" and "Ebonheart").
local function overlaps(a, b)
    a, b = lower(a), lower(b)
    return a:find(b, 1, true) ~= nil or b:find(a, 1, true) ~= nil
end
M.overlaps = overlaps

-- A landmark is only worth naming if it isn't the town or the place itself, and can't be
-- mistaken for either.
local function usable(l, townName, placeName, have)
    if have and not have(l.req) then return false end
    local n = lower(l.n):match('^([^,]+)') or lower(l.n)
    if overlaps(n, townName) then return false end
    if overlaps(n, placeName:match('^([^,]+)') or placeName) then return false end
    return true
end

-- Nearest named place to (x, y) within maxCells.
function M.nearestLandmark(landmarks, x, y, maxCells, townName, placeName, have)
    local best, bd
    for _, l in ipairs(landmarks) do
        if usable(l, townName, placeName, have) then
            local d = cells(l.x, l.y, x, y)
            if d <= maxCells and (not bd or d < bd) then best, bd = l, d end
        end
    end
    return best, bd
end

-- A named place roughly on the way: projected between a quarter and four fifths of the trip, and
-- within corridor cells of the straight line. The one nearest halfway wins.
function M.onTheWay(landmarks, ax, ay, bx, by, corridor, townName, placeName, have, skip)
    local dx, dy = bx - ax, by - ay
    local len2 = dx * dx + dy * dy
    if len2 < (2 * CELL) ^ 2 then return nil end
    local len = math.sqrt(len2)
    local best, bs
    for _, l in ipairs(landmarks) do
        if l ~= skip and usable(l, townName, placeName, have) then
            local t = ((l.x - ax) * dx + (l.y - ay) * dy) / len2
            local off = math.abs((l.x - ax) * dy - (l.y - ay) * dx) / len / CELL
            if t >= 0.25 and t <= 0.8 and off <= corridor then
                local score = math.abs(t - 0.5)
                if not bs or score < bs then best, bs = l, score end
            end
        end
    end
    return best
end

-- A landmark in a sentence: "the Monastery of St. Seryn", but "Mount Kand" and "Ald Sotha".
local function landmarkText(name)
    local t = T.placeName(name).text
    if t:find('^%u%l+ of ') then return 'the ' .. t end
    return t
end

local WAY_ORDER = { ['silt strider'] = 1, boat = 2, ['guild guide'] = 3 }

local function sharedWay(a, b)
    local best
    for _, w in ipairs(a.ways or {}) do
        for _, w2 in ipairs(b.ways or {}) do
            if w == w2 and (not best or WAY_ORDER[w] < WAY_ORDER[best]) then best = w end
        end
    end
    return best
end

-- Stations in the board's town: the town itself and its docks ("Town, Docks").
local function townStations(travel, townName)
    local out = {}
    local pre = lower(townName)
    for name, st in pairs(travel) do
        local n = lower(name)
        if n == pre or n:sub(1, #pre + 1) == pre .. ',' then out[#out + 1] = { name = name, st = st } end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

-- The best transport hop from the town towards (x, y), or nil when walking is as good.
function M.travelTip(travel, townName, tx, ty, x, y, have)
    local direct = cells(tx, ty, x, y)
    if direct < 4 then return nil end
    local best
    for _, from in ipairs(townStations(travel, townName)) do
        for _, destName in ipairs(from.st.to or {}) do
            local dest = travel[destName]
            if dest and (not have or have(dest.req)) then
                local way = sharedWay(from.st, dest)
                local d = cells(dest.x, dest.y, x, y)
                if way and d < direct * 0.6 and (not best or d < best.d) then
                    best = { to = destName, way = way, d = d, x = dest.x, y = dest.y }
                end
            end
        end
    end
    return best
end

-- p: { town = {name, x, y}, place = {n, x, y}, region, landmarks, travel, have, door }.
-- door: the place's name as the player will see it outside (story.area), else read from the cell.
function M.describe(p)
    local town, place = p.town, p.place
    local lms = p.landmarks or {}
    local placeText = p.door and { text = p.door, plural = T.isPlural(p.door) } or T.placeName(place.n)
    local dist = cells(town.x, town.y, place.x, place.y)
    local dir = M.bearing(town.x, town.y, place.x, place.y)
    local near, nd = M.nearestLandmark(lms, place.x, place.y, 2.5, town.name, place.n, p.have)
    local via = M.onTheWay(lms, town.x, town.y, place.x, place.y, 1.2, town.name, place.n, p.have, near)

    local parts = {}
    if via then
        parts[#parts + 1] = string.format('Head %s out of %s, past %s.', dir, town.name, landmarkText(via.n))
    end
    local s = string.format('%s %s %s %s of %s', cap(placeText.text), placeText.plural and 'are' or 'is',
        T.howFar(dist), dir, town.name)
    if near then
        if nd < 0.5 then
            s = s .. string.format(', by %s', landmarkText(near.n))
        else
            s = s .. string.format(', %s of %s', M.bearing(near.x, near.y, place.x, place.y),
                landmarkText(near.n))
        end
    end
    if p.region and p.region ~= '' then
        s = s .. ', in the ' .. p.region
    end
    parts[#parts + 1] = s .. '.'
    local tip = p.travel and M.travelTip(p.travel, town.name, town.x, town.y, place.x, place.y, p.have)
    if tip then
        local to = T.placeName(tip.to).text
        if overlaps(tip.to:match('^([^,]+)') or tip.to, town.name) then
            to = string.format('%s, which is a different town from %s', to, town.name)
            parts[#parts + 1] = string.format('Quicker: take the %s to %s. From there it is %s %s.', tip.way,
                to, T.howFar(tip.d), M.bearing(tip.x, tip.y, place.x, place.y))
        else
            parts[#parts + 1] = string.format('Quicker: take the %s to %s; from there it is %s %s.', tip.way,
                to, T.howFar(tip.d), M.bearing(tip.x, tip.y, place.x, place.y))
        end
    end
    return table.concat(parts, ' ')
end

return M
