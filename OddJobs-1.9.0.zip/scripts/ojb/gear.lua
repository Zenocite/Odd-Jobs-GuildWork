---@omw-context runtime
-- Worn gear for a contract group. Ids and base values were read from this load order
-- (tools/build_strength.py's walk). Nothing here is invented.
-- A follower wears two or three pieces. The better piece stays on the leader.
-- Glass, ebony and daedric stay off easy and normal. On elite the leader and the second
-- may each carry one such piece, and it is never a cuirass.
-- The group's base value stays under C.THREAT.GEAR_VALUE. What a merchant would pay for it,
-- plus gold at the bottom of the band, stays inside the tier's value cap. That is the
-- "pool too rich" line: a glass cuirass (28000) fails it, a modest glass sword does not.

local C = require('scripts.ojb.config')
local ST = require('scripts.ojb.data.strength')

local M = {}

-- Gold at the bottom of the live band. Not the comparison column in the design doc.
local GOLD_BOTTOM = { easy = 50, normal = 130, dangerous = 350, elite = 700 }

-- Economy Plus resale, middling price (about two thirds) then the curve that is full
-- through 2000, harsher by 8000, and a fifth by 20000.
local function curve(v)
    if v <= 2000 then return 1 end
    if v <= 8000 then return 1 + (0.6 - 1) * ((v - 2000) / 6000) end
    if v <= 20000 then return 0.6 + (0.2 - 0.6) * ((v - 8000) / 12000) end
    return 0.2
end

function M.sell(v)
    return (v or 0) * (2 / 3) * curve(v or 0)
end

function M.sellCap(tier)
    local top = C.TIER.VALUE[tier] and C.TIER.VALUE[tier][2] or 0
    return top - (GOLD_BOTTOM[tier] or 0)
end

function M.tooRich(tier, sell)
    return (GOLD_BOTTOM[tier] or 0) + (sell or 0) > (C.TIER.VALUE[tier] and C.TIER.VALUE[tier][2] or 0) + 0.01
end

local function P(id, v, k, slot, n)
    local known = ST.item[id:lower()]
    if known and known.v then v = known.v end
    local wc, ar
    if k == 'w' then
        local s = id:lower()
        if s:find('glass', 1, true) or s:find('ebony', 1, true) or s:find('daedric', 1, true) then wc = 22
        elseif s:find('orcish', 1, true) or s:find('dwarven', 1, true) or s:find('dwemer', 1, true) then wc = 12
        elseif s:find('silver', 1, true) or s:find('bonemold', 1, true) then wc = 8
        elseif s:find('steel', 1, true) or s:find('imperial', 1, true) then wc = 6
        else wc = 4 end
    else ar = n end
    return { id = id, v = v, k = k, slot = slot, wc = wc, ar = ar }
end

-- slot: weapon, bow, helm, cuirass, pauldron, greaves, boots, bracer.
-- Values are the load order's base value. Armour's last number is the rating.
local EASY_W = {
    P('iron spear', 20, 'w', 'weapon'), P('iron longsword', 40, 'w', 'weapon'),
    P('iron war axe', 30, 'w', 'weapon'), P('iron mace', 24, 'w', 'weapon'),
    P('chitin spear', 13, 'w', 'weapon'), P('chitin shortsword', 13, 'w', 'weapon'),
    P('chitin dagger', 6, 'w', 'weapon'), P('short bow', 60, 'w', 'bow'),
}
local STEEL_W = {
    P('steel spear', 40, 'w', 'weapon'), P('steel longsword', 80, 'w', 'weapon'),
    P('steel dagger', 20, 'w', 'weapon'), P('steel war axe', 60, 'w', 'weapon'),
    P('steel mace', 48, 'w', 'weapon'), P('long bow', 50, 'w', 'bow'),
}
local FINE_W = {
    P('silver longsword', 160, 'w', 'weapon'), P('silver dagger', 40, 'w', 'weapon'),
    P('silver war axe', 120, 'w', 'weapon'), P('dwarven shortsword', 300, 'w', 'weapon'),
    P('dwarven mace', 360, 'w', 'weapon'),
}
local GLASS_W = P('AB_w_AshlGlassLongsword', 400, 'w', 'weapon')
local STAFF = {
    P('wooden staff', 8, 'w', 'weapon'), P('silver staff', 56, 'w', 'weapon'),
}
local HIDE = {
    P('fur_boots', 10, 'a', 'boots', 5), P('fur_helm', 15, 'a', 'helm', 5),
    P('fur_cuirass', 35, 'a', 'cuirass', 5), P('fur_bearskin_cuirass', 35, 'a', 'cuirass', 5),
}
local NETCH = {
    P('netch_leather_boots', 10, 'a', 'boots', 5), P('netch_leather_helm', 15, 'a', 'helm', 5),
    P('netch_leather_greaves', 22, 'a', 'greaves', 5), P('netch_leather_cuirass', 35, 'a', 'cuirass', 5),
}
local CHITIN = {
    P('chitin cuirass', 45, 'a', 'cuirass', 10),
}
local STEEL_A = {
    P('steel_boots', 40, 'a', 'boots', 15), P('steel_helm', 60, 'a', 'helm', 15),
    P('steel_greaves', 88, 'a', 'greaves', 15), P('steel_cuirass', 150, 'a', 'cuirass', 15),
}
local BONE = {
    P('bonemold_bracer_left', 50, 'a', 'bracer', 15), P('bonemold_boots', 100, 'a', 'boots', 15),
    P('bonemold_pauldron_l', 120, 'a', 'pauldron', 15), P('bonemold_helm', 150, 'a', 'helm', 18),
    P('bonemold_cuirass', 350, 'a', 'cuirass', 16),
}
local STUDDED = { P('imperial_studded_cuirass', 65, 'a', 'cuirass', 10) }
local NORD_A = {
    P('nordic_iron_helm', 50, 'a', 'helm', 16), P('nordic_iron_cuirass', 130, 'a', 'cuirass', 16),
}
local DWEMER_A = {
    P('dwemer_pauldron_left', 360, 'a', 'pauldron', 20), P('dwemer_helm', 450, 'a', 'helm', 20),
}

local function list(t, ...)
    local out = {}
    for i = 1, select('#', ...) do
        for _, p in ipairs(select(i, ...)) do out[#out + 1] = p end
    end
    table.sort(out, function(a, b) return a.v < b.v end)
    return out
end

-- culture, tier -> weapons, armour. Cheap pieces are in every tier so a full crew still fits.
local function pool(culture, tier)
    local mage = culture == 'mage'
    local w, a
    if mage then
        w = tier == 'easy' and { STAFF[1], EASY_W[7] } or { STAFF[1], STAFF[2], EASY_W[7] }
        a = {}
        return w, a
    end
    if tier == 'easy' then
        w = EASY_W
        if culture == 'nord' then w = list(nil, EASY_W, { P('nordic battle axe', 60, 'w', 'weapon') }) end
        a = list(nil, HIDE, NETCH, CHITIN)
        if culture == 'imperial' then a = list(nil, a, STUDDED) end
        return w, a
    end
    if tier == 'normal' then
        w = list(nil, EASY_W, STEEL_W)
        a = list(nil, NETCH, CHITIN, STEEL_A, { BONE[1] })
        if culture == 'nord' then
            w = list(nil, w, { P('nordic battle axe', 60, 'w', 'weapon') })
            a = list(nil, HIDE, NORD_A, { BONE[1] })
        elseif culture == 'imperial' then a = list(nil, a, STUDDED)
        elseif culture == 'pirate' then a = list(nil, HIDE, NETCH, STEEL_A)
        elseif culture == 'dunmer' or culture == 'grave' then a = list(nil, NETCH, CHITIN, { BONE[1], BONE[2] })
        end
        return w, a
    end
    w = list(nil, EASY_W, STEEL_W, FINE_W)
    a = list(nil, NETCH, CHITIN, STEEL_A, BONE)
    if culture == 'nord' then
        w = list(nil, w, { P('nordic battle axe', 60, 'w', 'weapon') })
        a = list(nil, HIDE, NORD_A, STEEL_A)
    elseif culture == 'imperial' then a = list(nil, STEEL_A, STUDDED, { BONE[1] })
    elseif culture == 'pirate' then a = list(nil, HIDE, NETCH, STEEL_A)
    elseif culture == 'dunmer' or culture == 'grave' then a = list(nil, NETCH, CHITIN, BONE)
    end
    if tier == 'elite' then a = list(nil, a, DWEMER_A) end
    return w, a
end

function M.culture(group, race)
    if group == 'necromancer' or group == 'warlock' or group == 'cultist' then return 'mage' end
    if group == 'pirate' or group == 'smuggler' then return 'pirate' end
    if group == 'graverobber' then return 'grave' end
    race = (race or ''):lower()
    if race == 'nord' then return 'nord' end
    if race == 'imperial' then return 'imperial' end
    if race == 'dark elf' then return 'dunmer' end
    return 'plain'
end

local function rich(id)
    local s = id:lower()
    return s:find('glass', 1, true) or s:find('ebony', 1, true) or s:find('daedric', 1, true)
end

local function raceOf(id)
    local st = id and ST.npc[id:lower()]
    return st and st.race or ''
end

local function people(b)
    local out = {}
    if b.champion then out[#out + 1] = { who = b.champion, id = b.champion.template, rank = 'leader' } end
    if b.lieutenant then out[#out + 1] = { who = b.lieutenant, id = b.lieutenant.template, rank = 'second' } end
    for _, m in ipairs(b.members or {}) do
        if not m.creature then out[#out + 1] = { who = m, id = m.id, rank = 'follower', role = m.role } end
    end
    return out
end

-- Puts the worn pieces on each person. Keeps spells already rolled for a role.
function M.dress(b, rnd)
    local tier = b.tier or 'normal'
    local folks = people(b)
    local vLeft = C.THREAT.GEAR_VALUE[tier] or 0
    local sLeft = M.sellCap(tier)
    local used = {}
    -- The cheapest two pieces a later person still has to be able to wear.
    local function reserveFor(rest)
        return rest * 16, rest * (M.sell(6) + M.sell(10))
    end
    for index, person in ipairs(folks) do
        local reserveV, reserveS = reserveFor(#folks - index)
        local function fits(p, extra)
            local v = p.v * (extra or 1)
            return v + reserveV <= vLeft + 0.01 and M.sell(v) + reserveS <= sLeft + 0.01
        end
        local function spend(p, extra)
            local v = p.v * (extra or 1)
            vLeft = vLeft - v
            sLeft = sLeft - M.sell(v)
        end
        local who = person.who
        local culture = M.culture(b.group, who.race or raceOf(person.id))
        local role = who.role or person.role
        local weapons, armour = pool(culture, tier)
        local fallback = weapons
        if role == 'healer' or role == 'summoner' or culture == 'mage' then weapons = STAFF end
        if role == 'archer' then
            weapons = { P('short bow', 60, 'w', 'bow'), P('long bow', 50, 'w', 'bow') }
        end
        -- Only the leader spends first on a better weapon. The second dresses with the crew,
        -- or a dwarven mace here leaves the last followers with nothing to wear.
        local best = person.rank == 'leader'
        local chosen, slots = {}, {}
        local function setKey(extra)
            local ids = {}
            for _, c in ipairs(chosen) do ids[#ids + 1] = c.n and (c.id .. '#' .. c.n) or c.id end
            if extra then ids[#ids + 1] = extra.id end
            table.sort(ids)
            return table.concat(ids, '|')
        end
        local function consider(p)
            if not p or slots[p.slot] or not fits(p) then return false end
            if p ~= GLASS_W and rich(p.id) then return false end
            if p.slot == 'cuirass' and rich(p.id) then return false end
            if p.slot == 'cuirass' and (tier == 'dangerous' or tier == 'elite') and person.rank == 'follower'
                and p.v >= 150 then return false end
            if used[setKey(p)] then return false end
            chosen[#chosen + 1] = p
            slots[p.slot] = true
            spend(p)
            return true
        end
        local function from(list, wantBest)
            local start, step, stop = 1, 1, #list
            if wantBest then start, step, stop = #list, -1, 1 end
            for i = start, stop, step do if consider(list[i]) then return true end end
            return false
        end
        if best then
            if person.rank == 'leader' and tier == 'elite' and fits(GLASS_W) then consider(GLASS_W) end
            if not slots.weapon and not slots.bow then from(weapons, true) end
            local armourN = culture == 'mage' and 0 or 2
            local guard = 0
            while armourN > 0 and guard < 6 do
                guard = guard + 1
                if not from(armour, false) then break end
                armourN = armourN - 1
            end
        else
            -- Armour first, so a bow or a staff cannot spend the piece the follower still needs.
            if culture ~= 'mage' then from(armour, false) end
            if role == 'archer' then from(weapons, false) end
            if not slots.weapon and not slots.bow then from(fallback, false) end
            -- The reserve is for people still to come. It must not leave this one with a single piece
            -- when the leftover would buy a cheap weapon.
            if culture ~= 'mage' and not slots.weapon and not slots.bow then
                reserveV, reserveS = 0, 0
                from(fallback, false)
            end
            if culture ~= 'mage' and #chosen < 2 then from(HIDE, false) end
        end
        if slots.bow and fits(P('iron arrow', 1, 'w', 'ammo'), 20) then
            spend(P('iron arrow', 1, 'w', 'ammo'), 20)
            chosen[#chosen + 1] = { id = 'iron arrow', v = 1, n = 20, k = 'w', slot = 'ammo' }
        end
        local ids = {}
        for _, p in ipairs(chosen) do ids[#ids + 1] = p.n and (p.id .. '#' .. p.n) or p.id end
        table.sort(ids)
        used[table.concat(ids, '|')] = true
        local spells = who.kit and who.kit.spells or {}
        local items, equip, wc, ar = {}, {}, 4, 0
        for _, p in ipairs(chosen) do
            items[#items + 1] = p.n and { p.id, p.n } or p.id
            if p.slot ~= 'ammo' then equip[#equip + 1] = p.id end
            if p.wc and p.wc > wc then wc = p.wc end
            ar = ar + (p.ar or 0)
        end
        who.kit = { items = items, equip = equip, spells = spells }
        who.gear = { wc = wc, ar = ar }
    end
end

function M.worn(b)
    local value, sell, pieces = 0, 0, {}
    for _, person in ipairs(people(b)) do
        local kit = person.who.kit
        for _, it in ipairs(kit and kit.items or {}) do
            local id, n = it, 1
            if type(it) == 'table' then id, n = it[1], it[2] end
            local st = ST.item[id:lower()]
            local v = st and st.v or 0
            if v == 0 then
                if id == 'AB_w_AshlGlassLongsword' then v = 400
                elseif id == 'iron arrow' then v = 1 end
            end
            value = value + v * n
            sell = sell + M.sell(v * n)
            if not tostring(id):lower():find('arrow', 1, true) then
                pieces[#pieces + 1] = { id = id, rank = person.rank, n = n }
            end
        end
    end
    return value, sell, pieces
end

return M
