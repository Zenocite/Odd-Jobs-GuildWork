---@omw-context global
-- Pure: what a notice says. Posters are ordinary people: they tell what they heard or saw, guess
-- at the numbers, and give clues that match what is really inside. Every notice is written whole
-- from the place's kind and its foes together, in two versions: rumour (the default) and plain
-- (exact numbers), in the poster's own voice. A pairing with no story that fits is not posted.
-- Also the flavour notices (no job). No engine calls.

local C = require('scripts.ojb.config')
local T = require('scripts.ojb.text')
local F = require('scripts.ojb.foes')

local M = {}

---------------------------------------------------------------------------------------------------
-- Grammar

local function cap(s)
    return (s:gsub('^%l', string.upper))
end

local SOUNDS_CONSONANT = { uni = true, use = true, usu = true, ure = true, one = true, eu = true }
local SOUNDS_VOWEL = { hour = true, honest = true, honour = true, heir = true }

-- 'a' or 'an' for the word that follows.
function M.article(word)
    local w = word:lower()
    for k in pairs(SOUNDS_VOWEL) do
        if w:sub(1, #k) == k then return 'an' end
    end
    for k in pairs(SOUNDS_CONSONANT) do
        if w:sub(1, #k) == k then return 'a' end
    end
    return w:match('^[aeiou]') and 'an' or 'a'
end

function M.a(word)
    return M.article(word) .. ' ' .. word
end

local NUMBERS = { 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven',
    'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty',
    'twenty-one', 'twenty-two', 'twenty-three', 'twenty-four', 'twenty-five' }
function M.number(n)
    n = math.floor(n + 0.5)
    return NUMBERS[n] or tostring(n)
end

-- A poster's guess at how many, never above the real number: 1 'one', 2 'a couple', 13 or more
-- 'a dozen or more', else 'low or low+1' with low between half the number (rounded up) and one
-- under it. rnd(k) -> 1..k; without it the guess is the lowest.
function M.guess(n, rnd)
    n = math.floor(n + 0.5)
    if n <= 1 then return 'one' end
    if n == 2 then return 'a couple' end
    if n >= 13 then return 'a dozen or more' end
    local lo, hi = math.ceil(n / 2), n - 1
    local low = rnd and (lo + rnd(hi - lo + 1) - 1) or lo
    return NUMBERS[low] .. ' or ' .. NUMBERS[low + 1]
end

-- A guess before a noun: 'a couple of bandits', 'four or five bandits'.
function M.guessOf(g, noun)
    if g == 'a couple' then return 'a couple of ' .. noun end
    return g .. ' ' .. noun
end

local function pronouns(female)
    if female == nil then
        return { he = 'they', him = 'them', his = 'their', He = 'They', His = 'Their', s = '', is = 'are', has = 'have', es = '' }
    end
    if female then
        return { he = 'she', him = 'her', his = 'her', He = 'She', His = 'Her', s = 's', is = 'is', has = 'has', es = 'es' }
    end
    return { he = 'he', him = 'him', his = 'his', He = 'He', His = 'His', s = 's', is = 'is', has = 'has', es = 'es' }
end
M.pronouns = pronouns

-- Fills {name} slots from a; every slot must be known, so nothing half-written reaches a notice.
local function fill(s, a)
    return (s:gsub('{(%w+)}', function(k)
        local v = a[k]
        if v == nil then error('story slot {' .. k .. '} has no value in: ' .. s) end
        return tostring(v)
    end))
end

---------------------------------------------------------------------------------------------------
-- Places, as people say them

local function regionShort(region)
    return region and (region:gsub('%s+[Rr]egion$', '')) or nil
end

-- Cells are "Place, Sublevel" ("Bal Fell, Inner Shrine") except a few "Town, Place" ones: town
-- sewers, a town's mine, and Solstheim's caves. Returns the place part and the sublevel parts.
local TOWN_STYLE_LAST = { mine = true, mines = true, eggmine = true, sewers = true, dungeon = true }
-- A place inside a town with a board ("Old Ebonheart, West Curtain Towers") is named by its own part.
local TOWN_NAMES = {}
for _, t in ipairs(require('scripts.ojb.data.towns')) do TOWN_NAMES[t.name] = true end
local function split(place)
    local parts = {}
    for s in place.n:gmatch('[^,:]+') do parts[#parts + 1] = s:match('^%s*(.-)%s*$') end
    if #parts < 2 then return parts[1] or place.n, {}, false end
    local last = (parts[2]:match('(%a+)%s*$') or ''):lower()
    local townStyle = place.k == 'sewer' or parts[1] == 'Solstheim' or TOWN_NAMES[parts[1]]
        or (TOWN_STYLE_LAST[last] and not parts[1]:lower():find('mine$'))
    local function from(i)
        local out = {}
        for j = i, #parts do out[#out + 1] = parts[j] end
        return out
    end
    if not townStyle then return parts[1], from(2), false end
    local name
    if parts[1] == 'Solstheim' then
        name = parts[2]
    else
        name = T.placeName(parts[1] .. ', ' .. parts[2]:gsub('[Ee]ggmine', 'Egg Mine')).text
    end
    return name, from(3), true
end

-- The place's name for a title and a sentence, never a raw sublevel. Wrecks are named by their
-- coast; named ships by the ship. Returns { name, at, door } where at is the preposition ('in',
-- 'at', 'on') and door is the name the player will see on the way in.
function M.area(place, region)
    local top, _, townStyle = split(place)
    if townStyle then return { name = top, at = 'in', door = top } end
    if place.k == 'wreck' then
        if top:find('[Ss]hipwreck') then
            local coast = regionShort(region)
            return { name = coast and ('the ' .. coast .. ' wreck') or 'the wreck', at = 'on', door = top }
        end
        local ship = top:gsub('^TEM%s+', '')
        return { name = 'the wreck of the ' .. ship, at = 'on', door = top }
    end
    local low = top:lower()
    if place.k == 'daedric' or place.k == 'dwemer' or place.k == 'stronghold' then
        return { name = top, at = 'at', door = top }
    end
    if low:find('mine$') or low:find('grotto$') or low:find('cave') or low:find('cavern') then
        return { name = top, at = 'in', door = top }
    end
    return { name = top, at = place.tomb and 'in' or 'at', door = top }
end

-- One sublevel as it reads after "make for": "the inner shrine", "Marowak's Spine", "the Magcargo Bays".
local function subPhrase(s)
    if T.allCommon(s) then return 'the ' .. s:lower() end
    if s:find("'s ") then return s end
    return 'the ' .. s
end

-- Where inside, for the directions: "the bottom level of the keep", or nil.
function M.inside(place)
    local _, subs = split(place)
    if #subs == 0 then return nil end
    local out = {}
    for i = #subs, 1, -1 do out[#out + 1] = subPhrase(subs[i]) end
    return table.concat(out, ' of ')
end

---------------------------------------------------------------------------------------------------
-- Foes: what a poster would notice, by family first, then group.
-- one/many: nouns. carries: can hold a recovered item. water: lives in water. cls: which ask and
-- title lines fit (people, undead, daedra, dwemer, beast, fish, kwama, ash).

local GENERIC_COUNT = {
    'I counted {g}, maybe more.',
    'At least {g}, by the look of it.',
    'Nobody has stayed long enough to count, but {g} at the least.',
    '{G} that anyone has seen, and likely more inside.',
    'Word is there are {g} of them.',
    'Someone who went close saw {g}.',
}
-- Big groups (eight or more): the guess and a warning that it is short.
local BIG_COUNT = {
    'I counted {g} before I lost count; expect more.',
    '{G} at the least, and more than I could count in the dark.',
    'More than I could count. {G} at the very least.',
    'I stopped counting at {g}, and they kept coming.',
    'A good many of them: {g} that I saw, and more behind.',
}

local FOES = {
    bandit = { one = 'bandit', many = 'bandits', cls = 'people', carries = true, deed = 'raiding',
        chief = 'bandit chief',
        clue = { 'You can see the campfire smoke from the road at dusk.',
            'Travellers on that road have been stripped of everything but their boots.',
            'A caravaner came through with nothing left but the clothes he wore.',
            "Armed men come and go from there, and they don't look like hunters.",
            'Stolen goods turn up at the market with the owners still looking for them.',
            'A pilgrim was robbed on the road and left tied to a tree.',
            'The guar traders have started paying for guards on that road.',
            'Someone has been watching the road from the rocks above it.' },
        count = { 'I saw {g} of them around a fire outside, maybe more.', '{G} of them at least, armed and not shy about it.' } },
    smuggler = { one = 'smuggler', many = 'smugglers', cls = 'people', carries = true, deed = 'smuggling',
        chief = 'smuggler boss',
        clue = { 'Boats put in there at odd hours with no lights showing.',
            'Crates go up from the shore at night, and nobody pays the Census for them.',
            'A fisherman saw lanterns on the water there long after dark.' },
        count = { 'I saw {g} unloading one night, maybe more.' } },
    necromancer = { one = 'necromancer', many = 'necromancers', cls = 'people', carries = true, deed = 'grave-robbing',
        chief = 'necromancer',
        clue = { 'Men in robes carry long bundles in there at night.',
            'Graves near the road have been dug up, and the bodies are gone.',
            'Someone has been digging in the graveyard at night.' },
        count = { 'I saw {g} in robes go in.' } },
    pirate = { one = 'pirate', many = 'pirates', cls = 'people', carries = true, deed = 'piracy',
        chief = 'pirate captain',
        clue = { 'A fishing boat came back with its catch gone and its crew beaten.',
            'A ship with no flag has been anchoring off that coast.',
            'Sailors in the tavern talk of a crew that comes alongside small boats and takes everything.',
            'Cargo from a lost ship turned up for sale before anyone knew it had gone down.',
            'The fishermen have stopped going out past the point.' },
        count = { 'A fisherman counted {g} of them on the beach, maybe more.', 'Sailors say {g}, all armed.' } },
    graverobber = { one = 'grave robber', many = 'grave robbers', cls = 'people', carries = true, deed = 'grave-robbing',
        chief = 'leader of the grave robbers',
        clue = { 'Someone has been carrying sacks out of there after dark.',
            'The door seal was broken, and there are spade marks in the dirt outside.',
            'Grave goods have turned up for sale in town, and the families know them.',
            'A herder saw lantern light at the door well after midnight.' },
        count = { 'I saw {g} of them with spades and sacks, maybe more.' } },
    -- The dead a contract's necromancers raised and brought with them; never a tomb's own.
    raised = { one = 'raised corpse', many = 'raised corpses', cls = 'undead',
        clue = { 'Folk who went close heard bones moving, and a voice giving orders.',
            'The dead in there walk in step, as if someone is leading them.',
            'Fresh graves near the road are empty, and whatever was in them walks in there now.' },
        count = { '{G} of the dead they raised, at least.' } },
    warlock = { one = 'warlock', many = 'warlocks', cls = 'people', carries = true, deed = 'dark work',
        chief = 'warlock',
        clue = { 'There are lights there at night, and the rocks by the entrance are burnt black.',
            'Herders say the rocks round the entrance are scorched.',
            'A pedlar went close and they threw fire at him.',
            'Something flashed at the entrance last night, bright as lightning.',
            'A herder lost two guar near there to something that burned them.',
            'They buy odd things in town, salts and bones, and pay too much for them.' },
        count = { 'I saw {g} of them in robes, maybe more.' } },
    vampire = { one = 'vampire', many = 'vampires', cls = 'people', carries = true, deed = 'feeding',
        chief = 'vampire',
        clue = { 'Two travellers were attacked on that road after dark. Both had bites on the neck.',
            'Guar near there have been found dead with no blood left in them.',
            'Nobody from town will go near the place after dark.' },
        count = { 'Folk say {g}.' } },
    cultist = { one = 'cultist', many = 'cultists', cls = 'people', carries = true, deed = 'rites',
        chief = 'cult leader',
        clue = { 'There is chanting from there at night, and pilgrims have been driven off.',
            'They have taken over the shrine and turn pilgrims away.',
            'Men in robes stand guard at the shrine, and they carry blades.',
            'Pilgrims who went to pray there came back with bruises and no offerings.',
            'Folk hear drums from there after dark.' },
        count = { 'I saw {g} in robes at the shrine, maybe more.' } },

    undead = { one = 'restless dead', many = 'restless dead', cls = 'undead',
        clue = { 'A herder saw them at the entrance after dark.',
            'A herder heard bones rattling inside.',
            'Skeletons have been seen at the entrance at night.',
            'Folk who went in came out fast and will not say much.',
            'Something cold comes out of the entrance at night, and the guar will not graze near it.',
            'A boy dared his friends to go in. He came back white and would not talk.',
            'The pilgrims who used to camp near there have stopped.' },
        count = { '{G} at least.' } },
    skeletons = { one = 'skeleton', many = 'skeletons', cls = 'undead', fam = 'undead' },
    bonewalkers = { one = 'bonewalker', many = 'bonewalkers', cls = 'undead', fam = 'undead' },
    bonelords = { one = 'bonelord', many = 'bonelords', cls = 'undead', fam = 'undead' },
    ['ancestor ghosts'] = { one = 'angry ghost', many = 'angry ghosts', cls = 'undead', fam = 'undead' },
    ghosts = { one = 'ghost', many = 'ghosts', cls = 'undead', fam = 'undead' },
    draugr = { one = 'draugr', many = 'draugr', cls = 'undead', fam = 'undead' },

    daedra = { one = 'daedra', many = 'daedra', cls = 'daedra',
        clue = { 'It smells of brimstone near there, and the stones are scorched.',
            'Pilgrims heard shrieking from inside and ran.',
            'Someone made offerings at the shrine, and daedra came. They are still there.',
            'A hunter heard laughter from inside, and no man laughs like that.',
            'The ground near the entrance is cracked and warm to the touch.' },
        count = { '{G} of them, maybe more.' } },
    scamps = { one = 'scamp', many = 'scamps', cls = 'daedra', fam = 'daedra' },
    atronachs = { one = 'atronach', many = 'atronachs', cls = 'daedra', fam = 'daedra' },
    clannfear = { one = 'clannfear', many = 'clannfear', cls = 'daedra', fam = 'daedra' },
    daedroths = { one = 'daedroth', many = 'daedroths', cls = 'daedra', fam = 'daedra' },
    dremora = { one = 'dremora', many = 'dremora', cls = 'daedra', fam = 'daedra' },
    hungers = { one = 'hunger', many = 'hungers', cls = 'daedra', fam = 'daedra' },
    ogrims = { one = 'ogrim', many = 'ogrims', cls = 'daedra', fam = 'daedra' },
    ['spider daedra'] = { one = 'spider daedra', many = 'spider daedra', cls = 'daedra', fam = 'daedra' },
    vermai = { one = 'vermai', many = 'vermai', cls = 'daedra', fam = 'daedra' },
    ['winged twilights'] = { one = 'winged twilight', many = 'winged twilights', cls = 'daedra', fam = 'daedra' },

    dwemer = { one = 'Dwemer machine', many = 'Dwemer machines', cls = 'dwemer',
        clue = { 'You can hear metal grinding inside, and there is steam coming out of the rocks.',
            'A scavenger saw one walking the halls on its own.',
            'A scavenger came out with steam burns and a dent in his helmet.',
            'A scavenger was chased out by a machine on legs.',
            'Folk who go in for scrap do not stay long now.' },
        count = { '{G} of those machines, maybe more.' } },
    centurions = { one = 'Dwemer machine', many = 'Dwemer machines', cls = 'dwemer', fam = 'dwemer' },

    ash = { one = 'ash creature', many = 'ash creatures', cls = 'ash',
        clue = { 'There are people covered in ash walking about the entrance. They are not right.',
            'Folk who live near there have been having bad dreams.',
            'A herder saw ash creatures at the entrance and will not go back.' },
        count = { '{G} of those things, maybe more.' } },
    ['ash slaves'] = { one = 'ash slave', many = 'ash slaves', cls = 'ash', fam = 'ash' },

    beast = { one = 'beast', many = 'beasts', cls = 'beast',
        clue = { 'You can hear growling from the entrance, and it stinks.',
            'Something has been dragging off supplies, and the tracks lead in there.',
            'A herder lost two guar near there and found only the bones.',
            'There are bones all round the entrance, and they are fresh.',
            'Something chased a hunter out of there last week.',
            'The tracks outside are big, and there are a lot of them.' },
        count = { '{G} of them, by the tracks, maybe more.' } },
    rats = { one = 'rat', many = 'rats', cls = 'beast', fam = 'beast',
        clue = { 'You can hear them from outside, and it stinks.',
            'Big rats, folk say, and they are not afraid of people.',
            'Sacks of grain go missing, and the gnawed holes lead back there.',
            'A beggar sleeping near the entrance woke up covered in bites.',
            'The cats in the street will not go near the place.', 'There is a nest in there, and it is getting bigger.' } },
    ['nix-hounds'] = { one = 'nix-hound', many = 'nix-hounds', cls = 'beast', fam = 'beast',
        clue = { 'You can hear them at dusk, and a herder lost two guar to them.',
            'They run in a pack and come out at dusk.', 'A herder lost a guar calf to them last week.' } },
    kagouti = { one = 'kagouti', many = 'kagouti', cls = 'beast', fam = 'beast',
        clue = { 'One charged a pilgrim on the road.', 'The ground outside is torn up by tusks.' } },
    alits = { one = 'alit', many = 'alits', cls = 'beast', fam = 'beast',
        clue = { 'Alits chased a trader halfway to town.', 'They hunt in twos and threes and they are fast.' } },
    durzogs = { one = 'durzog', many = 'durzogs', cls = 'beast', fam = 'beast' },
    guar = { one = 'wild guar', many = 'wild guar', cls = 'beast', fam = 'beast' },
    parastyli = { one = 'parastylus', many = 'parastyli', cls = 'beast', fam = 'beast' },
    trolls = { one = 'troll', many = 'trolls', cls = 'beast', fam = 'beast' },
    velk = { one = 'velk', many = 'velk', cls = 'beast', fam = 'beast' },
    wolves = { one = 'wolf', many = 'wolves', cls = 'beast', fam = 'beast',
        clue = { 'You can hear them howling at night, and they are getting closer.' } },
    goblins = { one = 'goblin', many = 'goblins', cls = 'beast', fam = 'beast',
        clue = { 'Goblins with spears, the herders say, and they steal anything not tied down.',
            'You can hear them arguing over loot just inside the entrance.',
            'A herder found his guar packs ripped open on the path that leads in.',
            'They come out at dusk with spears and go back in before dawn.',
            'Footprints and broken pots all round the entrance, and they are fresh.',
            'A trader turned back last week. He said they were waiting just inside.' } },
    mudcrabs = { one = 'mudcrab', many = 'mudcrabs', cls = 'beast', fam = 'beast',
        clue = { 'Big mudcrabs, all over the entrance. Laugh if you like; one took a man\'s finger.' } },
    monster = { one = 'creature', many = 'creatures', cls = 'beast', fam = 'beast' },
    kwama = { one = 'kwama warrior', many = 'kwama', cls = 'kwama',
        clue = { 'The warriors have gone wild and driven the miners out.',
            'The warriors turned on the miners, and nobody has gone below since.',
            'The miners came up bitten and will not go back down.',
            'The warriors attack anyone who goes down the shaft.' },
        count = { 'At least {g} of them.' } },
    slaughterfish = { one = 'slaughterfish', many = 'slaughterfish', cls = 'fish', water = true,
        clue = { 'Anyone who wades in there comes out bleeding.',
            'There are slaughterfish in the water there.',
            'The fishermen will not set a net near it any more.' },
        poolClue = { 'There are slaughterfish in the pools.',
            'Anyone who wades into the water in there comes out bleeding.',
            'A hunter waded into a pool in there and got bitten badly.',
            'The flooded passages are full of slaughterfish.' },
        count = { 'Fishermen reckon {g}.' } },
    dreugh = { one = 'dreugh', many = 'dreugh', cls = 'fish', water = true,
        clue = { 'There are dreugh in the water there.',
            'A diver came up with his leg torn open and would not go down again.' },
        poolClue = { 'There are dreugh in the deep water inside.',
            'A diver went into the flooded passages and came out with his arm torn open.',
            'Something big lives in the water in there. The divers say dreugh.' },
        count = { '{G} of them, the divers think.' } },
}

-- Every foe noun pair, for tests: { {one, many}, ... }.
function M.nouns()
    local out = {}
    for _, e in pairs(FOES) do out[#out + 1] = { e.one, e.many } end
    return out
end

-- The foe entry for a target { group, n, word }, with its family's clues filled in.
function M.foe(t)
    local e = FOES[t.word or ''] or FOES[t.group] or FOES.beast
    if e.fam and not e.clue then
        local f = FOES[e.fam]
        local out = {}
        for k, v in pairs(f) do out[k] = v end
        for k, v in pairs(e) do out[k] = v end
        e = out
    end
    return e
end

---------------------------------------------------------------------------------------------------
-- Posters. Town notices come from a person with a trade; the trade picks the stories they'd tell.

local FOLK = {
    { 'Ondres', 'Nerano', 'fisherman' }, { 'Dravasa', 'Andrethi', 'egg miner', f = true },
    { 'Llevas', 'Fels', 'trader' }, { 'Sedris', 'Hlaren', 'caravaner' }, { 'Ienas', 'Sarandas', 'farmer' },
    { 'Aurane', 'Frernis', 'seamstress', f = true }, { 'Gindrala', 'Hleran', 'widow', f = true },
    { 'Felisa', 'Ulessen', 'scout', f = true }, { 'Tanar', 'Ralen', 'cooper' }, { 'Mivanu', 'Dalas', 'herder' },
    { 'Brelyna', 'Avani', 'porter', f = true }, { 'Marus', 'Cosades', 'clerk' },
    { 'Ranis', 'Athrys', 'smith', f = true }, { 'Varona', 'Indrano', 'pilgrim', f = true },
    { 'Dirvos', 'Telvani', 'herder' }, { 'Athal', 'Seloth', 'boatwright' }, { 'Nilera', 'Darys', 'weaver', f = true },
    { 'Galos', 'Mathendis', 'pilgrim' }, { 'Tirer', 'Belvayn', 'tanner' }, { 'Nelvayn', 'Omani', 'clerk' },
    { 'Sabia', 'Vedrus', 'fisher', f = true }, { 'Uvren', 'Llethri', 'trader' }, { 'Fadase', 'Selvayn', 'fisher', f = true },
    { 'Brerama', 'Morvayn', 'clerk', f = true }, { 'Teris', 'Verano', 'egg miner' }, { 'Mils', 'Andalor', 'caravaner' },
    { 'Ilvi', 'Raviro', 'farmer', f = true }, { 'Nalis', 'Gareth', 'herder' }, { 'Elone', 'Sadri', 'scout', f = true },
    { 'Rovone', 'Arvel', 'porter' }, { 'Dalvilu', 'Ienith', 'widow', f = true }, { 'Garyn', 'Romari', 'hunter' },
    { 'Meril', 'Hlervu', 'hunter', f = true }, { 'Llaros', 'Uvayn', 'boatwright' }, { 'Ervesa', 'Drelas', 'trader', f = true },
    { 'Haldyn', 'Sendas', 'smith' }, { 'Mehra', 'Faryon', 'pilgrim', f = true }, { 'Bolvyn', 'Indaren', 'farmer' },
}
local FIRST = { m = { 'Dranas', 'Feldrelo', 'Athyn', 'Rels', 'Gavas', 'Nevos', 'Turedus', 'Varvur' },
    f = { 'Dalse', 'Llarara', 'Nedhelas', 'Sarvura', 'Tirala', 'Vedrana', 'Ervona', 'Miruna' } }

function M.townsfolk()
    local out = {}
    for i, p in ipairs(FOLK) do out[i] = p[1] .. ' ' .. p[2] .. ', ' .. p[3] end
    return out
end

local function personOf(p)
    return { first = p[1], last = p[2], trade = p[3], female = p.f == true,
        from = p[1] .. ' ' .. p[2] .. (p[3] and (', ' .. p[3]) or '') }
end

-- A tomb's own family: "Andrano Ancestral Tomb" -> "Andrano".
function M.tombFamily(name)
    return name:match('^(%a+) Ancestral Tomb') or name:match('^(%a+) Family Tomb') or name:match('^(%a+) Tomb')
end

local GUILD_FROM = {
    ['fighters guild'] = { 'Steward of the Fighters Guild', 'The Fighters Guild hall' },
    ['mages guild'] = { 'Steward of the Mages Guild', 'The Mages Guild hall' },
    legion = { 'The Quartermaster', 'By order of the Commander' },
    temple = { 'Brother Mivos, for the Temple', 'Sister Dalse, for the Temple',
        'Brother Gavas, for the Temple', 'Sister Llarara, for the Temple',
        'Brother Rels, for the Temple', 'Sister Vedrana, for the Temple',
        'The priesthood of the Temple', 'The sexton, for the Temple' },
}

-- Voices: how a poster talks, by trade (town) or guild. lead: a first sentence before the story;
-- count: the guess in their words ({g}, never before a noun); sign: a last line after the ask.
-- Job-neutral, so any of them fits a cull, a bounty or a lost item.
local VOICES = {
    sea = {
        lead = { 'I have worked these waters all my life, and I do not scare easily.',
            'I work the boats; I am no fighter, so I am asking.',
            'Nobody on the water will say this out loud, so I will.',
            'This is not the sort of thing I usually pin up.',
            'Ask anyone on the shore; they will tell you the same.',
            'I lost a day\'s work over this already.',
            'The catch has been poor all season, and this does not help.',
            'I would sort it myself, but I have a family to feed.' },
        count = { 'From the boat I made it {g}.', 'I would put it at {g}, and I am being kind.',
            'The lads on the nets say {g}.', 'I saw {g} from the water before I turned back.',
            '{G}, as near as I could tell from the shore.', 'Old Hleran swears it is {g}.',
            'I counted {g} before the light went.', 'Call it {g}; I did not stay to be sure.' },
        sign = { 'You will find me mending nets most mornings.', 'There is a drink in it from me as well.',
            'I will hear of it when it is done; word travels on the water.', 'Tide and Almsivi keep you.',
            'Do not keep me waiting too long.', 'My thanks, whoever you are.',
            'Ask for me where the boats come in.', 'Go careful.' },
    },
    land = {
        lead = { 'I keep to my fields and my beasts, and I want no trouble.',
            'I am a plain working sort, and this is beyond me.',
            'My neighbours think I am fussing. I am not.',
            'I have lived out this way thirty years and never seen the like.',
            'I would not ask if I could do it myself.',
            'The whole valley is talking about it.',
            'It is not my business, maybe, but somebody has to say it.',
            'I lost sleep over this before I wrote it down.' },
        count = { 'I would say {g}, from the tracks.', 'My boy counted {g} from the ridge.',
            '{G}, the herders reckon.', 'I saw {g} myself at dusk.', 'At a guess, {g}.',
            'There were {g} the night I looked.', 'The dog will not go near the place, hackles up. I would guess {g}.',
            'From the hill it looked like {g}.' },
        sign = { 'Come by the farm after and I will feed you.', 'There will be a meal in it as well.',
            'I am up before dawn if you need me.', 'Mind the guar on the road.',
            'My thanks, and my neighbours\' too.', 'Go careful out there.',
            'I will sleep easier when it is done.', 'The gods keep you.' },
    },
    road = {
        lead = { 'I move goods for a living, and the road is my living.',
            'Business is business, and this is bad for business.',
            'I have done this route for years without trouble, until now.',
            'Every trader in town is talking about it.',
            'Time is money, and I am losing both.',
            'I am no sellsword, so I am paying for one.',
            'You will want the facts, so here they are.',
            'I will keep this short; I have a caravan to load.' },
        count = { 'My drivers counted {g}.', '{G}, by my reckoning.', 'Call it {g}, and plan for more.',
            'The last caravan through saw {g}.', 'I paid a scout to look: {g}.',
            'At least {g}, the drovers say.', 'I saw {g} myself from the road.',
            '{G}, as far as anyone on the road can tell.' },
        sign = { 'Fair pay, paid promptly.', 'I pay what I promise, ask anyone.',
            'I leave town in a few days, so be quick.', 'Ask for me at the traders\' stalls.',
            'Do this and I will remember you.', 'Safe roads.', 'There may be more work after this.',
            'My thanks in advance.' },
    },
    desk = {
        lead = { 'I am writing this as plainly as I can.', 'I keep accounts, not swords.',
            'This is a matter of some delicacy.', 'I would rather this stayed between us.',
            'Please read this carefully.', 'I have never put up a notice before.',
            'Forgive the formality; it is my trade.', 'I will be brief and exact.' },
        count = { 'By my count, {g}.', 'I am told {g}.', 'The reports say {g}.',
            'My best estimate is {g}.', 'I have it on good authority: {g}.', 'Roughly {g}, I gather.',
            'Accounts differ, but {g}.', '{G}, by the most careful account I have.' },
        sign = { 'Discretion is appreciated.', 'The fee will be paid in full.', 'I keep regular hours.',
            'Thank you for your time.', 'Please be quick; I am expected to account for it.',
            'You will be paid on the day.', 'I am grateful in advance.', 'My office will know where to find me.' },
    },
    craft = {
        lead = { 'I work with my hands, and they are full enough already.',
            'I have a shop to keep, so I cannot go myself.',
            'My customers have stopped coming because of this.',
            'I am a craftsman, not an adventurer.',
            'You will not find a more honest notice in town.',
            'This has cost me a week\'s work already.',
            'I put down my tools to write this, so you know I mean it.',
            'Everyone at the market has an opinion on this. Here is mine.' },
        count = { 'My apprentice saw {g}.', 'A customer told me {g}.', '{G}, or so I hear.',
            'At a guess, {g}.', 'I heard {g} from a man who went close.', 'The talk at the market is {g}.',
            'I saw {g} with my own eyes.', 'Folk who were there say {g}.' },
        sign = { 'Come by the shop when it is done.', 'There is a discount in it for you after.',
            'I will not forget it.', 'Good luck to you.', 'Mind yourself in there.',
            'I am at my bench every day but Sundas.', 'You have my thanks.', 'Do it well and come back for more.' },
    },
    devout = {
        lead = { 'I pray this reaches someone braver than I am.', 'Almsivi forgive me for asking a stranger.',
            'I have lit candles over this, and now I am writing it down.',
            'The priests say patience. I have run out of it.', 'I ask this in the Three\'s name.',
            'I am nobody important, but I know what I saw.', 'I have never asked a stranger for help before.',
            'I am not brave, so I am asking.' },
        count = { 'I saw {g}, and I do not wish to see them again.', '{G}, may the Three help us.',
            'Others on the road counted {g}.', 'There were {g} at least; I did not stay.',
            'I saw {g} and fled.', 'Others say {g}.', '{G}, I think. I was frightened.',
            'There were {g} when I looked, and I prayed I was wrong.' },
        sign = { 'Almsivi keep you.', 'I will pray for you.', 'The Three bless whoever does this.',
            'My thanks, and my prayers.', 'Walk in the light.', 'Go with the gods.',
            'May your road be safe.', 'I will light a candle for you.' },
    },
    scout = {
        lead = { 'I looked it over myself, so this is first-hand.', 'I know the country out there better than most.',
            'I scout for a living; trust me on this.', 'I went as close as I dared, which is closer than most.',
            'Take this as a warning as much as a job.', 'I mapped the way in, so you will not get lost.',
            'Some of you will want the details. Here they are.', 'I have seen worse, but not often.' },
        count = { 'I counted {g} from cover.', '{G} on watch when I passed.', 'I made it {g}, and I count well.',
            'I saw {g} myself, two nights running.', 'From the rocks I counted {g}.',
            'At least {g}; there could be more below.', '{G}, give or take, from where I lay.',
            'I spotted {g} before I backed off.' },
        sign = { 'Go in quiet.', 'Watch the way in; that is where they look.', 'Good hunting.',
            'Bring a torch.', 'Come back alive and you will be paid.', 'Keep low.',
            'I owe you a drink if you clear it.', 'Mind your footing.' },
    },
    fg = {
        lead = { 'The Guild has work for a steady hand.', 'Work for members and friends of the Guild.',
            'This one is open to any blade the Guild can trust.', 'The Guild is short of hands this week.',
            'Good work for a member looking to make a name.', 'The steward wants this one done quickly.',
            'Here is honest work for honest steel.', 'The Guild keeps its word, and it expects the same.',
            'Posted by order of the steward.', 'Work for a member who can handle a blade.',
            'The Guild needs this seen to.', 'Another job the Guild would rather not leave undone.' },
        count = { 'Our scouts counted {g}.', '{G}, by the last report.', 'The report says {g}; plan for more.',
            'A member who went close counted {g}.', 'Reports put it at {g}.',
            'We count {g}, and there may be more.', 'The last team saw {g}.',
            'A recruit on watch counted {g} going in.', 'Word from the road is {g}.',
            'The steward reckons {g}.', 'Our tracker puts it at {g}.' },
        sign = { 'Report to the steward when done.', 'The Guild pays on proof.', 'Steel and honour.',
            'Do the Guild proud.', 'Members first; others may apply.', 'The Guild remembers good work.',
            'Report back in person.', 'Go with the Guild\'s blessing.' },
    },
    legion = {
        lead = { 'By order of the garrison commander.', 'The Legion has more roads than soldiers this season.',
            'The patrols are stretched thin, so the fort is hiring.', 'A matter the Legion wants settled quietly and soon.',
            'This falls to the fort, and the fort is short of hands.', 'Civilians may take this on with the Legion\'s leave.',
            'The road must be kept open; that is the Legion\'s whole business.', 'Posted at the commander\'s request.',
            'The garrison would rather pay a stranger than lose a patrol.', 'Notice from the fort, for anyone fit to fight.',
            'Riders came in short of men, and the work is still waiting.', 'Duty posts this, for anyone who can hold a sword.',
            'A warrant from the commander, open to civilians this once.', 'Keep the road open. The garrison cannot spare a patrol.',
            'Word from the duty officer: this needs doing, and soon.', 'Soldiers are on other roads. Coin is posted for this one.' },
        count = { 'The last patrol counted {g}.', 'A scout from the fort put it at {g}.', '{G}, by the sentry\'s report.',
            'Our riders saw {g} from the road.', 'Patrol reports say {g}.', 'The watch on the wall reckons {g}.',
            'Expect {g}; the report may be short.', 'A wounded patrolman counted {g}.',
            'The night watch saw {g} by torchlight.', 'A patrol that rode past counted {g}.',
            'Our last scout came back saying {g}.', 'The garrison reckons {g}, give or take.' },
        sign = { 'Report to the quartermaster when done.', 'The Legion pays on proof.', 'For the Emperor.',
            'Sign for your pay at the stores.', 'Do not make us send a patrol after you.', 'Done right, the fort remembers.',
            'Draw your pay from the quartermaster.', 'The fort pays its debts.', 'Ask for the duty officer on your return.',
            'The garrison thanks you in advance.' },
    },
    mg = {
        lead = { 'The Guild of Mages has a matter for capable hands.', 'A commission from the Guild, with apologies for the urgency.',
            'This concerns the Guild\'s scholarship, and so it concerns us all.',
            'Our archmagister would like this resolved.', 'The Guild prefers to resolve this quietly.',
            'An apprentice has caused us some embarrassment.', 'Scholars are not soldiers, so we ask.',
            'The Guild would be grateful for discreet help.', 'Posted on behalf of the hall.',
            'A small matter, but an awkward one.', 'The Guild asks a favour of its friends.',
            'A request from the Guild, for anyone suitably capable.' },
        count = { 'Our apprentices report {g}.', 'A journeyman who poked his head in counted {g}.',
            'One of our apprentices counted {g} before she ran.',
            'Someone from the hall ran back saying {g}.', '{G}, by our best account.', 'One of our scholars counted {g}.',
            'Reports from the field say {g}.', 'A porter who dumped his books and ran said {g}.',
            'Our survey notes record {g}.', 'An apprentice who looked in from the entrance saw {g}.',
            'The last scholar to go in reckoned {g}.', 'By our reckoning, {g}.',
            'A bound scout came back with {g}.', 'Our records suggest {g}.' },
        sign = { 'The steward will see you paid.', 'The Guild values its friends.', 'Knowledge is its own reward; gold helps.',
            'With the Guild\'s thanks.', 'Report to any steward.',
            'The Guild does not forget a kindness.', 'Mind what you touch in there.' },
    },
    temple = {
        lead = { 'The Temple asks for a capable hand.', 'Posted with the blessing of the priesthood.',
            'This is Temple work, for anyone who still honours the Three.',
            'The priesthood would rather not send a novice into this.',
            'A matter the Temple cannot leave to chance.',
            'The sexton brought word, and now we are writing it down.',
            'The Temple keeps its own house, and this is part of that.',
            'We ask this in the Three\'s name, of anyone willing.' },
        count = { 'A pilgrim who looked in counted {g}.', 'The sexton saw {g} from the steps.',
            'One of our own counted {g} before she ran.', '{G}, by the last pilgrim to come this way.',
            'Folk on the steps say {g}.', 'A novice who went as far as the door counted {g}.',
            'The last one who looked in reckoned {g}.', 'Call it {g}; nobody stayed to be sure.' },
        sign = { 'The ancestors remember those who keep them.', 'Almsivi keep you.',
            'The Temple pays what it promises.', 'Report to the priest when it is done.',
            'Walk in the light.', 'The Three bless whoever does this.',
            'Come back to the shrine when you are finished.', 'The priesthood will know your name.' },
    },
}
local VOICE_OF_TRADE = {
    fisherman = 'sea', fisher = 'sea', boatwright = 'sea',
    farmer = 'land', herder = 'land', hunter = 'land', ['egg miner'] = 'land',
    trader = 'road', caravaner = 'road', porter = 'road',
    clerk = 'desk',
    smith = 'craft', cooper = 'craft', tanner = 'craft', weaver = 'craft', seamstress = 'craft',
    pilgrim = 'devout', widow = 'devout',
    scout = 'scout',
}
M.VOICES = VOICES

local function voiceFor(poster, person)
    if poster == 'fighters guild' then return VOICES.fg end
    if poster == 'legion' then return VOICES.legion end
    if poster == 'mages guild' then return VOICES.mg end
    if poster == 'temple' then return VOICES.temple end
    return VOICES[VOICE_OF_TRADE[person and person.trade or ''] or 'land'] or VOICES.land
end

-- Tomb guardians, varied so a board with two tomb jobs does not say it twice.
local TOMB_GUARDS = {
    'The tomb\'s guardians will not welcome you.', 'The ancestors guard their rest, and they will not know you.',
    'The family dead still keep the tomb; they will see you as a thief.', 'Go softly; the tomb is guarded by its own.',
    'The dead of the house watch over it, and they do not ask names.', 'Expect the tomb\'s keepers to stand in your way.',
}

---------------------------------------------------------------------------------------------------
-- Stories. Each: where it fits (place kinds k, foe classes cls, people only, water only), who tells
-- it (trades; guild posters have their own), which items it can be about, and its sentences.
-- {item}: 'my family ring'; {It}/{it}/{its}: the item's pronoun; {place}: the area in a sentence;
-- {foe}/{foes}: the foe nouns; {town}; {coast}: the region's short name.

local RECOVERY = {
    { id = 'wreck cargo', k = { wreck = true }, items = { 'ledger', 'letter', 'cup', 'ring', 'journal' },
      trades = { trader = 1, caravaner = 1, clerk = 1, porter = 1, boatwright = 1, fisherman = 1, fisher = 1 },
      text = { 'My brother shipped {item} on a coaster that went down off {coastText}. The wreck still lies there, and the hold may be dry enough that {it} survived.',
          'When the ship went down off {coastText}, {item} went down with the cargo. The wreck is still there, half out of the water.' } },
    { id = 'robbed on the road', cls = { people = true }, people = true, groups = { bandit = true },
      items = { 'ring', 'amulet', 'cup', 'ledger', 'letter' },
      trades = { caravaner = 1, trader = 1, porter = 1, pilgrim = 1, herder = 1, scout = 1, farmer = 1, clerk = 1 },
      text = { 'Bandits stopped me on the road and took my purse and {item}. They went back to {place} with it all.',
          'I was robbed on the road by men who went off towards {place}. They took {item} with the rest.' } },
    { id = 'held as surety', people = true, groups = { smuggler = true }, items = { 'ledger', 'letter' },
      trades = { clerk = 1, trader = 1, boatwright = 1, porter = 1 },
      text = { 'I did some business with the smugglers at {place}. I will not say what. They kept {item} as surety, and now they will not give {it} back.' } },
    { id = 'taken off a boat', people = true, groups = { pirate = true }, items = { 'ledger', 'letter', 'ring', 'cup' },
      trades = { fisherman = 1, fisher = 1, boatwright = 1, trader = 1, porter = 1 },
      text = { 'Pirates came alongside our boat and took everything worth carrying, {item} with it. They row back to {place} after.',
          'My boat was boarded off the coast. They took the catch, my purse and {item}, and went off towards {place}.' } },
    { id = 'pilgrims attacked', k = { daedric = true }, groups = { cultist = true, warlock = true, daedra = true },
      items = { 'cup', 'amulet', 'ring', 'urn' }, trades = { pilgrim = 1, widow = 1, farmer = 1 },
      text = { 'Our pilgrims were set on near {place} and the offerings were stolen. {Item} was among them.',
          'We were on the road to pray when things came out of {place} at us. I dropped {item} running and it is somewhere inside now.',
          'We lost the offerings on the road by {place}. {Item} went in with the ones who took it.',
          'A shrine party was robbed near {place}, and {item} was carried inside.',
          'I was walking with the pilgrims when we were set on near {place}. {Item} is still in there.' } },
    { id = 'grave robbed', people = true, groups = { necromancer = true, graverobber = true }, items = { 'urn', 'amulet', 'ring' },
      trades = { widow = 1, farmer = 1, pilgrim = 1, smith = 1, tanner = 1 },
      text = { 'Someone robbed my grandmother\'s grave and took {item}. The diggers went off towards {place}.',
          'Grave robbers took {item} from my family\'s plot. Folk saw them carry it to {place}.' } },
    { id = 'took it as a sample', people = true, groups = { warlock = true }, items = { 'ring', 'amulet', 'journal' },
      trades = { trader = 1, smith = 1, weaver = 1, seamstress = 1, clerk = 1 },
      text = { 'A man in robes bought {item} from me with coin that turned to ash by morning. Folk say he works out of {place}.' } },
    { id = 'house broken into', people = true, groups = { vampire = true }, items = { 'ring', 'amulet', 'letter' },
      trades = { widow = 1, farmer = 1, weaver = 1, seamstress = 1, smith = 1 },
      text = { 'Someone broke into my house at night and took {item}. Nobody was hurt. The tracks went towards {place}.',
          'Thieves came in the night and took {item}. We were all asleep and are all fine. Folk say they came from {place}.' } },
    { id = 'pack dropped', cls = { beast = true, fish = true, undead = true, ash = true },
      k = { cave = true, stronghold = true, mine = true },
      items = { 'journal', 'ledger', 'letter', 'ring', 'amulet' },
      trades = { scout = 1, herder = 1, porter = 1, pilgrim = 1, hunter = 1, ['egg miner'] = 1, farmer = 1 },
      text = { 'I sheltered in {place} from a storm and was attacked inside. I got out, but I dropped my pack, and {item} was in it.',
          'I went into {place} after a lost guar and had to run. My pack, with {item} in it, is still down there.',
          'I was cutting through {place} to save half a day and was attacked. I got out, but {item} did not.',
          'I took a wrong turn into {place} and ran. {Item} fell from my belt on the way out.' },
      loose = { 'I put {item} down on a table in one of the back rooms to light a torch, and then they came at me.',
          'I set my pack down in the back of {place} to rest, and {item} fell out. I left {it} lying there when I ran.' } },
    { id = 'dared', cls = { beast = true, fish = true, undead = true, ash = true },
      k = { cave = true, stronghold = true, mine = true }, items = { 'ring', 'amulet', 'letter' },
      trades = { farmer = 1, porter = 1, herder = 1, weaver = 1, smith = 1, widow = 1 },
      text = { 'My boy went into {place} on a dare. He came home safe, but without {item}.',
          'Some lads dared each other into {place}. They all got out, but my son dropped {item} running.',
          'My daughter took {item} into {place} on a dare. She came home safe, but she dropped {it} inside.' },
      loose = { 'My son went into {place} on a dare and put {item} down to prove he had been in the back. He ran home without {it}.' } },
    { id = 'miners fled', k = { mine = true }, cls = { kwama = true }, items = { 'ledger', 'journal', 'cup' },
      trades = { ['egg miner'] = 3, clerk = 1, porter = 1 },
      text = { 'The warriors in {place} went wild and we all ran. {Item} is still down there.',
          'We all got out of {place} when the warriors turned, but {item} stayed behind.',
          'The kwama in {place} turned on us at the end of a shift. I got out with my skin and nothing else; {item} is still in there.',
          'Our foreman left {item} behind when the warriors drove us out of {place}.',
          'Nobody has been down {place} since the warriors went wild, and {item} went with the rest of what we left.' },
      loose = { 'We left {place} in a hurry when the warriors turned. I left {item} on the table in the back gallery.',
          'When the warriors went wild we all ran from {place}. {Item} is still where I left {it}, out on a table in the lower tunnels.' } },
    { id = 'scavenger fled', k = { dwemer = true }, items = { 'journal', 'letter', 'ledger' },
      trades = { scout = 1, smith = 1, clerk = 1, trader = 1, hunter = 1 },
      text = { 'My cousin went into {place} looking for Dwemer coins. A machine chased him out, and he lost {item} on the way.',
          'I went into {place} for Dwemer scrap and dropped {item} when a machine came at me.',
          'My uncle sells Dwemer scrap. He went into {place} for more, got chased out, and lost {item}.',
          'I was looking for Dwemer coins in {place} and a machine came at me. I got out. {Item} did not.',
          'A friend and I went into {place} after scrap. We both got out, but I dropped {item} on the way.' },
      loose = { 'I was sorting Dwemer scrap on a table deep in {place} when a machine came at me. I left {item} lying there.' } },
    { id = 'sleepwalker', cls = { ash = true }, items = { 'amulet', 'ring', 'journal' },
      trades = { widow = 1, farmer = 1, weaver = 1, herder = 1, seamstress = 1 },
      text = { 'My brother walks in his sleep. Two nights ago he walked as far as {place}. He is home now, but {item} is not.' } },
    { id = 'dared', k = { cave = true, stronghold = true }, cls = { undead = true }, items = { 'ring', 'amulet', 'cup', 'journal' },
      trades = { cooper = 1, tanner = 1, smith = 1, farmer = 1, porter = 1, boatwright = 1 },
      text = { 'My son went into {place} on a dare. He is home and unhurt, but he lost {item} in there.' } },
    { id = 'washed down', k = { sewer = true }, items = { 'ring', 'letter', 'ledger' },
      trades = { clerk = 1, trader = 1, porter = 1, weaver = 1, seamstress = 1 },
      text = { 'I dropped {item} down a grate in the street and it washed into {place}. Nobody will go down there after it.',
          'The rain last week carried {item} off my step and down into {place}.',
          'A pickpocket ran from me into {place} with {item}, and the watch would not follow him down.',
          'My lad was playing at the drain with {item} and lost {it} into {place}.' } },
}

-- In a family's own tomb: the poster is of that family; the guardians are not the trouble.
local RECOVERY_TOMB = {
    { id = 'laid with grandfather', items = { 'ring', 'amulet', 'cup' },
      text = { '{Item} was laid in {place} with my grandfather by mistake. It was never meant to stay there, and the family wants it back.',
          'When we buried my grandfather in {place}, {item} went in with him by mistake. The family wants it back where it belongs.' } },
    { id = 'dropped in the dark', items = { 'urn', 'ring', 'amulet', 'cup' },
      text = { 'I carried {item} into {place} to honour the ancestors and dropped {it} in the dark. I cannot face going back.',
          'My torch went out in {place}, and I left {item} behind when I found my way out.' } },
    { id = 'robbers dropped it', items = { 'urn', 'ring', 'amulet' }, intruders = true,
      text = { 'Grave robbers broke into {place} and dropped {item} in their hurry. Bring {it} home.',
          'Thieves have been in {place}. They dropped {item} running from the guardians, and it lies there still.' } },
}

local RECOVERY_GUILD = {
    ['fighters guild'] = {
        { id = 'caravan ambushed', people = true, items = { 'goods', 'gledger' },
          text = { 'A caravan we were guarding was ambushed near {place}, and the {noun} went off with the raiders.',
              'Raiders hit a caravan under our guard on the road by {place}. They took the {noun}.' } },
        { id = 'contract went badly', items = { 'gledger', 'banner' }, notK = { tomb = true },
          text = { 'Our last job at {place} went badly. The team got out, but the {noun} did not.',
              'A Guild team pulled out of {place} in a hurry and left the {noun} behind.',
              'We sent a recruit into {place} with the {noun}. The recruit came back; the {noun} did not.',
              'Our people fell back from {place} under attack, and the {noun} {was} dropped in the retreat.',
              'Two members went into {place} and came out hurt. They left the {noun} behind.',
              'The job at {place} went wrong. Everyone is home, but the {noun} {is} still in there.' },
          loose = { 'Our team set the {noun} down in a back room of {place} and had to fall back. {It} should still be lying there.',
              'A Guild team left the {noun} on a table deep in {place} when they were driven out. Nobody was lost.' } },
        { id = 'courier robbed', people = true, items = { 'gledger', 'goods', 'banner' },
          text = { 'The {foes} at {place} jumped our courier on the road. He got away; the {noun} did not.',
              'The {foes} at {place} robbed a Guild runner. He is fine. The {noun} {was} in his pack.' } },
        { id = 'stores raided', people = true, items = { 'goods', 'banner', 'gledger' },
          text = { 'Thieves from {place} broke into the Guild\'s stores and made off with the {noun}.',
              'Someone got past the night watch and took the {noun} from our stores. The trail ends {placeAt}.' } },
        { id = 'wager', notK = { tomb = true, wreck = true }, items = { 'banner', 'gledger' },
          text = { 'A member bet the {noun} that he could clear {place} alone. He came back hurt and without {it}.',
              'Two of our members argued over who could clear {place} first, and the {noun} {was} the prize. Neither won.',
              'A member took the {noun} into {place} to prove a point. The point was not proved.' },
          loose = { 'A member bet he could plant the {noun} in the deepest room of {place}. He did, then had to run. {It} {is} still there.' } },
        { id = 'client job', notK = { tomb = true, wreck = true }, items = { 'goods', 'gledger' },
          text = { 'A client paid us to fetch the {noun} out of {place}. The member we sent did not get far.',
              'A client of the Guild wants the {noun} back from {place}, and we have promised to deliver.',
              'We took a client\'s coin to recover the {noun} from {place}, and now the Guild\'s name rides on it.',
              'A merchant has paid the Guild to get the {noun} back from {place}.',
              'A client of ours owns the {noun}. {It} {is} in {place}, and we said we would fetch {it}.' } },
        { id = 'patrol', notK = { tomb = true, wreck = true }, items = { 'banner', 'gledger' },
          text = { 'A Guild patrol was driven out of {place} and dropped the {noun} on the way.',
              'Our patrol through {place} ended in a running fight, and the {noun} {was} lost in it.',
              'We lost the {noun} when a patrol was chased out of {place}.',
              'A patrol was attacked in {place}. They all got out, but they left the {noun}.' },
          loose = { 'Our patrol made camp in the back of {place} and was attacked. They left the {noun} lying in the back room.' } },
        { id = 'escort sank', k = { wreck = true }, items = { 'goods', 'gledger' },
          text = { 'The {noun} went down with a ship we were escorting off {coastText}. The wreck has been found.',
              'A ship under Guild escort went down off {coastText} with the {noun} aboard.' } },
    },
    ['mages guild'] = {
        { id = 'fieldwork', items = { 'tome', 'notes', 'samples', 'chart' }, notK = { tomb = true },
          text = { 'An apprentice took the {noun} into {place} for fieldwork and ran without {it}.',
              'Our apprentice was studying in {place} when she was attacked. She got out; the {noun} did not.',
              'A journeyman left the {noun} behind when he ran from {place}.',
              'The Guild\'s expedition to {place} came back without the {noun}.' },
          loose = { 'Our apprentice was working at a table in the back of {place} when she was attacked. She got out and left the {noun} on the table.',
              'A journeyman set the {noun} down in one of the deeper rooms of {place} to take notes, and then had to run.' } },
        { id = 'borrowed', items = { 'tome', 'chart', 'notes' }, notK = { tomb = true, wreck = true },
          text = { 'A member borrowed the {noun} from our library and took {it} into {place}. He came back; {it} did not.',
              'Someone signed out the {noun} for "a little light reading" in {place}. We would like {it} back.',
              'A member took the {noun} from our library to {place} and came back without {it}.' } },
        { id = 'specimens', notK = { tomb = true, wreck = true }, items = { 'samples', 'notes' },
          text = { 'One of our alchemists went to {place} for specimens and left the {noun} behind when she ran.',
              'A collector dropped the {noun} in {place} when he was attacked. He got out.',
              'A specimen hunt in {place} went wrong. Everyone got out, but the {noun} {is} still in there.',
              'Our journeyman was gathering in {place} when something came at her, and she dropped the {noun}.',
              'We sent two apprentices to {place} for samples. They came back pale and without the {noun}.' },
          loose = { 'Our alchemist set the {noun} down on a shelf deep in {place} while she worked, and had to leave {it} when she was attacked.' } },
        { id = 'visiting scholar', notK = { tomb = true, wreck = true }, items = { 'tome', 'chart', 'notes' },
          text = { 'A visiting scholar insisted on seeing {place} for herself. She came back; the {noun} did not.',
              'Our guest from Cyrodiil wanted to see {place}, and the Guild lent her the {noun}. She came back without {it}.',
              'A scholar from another hall took the {noun} into {place}, against advice.',
              'A guest of the hall took the {noun} to {place} to see it for himself. He ran, and left {it} there.',
              'We lent the {noun} to a visiting scholar. She took {it} into {place} and came back without {it}.' } },
        { id = 'thieves', people = true, items = { 'tome', 'samples', 'chart', 'notes' },
          text = { 'Thieves broke into the hall and carried the {noun} off to {place}.',
              'Someone stole the {noun} from our hall, and the trail leads to the {foes} {placeAt}.' } },
        { id = 'courier set upon', people = true, items = { 'notes', 'samples', 'tome' },
          text = { 'The {noun} {was} on the way to another hall when the courier was robbed near {place}. He is fine.',
              'Our courier was robbed on the road and came back without the {noun}. The {foes} {placeAt} have {it} now.' } },
        { id = 'survey', k = { dwemer = true }, items = { 'notes', 'chart', 'tome', 'samples' },
          text = { 'Our scholar was surveying {place} when the machines started moving. She got out; the {noun} {is} still inside.',
              'A survey of {place} ended when the machines attacked. The {noun} {was} left behind.' },
          loose = { 'Our scholar left the {noun} on a table deep in {place} when the machines started moving.' } },
        { id = 'shrine study', k = { daedric = true }, items = { 'notes', 'tome', 'chart' },
          text = { 'We lent the {noun} to an apprentice studying the shrine at {place}. She was driven off, and the {noun} {was} left behind.',
              'A scholar went to {place} to record the shrine and left the {noun} there when its keepers came for her.' } },
        { id = 'wreck salvage', k = { wreck = true }, items = { 'samples', 'chart', 'tome' },
          text = { 'The {noun} {was} aboard a ship that went down off {coastText}, bound for our hall.' } },
    },
    temple = {
        { id = 'shrine taken', k = { daedric = true }, items = { 'token', 'prayer', 'amulet' },
          text = { 'Pilgrims left the {noun} at the shrine in {place}. The keepers there will not let anyone near it now.',
              'A pilgrim offered the {noun} at {place} and was driven off. {It} is still on the altar, they say.' } },
        { id = 'tomb relic', k = { tomb = true }, items = { 'urn', 'prayer', 'token', 'amulet' },
          text = { 'The {noun} belongs in {place} with the family, and someone has moved it. The Temple wants {it} found and left in peace, or brought back if {it} has been taken.',
              'A family asked the Temple to recover the {noun} from {place}. The ancestors should not be left without {it}.' },
          loose = { 'The {noun} was laid out in a back chamber of {place} and never meant to leave. Look on the shelves and altars, not in a thief\'s chest.' } },
        { id = 'novice fled', items = { 'prayer', 'token', 'amulet' }, notK = { wreck = true },
          text = { 'A novice took the {noun} into {place} to pray and ran when the keepers came. {It} is still inside.',
              'We sent a novice to {place} with the {noun}. He came back pale and empty-handed.' },
          loose = { 'The novice set the {noun} down on a shelf in the back of {place} to light a candle, and then ran.' } },
        { id = 'stolen offering', people = true, items = { 'token', 'amulet', 'urn', 'prayer' },
          text = { 'Someone took the {noun} from the shrine and went to ground {placeAt}.',
              'The {noun} was stolen from the offering table. The trail leads to the {foes} {placeAt}.' } },
    },
}

-- Where to look, by where the item really is: people (a chest or their leader), things (a chest),
-- loose (lying out on something in the deeper rooms, not in a chest). A story's own `loose` lines
-- take the place of the open and this line when they fit.
local WHERE_ITEM = {
    people = { '{It} will be in one of their chests, or on whoever leads them.', 'Look in their stash, or on the one giving the orders.',
        'They will have put {it} with the rest of their loot, or their leader has {it}.',
        'Search their chests and sacks, and the one in charge.', 'Check the leader\'s pockets first.' },
    things = { '{It} will be in a chest or sack somewhere inside.', 'Look in the chests and sacks inside.',
        '{It} should be in a chest or a sack in there.', 'Try the old chests and crates inside.',
        'Somewhere inside, in a chest or a sack.', 'Check every chest and barrel.',
        '{It} will have ended up in some crate or urn inside.' },
    loose = { '{It} will be lying out somewhere in the back, not in a chest.', 'Look on the tables and shelves in the deeper rooms.',
        '{It} should be lying in plain sight, somewhere past the first rooms.', 'Look for {it} out in the open, further in.',
        'Not in a chest. {It} will be lying about somewhere deep inside.' },
}

local ASK_RECOVERY = {
    town = { 'Bring {it} back here and the reward is yours.', 'Whoever brings {it} back to me will be paid.',
        'Return {it} here; I come by every morning.', 'Bring {it} home and the coin is yours.',
        'I will pay well to have {it} back in my hands.', 'Bring {it} to me and you will not be sorry.',
        'Return {it}, and name your thanks.', 'There is good coin for whoever brings {it} back.' },
    guild = { 'Recover {it}; the steward pays on return.', 'Bring {it} to any guild hall.',
        'Return {it} to the Guild and the steward will pay.', 'Any steward will take {it} and pay the fee.',
        'Recover {it}, and the Guild will see you rewarded.', 'Hand {it} to a steward and collect the fee.',
        'Bring {it} back to the hall.', 'The Guild pays on return, at any hall.' },
}

-- Who to blame, the clue, how many, and what to do: by foe class.
local NEST_OPEN = {
    people = { 'Nobody goes near {place} since the {foes} moved in.', 'The {foes} at {place} have grown bold this season.',
        '{Foes} have taken over {place}, and the road past it is not safe.', 'There is a band of {foes} holed up {placeAt}.',
        'A gang of {foes} has moved into {place}.', '{Place} is a {foe} camp now.',
        'The {foes} {placeAt} have been robbing anyone who passes.', 'Since spring, {foes} have been living in {place}.' },
    undead = { 'The dead do not rest in {place}.', 'Nobody goes near {place} since the dead began to walk.',
        'Something has woken the dead {placeAt}.', 'The restless dead walk {placeAt} again.',
        'The dead are out of their graves {placeAt}.', '{Place} is full of walking dead.',
        'Lights move in {place} at night, and nobody living carries them.',
        'Herders will not graze near {place} since the dead started walking.',
        'The dead {placeAt} have started wandering out after dark.', 'Bones have been seen moving about {placeAt}.' },
    daedra = { 'Someone summoned daedra {placeAt} and never sent them back.', 'Daedra have come to {place}, and they are not leaving.',
        'Whatever was called up {placeAt} was never sent back.', 'There are daedra loose {placeAt}.',
        'Daedra have taken over {place}.', 'Folk have seen daedra {placeAt}, bold as you like.' },
    dwemer = { 'The old machines in {place} are moving again.', 'Someone has started the old machines in {place} again.',
        'The Dwemer machines {placeAt} are working again.', 'The machines {placeAt} are walking about again.',
        '{Place} is not empty any more. The machines are awake.',
        'Scavengers coming out of {place} say something in there is walking the halls.',
        'There is steam coming out of {place} again, and something moving behind it.',
        'Whatever kept {place} quiet has stopped working, and the machines are up.',
        'Nobody goes into {place} for scrap now. The guardians have woken.' },
    beast = { 'Something has made a den of {place}.', 'There are too many {foes} in {place} now to leave alone.',
        '{Foes} have nested {placeAt}, and they are breeding.', 'There is a pack of {foes} {placeAt}, and it is getting bigger.',
        '{Foes} have moved into {place}.', 'The {foes} {placeAt} have started coming out to hunt.',
        'A herder lost two guar near {place}, and the tracks go inside.', 'Nobody walks past {place} at dusk now.',
        'Hunters say {place} is crawling with {foes}.' },
    fish = { 'There are {foes} in the water at {place}.', 'Nobody fishes near {place} any more.',
        'The {foes} round {place} have driven the fishing boats off.', 'The water {placeAt} is full of {foes}.' },
    pool = { 'There are {foes} in the pools in {place}.', 'The water in {place} is full of {foes}.',
        'The flooded passages of {place} are full of {foes}.', 'There are {foes} in the water {placeAt}.',
        'Nobody wades into {place} now. {Foes} took a man by the leg there.',
        'Something in the deep water {placeAt} bit a diver.', '{Foes} have the flooded halls of {place}.',
        'Keep out of the water in {place}. It is thick with {foes}.',
        'Something with teeth lives in the water {placeAt} now.',
        'A scavenger came out of {place} bleeding from the legs, and he blames {foes}.',
        '{Foes} are breeding in the water {placeAt}.', 'Nobody goes into the water at {place} since the {foes} came.' },
    kwama = { 'The kwama in {place} have turned on the miners.', 'The miners of {place} have stopped work.',
        'The kwama {placeAt} have gone wild.', 'Nobody can work {placeAt} since the warriors turned.',
        'No eggs have come out of {place} in a week.', 'The egg miners will not go back into {place}.',
        'The warriors {placeAt} killed a miner, and the rest refuse to go down.',
        'The egg market is short this month because {place} has gone wild.',
        'Something has set the kwama {placeAt} against anyone who comes near.' },
    ash = { 'There are ash creatures {placeAt}.', 'The ash creatures at {place} have been seen closer to the road.',
        'Sixth House creatures have moved into {place}.', 'There are ash creatures {placeAt}, and there are more each week.' },
}
local ASK_NEST = {
    people = { 'Drive out every one of them and I will pay you myself.', 'Clear them out and come back here for the coin.',
        'Clear them out for good.', 'Run them off or put them down; either way, you will be paid.' },
    undead = { 'Put them back in the ground, all of them.', 'Lay them to rest, and you will be paid for it.',
        'Put them down for good.', 'Send them back to their rest.',
        'See that none of them walks again.', 'Give them their rest, and come back for the coin.',
        'Break every one of them, then come back for your pay.' },
    daedra = { 'Send them back where they came from.', 'Banish every one, then come back for your pay.',
        'Banish them, every last one.', 'Send them home to Oblivion.' },
    dwemer = { 'Break them for good; I do not care about the scrap.', 'Shut them down for good, and the coin is yours.',
        'Smash every one of them.', 'Put them out of action for good.',
        'Leave none of them moving.', 'Wreck every machine in there, then come back for your pay.',
        'Stop every one of them, and you will be paid.' },
    beast = { 'Kill every one of them and I will pay you myself.', 'Clear the place out and come back for the coin.',
        'Kill every last one of them.', 'Clear the den, and you will not go unpaid.',
        'Put them all down and the place is ours again.', 'Leave nothing alive in there, and come back for your pay.',
        'Thin them out to nothing, and the coin is yours.', 'Hunt them down to the last, then come and see me.' },
    fish = { 'Kill the fish so the nets can go back in.', 'Clear the water and there is coin in it for you.',
        'Get rid of them so we can fish again.', 'Clear them out of the water.' },
    pool = { 'Clear the water, and you will be paid.', 'Kill every one, and come back for the coin.',
        'Clear the pools for good.', 'Get rid of them, every one.' },
    kwama = { 'Clear out the warriors so the miners can go back down.', 'Put the warriors down; the queen must live.',
        'Deal with the warriors and leave the queen be.', 'Make the mine safe to work again.',
        'Clear the warriors out, but do not touch the queen.', 'Kill the warriors and the miners will go back to work.',
        'Get the mine working again; the queen stays alive.' },
    ash = { 'Put them down before they come any closer.', 'End them, and the coin is yours.',
        'Destroy them before the sickness spreads.', 'Clear them out before they reach the road.' },
}
local NEST_TITLE = {
    people = { '{Foes} {at} {area}' },
    undead = { 'The dead walk {at} {area}', 'Restless dead {at} {area}' },
    daedra = { 'Daedra {at} {area}', '{Foes} {at} {area}' },
    dwemer = { 'Machines stirring {at} {area}', 'The machines {at} {area}' },
    beast = { '{Foes} {at} {area}' },
    fish = { '{Foes} {at} {area}' },
    pool = { '{Foes} {at} {area}' },
    kwama = { 'Trouble {at} {area}', 'The kwama {at} {area}' },
    ash = { 'Ash creatures {at} {area}' },
}

-- Fitting trades for nest notices: who would see this foe.
local NEST_TRADES = {
    fish = { fisherman = 3, fisher = 3, boatwright = 2 }, pool = { scout = 2, hunter = 2, herder = 1 }, kwama = { ['egg miner'] = 3, porter = 1 },
    beast = { herder = 2, hunter = 2, farmer = 2, scout = 1 }, people = { caravaner = 2, trader = 2, porter = 1, scout = 1 },
    undead = { pilgrim = 1, widow = 1, scout = 1, farmer = 1 }, daedra = { pilgrim = 2, scout = 1 },
    dwemer = { scout = 2, smith = 1, hunter = 1 }, ash = { herder = 2, farmer = 1, scout = 1 },
}

-- open, count (rumour; {g} the guess, {noun} agreeing with it), alone (when nobody is with them), ask.
local BOUNTY_TEXT = {
    { open = 'Folk on the road say {Leader} has holed up {placeAt}.',
      count = '{He} is not alone. I counted {gn} with {him}, maybe more.',
      alone = 'As far as anyone knows, {he} is alone.',
      ask = 'End {his} {deed} and bring back the signet {he} wears as proof.' },
    { groups = { bandit = true, smuggler = true },
      open = '{Leader} robbed my cousin on the road last month and laughed about it.',
      count = '{He} keeps {gn} {placeAt}, and there may be more.',
      alone = '{He} hides {placeAt}, alone as far as anyone knows.',
      ask = 'Bring me the signet {he} wears, and I will know {he} is done laughing.' },
    { groups = { pirate = true },
      open = '{Leader} has been taking the catch off our boats, and the fishermen are going hungry.',
      count = '{He} keeps a crew of {gn} {placeAt}.',
      alone = '{He} works alone from {place}, which is bold even for a pirate.',
      ask = 'Bring back the signet {he} wears, so we know {he} is done.' },
    { open = 'The roads round {town} will not be safe while {Leader} runs {his} {deed} out of {place}.',
      count = '{Gn} answer to {him}, at least.',
      alone = '{He} works alone, they say.',
      ask = 'The signet {he} wears is proof enough.' },
    { groups = { necromancer = true, warlock = true, vampire = true, cultist = true, graverobber = true },
      open = 'Folk say {Leader} is behind the {deed} {placeAt}, and nobody else will name {him}.',
      count = '{He} has {gn} about {him}, maybe more.',
      alone = 'Nobody has seen anyone else with {him}.',
      ask = 'Put a stop to {his} {deed}, and bring back the signet {he} wears as proof.' },
    { open = 'Everyone in {town} knows the name {Leader}, and nobody says it loudly.',
      count = '{He} runs with {gn}, as far as anyone can tell.',
      alone = 'Folk say {he} works alone.',
      ask = 'Bring back the signet {he} wears, and {town} will breathe easier.' },
    { open = 'There is a price on {Leader}, and I am adding to it.',
      count = 'Mind, {he} has {gn} about {him}.',
      alone = '{He} is alone, they say, but careful.',
      ask = 'The signet {he} wears is all the proof I need.' },
    { open = '{Leader} has been seen going in and out of {place}.',
      count = 'Not alone, either: {gn}, maybe more.',
      alone = 'Always alone, and always watching the road.',
      ask = 'Bring me the signet {he} wears.' },
    { open = 'I want {Leader} gone from {place}.',
      count = '{He} has {gn} with {him}. Go armed.',
      alone = '{He} is on {his} own in there, I am told.',
      ask = 'Bring back {his} signet and I will pay.' },
    { open = 'My guar came home without its packs. {Leader} took them, and everyone knows it.',
      count = '{He} hides {placeAt} with {gn}.',
      alone = '{He} hides {placeAt}, on {his} own.',
      ask = 'I want the signet {he} wears in my hand.' },
    { open = 'The guards will not go near {place}, so I am asking you. {Leader} is in there.',
      count = 'Expect {gn} around {him}.',
      alone = 'Nobody has seen anyone with {him}.',
      ask = 'Bring me {his} signet as proof.' },
    { open = 'Wanted: {Leader}, for {his} {deed}. Last seen {placeAt}.',
      count = '{He} has {gn} with {him}, the last I heard.',
      alone = '{He} was alone when last seen.',
      ask = 'Payment on return of the signet {he} wears.' },
    { open = 'A trader I know lost a cart and a good guard to {Leader}.',
      count = '{He} is {placeAt}, with {gn}.',
      alone = '{He} is {placeAt}, alone.',
      ask = 'Bring back the signet {he} wears and the coin is yours.' },
    { open = 'The herders avoid the track past {place} while {Leader} holds it.',
      count = '{He} has {gn} with {him}.',
      alone = '{He} is there alone, the herders say.',
      ask = 'Bring back the signet {he} wears.' },
    { open = 'Coin on offer for {Leader}, who works out of {place}.',
      count = 'Go ready: {gn} answer to {him}.',
      alone = '{He} works alone, by all accounts.',
      ask = 'The signet {he} wears is the proof.' },
    { open = 'Last month a pack guar was taken, and the tracks lead to {Leader} at {place}.',
      count = '{He} keeps {gn} there.',
      alone = '{He} keeps to {place}, alone.',
      ask = 'I will pay for the signet {he} wears.' },
    { open = 'People in {town} bar the door at dusk because of {Leader}.',
      count = '{He} is {placeAt} with {gn}.',
      alone = '{He} is {placeAt}, and alone.',
      ask = 'Bring me {his} signet and the coin is yours.' },
    { open = 'A caravan turned back rather than pass {place}, and they named {Leader}.',
      count = '{Gn} travel with {him}.',
      alone = '{He} travels alone, they say.',
      ask = 'The signet {he} wears will do for proof.' },
    { open = 'Several people in {town} have named {Leader}, and they all point to {place}.',
      count = '{He} has {gn} about {him}.',
      alone = 'They saw no one else with {him}.',
      ask = 'Bring back the signet {he} wears and you will be paid.' },
}
local BOUNTY_TEXT_LEGION = {
    { open = '{Leader} and {his} {foes} have been preying on travellers near {place}, and the Legion wants it stopped.',
      count = 'The patrol that went close saw {gn} with {him}.',
      alone = '{He} works alone, by the patrol\'s report.',
      ask = 'Bring the signet {he} wears to the quartermaster.' },
    { open = 'A price is posted on {Leader}, who leads the {foes} {placeAt}.',
      count = 'Expect {gn} at {his} side.',
      alone = 'Nobody has been seen with {him}.',
      ask = '{His} signet closes the matter.' },
    { open = 'A supply wagon was taken on the road, and the trail leads to {Leader} {placeAt}.',
      count = 'A scout counted {gn} with {him}.',
      alone = '{He} seems to have done it alone, which is worse.',
      ask = 'The signet {he} wears will do as proof.' },
    { open = 'Wanted by the Legion: {Leader}, hiding {placeAt}.',
      count = '{He} has {gn} about {him}.',
      alone = '{He} is thought to be alone.',
      ask = 'Return with {his} signet for the bounty.' },
    { open = 'The Legion wants {Leader} brought to account for {his} {deed} {placeAt}.',
      count = 'Our scouts put {gn} with {him}.',
      alone = 'The scouts saw nobody with {him}.',
      ask = 'Hand {his} signet to the duty officer for your pay.' },
    { open = 'A courier was robbed on the road, and the fort holds {Leader} to blame.',
      count = '{He} has gone to ground {placeAt} with {gn}.',
      alone = '{He} has gone to ground {placeAt}, alone.',
      ask = 'The signet {he} wears is the proof the fort needs.' },
    { open = 'Two of our men came back wounded from {place}, and {Leader} did it.',
      count = 'A sentry saw {gn} with {him} at the entrance.',
      alone = '{He} fought them on {his} own, which says enough.',
      ask = 'Bring {his} signet back to the fort.' },
    { open = 'The garrison has posted a reward for {Leader}, for {his} {deed}.',
      count = '{He} is {placeAt}, with {gn} by the last patrol.',
      alone = '{He} is {placeAt}, and the patrol saw no one else.',
      ask = 'Show {his} signet at the stores and draw your reward.' },
    { open = 'Notice to all travellers: {Leader} is wanted by the garrison.',
      count = '{He} keeps {gn} close, {placeAt}.',
      alone = '{He} keeps to {place}, alone.',
      ask = 'The quartermaster pays when {his} signet is on the table.' },
    { open = 'The commander will not spare a patrol for {Leader}, so the fort is paying for the work.',
      count = 'Expect {gn} with {him} {placeAt}.',
      alone = '{He} is {placeAt}, and seems to be alone.',
      ask = 'Return with {his} signet and the Legion settles up.' },
    { open = '{Leader} has made a den of {place}, and the road suffers for it.',
      count = 'The patrol counted {gn} going in and out.',
      alone = '{He} goes in and out alone, by the patrol\'s count.',
      ask = 'The fort pays on sight of the signet {he} wears.' },
    { open = 'The road patrol lost a pack guar and nearly a man to {Leader} near {place}.',
      count = '{He} has {gn} with {him} there.',
      alone = '{He} was alone, the patrol says.',
      ask = 'The fort wants {his} signet as proof.' },
    { open = 'By the commander\'s word, a bounty on {Leader}, for {his} {deed}.',
      count = 'Last reported {placeAt} with {gn}.',
      alone = 'Last reported {placeAt}, alone.',
      ask = 'Bring {his} signet to the stores.' },
    { open = 'Farmers near {place} have stopped bringing goods to the fort, for fear of {Leader}.',
      count = '{He} rides with {gn}, they say.',
      alone = 'They say {he} goes about alone.',
      ask = 'The signet {he} wears will settle it with the quartermaster.' },
    { open = 'Three complaints came in this month, and every one names {Leader}.',
      count = '{He} is holed up {placeAt}, and {gn} are with {him}.',
      alone = '{He} is holed up {placeAt}, by {him}self.',
      ask = 'Bring in {his} signet and the complaints stop.' },
    { open = 'Legion business: {Leader}, wanted for {his} {deed}.',
      count = 'A patrol saw {gn} with {him} {placeAt}.',
      alone = 'A patrol saw {him} {placeAt}, with nobody else.',
      ask = 'Proof is {his} signet, brought to the fort.' },
    { open = 'Our gate guard knows the face of {Leader}, and so does half the road.',
      count = '{He} is {placeAt} now, with {gn}.',
      alone = '{He} is {placeAt} now, alone.',
      ask = 'Bring the signet {he} wears and the fort will pay what it owes.' },
    { open = 'Merchants have petitioned the fort over {Leader} and {his} {deed}.',
      count = 'Scouts saw {gn} with {him} {placeAt}.',
      alone = 'Scouts found {him} {placeAt}, on {his} own.',
      ask = 'Bring us {his} signet and the petition is answered.' },
    { open = 'The fort is offering coin for {Leader}, who has made the road a misery.',
      count = 'Expect {gn} {placeAt}, by the patrol\'s count.',
      alone = 'The patrol found {him} alone {placeAt}.',
      ask = '{His} signet, handed in at the stores, ends it.' },
}
local BOUNTY_TEXT_GUILD = {
    { open = 'The Guild has taken money to deal with {Leader}, who leads the {foes} {placeAt}.',
      count = 'Our scouts saw {gn} with {him}; expect more.',
      alone = '{He} is thought to be alone.',
      ask = 'Bring the signet {he} wears.' },
    { open = 'The Guild wants {Leader}, holed up {placeAt}.',
      count = 'Expect {gn} around {him}.',
      alone = 'Reports say {he} has no one with {him}.',
      ask = 'Bring back {his} signet and the matter is closed.' },
    { open = '{Leader} has a price on {his} head, and the Guild means to collect.',
      count = '{He} keeps {gn} close.',
      alone = '{He} is alone, by the last report.',
      ask = '{His} signet is the proof the steward needs.' },
    { open = 'Wanted by the Guild: {Leader}, last seen {placeAt}.',
      count = 'Our reports put {gn} with {him}.',
      alone = 'No one has been seen with {him}.',
      ask = 'Return with the signet {he} wears.' },
    { open = 'Travellers have paid the Guild to deal with {Leader} {placeAt}.',
      count = '{He} is not alone; {gn} at the last report.',
      alone = '{He} seems to work alone.',
      ask = 'The steward pays when {his} signet is on the desk.' },
    { open = 'The steward has taken a commission against {Leader}, who is hiding {placeAt}.',
      count = 'There are {gn} with {him}, by our count.',
      alone = 'As far as we know, {he} has no one with {him}.',
      ask = 'The signet {he} wears is the proof we need.' },
    { open = 'Merchants have had enough of {Leader} {placeAt}, and they have paid the Guild to say so.',
      count = '{He} runs with {gn}.',
      alone = '{He} works alone, they say.',
      ask = 'Take the signet from {him} and bring it to the steward.' },
    { open = '{Leader} is {placeAt}. The Guild wants {him} dealt with.',
      count = 'Expect {gn} with {him}.',
      alone = '{He} is alone, as far as we know.',
      ask = 'Bring {his} signet to the steward.' },
    { open = '{Leader} has gone too far with {his} {deed}, and the Guild has been asked to answer it.',
      count = '{He} is {placeAt} with {gn}.',
      alone = '{He} is {placeAt}, alone.',
      ask = 'The steward pays on sight of the signet {he} wears.' },
    { open = 'For any member who wants it: {Leader}, {placeAt}.',
      count = '{Gn} with {him}, by the last report.',
      alone = 'No one else has been seen with {him}.',
      ask = 'Proof is the signet {he} wears.' },
    { open = 'The town has asked the Guild to put an end to {Leader}.',
      count = '{He} is {placeAt}, and {gn} are with {him}.',
      alone = '{He} is {placeAt}, on {his} own.',
      ask = 'Bring back the signet {he} wears.' },
    { open = 'A bounty for any member: {Leader}, {placeAt}.',
      count = 'Expect {gn} with {him}.',
      alone = '{He} is reported to be alone.',
      ask = 'Bring back {his} signet.' },
}
local BOUNTY_BAND = {
    { 'Somebody leads the {foes} {placeAt}, and folk say {g} of them answer to that one.',
      'Find whoever gives the orders and bring back the signet they wear.' },
    { 'The {foes} {placeAt} have gone unnamed long enough.', 'Their leader wears a signet; bring it back as proof.' },
    { 'Ask around {place} and nobody can name who leads the {foes} there, though {g} of them follow somebody.',
      'Bring back the signet their leader wears.' },
    { 'The {foes} {placeAt} answer to one of their own, and {g} of them do as they are told.',
      'The one giving the orders wears a signet; that is the proof.' },
    { 'Whoever leads the {foes} {placeAt} keeps out of sight, but {g} of them take that one\'s orders.',
      'Find the leader and bring back the signet as proof.' },
    { 'One of the {foes} {placeAt} gives the orders, and {g} of them obey.',
      'Bring back the signet the leader wears.' },
    { 'Word is that {g} of the {foes} {placeAt} take orders from one leader.',
      'Bring that leader\'s signet back here.' },
    { 'A leader holds the {foes} {placeAt} together, {g} of them at the last count.',
      'The leader wears a signet. Bring it back.' },
    { 'People on the road have seen {g} of the {foes} {placeAt}, and someone is giving them orders.',
      'Find the one in charge and bring back the signet.' },
    { 'The {foes} {placeAt} have a leader nobody here has seen, and {g} of them do that leader\'s bidding.',
      'The signet on the leader\'s hand is the proof we need.' },
    { 'Patrols have not put a name to whoever holds the {foes} {placeAt} together, {g} of them at least.',
      'The one in charge wears a signet; that is the proof.' },
    { 'Scouts put {g} of the {foes} {placeAt}, answering to a leader they never saw.',
      'Bring back the signet that leader wears.' },
    { 'Reports name no one, only {g} of the {foes} {placeAt} who take orders from someone.',
      'Find that someone and bring the signet they wear.' },
    { 'Out of {place} come {foes} who answer to a face nobody here has seen, {g} of them by the last count.',
      'The leader\'s signet is the proof we need.' },
    { 'Travellers near {place} talk of {g} of the {foes} there, and of a leader whose name they will not give.',
      'Bring that leader\'s signet back here.' },
}
local BOUNTY_TITLE = { 'WANTED: {Leader}', 'WANTED: {Leader}, {one}' }
local BAND_TITLE = { 'WANTED: the {chief} hiding in {areaName}', 'WANTED: whoever leads the {foes} {at} {areaName}' }

local FEEL = {
    { 'Nothing a careful hand cannot manage.', 'Not much of a fight for anyone who knows a blade.',
        'A sensible sort with a good blade will manage.', 'Rough work, but not deadly.' },
    { 'Not for the unprepared.', 'Go armed, and go ready.', 'Do not go in half-equipped.', 'It is dangerous, make no mistake.' },
    { 'Go well armed, and do not go alone if you can help it.', 'Whoever goes should know what they are doing.',
        'This is no job for a beginner.', 'Two men tried already and came back hurt.' },
}

---------------------------------------------------------------------------------------------------
-- Building one notice

local function pickFrom(list, rnd)
    return list[rnd(#list)]
end

-- One line of list, filled from a (when given); a line whose text is already on this board
-- (used.bodies) is passed over while another is left.
-- A guild or the Legion speaks as "we": lines in a lone person's "I" are left out of the shared
-- pools for them (all of a pool when none is left).
local function voiced(list, poster)
    if poster == 'town' or not poster then return list end
    local out = {}
    for _, s in ipairs(list) do
        if not (s:find('%f[%a]I%f[%A]') or s:find('%f[%a]my%f[%A]') or s:find('myself', 1, true)) then out[#out + 1] = s end
    end
    return #out > 0 and out or list
end

local function pickFresh(list, rnd, used, a)
    local bodies = used and used.bodies or {}
    local fresh, all = {}, {}
    for _, s in ipairs(list) do
        local text = a and fill(s, a) or s
        all[#all + 1] = text
        -- The fixed words before the first blank, or else after the last, when there are enough of
        -- them, so a line counts as used whatever place or number filled it last time.
        local fixed = s:match('^([^{]*)')
        local tail = s:match('}([^{}]*)$') or ''
        local probe = #fixed >= 8 and fixed or #tail >= 8 and tail or text
        local seen = false
        for _, body in ipairs(bodies) do
            if body:find(probe, 1, true) then seen = true break end
        end
        if not seen then fresh[#fresh + 1] = text end
    end
    if #fresh > 0 then return fresh[rnd(#fresh)] end
    return all[rnd(#all)]
end

-- A story from those that fit, each weighted by how many ways it can be told, so a story with one
-- text doesn't open as many notices as one with four.
local function pickStory(list, rnd)
    local total = 0
    for _, s in ipairs(list) do total = total + #s.text end
    local r = rnd(total)
    for _, s in ipairs(list) do
        r = r - #s.text
        if r <= 0 then return s end
    end
    return list[#list]
end

local function anyOf(set, key)
    return set == nil or set[key] == true
end

-- Weighted choice of a poster from the free ones; trades: trade -> weight (nil: anyone).
local function choosePerson(trades, used, rnd)
    local pool, total = {}, 0
    for _, p in ipairs(FOLK) do
        if not used[p[2]] then
            local w = trades and (trades[p[3]] or 0) or 1
            if w > 0 then
                pool[#pool + 1] = { p = p, w = w }
                total = total + w
            end
        end
    end
    if total == 0 then
        if trades then return choosePerson(nil, used, rnd) end
        return nil
    end
    local r = (rnd(1000) - 1) / 1000 * total
    for _, e in ipairs(pool) do
        r = r - e.w
        if r < 0 then return personOf(e.p) end
    end
    return personOf(pool[#pool].p)
end

local function itemFor(story, free, a)
    for _, key in ipairs(story.items) do
        for _, k in ipairs(free) do
            if k.key == key and (not k.carried or a.people or a.k == 'wreck') then return k end
        end
    end
    return nil
end

local function fits(story, a)
    if story.k and not story.k[a.k] then return false end
    if story.notK and story.notK[a.k] then return false end
    if story.cls and not story.cls[a.cls] then return false end
    if story.people and not a.people then return false end
    if story.groups and not story.groups[a.group] then return false end
    if story.intruders and not a.people then return false end
    return true
end

local function dangerBand(danger, level)
    local r = danger / math.max(1, level)
    if r < 1.5 then return 1 end
    if r < 3 then return 2 end
    return 3
end

-- A notice is one problem and at most two rumours, then the ask: six sentences at most.
-- When there are more, the first two stay (the problem and the first rumour) and so do the
-- last ones, which are the ask and whatever was added just before it.
function M.shorten(text, most)
    most = most or 6
    local function split(s)
        local out = {}
        for sent in (s or ''):gmatch('%s*([^%.%!%?]+[%.%!%?])') do
            sent = sent:gsub('^%s+', ''):gsub('%s+$', '')
            if sent ~= '' then out[#out + 1] = sent end
        end
        if #out == 0 and s and s ~= '' then out[1] = s end
        return out
    end
    local function cut(s)
        local all = split(s)
        if #all <= most then return table.concat(all, ' ') end
        local keep = {}
        for i = 1, 2 do keep[i] = all[i] end
        for i = #all - (most - 3), #all do
            if i > 2 then keep[#keep + 1] = all[i] end
        end
        return table.concat(keep, ' ')
    end
    if text.body then text.body = cut(text.body) end
    if text.plain then text.plain = cut(text.plain) end
    if text.story then
        local again = split(text.body)
        text.story = again
    end
    return text
end

-- args: { kind, poster, place (places.lua entry), level, danger, hostiles (all foes, for a
-- recovery), targets (F.targets), boss, band, town, region, where, freeItems (item kinds not on the
-- board yet, shuffled), used = { names = surname -> true, titles, bodies = { the board's other
-- notices } }, rnd(n) -> 1..n }.
-- Returns { title, body, plain, from, item = kind, itemPhrase, itemName, details } or nil, why.
function M.build(args)
    local rnd = args.rnd
    local place, kind, poster = args.place, args.kind, args.poster
    local town = args.town
    local area = M.area(place, args.region)
    local placeText = area.name
    local coast = regionShort(args.region)
    local top = args.targets[1]
    local foe = top and M.foe(top) or FOES.beast
    local count = math.floor(F.count(args.targets) + 0.5)
    local a = {
        town = town, place = placeText, Place = cap(placeText), foe = foe.one, placeAt = area.at .. ' ' .. placeText, at = area.at, area = placeText,
        areaName = area.name, coastText = coast and ('the ' .. coast) or 'the coast',
        k = place.k or 'cave', cls = foe.cls, group = top and top.group or 'beast',
        people = top ~= nil and F.PEOPLE[top.group] == true, one = foe.one, foes = foe.many, Foes = cap(foe.many),
        deed = foe.deed or 'work', chief = foe.chief or ('leader of the ' .. foe.many),
    }
    local from, person
    local band = dangerBand(args.danger or 0, args.level or 1)
    -- Fish away from the coast live in a cave's pools: no nets, no fishermen.
    local inPools = foe.cls == 'fish' and a.k ~= 'wreck'
    local cls = inPools and 'pool' or foe.cls
    local clues = inPools and (foe.poolClue or foe.clue) or foe.clue
    local counts = not inPools and foe.count or nil
    local folk
    for _, t in ipairs(args.targets) do
        if not folk and F.PEOPLE[t.group] then folk = M.foe(t) end
    end

    -- A second kind worth naming: under three quarters of the count are the top kind.
    local second = args.targets[2] and top.n < 0.75 * F.count(args.targets) and M.foe(args.targets[2]) or nil
    if second and second.many == foe.many then second = nil end
    local voice

    local function clueAndCount(n, plainMode)
        if plainMode then
            local parts = {}
            for _, t in ipairs(args.targets) do
                local k = math.floor(t.n + 0.5)
                if k >= 1 then
                    local f = M.foe(t)
                    parts[#parts + 1] = M.number(k) .. ' ' .. (k == 1 and f.one or f.many)
                end
            end
            if #parts <= 1 or n ~= math.floor(F.count(args.targets) + 0.5) then
                local noun = n == 1 and foe.one or foe.many
                if #parts > 1 then noun = n == 1 and 'foe' or 'foes' end
                return { fill('{N} {noun} inside, at the last count.', { N = cap(M.number(n)), noun = noun }) }
            end
            local last = table.remove(parts)
            return { fill('{N} inside at the last count: {list} and {last}.',
                { N = cap(M.number(n)), list = table.concat(parts, ', '), last = last }) }
        end
        local out = {}
        out[#out + 1] = pickFresh(clues or FOES.beast.clue, rnd, args.used)
        -- Lines naming the top kind only when it is the only kind worth naming.
        local pool = {}
        if not second then
            for _, s in ipairs(counts or {}) do pool[#pool + 1] = s end
        end
        local own = (voice or VOICES.land).count
        for _, s in ipairs(own) do pool[#pool + 1] = s end
        for _, s in ipairs(voiced(n >= 8 and BIG_COUNT or GENERIC_COUNT, poster)) do pool[#pool + 1] = s end
        local g = M.guess(n, rnd)
        local line = pickFresh(pool, rnd, args.used, { g = g, G = cap(g) })
        if n >= 8 and not line:lower():find('more') then
            line = line .. ' ' .. pickFrom({ 'Expect more.', 'There will be more.', 'Likely more inside.',
                'Plan for more.', 'There are more, I am sure of it.', 'That was only the ones we saw.',
                'Count on more than that.', 'The rest were further in.' }, rnd)
        end
        out[#out + 1] = line
        if second then
            out[#out + 1] = pickFresh({ 'And there are {more} about the place too.',
                'It is not only {foes} in there, either; folk have seen {more}.', 'Watch for {more} as well.',
                'There have been {more} seen there too.', 'Mind the {more} as well.' }, rnd, args.used,
                { more = second.many, foes = foe.many })
        end
        return out
    end

    local title, story, plain, item, details, hold, askLine
    if kind == 'nest' then
        if count < 3 then return nil, 'too small a job' end
        a.Foes = cap(foe.many)
        local trades = NEST_TRADES[cls]
        if poster == 'town' then
            person = choosePerson(trades, args.used.names, rnd)
            if not person then return nil, 'no poster free' end
        end
        voice = voiceFor(poster, person)
        local open = pickFresh(NEST_OPEN[cls], rnd, args.used, a)
        local ask = pickFresh(voiced(ASK_NEST[cls], poster), rnd, args.used, a)
        askLine = ask
        local extra = {}
        if place.tomb then extra[#extra + 1] = 'Leave the ancestors in peace; only the intruders are to go.' end
        if poster == 'mages guild' and rnd(2) == 1 then
            extra[#extra + 1] = pickFresh({ 'The Guild would rather its apprentices could reach the place safely.',
                'Our apprentices have fieldwork waiting there.', 'The Guild wants the way open for its scholars.',
                'There is research to be done there, once it is safe.', 'Our scholars are waiting to get back in.',
                'The place is of some interest to the Guild.' }, rnd, args.used)
        end
        local r = { open }
        for _, s in ipairs(clueAndCount(count)) do r[#r + 1] = s end
        if rnd(2) == 1 then r[#r + 1] = pickFresh(FEEL[band], rnd, args.used) end
        r[#r + 1] = ask
        for _, s in ipairs(extra) do r[#r + 1] = s end
        local p = { open }
        for _, s in ipairs(clueAndCount(count, true)) do p[#p + 1] = s end
        p[#p + 1] = ask
        for _, s in ipairs(extra) do p[#p + 1] = s end
        story, plain = r, p
        title = fill(pickFrom(NEST_TITLE[cls], rnd), a)
    elseif kind == 'bounty' then
        if args.boss then
            -- The leader's own people: other groups in the place are not "with" them.
            local own = count
            for _, t in ipairs(args.targets) do
                if t.group == args.boss.group then own = math.floor(t.n + 0.5) end
            end
            local bossFoe = FOES[args.boss.group] or foe
            a.foes, a.one, a.deed = bossFoe.many, bossFoe.one, bossFoe.deed or a.deed
            local others = math.max(0, own - 1)
            local pr = pronouns(args.boss.female)
            for k, v in pairs(pr) do a[k] = v end
            a.Leader = args.boss.name
            local g = M.guess(others, rnd)
            a.g, a.G = g, cap(g)
            a.noun = others == 1 and bossFoe.one or bossFoe.many
            a.gn = M.guessOf(g, a.noun)
            a.Gn = cap(a.gn)
            local fitting = {}
            for _, l in ipairs(poster == 'town' and BOUNTY_TEXT or poster == 'legion' and BOUNTY_TEXT_LEGION
                or BOUNTY_TEXT_GUILD) do
                if not l.groups or l.groups[args.boss.group] then fitting[#fitting + 1] = l end
            end
            local lines = pickFrom(fitting, rnd)
            local r = { fill(lines.open, a) }
            local p = { r[1] }
            if others == 0 then
                r[#r + 1] = fill(lines.alone, a)
                p[#p + 1] = fill('{He} is alone.', a)
            else
                r[#r + 1] = fill(others == 1 and pickFrom({ 'Folk say {he} keeps one {noun} at {his} side.',
                    '{He} has one {noun} with {him}.', 'There is a {noun} with {him}, maybe two.',
                    'One {noun} goes everywhere with {him}.' }, rnd) or lines.count, a)
                p[#p + 1] = fill('{N} {noun} with {him}, at the last count.',
                    { N = cap(M.number(others)), noun = a.noun, him = a.him })
            end
            r[#r + 1] = pickFresh(bossFoe.clue or FOES.bandit.clue, rnd, args.used)
            -- Whatever else shares the place, so nobody walks in expecting only the band.
            local rest, restFoe = 0, nil
            for _, t in ipairs(args.targets) do
                if t.group ~= args.boss.group then
                    rest = rest + t.n
                    restFoe = restFoe or M.foe(t)
                end
            end
            rest = math.floor(rest + 0.5)
            if restFoe and rest >= 2 then
                local gm = M.guessOf(M.guess(rest, rnd), restFoe.many)
                r[#r + 1] = pickFresh({ 'Folk talk of {gm} in there too.', 'There are {gm} in there as well, they say.',
                    '{Gm} share the place with {who}, by all accounts.', 'Watch for {gm} about the place as well.',
                    'And it is not only people: {gm} as well, the last anyone looked.',
                    'Someone who went close heard {gm} in there besides.', 'Expect {gm} in the dark corners too.',
                    'The ones who got out say there are {gm} with them.' }, rnd, args.used,
                    { gm = gm, Gm = cap(gm), who = others == 0 and a.him or 'them' })
                p[#p + 1] = fill('{N} others inside as well, mostly {more}.', { N = cap(M.number(rest)), more = restFoe.many })
            end
            local ask = fill(lines.ask, a)
            askLine = ask
            r[#r + 1], p[#p + 1] = ask, ask
            story, plain = r, p
            title = fill(pickFrom(BOUNTY_TITLE, rnd), a)
        else
            -- The band is the top group (pick.lua); others in the place are not part of it.
            local own = math.floor(top.n + 0.5)
            if own < 3 then return nil, 'too small a band' end
            a.g = M.guess(own, rnd)
            local lines = pickFrom(BOUNTY_BAND, rnd)
            local r, p = {}, {}
            r[1] = fill(lines[1], a)
            r[2] = pickFresh(foe.clue or FOES.bandit.clue, rnd, args.used)
            r[3] = fill(lines[2], a)
            local exact = fill('{N} {foes} {placeAt}, at the last count; nobody knows who leads them.',
                { N = cap(M.number(own)), foes = foe.many, placeAt = a.placeAt })
            p[1] = exact
            p[2] = fill(lines[2], a)
            story, plain = r, p
            title = fill(pickFrom(BAND_TITLE, rnd), a)
        end
        if poster == 'town' then
            person = choosePerson(NEST_TRADES.people, args.used.names, rnd)
            if not person then return nil, 'no poster free' end
        end
        voice = voiceFor(poster, person)
    else
        local hostiles = math.floor((args.hostiles or 0) + 0.5)
        local guardians = math.floor((args.guardians or 0) + 0.5)
        -- Not worth a notice: one or two creatures, or a lone person.
        if hostiles < 2 or (hostiles < 3 and not folk) then return nil, 'too small a job' end
        local stories, family
        if place.tomb then
            family = M.tombFamily(place.n)
            if poster == 'town' and not family then return nil, 'no family for this tomb' end
            stories = poster == 'town' and RECOVERY_TOMB or RECOVERY_GUILD[poster]
        else
            stories = poster == 'town' and RECOVERY or RECOVERY_GUILD[poster]
        end
        local fitting = {}
        for _, s in ipairs(stories or {}) do
            if fits(s, a) and itemFor(s, args.freeItems, a) then fitting[#fitting + 1] = s end
        end
        if #fitting == 0 then return nil, 'no story fits ' .. a.k .. ' with ' .. a.group end
        local s = pickStory(fitting, rnd)
        item = itemFor(s, args.freeItems, a)
        if poster == 'town' then
            if family then
                if args.used.names[family] then return nil, 'that family already posted' end
                local female = rnd(2) == 1
                person = { first = pickFrom(FIRST[female and 'f' or 'm'], rnd), last = family, female = female,
                    trade = 'widow' }
                person.from = person.first .. ' ' .. family
            else
                person = choosePerson(s.trades, args.used.names, rnd)
                if not person then return nil, 'no poster free' end
            end
        end
        voice = voiceFor(poster, person)
        local owner = item.owned == 'family' and (person and person.last or town) or town
        local phrase = owner .. ' ' .. item.noun
        a.noun = item.noun
        a.item = poster == 'town' and ('my ' .. item.noun) or ('the ' .. item.noun)
        a.Item = cap(a.item)
        if place.tomb and poster == 'town' then
            a.item = 'my ' .. (item.key == 'urn' and "great-aunt's urn" or ('family ' .. item.noun:gsub('^family ', '')))
            a.Item = cap(a.item)
        end
        a.it, a.It = item.plural and 'them' or 'it', item.plural and 'They' or 'It'
        a.is, a.was = item.plural and 'are' or 'is', item.plural and 'were' or 'was'
        -- hold: 'loose' lying out deep inside, else in a chest or on one of them. A story told
        -- by someone who was there may say where it was left instead of a where line.
        local loose = args.hold == 'loose' and not a.people
        hold = loose and 'loose' or 'chest'
        local open, wherePhrase
        local told = loose and s.loose and rnd(2) == 1
        open = pickFresh(told and s.loose or s.text, rnd, args.used, a)
        if told then
            wherePhrase = nil
        elseif loose then
            wherePhrase = pickFresh(WHERE_ITEM.loose, rnd, args.used, a)
        elseif a.people then
            wherePhrase = pickFresh(WHERE_ITEM.people, rnd, args.used, a)
        elseif folk then
            wherePhrase = pickFresh({ '{It} will be in a chest somewhere inside, or on one of the {folk}.',
                'Search the chests inside, and search the {folk} too.',
                'One of the {folk} may have picked {it} up; if not, try the chests.',
                'Check the containers inside, and whatever the {folk} are carrying.' }, rnd, args.used,
                { It = a.It, it = a.it, folk = folk.many })
        else
            wherePhrase = pickFresh(WHERE_ITEM.things, rnd, args.used, a)
        end
        local ask = pickFresh(poster == 'town' and ASK_RECOVERY.town or ASK_RECOVERY.guild, rnd, args.used, a)
        local r, p = { open }, { open }
        if place.tomb then
            r[#r + 1] = pickFresh(TOMB_GUARDS, rnd, args.used)
            local gn = math.max(1, guardians)
            p[#p + 1] = fill('{N} of the tomb\'s own dead {verb} it.',
                { N = cap(M.number(gn)), verb = gn == 1 and 'guards' or 'guard' })
            local others = hostiles - guardians
            if others >= 1 and a.people then
                if others == 1 then
                    r[#r + 1] = fill('And someone has broken in; folk saw {a} go in.', { a = M.a(foe.one) })
                    p[#p + 1] = fill('One {noun} has broken in.', { noun = foe.one })
                else
                    r[#r + 1] = fill('And {foes} have broken in, {g} of them.', { foes = foe.many, g = M.guess(others, rnd) })
                    p[#p + 1] = fill('{N} {noun} have broken in.', { N = cap(M.number(others)), noun = foe.many })
                end
            end
        else
            for _, x in ipairs(clueAndCount(hostiles)) do r[#r + 1] = x end
            for _, x in ipairs(clueAndCount(hostiles, true)) do p[#p + 1] = x end
        end
        if wherePhrase then
            r[#r + 1] = wherePhrase
            p[#p + 1] = wherePhrase
        end
        r[#r + 1] = ask
        p[#p + 1] = ask
        story, plain = r, p
        local lostTitle = { 'Lost: ' .. phrase, 'Reward for the ' .. phrase, 'Wanted back: ' .. phrase }
        title = poster == 'town' and pickFrom(lostTitle, rnd) or ('Lost: the ' .. phrase)
        details = { itemPhrase = phrase, itemName = T.titleCase(phrase) }
        if loose then
            local low = open:lower()
            details.on = (low:find('table') and 'table') or (low:find('shelf') and 'shelf') or nil
        end
    end
    if args.used.titles and args.used.titles[title] then return nil, 'title already on the board' end

    -- A lead in front, some of the time, so one board does not open every notice the same way.
    -- The sign-off stays off: it was a second voice, and some of them stated a guild rule.
    voice = voice or voiceFor(poster, person)
    local roll = rnd(10)
    if roll <= 3 then
        local lead = pickFresh(voice.lead, rnd, args.used)
        table.insert(story, 1, lead)
        table.insert(plain, 1, lead)
    elseif roll <= 7 then
        pickFresh(voice.sign, rnd, args.used)
    end
    if person then
        from = person.from
    else
        from = pickFrom(GUILD_FROM[poster] or { 'the town' }, rnd)
    end
    local inside = M.inside(place)
    local where = args.where
    if inside and where then where = where .. ' Inside, make for ' .. inside .. '.' end
    return M.shorten({
        title = title, body = table.concat(story, ' '), plain = table.concat(plain, ' '), from = from,
        where = where, item = item, itemPhrase = details and details.itemPhrase,
        itemName = details and details.itemName, surname = person and person.last, trade = person and person.trade,
        story = story, ask = askLine,
        hold = hold, on = details and details.on,
    })
end

---------------------------------------------------------------------------------------------------
-- Flavour notices: no job, nothing to take. Ads, announcements and the odd joke, each one clear on
-- its own. trades: who would post it (a townsperson signs); by: a fixed signer instead; towns: only
-- on these towns' boards.

local STRIDER_TOWNS = { ['Seyda Neen'] = true, Balmora = true, Vivec = true, Suran = true, Gnisis = true,
    ['Ald-ruhn'] = true, ['Old Ebonheart'] = true, Necrom = true }
local SEA_TOWNS = { ['Seyda Neen'] = true, Ebonheart = true, ['Old Ebonheart'] = true, ['Sadrith Mora'] = true,
    Vivec = true, Firewatch = true, Necrom = true }
local CENSUS_TOWNS = { ['Seyda Neen'] = true, Ebonheart = true, Pelagiad = true, ['Old Ebonheart'] = true,
    Firewatch = true }

local FLAVOUR = {
    -- Shops and trades
    { title = 'Sale at the clothier', trades = { seamstress = 2, weaver = 2 },
      body = 'Last season\'s shirts and skirts, a third off while they last. Some are a little faded. None of them are cursed.' },
    { title = 'Letters written', trades = { clerk = 3 },
      body = 'Cannot write? I can. Letters home, petitions to the Council, love notes. Five drakes a page. Spelling is free.' },
    { title = 'Reading lessons', trades = { clerk = 2 },
      body = 'I will teach anyone in {town} to read and write for a few coins a week. Children welcome, and their parents too.' },
    { title = 'Boots mended', trades = { tanner = 3 },
      body = 'Boots and belts mended while you wait. Netch leather, guar hide, whatever you bring me. I do not ask how it got torn.' },
    { title = 'Knives sharpened', trades = { smith = 3 },
      body = 'Knives, axes and scissors sharpened, two drakes each. Swords cost more, because people complain more.' },
    { title = 'Barrels for sale', trades = { cooper = 3 },
      body = 'Good barrels, sound and dry. One leaks a little. That one is cheap.' },
    { title = 'Boat for hire', trades = { boatwright = 3 }, towns = SEA_TOWNS,
      body = 'Small boat for hire by the day. It floats. Bring a bucket anyway.' },
    { title = 'Fresh scuttle', trades = { fisherman = 1, fisher = 1, trader = 1 },
      body = 'Fresh scuttle every morning at the market. Cheaper than the tavern, and it tastes the same. Mostly.' },
    { title = 'Kwama eggs, cheap', trades = { ['egg miner'] = 3 },
      body = 'Small eggs, a little cracked, half price. They cook the same as the big ones.' },
    { title = 'Guar milk', trades = { herder = 3 },
      body = 'Fresh guar milk every morning by the east gate. It is better than it sounds.' },
    { title = 'Firewood', trades = { farmer = 2, herder = 1 },
      body = 'Dry wood by the bundle. It burns, which is more than you can say for the last lot you bought.' },
    { title = 'Saltrice bread', trades = { farmer = 3 },
      body = 'Saltrice bread, baked this morning. Ask at the farmhouse by the road. Bring your own sack.' },
    { title = 'For sale: a good mortar and pestle', trades = { smith = 1, trader = 1, clerk = 1 },
      body = 'Hardly cracked, and only a little stained. Fair offers only. Ask at the tradehouse.' },
    { title = 'Pilgrim\'s guide', trades = { pilgrim = 3 },
      body = 'Going to the shrines this month? I know the roads and the prayers. Small fee, good company, no singing.' },
    { title = 'Room to let', trades = { widow = 3 },
      body = 'Clean, dry, and only a little noisy. No smugglers, no necromancers, no Telvanni.' },
    { title = 'Porters wanted', trades = { porter = 2, trader = 1 },
      body = 'Two porters wanted to carry crates up from the docks. Fair pay. Bring your own back.' },
    { title = 'Cook wanted', trades = { trader = 1, clerk = 1 },
      body = 'The tavern needs a cook who can make something other than scuttle. Ask the publican.' },
    { title = 'Guar rides', trades = { caravaner = 3 },
      body = 'Leaving at the end of the week with two pack guar and room for one more traveller. You walk the steep bits.' },
    { title = 'Wanted: a cat', trades = { cooper = 1, tanner = 1, weaver = 1 },
      body = 'Wanted: a cat that catches rats, not one that watches them. Will pay in fish.' },
    { title = 'Dunmeri lessons', trades = { clerk = 2 },
      body = 'New to {town}? Learn enough Dunmeri to buy bread and not insult anyone. Two lessons a week, at the tavern.' },

    -- Lost, found and wanted back
    { title = 'Lost: grey guar, answers to Nibs', trades = { herder = 1, farmer = 1 },
      body = 'Wandered off from the edge of {town} two days ago. Grey, one bent horn, will eat your hat. If you see him, walk him back to the stables. He likes salt.' },
    { title = 'Found: a brown guar', trades = { farmer = 3 },
      body = 'A brown guar has been eating my garden for three days. If he is yours, come and get him. If he is nobody\'s, he is mine now.' },
    { title = 'Lost: a pet scrib', trades = { ['egg miner'] = 2 },
      body = 'Small, friendly, answers to Pip. If you find him, bring him to me at the market. Please do not step on him.' },
    { title = 'Found: one boot', trades = { porter = 1, herder = 1 },
      body = 'Found on the road outside {town}: one good boot, left foot, hardly worn. The owner can have it back if they can say what is scratched inside the heel.' },
    { title = 'Lost: my hat', trades = { herder = 1, scout = 1, caravaner = 1 },
      body = 'Brown felt hat with a feather in the band. A cliff racer took it off my head on the north road. If it drops it, I want it back.' },
    { title = 'Lost: a ring of keys', trades = { porter = 2, clerk = 1 },
      body = 'Three keys on a leather loop. They open nothing you would want. Leave them with the publican, please.' },
    { title = 'Return my ladder', trades = { cooper = 1, smith = 1, tanner = 1 },
      body = 'To whoever borrowed my ladder: I know it was you. Bring it back and we will say no more about it.' },
    { title = 'Who took the bench?', trades = { cooper = 1, porter = 1 },
      body = 'There was a bench outside the tavern. Now there is not. It was not a gift. Bring it back.' },

    -- Warnings
    { title = 'Do not play dice with the Bosmer', trades = { trader = 1, porter = 1, caravaner = 1 },
      body = 'A wood elf in a green hood has won every game of dice at the tavern this week. The dice are his own. Nobody has seen him lose. Do not play with him.' },
    { title = 'Bad mazte', trades = { clerk = 1, trader = 1 },
      body = 'Someone has been selling mazte from a cart by the gate. It is mostly water, and some of it is not water. Do not buy it.' },
    { title = 'He is not a moneylender', trades = { clerk = 2 },
      body = 'A man calling himself a moneylender is going door to door. He has no money. Do not give him yours.' },
    { title = 'Mind the cliff racers', trades = { scout = 1, caravaner = 1, porter = 1 },
      body = 'Cliff racers have been diving at people on the road out of {town}. Wear a hat. Carry a stick.' },
    { title = 'Ash storm coming', trades = { scout = 2, herder = 2 },
      body = 'The herders say an ash storm is coming in from the east. Cover your water and keep your guar inside.' },
    { title = 'Stop feeding the scribs', trades = { clerk = 1, ['egg miner'] = 1 },
      body = 'Whoever is feeding the scribs behind the tradehouse: they now follow everyone home. Please stop.' },
    { title = 'To whoever leaves the fish heads', trades = { clerk = 1, trader = 1 },
      body = 'Whoever keeps leaving fish heads behind the stalls: stop it. The smell has reached the shrine, and the priests have noticed.' },
    { title = 'To the singer at the tavern', trades = { cooper = 1, tanner = 1, clerk = 1 },
      body = 'To the man who sang at the tavern last night: we heard you. All of us. Please practise somewhere else.' },

    -- Orders and announcements
    { title = 'No swimming in the canals', by = 'the Canton Watch', towns = { Vivec = true },
      body = 'By order of the Ordinators: no swimming in the canals. This means you. The slaughterfish have been fed enough this year.' },
    { title = 'No washing in the Odai', by = 'the Balmora Guard', towns = { Balmora = true },
      body = 'The Odai is not a bath. Anyone washing in the river by the bridges will be fined.' },
    { title = 'Sign the register', by = 'the Census and Excise Office', towns = CENSUS_TOWNS,
      body = 'Every new arrival must sign the register at the Census and Excise Office. Yes, even you.' },
    { title = 'Strider seats', trades = { caravaner = 3 }, towns = STRIDER_TOWNS,
      body = 'The strider is full on Morndas again. Book your seat a day early, or bring a good book for the wait.' },
    { title = 'Mudcrab races', trades = { fisherman = 2, fisher = 2 }, towns = SEA_TOWNS,
      body = 'Mudcrab races on the beach at low tide, Sundas. Bring a crab or bet on one. Last week\'s winner has retired.' },
    { title = 'Fishing contest', trades = { fisherman = 2, fisher = 2, boatwright = 1 }, towns = SEA_TOWNS,
      body = 'Biggest fish caught off the docks by Fredas wins a jug of mazte. Slaughterfish do not count. Neither do boots.' },
    { title = 'A wedding', trades = { pilgrim = 1, widow = 1, weaver = 1 },
      body = 'Tirala and Rels are to be married at the shrine on Morndas. Everyone is welcome. Bring your own cup.' },
    { title = 'Music at the tavern', trades = { porter = 1, trader = 1, weaver = 1 },
      body = 'There will be singing at the tavern on Fredas night. Bring a voice, or at least bring coin for the singers.' },
    { title = 'Prayers for the sick', trades = { pilgrim = 2, widow = 1 },
      body = 'We will pray for the sick at the shrine each morning this week. All are welcome, and nobody will be asked for coin.' },
    { title = 'Alms for the poor', trades = { pilgrim = 2, widow = 1 },
      body = 'The Temple is collecting for the poor of {town}. Old clothes, blankets, coin. Leave them at the shrine.' },
    { title = 'Taxes, again', trades = { trader = 1, caravaner = 1, smith = 1 },
      body = 'The tax man came round twice this month. Twice. If anyone knows what we are paying for, write it underneath.' },

    -- People
    { title = 'Thank you', trades = { fisherman = 1, fisher = 1, boatwright = 1 },
      body = 'To the stranger who pulled my son out of the water last week: thank you. You would not take coin, so I am telling everyone instead.' },
    { title = 'An apology', trades = { porter = 1, cooper = 1, tanner = 1 },
      body = 'I was not myself at the tavern last Loredas. If it was you I insulted, I am sorry. If it was you I paid, I would like it back.' },
    { title = 'Seeking a companion', trades = { tanner = 1, smith = 1, ['egg miner'] = 1 },
      body = 'Honest, hard-working, own teeth. Seeks someone patient who does not mind the smell of the trade. Leave a note with the publican.' },
    { title = 'To my neighbour', trades = { farmer = 1, herder = 1 },
      body = 'To my neighbour: your guar is lovely. It is also in my house. Again.' },
}
M.FLAVOUR = FLAVOUR

-- One flavour notice for a board. args: { town, used (as for build), rnd }. Returns { title, body,
-- plain, from, surname, flavour = true } or nil when every one is on the board or no poster is free.
function M.flavour(args)
    local rnd, used = args.rnd, args.used
    -- One not on the board and not among its recent notices, so they rarely repeat.
    local fresh, other = {}, {}
    for _, f in ipairs(FLAVOUR) do
        if (not f.towns or f.towns[args.town]) and not (used.titles and used.titles[f.title]) then
            local probe = f.body:match('^([^{]*)')
            local seen = false
            for _, body in ipairs(used.bodies or {}) do
                if body:find(probe:sub(1, 30), 1, true) then seen = true break end
            end
            local into = seen and other or fresh
            into[#into + 1] = f
        end
    end
    local pool = #fresh > 0 and fresh or other
    if #pool == 0 then return nil end
    local f = pool[rnd(#pool)]
    local from, surname
    if f.by then
        from = cap(f.by)
    else
        local person = choosePerson(f.trades, used.names, rnd)
        if not person then return nil end
        from, surname = person.from, person.last
    end
    local body = fill(f.body, { town = args.town })
    return { title = f.title, body = body, plain = body, from = from, surname = surname, flavour = true }
end

---------------------------------------------------------------------------------------------------
-- The contract log once the player has been inside: plain details. count: what was really there
-- and standing on first entry; the kinds come from the place's data at the contract's level, named
-- only as "mostly" when the data's numbers don't match what was found. all: every hostile (a
-- recovery, tomb guardians included) rather than only the job's targets.
function M.contractDetails(place, level, count, leader, all)
    if count <= 0 then return 'Nothing inside was still standing when you got there.' end
    local list = {}
    for _, e in ipairs(place.e or {}) do
        local n = 0
        local L = C.TIER_LEVELS
        local ns = e[2]
        if level <= L[1] then n = ns[1] elseif level >= L[3] then n = ns[3] else
            local i = level <= L[2] and 1 or 2
            n = ns[i] + (ns[i + 1] - ns[i]) * (level - L[i]) / (L[i + 1] - L[i])
        end
        if (all or not place.tomb or F.INTRUDERS[e[1]]) and n >= 0.5 then
            list[#list + 1] = { group = e[1], word = e[3], n = math.floor(n + 0.5) }
        end
    end
    table.sort(list, function(x, y) return x.n > y.n end)
    local sum = 0
    for _, t in ipairs(list) do sum = sum + t.n end
    local top = list[1] and M.foe(list[1])
    local s
    if not top then
        s = fill('Inside: {n} in all', { n = M.number(count) })
    elseif #list == 1 or sum ~= count then
        local noun = count == 1 and top.one or top.many
        if #list > 1 then
            s = fill('Inside: {n} in all, mostly {foes}', { n = M.number(count), foes = top.many })
        else
            s = fill('Inside: {n} {noun}', { n = M.number(count), noun = noun })
        end
    else
        local parts = {}
        for _, t in ipairs(list) do
            local f = M.foe(t)
            parts[#parts + 1] = M.number(t.n) .. ' ' .. (t.n == 1 and f.one or f.many)
        end
        local last = table.remove(parts)
        s = fill('Inside: {n} in all, {list} and {last}', { n = M.number(count), list = table.concat(parts, ', '), last = last })
    end
    if leader then s = s .. ', led by ' .. leader end
    return s .. '.'
end

return M
