---@omw-context global
-- Odd Jobs: everything a job puts into the world, under the five spawn rules (Harsh Measures report).
--  1. The saved list gets each object in the same call that creates it, before it is placed.
--  2. Every actor carries spawn.lua; it reports death and, when its cell loads, its job and
--     generation, so a spawn whose job is gone is removed then.
--  3. Removal holds the object and calls remove() whether or not its cell is loaded; a handle that
--     isn't valid yet waits on a retry list (no getAll sweeps).
--  4. Positions come from the player script's navmesh search (spots.lua), never guessed here.
--  5. Caps: per job by tier and across all of Odd Jobs; creation is batched PER_FRAME a frame.

local async = require('openmw.async')
local types = require('openmw.types')
local util = require('openmw.util')
local world = require('openmw.world')

local C = require('scripts.ojb.config')

local M = {}

-- ctx: S() saved state, now(), log(fmt, ...), say(fmt, ...).
function M.new(ctx)
    local SP = {}
    local SC = C.SPAWN

    local function state()
        local S = ctx.S()
        S.spawns = S.spawns or {}     -- owner -> { tier, list = { { obj, kind = 'actor'|'prop'|'changed', role } } }
        S.corpses = S.corpses or {}   -- { obj, day }: our dead, taken away CORPSE_DAYS after their job ended
        S.spawnRetry = S.spawnRetry or {}   -- objects to remove whose handle wasn't valid yet
        S.recs = S.recs or {}         -- template .. '|' .. name -> created record id
        return S
    end

    local function key(owner) return tostring(owner) end

    local function isDead(o)
        return types.Actor.objectIsInstance(o) and types.Actor.isDead(o)
    end

    -- Actors of ours alive now, across every job; and for one job.
    function SP.alive(owner)
        local S, n = state(), 0
        for k, job in pairs(S.spawns) do
            if owner == nil or k == key(owner) then
                for _, e in ipairs(job.list) do
                    if e.kind == 'actor' and e.obj:isValid() and e.obj.count > 0 and not isDead(e.obj) then n = n + 1 end
                end
            end
        end
        return n
    end

    local function props()
        local n = 0
        for _, job in pairs(state().spawns) do
            for _, e in ipairs(job.list) do
                if e.kind == 'prop' then n = n + 1 end
            end
        end
        return n
    end

    -- How many more actors this job may have alive.
    function SP.room(owner, tier)
        local per = SC.PER_JOB[tier or 'normal'] or SC.PER_JOB.normal
        return math.max(0, math.min(per - SP.alive(owner), SC.MAX_ALIVE - SP.alive()))
    end

    local function jobOf(owner, tier)
        local S = state()
        local job = S.spawns[key(owner)]
        if not job then
            job = { tier = tier or 'normal', list = {} }
            S.spawns[key(owner)] = job
        end
        return job
    end

    function SP.list(owner)
        local job = state().spawns[key(owner)]
        return job and job.list or {}
    end

    -- A record of our own made from a template, named; one per template and name, kept for good
    -- (records stay in the save), so the same champion or title never makes a second one.
    -- head: a body-part id read off another NPC of the same race. Only the contract leader
    -- passes one. If the engine ignores the field, the face stays the template's.
    function SP.record(template, name, t, head)
        local S = state()
        local k = template .. '|' .. name .. (head and ('|' .. head) or '')
        if S.recs[k] then return S.recs[k] end
        t = t or (types.NPC.records[template] and types.NPC or types.Creature)
        local base = t.records[template]
        if not base then return nil end
        local draft = { template = base, name = name }
        if head and head ~= '' then draft.head = head end
        local id = world.createRecord(t.createRecordDraft(draft)).id
        S.recs[k] = id
        return id
    end

    local function place(obj, cellName, pos, yaw)
        obj:teleport(cellName, util.vector3(pos.x, pos.y, pos.z), { rotation = util.transform.rotateZ(yaw or 0),
            onGround = true })
    end

    -- One actor now. spec: { id, cell, pos, yaw, items = { id or {id, n} }, act = {...}, role }.
    -- Returns the object, or nil and why.
    function SP.actor(owner, tier, spec)
        if SP.room(owner, tier) <= 0 then return nil, 'spawn cap' end
        local job = jobOf(owner, tier)
        local obj = world.createObject(spec.id)
        job.list[#job.list + 1] = { obj = obj, kind = 'actor', role = spec.role }
        place(obj, spec.cell, spec.pos, spec.yaw)
        local inv = types.Actor.inventory(obj)
        -- The template's weapon and armour come off before the job's own pieces go on,
        -- so the old spear does not stay in the pocket. Clothes are left as they were.
        if spec.strip then
            inv:resolve()
            for _, it in ipairs(inv:getAll()) do
                if it.type == types.Weapon or it.type == types.Armor then it:remove() end
            end
        end
        for _, it in ipairs(spec.items or {}) do
            local id, n = it, 1
            if type(it) == 'table' then id, n = it[1], it[2] end
            world.createObject(id, n):moveInto(inv)
        end
        obj:addScript(SC.SCRIPT, { owner = key(owner), gen = SC.GEN, act = spec.act,
            strip = spec.strip or false, tier = tier })
        return obj
    end

    -- Second strip, once the actor's cell has loaded and the template's own items are in the
    -- inventory. The first strip can run before resolve() has filled it.
    function SP.stripLoaded(actor, tier)
        if not actor or not actor:isValid() then return end
        local inv = types.Actor.inventory(actor)
        inv:resolve()
        local classCap = C.THREAT.GEAR_CLASS[tier or 'normal'] or C.THREAT.GEAR_CLASS.normal
        local armorCap = C.THREAT.GEAR_ARMOR[tier or 'normal'] or C.THREAT.GEAR_ARMOR.normal
        local ST = require('scripts.ojb.data.strength')
        for _, it in ipairs(inv:getAll()) do
            local rec = it.type and it.type.record and it.type.record(it)
            local enchant = rec and rec.enchant and rec.enchant ~= ''
            local ammo = false
            if it.type == types.Weapon and rec then
                ammo = rec.type == types.Weapon.TYPE.Arrow or rec.type == types.Weapon.TYPE.Bolt
            end
            local over = false
            if it.type == types.Weapon or it.type == types.Armor then
                local known = ST.item[(it.recordId or ''):lower()]
                local wc = known and known.wc or 0
                local id = (rec and rec.id or it.recordId or ''):lower()
                if wc == 0 then
                    if id:find('glass', 1, true) or id:find('ebony', 1, true) or id:find('daedric', 1, true) then wc = 22
                    elseif id:find('orcish', 1, true) or id:find('dwarven', 1, true) or id:find('dwemer', 1, true) then wc = 12
                    elseif id:find('silver', 1, true) or id:find('bonemold', 1, true) then wc = 8
                    end
                end
                if it.type == types.Armor then
                    local v = (known and known.v) or (rec and rec.value) or 0
                    if v > armorCap then over = true end
                elseif wc > classCap then
                    over = true
                end
            end
            local dearAmmo = ammo and (enchant or (rec and (rec.value or 0) or 0) > C.THREAT.AMMO_VALUE)
            if enchant or dearAmmo or over then it:remove() end
        end
    end

    -- A prop: a cart, a crate, a fire. Containers come out of the template empty.
    function SP.prop(owner, spec)
        if props() >= SC.PROPS_MAX then return nil, 'prop cap' end
        local job = jobOf(owner, spec.tier)
        local obj = world.createObject(spec.id)
        job.list[#job.list + 1] = { obj = obj, kind = 'prop', role = spec.role }
        place(obj, spec.cell, spec.pos, spec.yaw)
        if spec.scale then obj:setScale(spec.scale) end
        if obj.type == types.Container then
            local inv = types.Container.content(obj)
            inv:resolve()
            for _, it in ipairs(inv:getAll()) do it:remove() end
        end
        return obj
    end

    -- An actor that was already there (a leader who may surrender, a group something worse killed):
    -- the script goes on, and comes off again when the job ends; the actor stays.
    function SP.change(owner, actor, act)
        local job = jobOf(owner)
        local known = false
        for _, e in ipairs(job.list) do
            if e.obj == actor then known = true end
        end
        if not known then job.list[#job.list + 1] = { obj = actor, kind = 'changed' } end
        if actor:hasScript(SC.SCRIPT) then
            if act then actor:sendEvent('OJB_Do', act) end
        else
            actor:addScript(SC.SCRIPT, { owner = key(owner), gen = SC.GEN, ours = false, act = act })
        end
    end

    function SP.tell(actor, act)
        if actor:isValid() and actor:hasScript(SC.SCRIPT) then actor:sendEvent('OJB_Do', act) end
    end

    -- Queued creation, PER_FRAME a frame. Runtime only: a save in between keeps what was made
    -- (it's on the saved list) and drops the rest. done(obj, spec) is called for each one made.
    local queue, pumping = {}, false
    local function pump()
        pumping = false
        for _ = 1, SC.PER_FRAME do
            local q = table.remove(queue, 1)
            if not q then return end
            local obj, why = SP.actor(q.owner, q.tier, q.spec)
            if obj then
                if q.done then q.done(obj, q.spec) end
            else
                ctx.log('spawn for %s skipped: %s (%s)', key(q.owner), why, q.spec.id)
            end
        end
        if #queue > 0 then
            pumping = true
            async:newUnsavableSimulationTimer(0, pump)
        end
    end
    function SP.queue(owner, tier, specs, done)
        for _, spec in ipairs(specs) do queue[#queue + 1] = { owner = owner, tier = tier, spec = spec, done = done } end
        if not pumping then pump() end
    end
    function SP.queued() return #queue end

    local function removeObj(o)
        if o:isValid() then
            if o.count > 0 then o:remove() end
            return true
        end
        return false
    end

    -- The job is over. Our living spawns go now; our dead stay CORPSE_DAYS so their loot can be taken;
    -- props go now; originals lose the script and keep everything else.
    function SP.release(owner)
        local S = state()
        local job = S.spawns[key(owner)]
        if not job then return 0 end
        local n = 0
        for _, e in ipairs(job.list) do
            local o = e.obj
            if e.kind == 'changed' then
                if o:isValid() and o:hasScript(SC.SCRIPT) then o:removeScript(SC.SCRIPT) end
            elseif e.kind == 'actor' and o:isValid() and isDead(o) then
                S.corpses[#S.corpses + 1] = { obj = o, day = ctx.now() }
            elseif not removeObj(o) then
                S.spawnRetry[#S.spawnRetry + 1] = o
            end
            n = n + 1
        end
        S.spawns[key(owner)] = nil
        for i = #queue, 1, -1 do
            if key(queue[i].owner) == key(owner) then table.remove(queue, i) end
        end
        ctx.log('spawns of %s released: %d', key(owner), n)
        return n
    end

    function SP.owners()
        local out = {}
        for k in pairs(state().spawns) do out[#out + 1] = k end
        return out
    end

    -- Periodic (nearTick): corpses due, handles that turned valid. Bounded by the caps.
    function SP.sweep()
        local S = state()
        local day = ctx.now()
        local keep = {}
        for _, c in ipairs(S.corpses) do
            if day - c.day >= SC.CORPSE_DAYS then
                if not removeObj(c.obj) then S.spawnRetry[#S.spawnRetry + 1] = c.obj end
            else
                keep[#keep + 1] = c
            end
        end
        S.corpses = keep
        local retry = {}
        for _, o in ipairs(S.spawnRetry) do
            if not removeObj(o) then retry[#retry + 1] = o end
        end
        S.spawnRetry = retry
    end

    -- Rule 2: a tracked spawn's cell loaded. One whose job is gone, or from an older generation of
    -- the rules, is removed.
    function SP.onActive(e)
        local a = e.actor
        if not a or not a:isValid() then return end
        local job = state().spawns[e.owner or '']
        local stale = (e.gen or 0) < SC.GEN or not job
        if not stale then return end
        if e.ours == false then
            if a:hasScript(SC.SCRIPT) then a:removeScript(SC.SCRIPT) end
        elseif a.count > 0 then
            ctx.log('stale spawn %s of %s removed', a.recordId, tostring(e.owner))
            a:remove()
        end
    end

    -- Rule 4: spots come from the player script. One answer per id; runtime only, so a reload drops
    -- the question and the asker sees waiting() turn false and asks again.
    local asks = {}
    function SP.ask(player, id, req, done)
        req.id = id
        asks[id] = done
        player:sendEvent('OJB_FindSpawnSpots', req)
    end
    function SP.waiting(id) return asks[id] ~= nil end
    -- On load: the player script's searches are gone with the old session, so are their questions.
    function SP.forget() asks = {} end
    function SP.onSpots(e)
        local done = asks[e.id]
        if not done then return end
        asks[e.id] = nil
        ctx.log('spawn spots for %s: %d found, %d rays, %d frames, %.1f ms (worst %.1f)%s', tostring(e.id),
            #(e.spots or {}), e.rays or 0, e.frames or 0, e.ms or 0, e.maxMs or 0,
            (e.tried and e.tried ~= '') and ('; rejected: ' .. e.tried) or '')
        done(e)
    end

    function SP.counts()
        local S = state()
        local jobs = 0
        for _ in pairs(S.spawns) do jobs = jobs + 1 end
        local scripts = 0
        for _, job in pairs(S.spawns) do
            for _, e in ipairs(job.list) do
                if e.kind == 'actor' or e.kind == 'changed' then scripts = scripts + 1 end
            end
        end
        return { alive = SP.alive(), props = props(), jobs = jobs, corpses = #S.corpses, retry = #S.spawnRetry,
            scripts = scripts,
            records = (function() local n = 0 for _ in pairs(S.recs) do n = n + 1 end return n end)() }
    end

    -- Everything, now: the settings page's "remove Odd Jobs spawns" and uninstall.
    function SP.releaseAll()
        local n = 0
        for _, k in ipairs(SP.owners()) do n = n + SP.release(k) end
        local S = state()
        for _, c in ipairs(S.corpses) do
            if not removeObj(c.obj) then S.spawnRetry[#S.spawnRetry + 1] = c.obj end
        end
        S.corpses = {}
        return n
    end

    return SP
end

return M
