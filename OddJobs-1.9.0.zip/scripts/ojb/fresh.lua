---@omw-context runtime
-- Pure: how much a job kind weighs after the player has done one. A kind just finished weighs
-- nothing and climbs back to 1 over C.FRESH.RECOVER days. A board's last posted kind weighs 0
-- (never the same kind twice in a row). Until C.FRESH.SAMPLE jobs are finished, kinds the player
-- has not done yet weigh C.FRESH.SAMPLE_W. Cached-absence: a missing day or done flag means full
-- weight (the kind has not been finished).

local C = require('scripts.ojb.config')

local M = {}

-- fresh: { last, done, finished, at, now }. last: the board's last posted kind. done: kind -> true.
-- at: kind -> day last finished. now: the current game day. Returns a multiplier; 0 means skip.
function M.weight(kind, fresh)
    if not fresh or not kind then return 1 end
    if fresh.last == kind then return 0 end
    local w = 1
    local day = fresh.at and fresh.at[kind]
    if day and fresh.now then
        local age = fresh.now - day
        local recover = C.FRESH.RECOVER
        if age < recover then w = w * math.max(0, age / recover) end
    end
    if (fresh.finished or 0) < C.FRESH.SAMPLE and not (fresh.done and fresh.done[kind]) then
        w = w * C.FRESH.SAMPLE_W
    end
    return w
end

-- The kind a finished contract counts as: a wild type's own name, else nest / bounty / recovery / req.
function M.kindOf(c)
    if not c then return nil end
    if c.wild and c.wild.type then return c.wild.type end
    if c.kind == 'req' or c.flavour then return c.kind end
    return c.kind
end

return M
