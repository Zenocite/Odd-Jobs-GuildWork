---@omw-context global
-- Requisitions at runtime: posting them on boards, handing goods in at the board, payment, and
-- the theft ledger that keeps stolen goods out. The picking, pay and words are in
-- req.lua (pure). global.lua makes one instance with M.new(ctx); ctx's helpers are read when
-- called, so global.lua can fill them in after defining them.

local async = require('openmw.async')
local core = require('openmw.core')
local types = require('openmw.types')
local util = require('openmw.util')
local world = require('openmw.world')
local I = require('openmw.interfaces')

local C = require('scripts.ojb.config')
local N = require('scripts.ojb.names')
local Q = require('scripts.ojb.req')
local ST = require('scripts.ojb.story')
local SUP = require('scripts.ojb.data.supply')

local GOLD = 'gold_001'

local M = {}

-- ctx: S() (saved state), DEFS, COMPANY, featureOn (tables, read live), and functions now, log,
-- say, tell, hasFile, itemName, playerLevel, postersOf, rewardText, townOf, grantRep,
-- syncPapers, placedSites, removeAll, makeItem, furnitureWord, sendBoard.
function M.new(ctx)
    local api = {}
    local openedContainer = nil -- { counts } while the player has an owned container open
    local pendingBook = nil     -- { obj, id, had } an owned book the player opened, until settled

    function api.openReqs(b)
        local n = 0
        for _, x in ipairs(b.notices or {}) do
            if x.kind == 'req' then n = n + 1 end
        end
        return n
    end

    -- Saves from before 1.8.9 may hold a requisition crate beside a site's notices; goods are
    -- handed in at the board now, so it comes away the next time the site is placed or synced.
    function api.dropCrate(holder)
        if not holder.crate then return end
        ctx.removeAll({ holder.crate }, holder.spot)
        holder.crate = nil
    end

    -- The site carrying the board's full set of notices, or nil while the board isn't placed.
    local function mainSpot(b)
        for _, s in ipairs(ctx.placedSites(b)) do
            if not s.site.second and s.site.spot then return s.site.spot end
        end
    end

    -----------------------------------------------------------------------------------------------
    -- Posting (req.lua picks; offline supply data, no cell loads)

    local function townKeyOf(key)
        local S = ctx.S()
        local d = ctx.DEFS[key] or ctx.DEFS[S.boards[key] and S.boards[key].originKey or '']
        return d and d.town.key
    end

    local function townHasCollector(tkey)
        for k, b in pairs(ctx.S().boards) do
            if townKeyOf(k) == tkey then
                for _, n in ipairs(b.notices or {}) do
                    if n.kind == 'req' and n.sub == 'collect' then return true end
                end
            end
        end
        return false
    end

    -- A townsperson of that trade from story.lua's names, to sign a smith's or trader's request.
    local function signerOf(trades)
        local open = {}
        for _, s in ipairs(ST.townsfolk()) do
            for _, t in ipairs(trades) do
                if s:sub(-#t - 2) == ', ' .. t then open[#open + 1] = s end
            end
        end
        return #open > 0 and open[math.random(#open)] or nil
    end

    -- The skill a trainer in this town would teach the player, within normal limits: below the
    -- trainer's own skill and the skill's governing attribute; guild requests only in the guild's
    -- skills. Returns skill id, price, trainer name.
    local function trainerFor(player, tkey, faction)
        local town = SUP.towns[tkey or '']
        if not town then return nil end
        local only
        local frec = faction and core.factions.records[faction]
        if frec then
            only = {}
            for _, s in ipairs(frec.skills) do only[s] = true end
        end
        local best
        for _, t in ipairs(town.trainers or {}) do
            for _, sk in ipairs(t.skills) do
                local id, most = sk[1], sk[2]
                local stat, rec = types.NPC.stats.skills[id], core.stats.Skill.records[id]
                if stat and rec and (not only or only[id]) then
                    local v = stat(player).base
                    local attr = types.Actor.stats.attributes[rec.attribute]
                    local limit = math.min(most, attr and attr(player).base or 100, 100)
                    if v < limit and (not best or v > best.v) then best = { id = id, v = v, trainer = t.name } end
                end
            end
        end
        if not best then return nil end
        return best.id, best.v * (core.getGMST('iTrainingMod') or 10), best.trainer
    end

    -- Training stands in for part of the gold on rare orders, souls and collectors, at its price.
    local function reqReward(n, player, tkey, faction)
        local reward = { gold = n.value, items = {}, supplies = 0, training = false, value = n.value }
        if n.grade ~= 'rare' or not ctx.featureOn.reqTraining then
            return reward
        end
        local skill, price, trainer = trainerFor(player, tkey, faction)
        if skill and price <= n.value * (1 - C.TRAINING_SHARE) then
            reward.gold, reward.training, reward.trainer, reward.price = n.value - price, true, trainer, price
            return reward, skill
        end
        return reward
    end

    function api.switchedOn(n)
        local on = ctx.featureOn
        if n.sub == 'company' then return on.companyReqs end
        if n.sub == 'collect' then return on.collectors end
        if n.sub == 'lost' then return on.lostLedgers end
        return on.requisitions
    end

    -- Whether a requisition still belongs on a board: not too old, and its kind switched on.
    function api.keeps(n)
        if n.kind ~= 'req' then return false end
        if ctx.now() - (n.postedAt or 0) >= C.REQ.KEEP_DAYS then return false end
        return api.switchedOn(n)
    end

    -- A notice coming down: a lost ledger still lying in the street goes with it. One the player
    -- picked up stays theirs.
    function api.discard(n)
        local o = n.sub == 'lost' and n.obj
        if o and o:isValid() and o.count > 0 and o.cell then o:remove() end
    end

    -- Goods sold in a town's nearby board towns. Key: town key; lifetime: the session (supply.lua
    -- is static data); a town with no neighbours caches an empty set.
    local regionCache = {}
    local function regionOf(tkey)
        local r = regionCache[tkey]
        if r then return r end
        r = {}
        for _, k in ipairs((SUP.towns[tkey] or {}).near or {}) do
            for id in pairs((SUP.towns[k] or {}).sells or {}) do r[id] = true end
        end
        regionCache[tkey] = r
        return r
    end

    -- How filled soul gems are priced, for req.soulWorth. The gem records and fSoulgemMult are read
    -- once a session (static data). Economy Plus's soul bands are read once too; when it isn't
    -- installed the cache holds false and souls go by ctx.soulMode, the player's match for
    -- OpenMW's "rebalance soul gem values" (Lua can't read engine settings).
    local GEM_IDS = { 'misc_soulgem_petty', 'misc_soulgem_lesser', 'misc_soulgem_common', 'misc_soulgem_greater',
        'misc_soulgem_grand' }
    local gemList, economyBands
    function api.soulOpts()
        if not gemList then
            local mult = core.getGMST('fSoulgemMult') or 3
            gemList = {}
            for i, id in ipairs(GEM_IDS) do
                local rec = types.Miscellaneous.records[id]
                local value = rec and rec.value or C.REQ.SOUL_GEMS[i].value
                gemList[i] = { cap = math.floor(value * mult + 0.5), value = value }
            end
        end
        if economyBands == nil then
            economyBands = false
            if I.EconomyTheft then
                -- Probing: Economy Plus is a separate mod and its module layout may change; if its
                -- rules can't be loaded, souls are priced by the engine's formula instead.
                local ok, R = pcall(require, 'scripts.economy.rules')
                if ok and type(R) == 'table' and type(R.SOUL_BANDS) == 'table' then economyBands = R.SOUL_BANDS end
            end
        end
        return { mode = ctx.soulMode or 'vanilla', gems = gemList, bands = economyBands or nil }
    end

    -- What a piece of goods is worth for an order's pay: Economy Plus's model price when it is
    -- installed (its shops sell near that, so pay keeps pace with what the goods cost), else the
    -- record's value. The price table is Economy Plus's own static data, looked up by record id for
    -- the session; false when Economy Plus is absent, and an id it doesn't price keeps base.
    local economyPrices
    function api.worthOf(id, base)
        if economyPrices == nil then
            economyPrices = false
            if I.EconomyTheft then
                -- Probing: as with the soul bands; without the price table, goods go by record value.
                local ok, P = pcall(require, 'scripts.economy.prices')
                if ok and type(P) == 'table' then economyPrices = P end
            end
        end
        local p = economyPrices and economyPrices[id:lower()]
        return (type(p) == 'number' and p > 0) and p or base
    end

    -- Which orders a board keeps open: 'guild' (guild halls, Temples, forts), 'company', 'town',
    -- 'village' (one common order, signed as a trader: the inn's kitchen and cellar).
    local function boardKind(key)
        if ctx.COMPANY[key] then return 'company' end
        local d = ctx.DEFS[key]
        if d and d.def.village then return 'village' end
        return ctx.postersOf(key)[1] == 'town' and 'town' or 'guild'
    end

    -- One requisition of a grade for the board, or nil, why.
    local function makeOne(key, player, grade, poster)
        local S = ctx.S()
        local b = S.boards[key]
        local on = ctx.featureOn
        local tkey = townKeyOf(key)
        local town = SUP.towns[tkey or ''] or { sells = {} }
        local d = ctx.DEFS[key] or ctx.DEFS[b.originKey]
        local used, usedText = {}, {}
        for _, ob in pairs(S.boards) do
            for _, n in ipairs(ob.notices or {}) do
                for _, l in ipairs(n.lines or { n.want }) do
                    if l and l.id then used[l.id] = true end
                end
            end
        end
        for _, s in ipairs(b.recent or {}) do usedText[s] = true end
        local a = { grade = grade, town = d.town.name, goods = SUP.goods, souls = SUP.souls, collect = SUP.collect,
            sells = town.sells, region = regionOf(tkey or ''), used = used, usedText = usedText, have = ctx.hasFile,
            name = ctx.itemName, rnd = math.random, shopOf = ctx.shopOf and function(id) return ctx.shopOf(tkey, id) end,
            soulOpts = api.soulOpts(), worth = api.worthOf }
        local n, why
        if poster == 'company' then
            if not on.companyReqs then return nil, 'company orders off' end
            a.company = ctx.COMPANY[key]
            n, why = Q.company(a)
        elseif poster == 'collector' then
            a.collector = town.collectors[math.random(#town.collectors)]
            n, why = Q.collector(a)
        else
            if not on.requisitions then return nil, 'requisitions off' end
            if poster == 'smith' then a.from = signerOf({ 'smith' }) end
            if poster == 'trade' then a.from = signerOf({ 'trader', 'caravaner' }) end
            if poster == 'legion' then a.from = b.signer or d.def.signer end
            a.poster = poster
            if poster == 'mages guild' and math.random() < C.REQ.SOUL_SHARE then
                n, why = Q.soul(a)
            else
                n, why = Q.order(a)
            end
        end
        if not n then return nil, why end
        local faction = C.GUILDS[poster] and poster or nil
        -- slot: the grade asked for, which a bulk harvest lot (shown as common) still fills.
        n.id, n.kind, n.poster, n.slot = S.nextId, 'req', faction or poster, grade
        S.nextId = S.nextId + 1
        n.reward, n.skill = reqReward(n, player, tkey, faction)
        n.postedAt = ctx.now()
        local what = {}
        for _, l in ipairs(n.lines or { n.want }) do
            what[#what + 1] = string.format('%d x %s at %d', l.count or 1, l.id or l.creature or ('soul ' .. tostring(l.soul)),
                l.each or n.value)
        end
        ctx.say('%s: requisition %d (%s %s %s): %s, pays %d (worth %d)%s', key, n.id, n.sub, n.grade or '-',
            n.group or '-', table.concat(what, ', '), n.value, n.worth or 0, n.skill and (', training ' .. n.skill) or '')
        return n
    end

    -- Posts new requisitions on the board up to its share (C.REQ.ORDERS), each grade by its own
    -- count, and returns them. A town board sometimes posts a collector's request in place of a
    -- common order.
    function api.fill(key, player)
        local S = ctx.S()
        local b = S.boards[key]
        local out = {}
        if not mainSpot(b) then return out end
        local kind = boardKind(key)
        local want = C.REQ.ORDERS[kind]
        local have = { common = 0, rare = 0 }
        for _, n in ipairs(b.notices or {}) do
            if n.kind == 'req' and n.sub ~= 'lost' then
                local g = (n.slot or n.grade) == 'rare' and 'rare' or 'common'
                have[g] = have[g] + 1
            end
        end
        local need = { common = want.common or 0, rare = want.rare or 0 }
        if kind == 'town' and math.random() < C.REQ.TOWN_SECOND then need.common = need.common + 1 end
        if kind == 'company' and math.random() < C.REQ.COMPANY_RARE then need.common = need.common + 1 end
        local posters = ctx.postersOf(key)
        local tkey = townKeyOf(key)
        local town = SUP.towns[tkey or ''] or {}
        local i = 0
        for _, grade in ipairs({ 'common', 'rare' }) do
            for _ = have[grade] + 1, need[grade] do
                i = i + 1
                local poster
                if kind == 'company' then
                    poster = 'company'
                elseif kind == 'village' then
                    poster = 'trade'
                elseif kind == 'town' then
                    if ctx.featureOn.collectors and #(town.collectors or {}) > 0 and math.random() < C.REQ.COLLECT_CHANCE
                        and not townHasCollector(tkey) then
                        poster = 'collector'
                    else
                        poster = Q.TOWN_POSTERS[math.random(#Q.TOWN_POSTERS)]
                    end
                else
                    poster = posters[(i - 1) % #posters + 1]
                end
                local n, why = makeOne(key, player, grade, poster)
                if n then
                    out[#out + 1] = n
                    b.notices = b.notices or {}
                    b.notices[#b.notices + 1] = n
                elseif why then
                    ctx.log('%s: no %s requisition from %s (%s)', key, grade, poster, why)
                end
            end
        end
        return out
    end

    -----------------------------------------------------------------------------------------------
    -- Lost ledgers. Searched for while the player stands at a town board (its street is loaded
    -- then); the book is placed by loose.lua's furniture search and the notice is posted only once
    -- the book has settled. pendingLost: board key -> one search; not saved, dropped after
    -- PENDING_SECONDS without an answer (the player walked off, or a contract search took over).

    local CELL = 8192
    local PENDING_SECONDS = 30
    local pendingLost = {}

    local function dropStale()
        local t = core.getSimulationTime()
        for k, p in pairs(pendingLost) do
            if t - p.askedAt > PENDING_SECONDS then pendingLost[k] = nil end
        end
    end

    local function townHasLost(tkey)
        for k in pairs(pendingLost) do
            if townKeyOf(k) == tkey then return true end
        end
        for k, b in pairs(ctx.S().boards) do
            if townKeyOf(k) == tkey then
                for _, n in ipairs(b.notices or {}) do
                    if n.kind == 'req' and n.sub == 'lost' then return true end
                end
            end
        end
        return false
    end

    -- Furniture, public doors and lights in the board's exterior cell and any neighbour within
    -- MAX_DIST of the board: five getAll per cell, at most four cells in practice.
    local function scanStreet(here, public)
        local L = C.LOST
        local furniture, doors, lights = {}, {}, {}
        local gx0, gy0 = math.floor(here.x / CELL), math.floor(here.y / CELL)
        for gx = gx0 - 1, gx0 + 1 do
            for gy = gy0 - 1, gy0 + 1 do
                local nx = math.max(gx * CELL, math.min(here.x, (gx + 1) * CELL))
                local ny = math.max(gy * CELL, math.min(here.y, (gy + 1) * CELL))
                if (nx - here.x) ^ 2 + (ny - here.y) ^ 2 <= L.MAX_DIST ^ 2 then
                    local cell = world.getExteriorCell(gx, gy)
                    for _, t in ipairs({ types.Static, types.Container, types.Activator }) do
                        for _, o in ipairs(cell:getAll(t)) do
                            local w = o.enabled and ctx.furnitureWord(o)
                            if w and L.WORDS[w] then
                                local d = (o.position - here):length()
                                if d >= L.MIN_DIST and d <= L.MAX_DIST then
                                    furniture[#furniture + 1] = { obj = o, word = w, depth = d }
                                end
                            end
                        end
                    end
                    for _, o in ipairs(cell:getAll(types.Door)) do
                        local dest = types.Door.isTeleport(o) and types.Door.destCell(o)
                        if dest and public[dest.name] then
                            doors[#doors + 1] = { name = Q.placeName(dest.name), pos = o.position }
                        end
                    end
                    for _, o in ipairs(cell:getAll(types.Light)) do lights[#lights + 1] = o.position end
                end
            end
        end
        return furniture, doors, lights
    end

    local function nearestDoor(doors, p, within)
        local best, bd
        for _, d in ipairs(doors) do
            local x = (d.pos - p):length()
            if x <= within and (not bd or x < bd) then best, bd = d, x end
        end
        return best
    end

    function api.tryLost(key, player)
        dropStale()
        local L = C.LOST
        if not ctx.featureOn.lostLedgers or pendingLost[key] then return end
        local d = ctx.DEFS[key]
        if not d or ctx.COMPANY[key] or not player.cell or not player.cell.isExterior then return end
        local spot = mainSpot(ctx.S().boards[key])
        if not spot or townHasLost(d.town.key) or math.random() >= L.CHANCE then return end
        local here = util.vector3(spot.x, spot.y, spot.z)
        local public = {}
        for _, name in ipairs((SUP.towns[d.town.key] or {}).public or {}) do public[name] = true end
        local furniture, doors, lights = scanStreet(here, public)
        if #furniture == 0 then
            ctx.log('%s: no lost ledger (no bench, crate or table in reach)', key)
            return
        end
        for _, f in ipairs(furniture) do
            local p = f.obj.position
            for _, lp in ipairs(lights) do
                if (lp - p):length() < C.LOOSE.LIGHT_NEAR then f.light = true break end
            end
            f.score = math.random() + (f.light and 0.3 or 0) + (nearestDoor(doors, p, L.LANDMARK_NEAR) and 0.5 or 0)
        end
        table.sort(furniture, function(a, b) return a.score > b.score end)
        local send = {}
        for i = 1, math.min(L.CANDIDATES, #furniture) do
            local f = furniture[i]
            send[i] = { obj = f.obj, word = f.word, depth = f.depth, light = f.light }
        end
        pendingLost[key] = { doors = doors, level = ctx.playerLevel(player), askedAt = core.getSimulationTime() }
        local at = { x = here.x, y = here.y, z = here.z }
        ctx.log('%s: lost ledger: %d furniture in reach, %d public doors, %d sent', key, #furniture, #doors, #send)
        player:sendEvent('OJB_FindLoose', { id = 'lost:' .. key, exterior = true, cands = send, small = true,
            minDepth = 0, entrance = at, anchor = at })
    end

    local function postLost(key, p, obj, at, n)
        local S = ctx.S()
        local b = S.boards[key]
        local box = obj:isValid() and obj.cell and obj:getBoundingBox()
        local drift = box and math.sqrt((obj.position.x - at.x) ^ 2 + (obj.position.y - at.y) ^ 2) or math.huge
        if not box or obj.count == 0 or drift > 3 or not b or b.status ~= 'placed' then
            if obj:isValid() and obj.count > 0 and obj.cell then obj:remove() end
            ctx.log('%s: lost ledger dropped (it moved or the board is gone)', key)
            return
        end
        -- A mesh's origin isn't always its base: set the bottom on the surface.
        local gap = at.z - (box.center.z - box.halfSize.z)
        if math.abs(gap) > 0.5 then
            obj:teleport('', util.vector3(obj.position.x, obj.position.y, obj.position.z + gap + 0.5),
                { rotation = obj.rotation })
        end
        n.id, n.kind, n.poster, n.obj = S.nextId, 'req', 'town', obj
        S.nextId = S.nextId + 1
        n.reward = { gold = n.value, items = {}, supplies = 0, training = false, value = n.value }
        n.level, n.postedAt = p.level, ctx.now()
        b.notices[#b.notices + 1] = n
        ctx.say('%s: lost ledger %d: %s on a %s at %.0f %.0f %.0f, pays %d', key, n.id, n.want.name, p.word,
            at.x, at.y, at.z, n.value)
        ctx.syncPapers(key)
    end

    function api.lostSpot(e)
        local key = e.id:sub(6)
        local p = pendingLost[key]
        if not p then return end
        pendingLost[key] = nil
        for _, t in ipairs(e.tried or {}) do ctx.log('  rejected %s', t) end
        if not e.ok then
            ctx.log('%s: no lost ledger (%s)', key, e.error or 'no furniture passed')
            return
        end
        local L = C.LOST
        local at = util.vector3(e.pos.x, e.pos.y, e.pos.z)
        local near = nearestDoor(p.doors, at, L.LANDMARK_NEAR)
        local stops, named = {}, { [near and near.name or ''] = true }
        local want = math.random(1, L.STOPS)
        local order = {}
        for i = 1, #p.doors do order[i] = p.doors[i] end
        for i = #order, 2, -1 do
            local j = math.random(i)
            order[i], order[j] = order[j], order[i]
        end
        for _, d in ipairs(order) do
            if #stops >= want then break end
            if not named[d.name] then
                named[d.name] = true
                stops[#stops + 1] = d.name
            end
        end
        local folk = ST.townsfolk()
        local from = folk[math.random(#folk)]
        local d = ctx.DEFS[key]
        local n = Q.lost({ level = p.level, town = d.town.name, from = from, first = from:match('^(%S+)'),
            stops = stops, word = e.word, near = near and near.name, rnd = math.random })
        n.want.id = ctx.makeItem(L.BASE, n.want.name)
        p.word = e.word
        local obj = world.createObject(n.want.id)
        obj:teleport('', at + util.vector3(0, 0, 1), { rotation = util.transform.rotateZ(math.random() * 2 * math.pi) })
        async:newUnsavableSimulationTimer(C.LOOSE.SETTLE_SECONDS, function() postLost(key, p, obj, at, n) end)
    end

    -----------------------------------------------------------------------------------------------
    -- Theft ledger. OpenMW clears an item's owner once it is in an inventory and gives Lua no
    -- stolen list, so pieces are counted as they are taken: owned items picked up in the world,
    -- owned books taken from the reading window, and whatever the player's pack gained while an
    -- owned container was open. With Economy Plus, its own ledger (I.EconomyTheft.count) counts
    -- too. Key: record id; saved in S.stolen; at most STOLEN_MAX records, the oldest dropped
    -- first. Never decreases: a stolen piece sold and bought back is still refused, which errs the
    -- safe way.

    local function ownedByOther(obj, player)
        local o = obj.owner
        if not o then return false end
        if o.recordId and o.recordId ~= '' then return o.recordId ~= player.recordId end
        if o.factionId and o.factionId ~= '' then return types.NPC.getFactionRank(player, o.factionId) <= 0 end
        return false
    end

    local function addStolen(id, n)
        local S = ctx.S()
        if not S or not id or n <= 0 then return end
        S.stolen = S.stolen or {}
        local e = S.stolen[id]
        if not e then
            local count, oldest, oldestAt = 0, nil, math.huge
            for k, v in pairs(S.stolen) do
                count = count + 1
                if v.at < oldestAt then oldest, oldestAt = k, v.at end
            end
            if count >= C.REQ.STOLEN_MAX and oldest then S.stolen[oldest] = nil end
            e = { n = 0 }
            S.stolen[id] = e
        end
        e.n, e.at = e.n + n, ctx.now()
        ctx.log('theft ledger: %s +%d (%d in all)', id, n, e.n)
    end

    local function stolenOf(id)
        local S = ctx.S()
        local e = S.stolen and S.stolen[id]
        local n = e and e.n or 0
        local ep = I.EconomyTheft
        if ep and ep.count then n = math.max(n, ep.count(id) or 0) end
        return n
    end

    function api.stolenRecords()
        local n = 0
        for _ in pairs(ctx.S().stolen or {}) do n = n + 1 end
        return n
    end

    local function packCounts(player)
        local out = {}
        for _, it in ipairs(types.Actor.inventory(player):getAll()) do
            out[it.recordId] = (out[it.recordId] or 0) + it.count
        end
        return out
    end

    local CARRIED = { types.Weapon, types.Armor, types.Clothing, types.Ingredient, types.Potion,
        types.Miscellaneous, types.Apparatus, types.Lockpick, types.Probe, types.Repair, types.Light }
    for _, kind in ipairs(CARRIED) do
        -- Returns nothing: the pickup goes ahead as normal.
        I.Activation.addHandlerForType(kind, function(obj, actor)
            if actor.type ~= types.Player then return end
            if kind == types.Light and not types.Light.record(obj).isCarriable then return end
            if ownedByOther(obj, actor) then addStolen(obj.recordId, obj.count) end
        end)
    end
    I.Activation.addHandlerForType(types.Book, function(obj, actor)
        if actor.type ~= types.Player or not ownedByOther(obj, actor) then return end
        pendingBook = { obj = obj, id = obj.recordId, had = types.Actor.inventory(actor):countOf(obj.recordId) }
    end)
    I.Activation.addHandlerForType(types.Container, function(obj, actor)
        if actor.type ~= types.Player or not ownedByOther(obj, actor) then return end
        openedContainer = { counts = packCounts(actor) }
    end)

    -- From the player script when the container window closes: what the pack gained is stolen.
    function api.containerClosed(e)
        if not openedContainer then return end
        local before = openedContainer.counts
        openedContainer = nil
        for id, n in pairs(packCounts(e.player)) do
            if n > (before[id] or 0) then addStolen(id, n - (before[id] or 0)) end
        end
    end

    -- From nearTick: an owned book opened earlier is settled once it is gone from the world.
    function api.settleBook(player)
        local p = pendingBook
        if not p then return end
        if p.obj:isValid() and p.obj.count > 0 then
            if not p.obj.cell or p.obj.cell.id ~= player.cell.id then pendingBook = nil end
            return
        end
        pendingBook = nil
        local gained = types.Actor.inventory(player):countOf(p.id) - p.had
        if gained > 0 then addStolen(p.id, gained) end
    end

    -----------------------------------------------------------------------------------------------
    -- Handing in at the board: what the player carries for each requisition. One inventory
    -- getAll per requisition shown, only when the board window opens or changes.

    -- all: the player's inventory getAll(), read once per order.
    local function carriedFor(want, all, ours)
        local out = {}
        if want.soul then
            for _, it in ipairs(all) do
                local id = it.recordId
                if it.type == types.Miscellaneous and id:find('^misc_soulgem') and id ~= 'misc_soulgem_azura' then
                    local soul = types.Item.itemData(it).soul
                    local crec = soul and types.Creature.records[soul]
                    if crec then
                        out[#out + 1] = { id = id, count = it.count, soul = soul, soulValue = crec.soulValue,
                            creature = crec.name, stolen = stolenOf(id), ours = ours[id], obj = it }
                    end
                end
            end
            return out
        end
        local wid = want.id:lower()
        for _, it in ipairs(all) do
            if it.recordId:lower() == wid then
                local e = { id = it.recordId, count = it.count, stolen = stolenOf(it.recordId),
                    ours = ours[it.recordId], obj = it }
                if want.sound then
                    local rec = it.type.record(it)
                    e.maxCondition = rec.health or rec.maxCondition
                    e.condition = types.Item.itemData(it).condition
                end
                out[#out + 1] = e
            end
        end
        return out
    end

    -- Each line of an order against the pack: { want, need, have, take }, and whether all are met.
    -- Delivery is all at once: a half-filled order would need saved progress per notice, and
    -- per-piece pay lets a player sell one piece at a time where a shop would pay less.
    local function tally(player, n)
        local ours = {}
        for _, c in pairs(ctx.S().contracts) do
            if c.item then ours[c.item] = true end
        end
        local all = types.Actor.inventory(player):getAll()
        local rows, ready = {}, true
        for _, l in ipairs(n.lines or { n.want }) do
            local need = l.soul and 1 or l.count
            local have, take = Q.match(l, carriedFor(l, all, ours))
            rows[#rows + 1] = { want = l, need = need, have = math.min(have, need), take = take }
            if have < need then ready = false end
        end
        return rows, ready
    end

    -- Hand-ins at a board in the last WEEK_DAYS. b.handed: times of each, pruned here.
    local function handedThisWeek(b)
        local keep, t = {}, ctx.now()
        for _, at in ipairs(b.handed or {}) do
            if t - at < C.REQ.WEEK_DAYS then keep[#keep + 1] = at end
        end
        b.handed = keep
        return #keep
    end

    local FULL = 'The stores here are full until next week.'

    -- A requisition on board key's window: the line under it, whether it can be handed over, and
    -- the order sheet rows { name, wanted, have, each, hint }.
    -- Orders saved before 1.8.9's order sheets carry no price a piece: the total less the fee,
    -- shared over the pieces of the lines that have none.
    local function fillEach(n)
        local lines = n.lines or { n.want }
        local known, pieces = 0, 0
        for _, l in ipairs(lines) do
            if l.each then known = known + l.each * (l.count or 1) else pieces = pieces + (l.count or 1) end
        end
        if pieces == 0 then return end
        local each = math.max(1, math.floor(((n.value or 0) - (n.fee or 0) - known) / pieces))
        for _, l in ipairs(lines) do l.each = l.each or each end
    end

    function api.status(player, n, key)
        fillEach(n)
        local rows, ready = tally(player, n)
        local b = ctx.S().boards[key]
        local full = b and handedThisWeek(b) >= C.REQ.WEEK_CAP
        local sheet, missing = {}, {}
        for _, r in ipairs(rows) do
            local l = r.want
            local row, miss = Q.sheetRow(n, l, r.need, r.have)
            row.hint = l.hint
            sheet[#sheet + 1] = row
            if miss then missing[#missing + 1] = miss end
        end
        if full then return FULL, false, sheet end
        if ready then return 'You have what they asked for.', true, sheet end
        if n.want.soul then return 'You carry no filled soul gem that will do.', false, sheet end
        return 'You still need ' .. N.list(missing) .. '.', false, sheet
    end

    function api.handIn(player, key, id, guild)
        local b = ctx.S().boards[key]
        local n, idx
        for i, x in ipairs(b and b.notices or {}) do
            if x.id == id and x.kind == 'req' then n, idx = x, i end
        end
        if not n then return end
        if handedThisWeek(b) >= C.REQ.WEEK_CAP then
            ctx.tell(player, FULL)
            ctx.sendBoard(player, key, guild)
            return
        end
        local rows, ready = tally(player, n)
        if not ready then
            ctx.tell(player, "You don't have everything they asked for.")
            ctx.sendBoard(player, key, guild)
            return
        end
        for _, r in ipairs(rows) do
            for _, t in ipairs(r.take) do t.entry.obj:remove(t.n) end
        end
        local reward, skill = n.reward, n.skill
        if reward.training then
            -- The player may have trained or lost the attribute since: then it's all gold.
            local still = trainerFor(player, townKeyOf(key), C.GUILDS[n.poster] and n.poster or nil)
            if still ~= skill then
                reward = { gold = reward.value, items = {}, supplies = 0, training = false, value = reward.value }
                skill = nil
            end
        end
        local inv = types.Actor.inventory(player)
        if reward.gold > 0 then world.createObject(GOLD, reward.gold):moveInto(inv) end
        player:sendEvent('OJB_Sound', { 'chest close', reward.gold > 0 and 'Item Gold Up' or nil })
        if reward.training and skill then player:sendEvent('OJB_Train', { skill = skill }) end
        local rep = C.GUILDS[n.poster] and ctx.grantRep(player, { poster = n.poster, kind = 'req', id = n.id }) or 0
        table.remove(b.notices, idx)
        b.handed[#b.handed + 1] = ctx.now()
        ctx.say('%s: requisition %d filled (%s): %d gold%s', key, n.id, n.want.id or n.want.name, reward.gold,
            skill and (', training ' .. skill) or '')
        local msg = 'Paid: ' .. ctx.rewardText(reward, skill) .. '.'
        if rep > 0 then msg = msg .. ' Your standing in the guild improves.' end
        ctx.tell(player, msg)
        ctx.syncPapers(key, true)
        ctx.sendBoard(player, key, guild)
    end

    return api
end

return M
