---@omw-context runtime
-- Pure: which paper a notice is pinned on, how big it is, which loose group of the board it
-- joins, and where it sits. No engine calls; global.lua classifies, window.lua draws, and
-- tests/run_tests.py runs it as is. Colours are plain {r, g, b} so this needs no openmw.util.

local M = {}

-- Paper by poster (ref4_paper_styles). tint multiplies the neutral paper texture; ink is the
-- writing colour; border: kind and colour; header: a coloured strip across the top with its words;
-- seal: wax colour, or nil for scraps; pins: 1 (a scrap pinned once) or 2 (top corners).
-- marks: what's pressed into a scrap (stains, dirt). ledger: faint ruled lines. sketch: an item box.
local BLACK = { 0.10, 0.08, 0.07 }
M.STYLES = {
    scrap = { tint = { 0.80, 0.66, 0.46 }, torn = true, ink = { 0.20, 0.13, 0.07 }, pins = 1, marks = 'stain' },
    farm = { tint = { 0.66, 0.53, 0.36 }, torn = true, ink = { 0.17, 0.11, 0.06 }, pins = 1, marks = 'dirt' },
    merchant = { tint = { 0.98, 0.94, 0.84 }, ink = BLACK, pins = 2,
        border = { kind = 'single', color = { 0.45, 0.33, 0.18 } }, seal = { 0.78, 0.60, 0.20 } },
    company = { tint = { 0.95, 0.93, 0.86 }, ink = BLACK, pins = 2, ledger = true,
        header = { color = { 0.16, 0.30, 0.20 }, text = 'Trading company' }, seal = { 0.16, 0.36, 0.22 } },
    legion = { tint = { 0.96, 0.93, 0.86 }, ink = BLACK, pins = 2,
        header = { color = { 0.55, 0.10, 0.08 }, text = 'Imperial Legion' }, seal = { 0.62, 0.08, 0.06 } },
    fighters = { tint = { 0.93, 0.93, 0.90 }, ink = BLACK, pins = 2,
        border = { kind = 'double', color = { 0.30, 0.38, 0.55 } }, seal = { 0.18, 0.26, 0.60 } },
    mages = { tint = { 1.00, 0.98, 0.92 }, ink = { 0.12, 0.17, 0.42 }, pins = 2,
        border = { kind = 'ornate', color = { 0.22, 0.32, 0.68 } }, seal = { 0.20, 0.28, 0.66 } },
    temple = { tint = { 0.97, 0.88, 0.70 }, ink = { 0.36, 0.12, 0.08 }, pins = 2,
        border = { kind = 'single', color = { 0.74, 0.58, 0.22 } }, seal = { 0.66, 0.10, 0.07 } },
    watch = { tint = { 0.97, 0.96, 0.92 }, ink = BLACK, pins = 2, seal = { 0.62, 0.08, 0.06 } },
    collector = { tint = { 0.90, 0.84, 0.72 }, ink = { 0.30, 0.19, 0.10 }, pins = 2, sketch = true,
        seal = { 0.40, 0.26, 0.16 } },
    shop = { tint = { 0.88, 0.78, 0.60 }, ink = { 0.26, 0.16, 0.08 }, pins = 1,
        header = { color = { 0.40, 0.24, 0.12 } } },
    flavour = { tint = { 0.92, 0.90, 0.85 }, torn = true, ink = { 0.33, 0.31, 0.29 }, pins = 1 },
}

-- Laid over the poster's paper. elite replaces the paper itself (heavier, straight, black ink).
M.TIER_LOOK = {
    dangerous = { frame = { 0.60, 0.08, 0.05 }, seal = { 0.62, 0.08, 0.06 }, marks = { 0.60, 0.08, 0.05 } },
    elite = { frame = { 0.80, 0.64, 0.24 }, seal = { 0.12, 0.05, 0.05 }, marks = { 0.60, 0.08, 0.05 },
        tint = { 0.93, 0.88, 0.76 }, ink = BLACK, ribbon = true },
}

-- Open-world work by who would post it, when a town board has it (a guild board posts its own).
local WILD = {
    caravan = 'merchant', roadblock = 'merchant', beast = 'farm', guar = 'farm', drive = 'farm',
    smuggler = 'watch', wreck = 'scrap', gather = 'temple', traveller = 'scrap', patrol = 'legion',
    graverobber = 'temple', machine = 'fighters', summon = 'mages', ritual = 'watch',
    tax = 'legion', piratecove = 'watch', pirate = 'watch',
}
-- Townsfolk by trade (story.lua's people), else by the reward pool their trade picked.
local TRADE = {
    farmer = 'farm', herder = 'farm', hunter = 'farm', ['egg miner'] = 'farm',
    trader = 'merchant', caravaner = 'merchant', porter = 'merchant', scout = 'merchant', pilgrim = 'temple',
}
local POOL = { land = 'farm', road = 'merchant' }
-- Requisition and board posters.
local POSTER = {
    ['fighters guild'] = 'fighters', ['mages guild'] = 'mages', legion = 'legion', temple = 'temple',
    company = 'company', collector = 'collector', smith = 'merchant', trade = 'merchant',
}

-- Tamriel Rebuilt halls post under their own faction ids: matched by what the id says.
local function byName(poster)
    local p = (poster or ''):lower()
    if p:find('mage') then return 'mages' end
    if p:find('fighter') then return 'fighters' end
    if p:find('temple') then return 'temple' end
    if p:find('legion') then return 'legion' end
    if p:find('company') then return 'company' end
    return nil
end

local function wanted(title)
    return (title or ''):find('^WANTED') ~= nil
end

-- n: { kind, poster, trade, pool, wild (type), title, flavour }. Returns a M.STYLES key.
function M.styleOf(n)
    local guild = POSTER[n.poster or ''] or byName(n.poster)
    if n.kind == 'ad' then return 'shop' end
    if n.flavour then
        -- Guild, fort and company news goes up on their own paper; town news and lost boots on scraps.
        if n.kind == 'news' and guild and guild ~= 'merchant' and guild ~= 'collector' then return guild end
        return 'flavour'
    end
    if guild then return guild end
    if n.wild and WILD[n.wild] then return WILD[n.wild] end
    if n.kind == 'bounty' or wanted(n.title) then return 'watch' end
    return TRADE[n.trade or ''] or POOL[n.pool or ''] or 'scrap'
end

-- Sized by kind (design units at 1600x900): big WANTED posters, standard letters, half-size order
-- slips, small shop cards and scraps.
M.SIZES = {
    wanted = { 226, 254 }, standard = { 216, 198 }, slip = { 210, 168 }, card = { 198, 140 }, scrap = { 188, 150 },
}

function M.sizeOf(n)
    if n.kind == 'ad' then return 'card' end
    if n.flavour then return 'scrap' end
    if n.req then return 'slip' end
    if wanted(n.title) then return 'wanted' end
    return 'standard'
end

M.GROUPS = { 'work', 'goods', 'news' }
function M.groupOf(n)
    if n.flavour then return 'news' end
    if n.req then return 'goods' end
    return 'work'
end

-- A notice's small differences: the same every time it is drawn, different between notices.
-- Returns a function giving the k-th value in [0, 1).
function M.rand(id)
    local s = (tonumber(id) or 1) * 7919 % 2147483647
    if s <= 0 then s = s + 2147483646 end
    return function(k)
        local x = s
        for _ = 1, k do x = x * 16807 % 2147483647 end
        return (x % 10007) / 10007
    end
end

-- Days up, as a fade from 0 (fresh) to 1 (curling): nothing for the first day, full by FADE_DAYS.
M.FADE_DAYS = 5
function M.age(days)
    return math.max(0, math.min(1, ((days or 0) - 1) / (M.FADE_DAYS - 1)))
end

-- Rows across the board, work first, then goods wanted, then news and shops, tallest first and
-- otherwise in board order within each. Each row is as tall as its tallest paper; spare width is shared out unevenly between the gaps
-- and each paper drifts a few units, so the board has no hard grid. A drift never exceeds half the
-- gap, so papers never cover each other's titles. A row that doesn't fit starts a new page.
-- list: { {id, w, h, group}, ... }. Returns { [id] = {x, y, page} } and the page count.
M.GAP, M.DRIFT = 18, 7
function M.place(list, areaW, areaH)
    local order = {}
    for gi, g in ipairs(M.GROUPS) do
        local group = {}
        for i, it in ipairs(list) do
            if it.group == g then group[#group + 1] = { it = it, i = i } end
        end
        -- Tallest first, so the big posters share a row instead of each heightening one.
        table.sort(group, function(a, b)
            if a.it.h ~= b.it.h then return a.it.h > b.it.h end
            return a.i < b.i
        end)
        for _, o in ipairs(group) do order[#order + 1] = o.it end
    end
    local rows, row, rowW = {}, nil, 0
    for _, it in ipairs(order) do
        if not row or rowW + M.GAP + it.w > areaW then
            row = { items = {}, h = 0 }
            rows[#rows + 1] = row
            rowW = -M.GAP
        end
        row.items[#row.items + 1] = it
        row.h = math.max(row.h, it.h)
        rowW = rowW + M.GAP + it.w
        row.w = rowW
    end
    local out, page, y = {}, 1, 0
    for _, r in ipairs(rows) do
        if y > 0 and y + r.h + M.DRIFT * 2 > areaH then page, y = page + 1, 0 end
        local spare = math.max(0, areaW - r.w)
        local weights, sum = {}, 0
        for i, it in ipairs(r.items) do
            weights[i] = 0.5 + M.rand(it.id)(1)
            sum = sum + weights[i]
        end
        local x = spare * weights[1] / (sum + 1) * 0.5
        for i, it in ipairs(r.items) do
            local rnd = M.rand(it.id)
            local dx = math.floor((rnd(2) * 2 - 1) * M.DRIFT + 0.5)
            local dy = math.floor(rnd(3) * M.DRIFT * 2 + 0.5)
            local px = math.max(0, math.min(areaW - it.w, x + dx))
            local py = math.min(y + r.h - it.h + M.DRIFT * 2, y + dy)
            out[it.id] = { x = px, y = math.max(y, py), page = page }
            x = x + it.w + M.GAP + spare * (weights[i + 1] or 0) / (sum + 1)
        end
        y = y + r.h + M.GAP + M.DRIFT
    end
    return out, page
end

-- Papers in the world: each look (a style, or the dangerous and elite tiers) on the vanilla
-- parchment ('p', 21 x 34 units, letters and WANTED posters) or note ('n', 15 x 18, slips, cards,
-- scraps), retextured by tools/make_wall_papers.py. Scales keep every paper inside the 26 x 34
-- patch a wall check measures (C.WALL.PAPER_HW, PAPER_HH), so none is larger than its place.
M.WALL_LOOKS = { 'scrap', 'farm', 'merchant', 'company', 'legion', 'fighters', 'mages', 'temple', 'watch',
    'collector', 'shop', 'flavour', 'dangerous', 'elite' }
M.WALL_SCALE = { wanted = 1.0, standard = 0.92, slip = 1.3, card = 1.2, scrap = 1.1 }

-- n: a notice as stored on a board. Returns the activator record id and its scale.
function M.wallOf(n)
    local flavour = n.flavour
    local kind = flavour and (n.kind == 'ad' and 'ad' or n.kind == 'news' and 'news' or 'flavour') or n.kind
    local look = M.styleOf({ kind = kind, poster = n.poster, trade = n.trade, title = n.title,
        pool = n.reward and n.reward.pool, wild = n.wild and n.wild.type, flavour = flavour })
    local tier = n.tier or (n.seal and n.diff)
    if not flavour and (tier == 'dangerous' or tier == 'elite') then look = tier end
    local size = M.sizeOf({ kind = kind, flavour = flavour, req = n.kind == 'req', title = n.title })
    local shape = (size == 'wanted' or size == 'standard') and 'p' or 'n'
    return 'ojb_notice_' .. look .. '_' .. shape, M.WALL_SCALE[size]
end

return M
