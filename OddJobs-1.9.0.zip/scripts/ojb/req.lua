---@omw-context runtime
-- Pure: requisitions. What a poster asks for, how many, what it pays and the notice's words. No
-- engine calls; global.lua passes in the supply data, item names and the random source, and
-- tests/run_tests.py runs it as is. Nothing here depends on the player's level: pay follows the
-- goods' worth, counts follow a gold band per grade, and the story follows the goods' category.

local C = require('scripts.ojb.config')
local N = require('scripts.ojb.names')

local M = {}
local Q = C.REQ

local function cap(s)
    return (s:gsub('^%l', string.upper))
end

-- Fills {key} in s from a; unknown keys stay as they are, so a test can spot them.
local function fill(s, a)
    return (s:gsub('{([%a_]+)}', function(k)
        local v = a[k]
        return v ~= nil and tostring(v) or '{' .. k .. '}'
    end))
end

local function pick(list, rnd)
    return list[rnd(#list)]
end

---------------------------------------------------------------------------------------------------
-- Pay. Each piece is priced at its base value x the grade's premium, rounded to the nearest gold;
-- the order adds one handling fee. Goods on a shelf in this town get LOCAL_PREMIUM and no fee: the
-- errand is a walk to a shop, and vanilla sells to a strong trader at 75 percent of worth.

local function between(r, rnd)
    return r[1] + (r[2] - r[1]) * rnd()
end

function M.premium(grade, rnd, sold)
    if sold == 'town' and grade ~= 'rare' then return between(Q.LOCAL_PREMIUM, rnd) end
    if sold == 'far' and grade == 'rare' then return Q.PREMIUM.rareFar end
    local p = Q.PREMIUM[grade] or Q.PREMIUM.common
    return type(p) == 'table' and between(p, rnd) or p
end

-- Gold for each piece. With a premium a piece pays at least a gold over its worth; at a gold or two
-- apiece, rounding would otherwise eat the premium.
function M.each(v, prem)
    local each = math.max(1, math.floor(v * prem + 0.5))
    if prem > 1 then each = math.max(each, math.floor(v) + 1) end
    return each
end

-- The order's handling fee: none when every line is sold in this town.
function M.fee(grade, lines)
    for _, l in ipairs(lines or {}) do
        if l.sold ~= 'town' then return Q.FEE[grade] or Q.FEE.common end
    end
    return lines and #lines > 0 and 0 or (Q.FEE[grade] or Q.FEE.common)
end

-- Pieces of an item worth v so the order lands in the grade's gold band, within COUNT's limits:
-- cheap stackables (worth COUNT.stackValue or less) up to COUNT.stack, a company lot up to
-- COUNT.company, a harvest order (a rare plant picked wild) harvestLo to harvestHi, a rare
-- order 1 or 2, and nothing over COUNT.max. Dear items may drop below COUNT.lo.
function M.count(v, grade, prem, rnd, harvest)
    local K = Q.COUNT
    local band = Q.BAND[grade] or Q.BAND.common
    local fee = Q.FEE[grade] or Q.FEE.common
    local per = math.max(0.5, v * prem)
    local function round(n)
        if n > 12 then n = math.floor(n / 5 + 0.5) * 5 end
        return n
    end
    if grade == 'rare' and harvest then
        local n = round(math.floor((between(Q.BAND.harvest, rnd) - fee) / per + 0.5))
        n = math.max(n, math.ceil((Q.BAND.harvest[1] - fee) / per))
        return math.max(K.harvestLo, math.min(K.harvestHi, K.max, n))
    end
    local target = between(band, rnd)
    if grade == 'rare' then
        if per + fee < band[1] then return 2 end
        return (per * 2 + fee <= band[2] and rnd() < Q.RARE_PAIR) and 2 or 1
    end
    local cheap = v <= K.stackValue
    local hi = cheap and K.stack or K.hi
    if grade == 'company' then hi = cheap and K.company or K.companyDear end
    hi = math.min(hi, K.max)
    local lo = K.lo
    while lo > 1 and per * lo + fee > band[2] * 1.2 do lo = lo - 1 end
    local n = round(math.floor((target - fee) / per + 0.5))
    n = math.max(lo, math.min(hi, n))
    return math.min(K.max, math.max(n, math.ceil((band[1] - fee) / per)))
end

-- The gold band an order of this grade must land in.
function M.band(grade, harvest)
    if grade == 'rare' and harvest then return Q.BAND.harvest end
    return Q.BAND[grade] or Q.BAND.common
end

-- What a filled gem holding a soul this strong sells for in game, before a merchant's cut.
-- opts: { mode = 'vanilla' | 'rebalanced', gems = { { cap, value }, ... } by cap (the soul gem
-- records; C.REQ.SOUL_GEMS when nil), bands = Economy Plus's SOUL_BANDS when it is installed }.
-- Vanilla: the cheapest gem able to hold it, value x soul. Rebalanced: OpenMW's "rebalance soul
-- gem values" (the Morrowind Code Patch curve), 0.0001 x soul^3 + 2 x soul.
function M.soulWorth(soul, opts)
    opts = opts or {}
    if opts.bands and #opts.bands > 0 then
        for _, b in ipairs(opts.bands) do
            if soul <= b.cap then return b.price end
        end
        return opts.bands[#opts.bands].price
    end
    if opts.mode == 'rebalanced' then return 0.0001 * soul ^ 3 + 2 * soul end
    local gems = opts.gems or Q.SOUL_GEMS
    for _, g in ipairs(gems) do
        if soul <= g.cap then return g.value * soul end
    end
    return gems[#gems].value * soul
end

-- A soul's pay: its filled gem's worth x SOUL_PREMIUM (collect for a collector), held between
-- SOUL_PAY's floor and cap for its strength, to the nearest 5 gold.
function M.soulPay(soul, grade, opts)
    local P = Q.SOUL_PAY
    local lo = P.floor[1] + P.floor[2] * soul
    local hi = math.min(P.max, P.cap[1] + P.cap[2] * soul)
    local v = M.soulWorth(soul, opts) * (Q.SOUL_PREMIUM[grade] or Q.SOUL_PREMIUM.rare)
    v = math.max(lo, math.min(hi, v))
    return math.floor(v / 5 + 0.5) * 5
end

-- A soul request in words. want: { soul, creature (name, or nil for "this strong") }.
-- sheet: "Kagouti's soul"; else "a soul gem holding a kagouti's soul".
function M.soulWords(want, sheet)
    local name = (want.creature or want.name or 'creature'):gsub('%s+', ' '):lower()
    local own = name .. (name:sub(-1) == 's' and "'" or "'s")
    local whose = (name:find('^[aeiou]') and 'an ' or 'a ') .. own
    if want.creature then
        return sheet and cap(own .. ' soul') or ('a soul gem holding ' .. whose .. ' soul')
    end
    return sheet and ('A soul as strong as ' .. whose) or ('a soul gem holding a soul as strong as ' .. whose)
end

-- An order sheet row for one line, and what is still missing in words (nil when none is).
-- row: { name, line (the board card's words), head (the table's first column), wanted, have, each }.
-- Books keep their title as written; souls read as the soul.
function M.sheetRow(n, l, need, have)
    local row = { wanted = need, have = have, each = l.each or n.value or 0 }
    if l.soul then
        row.name, row.line, row.head = M.soulWords(l, true), M.soulWords(l, true), 'Soul gem'
        return row, nil
    end
    if l.book or (n.sub == 'collect' and n.group == 'scholar') then
        row.name, row.line, row.head = l.name, l.name, 'Book'
        return row, have < need and ('a copy of ' .. l.name) or nil
    end
    if n.sub == 'lost' then
        row.name, row.line, row.head = l.name, l.name, 'Lost'
        return row, have < need and l.name or nil
    end
    local drink = l.cat == 'drink'
    local name = l.name or l.id
    row.name = need == 1 and cap(N.forms(name, drink).one) or N.label(name, drink)
    row.head = 'Goods'
    return row, have < need and N.count(name, need - have, drink) or nil
end

---------------------------------------------------------------------------------------------------
-- Story families: what a lead line talks about. Every item category belongs to one, and a lead is
-- only ever drawn from its item's family, so a story about blades never asks for javelins.

M.FAMILY = {
    blade = 'arms', blunt = 'arms', axe = 'arms', spear = 'arms', thrown = 'thrown',
    arrow = 'archery', bolt = 'archery', bow = 'ranged', crossbow = 'ranged',
    armour = 'armour', shield = 'armour', repair = 'repair',
    ingredient = 'ingredient', scroll = 'scroll', soulgem = 'soulgem', apparatus = 'apparatus',
    potion = 'potion', food = 'food', drink = 'drink', hide = 'hide', material = 'material',
    clothing = 'clothing', lockpick = 'tools', probe = 'tools',
}
-- How a lead names a family in general: "the Guild's spare blades".
local SHORT = { blade = 'blades', blunt = 'clubs and maces', axe = 'axes', spear = 'spears', arrow = 'arrows',
    bolt = 'bolts', armour = 'armour', shield = 'shields', bow = 'bows', crossbow = 'crossbows' }

-- Common leads by poster and family. {items}: "ten iron arrows"; {mass}: "iron arrows" or
-- "saltrice"; {short}: the family's word; {one}: "set of repair prongs" (no article).
local LEADS = {
    fighters = {
        arms = {
            'Three new recruits turned up with nothing but their boots.',
            'The training yard has more broken {short} than whole ones.',
            "A recruit sold the Guild's spare {short} to buy drink.",
            'We are fitting out a patrol and the racks are bare.',
            'The last lot of {mass} came in rusted.',
            'Our drill master wants every recruit armed by the end of the week.',
            'A job went badly and half the {short} in the hall went with it.',
            'The armoury is down to {short} nobody would trust in a fight.',
        },
        thrown = {
            'The recruits are learning to throw, and they lose more {mass} in the grass than they land.',
            'Our scouts like something to throw before the fighting starts.',
            'A hunting party used every one we had on a single kagouti.',
            'The throwing range opens again next week and the box is empty.',
            'A member swears by {mass} and has taught half the hall to use them.',
        },
        archery = {
            'The recruits loose more {short} into the river than into the butts.',
            'We go through {short} faster than any fletcher can make them.',
            'The last crate of {short} from the coast came in warped.',
            'Archery practice starts again next week and the racks are empty.',
            'A patrol came back with empty quivers and a story about it.',
            'Our marksmen have shot at everything on the road this month, and now the quivers are empty.',
        },
        armour = {
            'Six recruits signed on this week and not one of them owns a stitch of armour.',
            'The last job cost us more {short} than it paid for.',
            'Our new members spar in their shirts, and the healers are tired of it.',
            'A cart of old kit went to the scrapper by mistake.',
            'We fit out every new member with something to stop a blade, and the store is empty.',
        },
        repair = {
            'Our armourer wore through her last {one} on a set of plate.',
            'Half the armour in the hall needs mending and the tools are spent.',
            'A bad fight left our armour in pieces, and the tools did not survive the mending.',
            "Somebody walked off with the armoury's tools.",
            'The armourer says she can mend anything, if somebody brings her tools that work.',
        },
    },
    legion = {
        arms = {
            'A new cohort marched in with half its kit missing.',
            "The garrison's spare {short} were worn out on the last patrol.",
            'The quartermaster counted the racks and did not like the number.',
            'Every man on the wall is meant to carry a sidearm, and some carry a stick.',
            'Inspection is due and the armoury will not pass it.',
        },
        archery = {
            'The archers on the wall have been shooting at cliff racers all month.',
            "The garrison's {short} went to the patrols on the road, and the wall is short.",
            'The quartermaster wants the wall stocked before the inspection.',
            'The crossbowmen on the gate have been loosing at shadows, and the store is empty.',
        },
        armour = {
            'Half the new recruits stand watch in borrowed kit.',
            "The Legion's supply ship was late again, and the men are patching their armour with rope.",
            'Inspection is coming and the kit is a disgrace.',
            'A patrol came back from the hills with its armour hacked to pieces.',
        },
        food = {
            'The supply wagon is late again.',
            'The garrison eats more than the stores can hold.',
            'A patrol came back early and hungry.',
            'The cook says the stores will not last the week.',
            'Rations for the men on the road are short.',
        },
        potion = {
            'The garrison healer is out of draughts and the patrols keep coming back cut.',
            'Every man on the road carries a draught, and the store is empty.',
            'A fever went through the barracks and took the last of the potions with it.',
            'The healer wants the shelf stocked before the next patrol goes out.',
        },
        repair = {
            'The garrison smith is mending more than he can keep up with.',
            'Our armourer broke her last {one} on a Legion cuirass.',
            'The quartermaster wants every buckle mended before the inspection.',
            'The forge has the work and not the tools.',
        },
    },
    mages = {
        ingredient = {
            'Our alchemist has run through her {mass} again.',
            'The apprentices used the last of the {mass} on a bad batch.',
            'We are out of {mass}, and there is brewing to do.',
            'A healer from the coast asked us for a draught we cannot make without {mass}.',
            'The stores are short of {mass}, and the season for gathering has gone.',
            'Someone left the jar open and the damp got into the {mass}.',
            'The last lot of {mass} from the caravans never came.',
            'An apprentice is learning to brew and wastes as much as she uses.',
        },
        scroll = {
            'A member took our last {one} on a trip and used it.',
            'We keep a few of each scroll for emergencies, and that shelf is bare.',
            "The library's copy was used to save a fool's life.",
            'We like to keep a {one} on the shelf, and the shelf is empty.',
            'A visiting scholar wants to study one, and we have none left.',
            'Our stock went out with the last expedition.',
        },
        soulgem = {
            'The enchanters go through soul gems faster than the traders bring them.',
            'An apprentice dropped a crate of gems down the stairs.',
            'We keep empty gems on hand for members on their travels, and the shelf is bare.',
            'A visiting enchanter bought every gem we had.',
        },
        apparatus = {
            'The apprentices broke half the alchemy kit in a single week.',
            'A new class of apprentices starts soon, and each one needs a set to learn on.',
            'Our old {one} cracked in the fire.',
            'The brewing room lost half its glass when a shelf came down.',
        },
    },
    temple = {
        potion = {
            'The pilgrims come in half-dead from the road and our healers are spent.',
            'We gave the last draught to a caravan guard last night.',
            'The shrine keeps a few potions by for the sick, and the shelf is empty.',
            'The healers have been up every night this week.',
            'The priests are worn out and the sick keep coming.',
            'Every pilgrim this month has needed a draught, and now we have none.',
        },
        food = {
            'Pilgrims sleep in the courtyard and eat at our table.',
            'The alms kitchen feeds the poor every evening, and the stores are thin.',
            'A pilgrimage leaves for the shrines next week and needs feeding on the road.',
            'The priests give food to anyone who asks, and many ask.',
            'A sick family has been staying with us, and they need feeding.',
        },
    },
    smith = {
        repair = {
            "I wore through my last {one} on a customer's cuirass.",
            'My apprentice keeps losing my tools.',
            'I have more mending than tools to do it with.',
            'A whole patrol brought me its armour on the same morning.',
        },
        arms = {
            'A caravan master wants his guards armed before the next run, and my racks are thin.',
            'I sold everything on the wall to a band of pilgrims heading into the hills.',
            'My forge is booked for a month, and customers still want something to carry today.',
            'The Legion bought out my stock, and the townsfolk want theirs.',
            'I take in sound blades to sell on, and nobody has brought me any lately.',
        },
        armour = {
            'A merchant wants his guards kitted out before the road gets worse.',
            'Every hunter in town wants armour this season, and I cannot make it fast enough.',
            'I sell good secondhand pieces, and the shelf has been empty for a week.',
            'A new crew signed on at the docks and every one of them wants a helm.',
            'My last delivery of armour went down with the boat.',
        },
        hide = {
            'I make straps and linings, and I am short of {mass}.',
            'A customer wants a padded jack lined, and I have nothing to line it with.',
            'Every buckle needs a strap, and I am out of leather.',
            'My usual supplier stopped coming after the rains.',
        },
        material = {
            'The forge is cold for want of {mass}.',
            'I promised a set by the end of the month and I am short of {mass}.',
            'My usual supplier stopped coming after the rains.',
            'A customer wants work done that needs {mass}.',
        },
    },
    trade = {
        food = {
            'The cook says we are out of {mass} again.',
            'A caravan is due through and the larder will not feed them.',
            'We are feeding more mouths than usual and the stores are thin.',
            'The last delivery of {mass} was spoiled when it got here.',
            'I run the kitchen and I am short of {mass}.',
        },
        drink = {
            'The cellar is down to its last barrel.',
            'A wedding party wants {mass}, and we have none.',
            'The regulars have drunk us dry of {mass}.',
            'My supplier died, and the new one waters everything.',
            'We have guests coming and nothing worth pouring.',
        },
        hide = {
            'A buyer on the coast wants {mass}, and I am short.',
            'My tanner went home and took my stock with him.',
            'I promised a load of {mass} to a caravan and came up short.',
        },
        clothing = {
            'A wedding party is coming through, and every one of them wants something new to wear.',
            'The tailor upriver closed his shop, and his customers come to me now.',
            'A noble house is hosting guests and has sent for good clothes by the armful.',
            'My last bale of finery got soaked on the road.',
            'Pilgrims buy a clean set of clothes before the shrines, and my shelves are bare.',
        },
        tools = {
            'Locks are getting better and my customers keep asking for tools to match.',
            'A crew of tomb wardens bought every pick and probe I had.',
            'I keep picks and probes for the Guild lads, and they cleaned me out.',
            'A locksmith in town wants tools to practise on, and I promised him a box of them.',
        },
    },
    company = {
        any = {
            'A ship leaves for Cyrodiil at the end of the week and the hold is not full.',
            'The Company has a buyer in Ebonheart waiting on {mass}.',
            'Our factor promised a cargo of {mass} and the suppliers let us down.',
            'The warehouse is short of {mass} for an outgoing shipment.',
            'We promised the Legion {mass}, and we are behind on it.',
            'Prices for {mass} are up on the mainland, and we mean to ship some.',
            'A client in Firewatch paid in advance for {mass}, and we have none to send.',
            'The next boat to the mainland has space, and we mean to fill it with {mass}.',
            'Our stores in Old Ebonheart asked for {mass} by the end of the month.',
            'A caravan going west is short a load, and {mass} would cover it.',
            'We turned down a buyer last week for want of {mass}. That will not happen twice.',
            'The factor wants {mass} on the next ship, and the usual suppliers have gone quiet.',
        },
    },
}
-- Leads for an order of two goods: one story that fits both.
local PAIR_LEADS = {
    arms = { 'Six recruits signed on this week and the rack is bare.', 'We are fitting out a patrol and need everything at once.',
        'The drill master wants every recruit armed and practising by the end of the week.' },
    food = { 'The supply wagon is late again.', 'The stores will not last the week.',
        'We are feeding more mouths than usual and the larder is thin.' },
    potion = { 'The healers have been up every night this week and the shelves are empty.',
        'Everyone who comes in off the road seems to need a draught, and the shelf is bare.' },
    ingredient = { 'Our alchemist has a long list of draughts to make before the month is out.',
        'The apprentices used up half the stores on a bad batch.' },
    repair = { 'Half the armour in the hall needs mending and the tools are spent.',
        'The armourer has the work and not the tools.' },
    hide = { 'I have a large order of straps and linings to fill.' },
}
-- Which family can go with which in a two-line order, by first family.
local PAIRS = { arms = { 'arms', 'archery' }, archery = { 'arms' }, food = { 'food' }, potion = { 'potion' },
    ingredient = { 'ingredient' }, repair = { 'repair' }, hide = { 'hide' }, clothing = { 'clothing' },
    tools = { 'tools' } }
local PAIR_STORY = { arms = 'arms', archery = 'arms', food = 'food', potion = 'potion', ingredient = 'ingredient',
    repair = 'repair', hide = 'hide' }

-- Rare leads: one or two good pieces. {a_item}: "a Dwarven crossbow"; {items}: "two silver longswords".
local RARE_LEADS = {
    fighters = {
        arms = { 'Our champion wants a weapon that will not break on the first troll.',
            'The Guild gives a prize at the end of the season, and it ought to be worth winning.',
            'The master of the hall wants a fine piece for the trophy wall.',
            'A member who held the door in a bad fight is owed a reward.' },
        ranged = { "The marksman's trials are coming, and the prize ought to be worth winning.",
            'Our best archer wants a better weapon than the one she has.' },
        armour = { 'The master of the hall wants better armour than the Guild issues.',
            'A member is heading into the Ashlands and wants something better than chitin on his back.' },
    },
    legion = {
        arms = { "A Knight Errant is coming through, and the Commander wants him properly armed.",
            "The Commander wants a fine piece for the officers' mess.",
            'An officer lost his sword in the river and will pay well to replace it.' },
        armour = { 'A Knight Errant is coming through, and the Commander wants him properly kitted.',
            'The new Centurion wants armour that befits the rank.',
            'An officer lost his kit in the river and will pay well to replace it.' },
    },
    mages = {
        ingredient = { 'A master of the Guild needs it for an experiment she will not discuss.',
            "The Arch-Mage's office asked every hall for {a_item}.",
            'We are trying a recipe from an old book, and it calls for {items}.' },
        apparatus = { 'Our alchemist has outgrown her kit and wants a master\'s piece.',
            'A senior member is setting up her own brewing room.' },
        soulgem = { 'The enchanters want a great gem for a great work.',
            'A commission came in that no lesser gem will hold.' },
    },
    temple = {
        potion = { 'A Buoyant Armiger was carried in from the Ashlands, and our own draughts are not strong enough.',
            'The High Fane asked every temple to send its strongest draughts for the sick.',
            'A priest is going out among the blighted and wants the best potions there are.' },
    },
    smith = {
        material = { 'A noble wants a piece worked in fine metal, and I need {a_item} for it.',
            'I have a commission that calls for {items}.' },
    },
    company = {
        any = { 'A buyer in the Imperial City has asked for {items} and will not take a substitute.',
            'The Company would like a sample of {mass} to show a client.' },
    },
}

local ASK = {
    many = { 'We need {items}.', 'We are after {items}.', '{Items} would see us through.',
        'Bring us {items} if you can.', 'We could use {items}.' },
    one = { 'We want {a_item}.', 'It is {a_item} we are after.', 'Bring us {a_item}.' },
    rare = { 'It must be {a_item}, sound and whole.', 'We want {a_item}, and nothing less.',
        'Bring {a_item} in good order and the price is yours.' },
    rareMany = { 'We want {items}, sound and whole.', 'Bring {items} in good order and the price is yours.' },
}
-- A smith or trader signs for themselves.
local ASK_I = {
    many = { 'I need {items}.', 'I am after {items}.', 'What I want is {items}.', '{Items} would see me through.',
        'Bring me {items} if you can.', 'I could use {items}.' },
    one = { 'I want {a_item}.', 'It is {a_item} I am after.', 'What I want is {a_item}.', 'Bring me {a_item}.' },
    rare = { 'It must be {a_item}, sound and whole.', 'I want {a_item}, and nothing less.',
        'Bring {a_item} in good order and the price is yours.' },
    rareMany = { 'I want {items}, sound and whole.', 'Bring {items} in good order and the price is yours.' },
}
local FIRST_PERSON = { smith = true, trade = true }
local LEADS_SOUL = {
    'The enchanters have a commission and no soul strong enough for it.',
    'A member wants to make a ring for her mother and needs a trapped soul.',
    'Our soul gems sit empty while the enchanting table gathers dust.',
    'A client wants a staff charged, and our own stock has run out.',
    'The Guild is short of filled gems after a busy month.',
    'Someone paid in advance for an enchantment we cannot finish yet.',
    "We need a soul to recharge a ward on the hall's door.",
    'Our last good soul went into a sword that was never paid for.',
}
local ASK_SOUL = {
    strength = { 'Any soul as strong as {strength} will do.', 'It needs a soul at least as strong as {strength}.',
        'Nothing weaker than {strength}, please.', 'A soul like {strength} or better.' },
    creature = { 'It has to be {creature} soul, nothing else.', 'We need {creature} soul in particular.',
        'Only {creature} soul will work for this one.', 'Bring us {creature} soul.' },
}
local DROP = {
    one = { 'Bring it here to the notices.', 'Bring it to these notices and you are paid on the spot.',
        'Hand it in here at the notices.', 'Bring it here and you are paid at once.', 'Bring it here to be paid.',
        'Payment on delivery, here at the notices.', 'Leave word here when you have it, and the money is ready.',
        'Whoever brings it here is paid the same day.' },
    many = { 'Bring them here to the notices.', 'Bring them to these notices and you are paid on the spot.',
        'Hand them in here at the notices.', 'Bring them here and you are paid at once.',
        'Bring them here to be paid.', 'Payment on delivery, here at the notices.',
        'Whoever brings them here is paid the same day.', 'Bring the lot here and the money is counted out on the spot.' },
    company = { 'Deliveries are taken at these notices.', 'Bring the goods to the notices outside the office.',
        'Hand the goods in here and the clerk pays at once.', 'Bring them here; the clerk will see you paid.',
        'Deliveries are paid for here, at the office door.' },
    companyOne = { 'Bring it to the notices outside the office.', 'Hand it in here at the office door.',
        'Bring it here and the clerk pays at once.' },
}

local TITLES = {
    arms = { 'Weapons for the training yard', 'Arms for the recruits', '{Label} wanted' },
    thrown = { '{Label} wanted', 'Something to throw' },
    archery = { '{Label} for the butts', '{Label} wanted', 'Short of {mass}' },
    armour = { 'Armour for the recruits', '{Label} wanted' },
    repair = { 'Repair tools wanted', '{Label} wanted', 'The armoury needs tools' },
    ingredient = { "Wanted for the Guild's stores", 'Short of {mass}', 'Alchemy stores running low', '{Label} wanted' },
    scroll = { 'Scrolls wanted', "Wanted for the Guild's library", '{Label} wanted' },
    soulgem = { 'Soul gems wanted', '{Label} wanted' },
    apparatus = { 'Alchemy kit wanted', '{Label} wanted' },
    potion = { 'Draughts for the healers', '{Label} wanted', 'The healers are spent' },
    food = { 'Provisions wanted', '{Label} wanted', 'The larder is bare' },
    drink = { 'Wanted for the cellar', '{Label} wanted', 'The cellar is dry' },
    hide = { 'Hides wanted', '{Label} wanted' },
    material = { 'Wanted at the forge', '{Label} wanted' },
    clothing = { 'Good clothes wanted', '{Label} wanted' },
    tools = { 'Picks and probes wanted', '{Label} wanted' },
    soul = { 'Wanted: a trapped soul', 'A soul for the enchanters', 'Soul gem wanted, filled' },
}
local POSTER_TITLES = {
    legion = { food = { 'Rations for the garrison', 'Supply order: {mass}' }, potion = { 'Draughts for the garrison' },
        archery = { 'Supply order: {mass}' }, arms = { 'Supply order: {mass}', 'Arms for the garrison' } },
    temple = { food = { 'Food for the pilgrims', 'For the alms kitchen' }, potion = { 'For the pilgrims', 'The healers are spent' } },
    company = { any = { '{Label} wanted', '{Label} for shipping' } },
    smith = { arms = { '{Label} wanted', 'Weapons for the shop' }, armour = { '{Label} wanted', 'Armour for the shop' } },
}

M.SIGN = {
    ['mages guild'] = { 'Steward of the Mages Guild', 'The Mages Guild stores', 'The enchanters of the Mages Guild' },
    ['fighters guild'] = { 'Steward of the Fighters Guild', 'The Fighters Guild armoury', 'The Fighters Guild hall' },
    temple = { 'The healers of the Temple', 'A priest of the Temple', 'The Temple alms kitchen' },
    legion = { 'The Quartermaster', 'By order of the Commander', 'The garrison stores' },
}

-- A creature named with its article for the asks: "a scamp's", "an ogrim's".
local function possessive(name)
    name = name:gsub('%s+', ' '):lower()
    local first = name:sub(1, 1):lower()
    local art = first:find('[aeiou]') and 'an' or 'a'
    return art .. ' ' .. name .. (name:sub(-1) == 's' and "'" or "'s")
end

---------------------------------------------------------------------------------------------------
-- Picking

-- Which goods list each poster asks from.
M.LIST = { ['fighters guild'] = 'fighters', ['mages guild'] = 'mages', temple = 'temple', legion = 'legion',
    smith = 'smith', trade = 'trade', company = 'company' }
-- Who signs a town board's requisition: the Temple, a smith or a trader.
M.TOWN_POSTERS = { 'temple', 'smith', 'trade' }
-- How often each category is asked for, per poster list.
local WEIGHT = {
    fighters = { blade = 3, blunt = 2, axe = 1, spear = 1, thrown = 1, arrow = 3, bolt = 1, armour = 2, shield = 1,
        repair = 2, crossbow = 1, bow = 1 },
    legion = { arrow = 2, bolt = 2, food = 3, potion = 2, repair = 2, blade = 2, blunt = 1, spear = 1, armour = 2 },
    mages = { ingredient = 5, scroll = 2, soulgem = 2, apparatus = 1 },
    temple = { potion = 5, food = 2 },
    smith = { repair = 2, material = 1, blade = 2, blunt = 1, axe = 1, spear = 1, armour = 3, shield = 1 },
    trade = { drink = 3, clothing = 3, lockpick = 1, probe = 1 },
    company = { food = 3, drink = 1, hide = 2, ingredient = 1, material = 1 },
}

-- Where the player can come by an item: 'town' (a shop here), 'region' (a shop in a nearby
-- town), or nil.
local function soldWhere(id, a)
    if a.sells and a.sells[id] then return 'town' end
    if a.region and a.region[id] then return 'region' end
    return nil
end

-- Rare orders never ask for what a shop in this town or the region stocks: rare goods are found,
-- not bought. Of the rest, those no merchant stocks anywhere (s == 0) come first; goods sold only
-- far away join them when a list has fewer than RARE_FOUND_MIN found pieces.
local function usable(list, a)
    local out = {}
    for _, g in ipairs(list or {}) do
        if (not a.have or a.have(g.req)) and not (a.used and a.used[g.id]) and (g.n or a.name(g.id))
            and not (a.grade == 'rare' and soldWhere(g.id, a)) then
            out[#out + 1] = g
        end
    end
    if a.grade == 'rare' then
        local found, far = {}, {}
        for _, g in ipairs(out) do
            if (g.s or 0) == 0 then found[#found + 1] = g else far[#far + 1] = g end
        end
        if #found < Q.RARE_FOUND_MIN then
            for _, g in ipairs(far) do found[#found + 1] = g end
        end
        out = found
    end
    return out
end

-- Rows by category, and a weighted category pick among those present.
local function byCat(list)
    local out = {}
    for _, g in ipairs(list) do
        local c = g.cat or 'any'
        out[c] = out[c] or {}
        out[c][#out[c] + 1] = g
    end
    return out
end

local function pickCat(cats, weights, rnd, only)
    local total, opts = 0, {}
    for c, rows in pairs(cats) do
        local fam = M.FAMILY[c] or c
        if #rows > 0 and (not only or only[fam]) then
            local w = (weights or {})[c] or 1
            opts[#opts + 1] = { c = c, w = w }
            total = total + w
        end
    end
    table.sort(opts, function(x, y) return x.c < y.c end)
    if total == 0 then return nil end
    local r = rnd() * total
    for _, o in ipairs(opts) do
        r = r - o.w
        if r <= 0 then return o.c end
    end
    return opts[#opts].c
end

-- One row of a category: REGION_SHARE of the time from what the region's shops sell, if any.
local function pickRow(rows, a, rnd)
    local near = {}
    for _, g in ipairs(rows) do
        if soldWhere(g.id, a) then near[#near + 1] = g end
    end
    if #near > 0 and (rnd() < Q.REGION_SHARE or #near == #rows) then return near[rnd(#near)] end
    return rows[rnd(#rows)]
end

-- A goods row's worth for pay: a.worth (id, base value -> worth) when given, else its base value.
local function worthOf(g, a)
    return a.worth and a.worth(g.id, g.v) or g.v
end

local function nameOf(g, a)
    local n = a.name and a.name(g.id)
    if not n or n == '' then n = g.n end
    return n
end

-- What an item is, without its grade: "Cheap Restore Health" and "Bargain Restore Health" are both
-- "restore health". Two lines of one order never share a stem.
local GRADES = { bargain = true, cheap = true, standard = true, quality = true, exclusive = true }
local function stem(name)
    local s = (name or ''):lower():gsub(' potion$', ''):gsub('^potion of ', '')
    local first, rest = s:match('^(%a+) (.+)$')
    if first and GRADES[first] then s = rest end
    return s
end

-- The words for an order. lines: { { name, count, cat }, ... }.
local function words(listKey, grade, lines, a, rnd)
    local first = lines[1]
    local fam = M.FAMILY[first.cat] or first.cat
    local drink = first.cat == 'drink'
    local vars = {
        items = N.count(first.name, first.count, drink), mass = N.lower(first.name), short = SHORT[first.cat],
        one = N.forms(first.name, drink).one, a_item = N.a(first.name, drink), town = a.town,
        Label = N.label(first.name, drink),
    }
    if first.count > 1 then vars.mass = N.plural(first.name, drink) end
    if first.cat == 'ingredient' or first.cat == 'food' or first.cat == 'hide' or first.cat == 'material'
        or drink then
        -- Stuffs read as the stuff itself ("short of saltrice"), countables as their plural.
        local f = N.forms(first.name, drink)
        vars.mass = f.many:match('^%a+ of (.+)$') or f.many
        vars.Label = cap(vars.mass)
    elseif first.count == 1 then
        vars.Label = cap(vars.one)
    end
    if not vars.short then vars.short = N.plural(first.name, drink) end
    if lines[2] then
        local second = lines[2]
        vars.items = vars.items .. ' and ' .. N.count(second.name, second.count, second.cat == 'drink')
    end
    vars.Items = cap(vars.items)
    local used = a.usedText
    local function fresh(list)
        local open = {}
        for _, s in ipairs(list) do
            local t = fill(s, vars)
            if not t:find('{', 1, true) and not (used and used[t]) then open[#open + 1] = t end
        end
        if #open == 0 then
            for _, s in ipairs(list) do
                local t = fill(s, vars)
                if not t:find('{', 1, true) then open[#open + 1] = t end
            end
        end
        return open[rnd(#open)]
    end
    local pool = (grade == 'rare' and RARE_LEADS or LEADS)[listKey] or {}
    local leads = pool[fam] or pool.any
    -- A smith or trader tells their own story for two goods; a guild has its pair leads.
    if lines[2] and not FIRST_PERSON[listKey] then leads = PAIR_LEADS[PAIR_STORY[fam]] or leads end
    if not leads then return nil end
    local lead = fresh(leads)
    if not lead then return nil end
    local ask
    local asks = FIRST_PERSON[listKey] and ASK_I or ASK
    if grade == 'rare' then
        local list = first.count == 1 and asks.rare or asks.rareMany
        -- "Sound and whole" is for arms and armour, not hair or gems.
        if fam ~= 'arms' and fam ~= 'armour' and fam ~= 'ranged' and fam ~= 'thrown' then
            local kept = {}
            for _, s in ipairs(list) do if not s:find('sound and whole', 1, true) then kept[#kept + 1] = s end end
            list = #kept > 0 and kept or list
        end
        ask = fresh(list)
    elseif first.count == 1 and not lines[2] then
        ask = fresh(asks.one)
    else
        ask = fresh(asks.many)
    end
    -- A lead that already names the goods with their count needs no ask.
    if lead:find(vars.items, 1, true) then ask = nil end
    local many = first.count > 1 or lines[2]
    local drop
    if listKey == 'company' then
        drop = fresh(many and DROP.company or DROP.companyOne)
    else
        drop = fresh(many and DROP.many or DROP.one)
    end
    local body = lead .. (ask and (' ' .. ask) or '') .. ' ' .. drop
    local title
    if lines[2] then
        local function word(l)
            local f = N.forms(l.name, l.cat == 'drink')
            return f.many:match(' of (.+)$') or f.many:match('(%S+)$')
        end
        local w1, w2 = word(first), word(lines[2])
        if w1 == w2 then
            title = fill(pick(TITLES[fam] or { '{Label} wanted' }, rnd), vars)
            if title:find(N.label(first.name, drink), 1, true) then title = cap(w1) .. ' wanted' end
        else
            title = cap(w1) .. ' and ' .. w2
        end
    elseif grade == 'rare' then
        title = (first.count == 1 and 'One ' or (cap(N.number(first.count)) .. ' ')) ..
            (first.count == 1 and vars.one or N.plural(first.name, drink))
    else
        local t = (POSTER_TITLES[listKey] or {})[fam] or (POSTER_TITLES[listKey] or {}).any or TITLES[fam]
            or { '{Label} wanted' }
        title = fill(pick(t, rnd), vars)
    end
    if #title > 48 then title = fill('{Label} wanted', vars) end
    return title, body
end

-- An order. a: { poster ('fighters guild', 'mages guild', 'temple', 'legion', 'smith', 'trade',
-- 'company'), grade ('common', 'rare'; 'company' for a company's bulk lot), town, goods
-- (supply.goods), company (a supply.companies entry, for 'company'), sells (set: sold in this
-- town), region (set: sold in a nearby town), used (set: asked for already), have (content file ->
-- bool), name (id -> display name), rnd, from (signature), usedText (set of sentences already on
-- this board), shopOf (id -> where a shop here sells it, or nil) }. Returns a notice table or nil, why.
function M.order(a)
    local rnd = a.rnd
    local key = M.LIST[a.poster]
    if not key then return nil, 'no goods list for ' .. tostring(a.poster) end
    local grade = a.grade or 'common'
    local list
    if a.poster == 'company' and grade ~= 'rare' then
        list = a.company and a.company.goods
        grade = 'company'
    else
        list = a.goods[key] and a.goods[key][grade == 'rare' and 'rare' or 'common']
    end
    list = usable(list, a)
    if #list == 0 then return nil, 'nothing on the ' .. grade .. ' list for ' .. a.poster end
    local cats = byCat(list)
    local weights = WEIGHT[key]
    for _ = 1, 4 do
        local cat = pickCat(cats, weights, rnd)
        if not cat then break end
        local row = pickRow(cats[cat], a, rnd)
        local name = nameOf(row, a)
        if name then
            local sold = soldWhere(row.id, a)
            if grade == 'rare' and (row.s or 0) > 0 then sold = 'far' end
            local harvest = grade == 'rare' and row.h or nil
            local prem = harvest and M.premium('harvest', rnd) or M.premium(grade, rnd, sold)
            local v = worthOf(row, a)
            local n = M.count(v, grade, prem, rnd, harvest)
            local lines = { { id = row.id, count = n, name = name, cat = cat, v = v, prem = prem, sold = sold,
                h = row.h } }
            -- Sometimes a second line from a family that shares the story, keeping the total in band.
            local fam = M.FAMILY[cat] or cat
            if grade == 'common' and PAIRS[fam] and rnd() < Q.PAIR_CHANCE then
                local only = {}
                for _, f in ipairs(PAIRS[fam]) do only[f] = true end
                local rest = {}
                local first = stem(name)
                for c, rows in pairs(cats) do
                    local left = {}
                    for _, g in ipairs(rows) do
                        if g.id ~= row.id and stem(nameOf(g, a)) ~= first then left[#left + 1] = g end
                    end
                    rest[c] = left
                end
                local cat2 = pickCat(rest, weights, rnd, only)
                if cat2 then
                    local row2 = pickRow(rest[cat2], a, rnd)
                    local name2 = nameOf(row2, a)
                    if name2 then
                        local sold2 = soldWhere(row2.id, a)
                        local prem2 = M.premium(grade, rnd, sold2)
                        local band = M.band(grade)
                        local v2 = worthOf(row2, a)
                        local n1 = math.max(1, math.floor(n * 0.6 + 0.5))
                        local room = band[2] - v * prem * n1 - Q.FEE.common
                        local n2 = math.max(1, math.min(Q.COUNT.hi, math.floor(room * 0.6 / math.max(0.5, v2 * prem2))))
                        if v2 <= Q.COUNT.stackValue then n2 = math.min(Q.COUNT.stack, math.max(n2, 5)) end
                        lines[1].count = n1
                        lines[2] = { id = row2.id, count = n2, name = name2, cat = cat2, v = v2, prem = prem2, sold = sold2 }
                    end
                end
            end
            -- Within the band: the first line grows toward the floor and shrinks under the ceiling, else
            -- the pick is dropped. a.worth can price a piece away from the base value the pick was made on.
            local floor, ceil = M.band(grade, harvest)[1], M.band(grade, harvest)[2]
            local function total()
                local t = M.fee(grade, lines)
                for _, l in ipairs(lines) do t = t + M.each(l.v, l.prem) * l.count end
                return t
            end
            local most = harvest and math.min(Q.COUNT.harvestHi, Q.COUNT.max) or (grade == 'rare' and 2 or Q.COUNT.max)
            while total() < floor and lines[1].count < most do lines[1].count = lines[1].count + 1 end
            while total() > ceil and lines[1].count > 1 do lines[1].count = lines[1].count - 1 end
            n = lines[1].count
            -- A rare order is one or two good pieces; a lot of anything is a common order.
            local shown = (grade == 'rare' and n > 2) and 'common' or grade
            local title, body
            local t = total()
            if t >= floor and t <= ceil then title, body = words(key, shown, lines, a, rnd) end
            if title then
                local fee = M.fee(grade, lines)
                local total, worth = fee, 0
                for _, l in ipairs(lines) do
                    l.each = M.each(l.v, l.prem)
                    l.sound = (M.FAMILY[l.cat] == 'arms' or M.FAMILY[l.cat] == 'armour' or l.cat == 'repair'
                        or M.FAMILY[l.cat] == 'ranged' or l.cat == 'thrown') or nil
                    l.hint = a.shopOf and l.sold == 'town' and a.shopOf(l.id) or nil
                    total = total + l.each * l.count
                    worth = worth + l.v * l.count
                    l.v, l.prem = nil, nil
                end
                local sub = a.poster == 'company' and 'company' or 'goods'
                local from = a.from or (a.poster == 'company' and a.company and (a.company.name .. ', ' .. a.town))
                    or pick(M.SIGN[a.poster] or { a.town }, rnd)
                return {
                    sub = sub, grade = (shown == 'company' or shown == 'common') and 'common' or shown, group = cat,
                    title = title, body = body, harvest = harvest,
                    plain = body, from = from, lines = lines, want = lines[1], value = total, worth = worth, fee = fee,
                }
            end
        end
    end
    return nil, 'no order fitted'
end

-- Kept for older callers and tests: a common goods order.
function M.goods(a)
    a.grade = a.grade or 'common'
    return M.order(a)
end

-- A soul requisition (Mages Guild, or an enchanter collector with min set). a: { grade, souls
-- (supply.souls), have, rnd, town, usedText, min }. The strength band and the creatures named come
-- from the grade, never the player: a creature named is one found at or below the grade's level.
-- Asks for a creature by name CREATURE_SHARE of the time, else a strength given as a creature of it.
function M.soul(a)
    local rnd = a.rnd
    local band = Q.SOULS[a.grade or 'common'] or Q.SOULS.common
    local lo, hi = a.min or band.lo, a.min and math.max(a.min, band.hi) or band.hi
    local fit = {}
    for _, s in ipairs(a.souls or {}) do
        if s.soul >= lo and s.soul <= hi and s.level <= band.level and (not a.have or a.have(s.req)) then
            fit[#fit + 1] = s
        end
    end
    if #fit == 0 then return nil, 'no findable creature in the strength band' end
    local s = fit[rnd(#fit)]
    s = { name = (s.name:gsub('%s+', ' ')), soul = s.soul, level = s.level }
    local byName = rnd() < Q.CREATURE_SHARE
    local vars = byName and { creature = possessive(s.name) } or { strength = possessive(s.name) }
    local lead = pick(LEADS_SOUL, rnd)
    local ask = fill(pick(byName and ASK_SOUL.creature or ASK_SOUL.strength, rnd), vars)
    local body = lead .. ' ' .. ask .. ' ' .. pick(DROP.one, rnd)
    local title = pick(TITLES.soul, rnd)
    if byName and rnd() < 0.5 then title = 'Wanted: ' .. possessive(s.name) .. ' soul' end
    -- A trapped soul is real work whatever the board's grade: always the rare premium.
    local pay = M.soulPay(s.soul, 'rare', a.soulOpts)
    return {
        sub = 'soul', grade = 'rare', slot = a.grade or 'common', group = 'soul', title = title, body = body, plain = body,
        from = a.from or pick(M.SIGN['mages guild'], rnd),
        want = { soul = s.soul, creature = byName and s.name or nil, name = s.name, each = pay, count = 1 },
        value = pay, worth = math.floor(M.soulWorth(s.soul, a.soulOpts) + 0.5),
    }
end

---------------------------------------------------------------------------------------------------
-- Collectors

local COLLECT_LEADS = {
    smith = {
        'I collect old Dwemer pieces, the stranger the better, and I am after {a_item}.',
        'A customer asked me for {a_item} and I would like to have one on the bench.',
        'I have wanted {a_item} for years and never seen one for sale.',
        'My master had {a_item} and I never got over losing it.',
    },
    scholar = {
        'I am looking for a copy of {item} for my shelves.',
        'Someone borrowed my copy of {item} years ago and never brought it back.',
        'A friend swears {item} is worth reading, and I have never found a copy.',
        'I am writing something and I need a copy of {item} to check a point.',
        'My copy of {item} went in a house move, and I miss it more than the furniture.',
        'The damp got into my copy of {item}, and the pages stick together now.',
    },
    enchanter = {
        'I have a piece that needs a strong soul, {strength} or better.',
        'I am working on something I will not talk about until it is done. It needs {creature} soul.',
        'A client wants a great work, and the soul has to be {strength} or stronger.',
        'The ring on my bench will only take {creature} soul.',
        'An old staff came to me for recharging, and its maker swore by {creature} soul.',
        'My last commission wants {creature} soul, and nothing else will hold the charm.',
        'I have a blade half enchanted, waiting on {strength} soul or stronger.',
    },
}
local COLLECT_ASK = {
    'I pay well for it, better than any merchant.', 'I will pay more than it is worth to anyone else.',
    'You will not find a better buyer.', 'I will pay over the odds for it.', 'No merchant will give you as much.',
    'It is worth more to me than to anyone in {town}.',
}
local COLLECT_DROP = {
    'Bring it here to the notices and I will see you paid.', 'Hand it in at these notices.',
    'Bring it here.', 'Bring it here and the money is yours.',
    'Hand it in here and you are paid on the spot.',
}
local COLLECT_TITLE = { smith = "A smith's request", scholar = 'Wanted: an old book', enchanter = "An enchanter's request" }

-- One uncommon piece for a named collector, at COLLECT premium over its worth. a: { collector =
-- { name, role }, town, collect (supply.collect), souls, used, have, name, rnd }. An enchanter
-- asks for a strong soul (COLLECT_SOUL_MIN or more, rare grade).
function M.collector(a)
    local rnd, who = a.rnd, a.collector
    local role = who.role
    if role == 'enchanter' then
        local s, why = M.soul({ grade = 'rare', souls = a.souls, have = a.have, rnd = rnd, town = a.town,
            min = Q.COLLECT_SOUL_MIN, soulOpts = a.soulOpts })
        if not s then return nil, why end
        local vars = { creature = s.want.creature and possessive(s.want.creature), strength = possessive(s.want.name),
            town = a.town }
        local leads = {}
        for _, l in ipairs(COLLECT_LEADS.enchanter) do
            if (l:find('{creature}') ~= nil) == (s.want.creature ~= nil) then leads[#leads + 1] = l end
        end
        s.sub, s.collector, s.grade = 'collect', who.name, 'rare'
        s.title = COLLECT_TITLE.enchanter
        s.body = fill(pick(leads, rnd), vars) .. ' ' .. fill(pick(COLLECT_ASK, rnd), vars) .. ' '
            .. pick(COLLECT_DROP, rnd)
        s.plain, s.from = s.body, who.name
        s.value = M.soulPay(s.want.soul, 'collect', a.soulOpts)
        s.want.each = s.value
        return s
    end
    local open = usable(a.collect[role], a)
    if #open == 0 then return nil, 'nothing collectable' end
    local it = open[rnd(#open)]
    local name = nameOf(it, a)
    local vars = { item = name, a_item = role == 'smith' and N.a(name) or name, town = a.town }
    local body = fill(pick(COLLECT_LEADS[role], rnd), vars) .. ' ' .. fill(pick(COLLECT_ASK, rnd), vars) .. ' '
        .. pick(COLLECT_DROP, rnd)
    local each = M.each(it.v, Q.PREMIUM.collect) + Q.FEE.collect
    local book = role == 'scholar' or nil
    local title = book and ('Wanted: a copy of ' .. name) or COLLECT_TITLE[role] or "A collector's request"
    if #title > 48 then title = COLLECT_TITLE[role] or title end
    return {
        sub = 'collect', grade = 'rare', group = role, collector = who.name,
        title = title, body = body, plain = body, from = who.name,
        want = { id = it.id, count = 1, name = name, each = each, book = book }, value = each, worth = it.v,
    }
end

-- A company order: a bulk lot of what the office trades in, or RARE_CHANCE of one rare material.
-- a: as M.order, with company set.
function M.company(a)
    a.poster = 'company'
    a.grade = a.rnd() < Q.COMPANY_RARE and 'rare' or 'company'
    local n, why = M.order(a)
    if not n and a.grade == 'rare' then
        a.grade = 'company'
        n, why = M.order(a)
    end
    return n, why
end


---------------------------------------------------------------------------------------------------
-- Lost ledgers

-- How a townsperson would name a public interior: "Balmora, Guild of Mages" -> "the Guild of
-- Mages", "Balmora, Meldor: Armorer" -> "Meldor's shop", "Balmora, Eight Plates" -> "Eight Plates".
local THE_START = { 'Census', 'Imperial', 'Grand', 'Hlaalu', 'Redoran', 'Telvanni', 'Temple', 'Council', 'Docks',
    'East Empire', 'Foreign', 'Upper', 'Lower', 'Market', 'Ordinator', 'Hawkmoth', 'Skyrim', 'Healers' }
local THE_END = { 'Tavern', 'Inn', 'Cornerclub', 'Club', 'Hall', 'Manor', 'Office', 'Barracks', 'Chapel', 'Chapels',
    'Mission', 'Garrison', 'Commission', 'Chambers', 'Society', 'Waistworks', 'Embassy', 'Bank', 'Library',
    'Temple', 'Tower', 'Lighthouse', 'Warehouse', 'Quarters', 'Guardhouse', 'Brewery', 'Dome', 'Tradehouse',
    'Plaza', 'Bazaar', 'Arena', 'Theater', 'College', 'Fane', 'Canton' }
local INSTITUTION = { 'Guild', 'Temple', 'Fort', 'Keep', 'Chapel', 'Hall', 'Manor', 'Tower', 'Council', 'Society',
    'Library', 'College', 'Office', 'Theater', 'Mission', 'House', 'Club', 'Bank', 'Garrison', 'Legion' }

local function hasWord(s, list, where)
    for _, w in ipairs(list) do
        if where == 'start' and s:sub(1, #w) == w then return true end
        if where == 'end' and s:sub(-#w) == w then return true end
        if where == 'any' and s:find('%f[%a]' .. w .. '%f[%A]') then return true end
    end
    return false
end

-- Places everyone calls by what they are: "the prison", "the sewers".
local PLAIN_PLACE = { prison = true, underworks = true, sewers = true, sewer = true, ['public bath'] = true,
    arena = true, docks = true, canalworks = true, waistworks = true }

function M.placeName(cell)
    local s = cell:gsub('^[^,]*,%s*', ''):gsub('_%w+$', '')
    local before = s:match('^(.-)%s*:')
    if before then
        if PLAIN_PLACE[before:lower()] then return 'the ' .. before:lower() end
        if not hasWord(before, INSTITUTION, 'any') then return before .. "'s shop" end
        s = before
    end
    if PLAIN_PLACE[s:lower()] then return 'the ' .. s:lower() end
    if s:find("'s ") or s:find("s' ") then return s end
    if s:sub(1, 4) == 'The ' then return 'the ' .. s:sub(5) end
    if s:find(' of ') or hasWord(s, THE_START, 'start') or hasWord(s, THE_END, 'end') then return 'the ' .. s end
    return s
end

local LOST_NOUNS = { 'ledger', 'account book', 'daybook' }
local LOST_TITLE = { 'Lost: my {noun}', 'Have you seen my {noun}?', 'Lost in {town}: one {noun}', 'Missing {noun}',
    '{anoun} gone astray' }
local LOST_LEAD = {
    'I lost my {noun} somewhere in {town} yesterday.',
    'My {noun} has gone missing, and every sale this season is written in it.',
    'I have lost my {noun}, and all my accounts are in it.',
    'Somewhere on my errands I put my {noun} down and never picked it up again.',
    'I cannot find my {noun}, and half the town owes me money by what is in it.',
    'My {noun} is lost, and I cannot settle a single debt without it.',
}
local LOST_FIRST = {
    'I had it at {a} in the morning.', 'In the morning I had it with me at {a}.', 'I know I had it at {a}.',
    'It was under my arm when I left {a}.', 'I remember paying with it open at {a}.',
}
local LOST_THEN = {
    'Then I went by {b}.', 'After that I stopped at {b}.', 'From there I walked over to {b}.',
    'Then I called in at {b}.', 'Next I went to {b} for a while.',
}
-- Sitting lines only for what a person sits on; a counter, shelf or table gets the others.
local SEATS = { bench = true, crate = true, barrel = true, chest = true }
local LOST_LAST_NEAR = {
    'The last place I recall is a {word} not far from {near}.',
    'I think I set it down on a {word} by {near} and walked off without it.',
}
local LOST_LAST_NEAR_SIT = {
    'Last I remember, I sat down on a {word} near {near}.',
    'I rested a while on a {word} close to {near}, and after that it was gone.',
}
local LOST_LAST = {
    'Last I remember, I set it down on a {word} out in the street.',
    'I think I left it on a {word} somewhere outside, between errands.',
}
local LOST_LAST_SIT = {
    'I rested a while on a {word} in the open, and after that it was gone.',
}
local LOST_ASK = {
    'Whoever finds it, I will pay for the trouble.', 'There is a reward for it.',
    'I will pay to have it back, no questions asked.', 'It is worth nothing to anyone but me, and I will pay for it.',
    'Bring it back and you will not go short.', 'I will gladly pay whoever returns it.',
}
local LOST_DROP = {
    'Bring it here.', 'Hand it in here at the notices.',
    'Bring it here and the money is yours.', 'Bring it here to be paid.',
    'Return it here and you are paid on the spot.', 'Bring it to these notices and the reward is yours.',
}

-- A lost ledger notice. a: { town, from (signer), first (owner's first name), stops (place
-- names before the last, 0 to C.LOST.STOPS), word (what it lies on), near (place name or nil), rnd }.
-- want.id is filled in by reqs.lua once the book exists.
function M.lost(a)
    local rnd = a.rnd
    local noun = pick(LOST_NOUNS, rnd)
    local vars = { noun = noun, anoun = (noun:find('^[aeiou]') and 'an ' or 'a ') .. noun, town = a.town,
        word = a.word, near = a.near, a = a.stops[1], b = a.stops[2] }
    local parts = { fill(pick(LOST_LEAD, rnd), vars) }
    if a.stops[1] then parts[#parts + 1] = fill(pick(LOST_FIRST, rnd), vars) end
    if a.stops[2] then parts[#parts + 1] = fill(pick(LOST_THEN, rnd), vars) end
    local last = a.near and LOST_LAST_NEAR or LOST_LAST
    if SEATS[a.word] then
        last = {}
        for _, s in ipairs(a.near and LOST_LAST_NEAR or LOST_LAST) do last[#last + 1] = s end
        for _, s in ipairs(a.near and LOST_LAST_NEAR_SIT or LOST_LAST_SIT) do last[#last + 1] = s end
    end
    parts[#parts + 1] = fill(pick(last, rnd), vars)
    parts[#parts + 1] = pick(LOST_ASK, rnd)
    parts[#parts + 1] = pick(LOST_DROP, rnd)
    local body = table.concat(parts, ' ')
    local name = a.first .. "'s " .. (noun == 'account book' and 'Account Book' or cap(noun))
    local pay = math.floor((C.LOST.GOLD[1] + (C.LOST.GOLD[2] - C.LOST.GOLD[1]) * rnd()) / 5 + 0.5) * 5
    return {
        sub = 'lost', grade = 'common', group = noun, title = cap(fill(pick(LOST_TITLE, rnd), vars)), body = body,
        plain = body, from = a.from, want = { count = 1, name = name, each = pay }, value = pay, worth = 0,
    }
end

---------------------------------------------------------------------------------------------------
-- Matching what the player carries

-- How many of `want` the player can hand in. carried: list of { id, count, soul (creature id or
-- nil), soulValue, creature (name), condition, maxCondition, ours (a contract item), stolen
-- (pieces of this record known stolen) }. Returns usable count and the entries it would take, in
-- order. Soul requests take one gem: the weakest that qualifies.
function M.match(want, carried)
    if want.soul then
        local best
        for _, c in ipairs(carried) do
            local ok = c.soulValue and not c.ours and (c.stolen or 0) < c.count
                and c.soulValue >= (want.creature and 0 or want.soul)
                and (not want.creature or (c.creature or ''):lower() == want.creature:lower())
            if ok and (not best or c.soulValue < best.soulValue) then best = c end
        end
        return best and 1 or 0, best and { { entry = best, n = 1 } } or {}
    end
    local total, take = 0, {}
    local want_id = want.id:lower()
    -- The stolen count is per record, so it is used up across every stack of it.
    local stolenLeft
    for _, c in ipairs(carried) do
        if c.id:lower() == want_id and not c.ours and not c.soul then
            stolenLeft = stolenLeft or c.stolen or 0
            local sound = not want.sound or not c.maxCondition or c.maxCondition <= 0
                or (c.condition or c.maxCondition) >= c.maxCondition * Q.CONDITION
            local skip = math.min(stolenLeft, c.count)
            stolenLeft = stolenLeft - skip
            if sound then
                local n = c.count - skip
                n = math.min(n, want.count - total)
                if n > 0 then
                    take[#take + 1] = { entry = c, n = n }
                    total = total + n
                end
            end
        end
        if total >= (want.count or 1) then break end
    end
    return total, take
end

return M
