---@omw-context global
-- Odd Jobs: small story turns on a contract already taken. Rolled when it's taken (nothing on the
-- notice gives them away) and played out on the first visit. Each is its own feature switch:
--   twistOffer   a bounty's leader gives up and offers a purse: take it, let them go, or finish it
--   twistLied    a note in the place says a town recovery belongs to someone else in another town
--   twistRival   another adventurer took the same job: dead, fighting, or racing the player in
--   twistWorse   a clearing job's foes were killed by something tougher, which is the job now
--   twistChains  a letter on a bounty's leader names a second place, posted as a follow-up

local core = require('openmw.core')
local types = require('openmw.types')
local world = require('openmw.world')

local C = require('scripts.ojb.config')
local ROSTER = require('scripts.ojb.roster')
local TI = require('scripts.ojb.tier')
local ST = require('scripts.ojb.story')

local TW = C.TWIST
local M = {}

local function pick(list, rnd) return list[rnd(#list)] end

local function fill(s, a)
    return (s:gsub('{(%w+)}', function(k) return a[k] ~= nil and tostring(a[k]) or ('{' .. k .. '}') end))
end

local function cap(s) return (s:gsub('^%l', string.upper)) end

-- The poster by name alone: a signature can carry a trade ("Sedris Hlaren, caravaner").
local function posterName(c) return (c.from or ''):match('^([^,]+)') or 'the poster' end

-- The piece as a stranger would call it: "ring", not "the Indaren family ring".
local function plainNoun(c)
    for _, list in pairs(C.ITEM_KINDS) do
        for _, k in ipairs(list) do
            if k.key == c.itemKind then return k.noun:match('(%S+)$') end
        end
    end
    return 'piece'
end

-- Whose voice a leader's lines are in, by the group they lead.
M.VOICE = { bandit = 'bandit', graverobber = 'bandit', smuggler = 'smuggler', pirate = 'pirate', cultist = 'cultist',
    warlock = 'warlock', necromancer = 'warlock', vampire = 'warlock' }

-- Lines. Plain notes and things people say, nothing that explains how the job works. offer, spare
-- and chain are said or written by the leader's people, so they come in each voice (M.VOICE).
M.LINES = {
    offer = {
        bandit = {
            '{Leader} lowers {his} guard. "Enough! I have {gold} drakes put by. Take them and tell them you never found me."',
            '{Leader} backs off, hands up. "Wait. Wait! There is {gold} in gold in it for you if you walk away."',
            '{Leader} drops to one knee. "I yield. {Gold} drakes, and you never saw me. Please."',
            '{Leader} spits blood and grins. "All right, you win. {Gold} drakes from the strongbox, and I am gone by morning."',
            '{Leader} throws down {his} blade. "I know when I am beaten. {Gold} drakes. It is all the road paid me this month."',
            '{Leader} stumbles back against the wall. "Hold! Hold. I have {gold} drakes. Nobody needs to know you found me."',
            '{Leader} raises an empty hand. "We can both walk out of here. {Gold} drakes says we can."',
            '{Leader} sinks down, breathing hard. "Take the purse, {gold} drakes. Tell them I was gone when you got here."',
            '{Leader} laughs, short and ugly. "You are better than the last ones. {Gold} drakes to forget my face."',
            '{Leader} backs into the corner. "Enough. {Gold} drakes, and I take my people somewhere far from here."',
        },
        smuggler = {
            '{Leader} lifts both hands. "Business, then. {Gold} drakes, and you never saw this place."',
            '{Leader} sets {his} blade down on a crate. "No need for more of this. {Gold} drakes, clean coin, and we are both gone."',
            '{Leader} backs off. "The cargo is worth more to me than this fight. {Gold} drakes if you let me load the boat and go."',
            '{Leader} wipes {his} mouth. "Listen. {Gold} drakes. No Census man ever paid you that much for honesty."',
            '{Leader} kneels by a crate. "Take {gold} drakes out of the strongbox. I will be across the water by tomorrow."',
            '{Leader} holds out a heavy purse. "{Gold} drakes. Count it if you like. Then forget the way here."',
            '{Leader} keeps {his} distance. "I deal, I do not die. {Gold} drakes, and the trade goes somewhere else."',
            '{Leader} lowers {his} blade. "Everyone has a price. Mine for you is {gold} drakes. Do we have a bargain?"',
            '{Leader} glances at the door. "The tide turns soon. {Gold} drakes, and I am on it."',
            '{Leader} sighs. "This was a good spot, too. {Gold} drakes to let me leave it quietly."',
        },
        cultist = {
            '{Leader} falls back, hands raised. "Stop! The offerings, {gold} drakes. Take them and let me go."',
            '{Leader} clutches at {his} robes. "My master will not save me, I see that now. {Gold} drakes, and I leave this place."',
            '{Leader} sinks to the floor of the shrine. "{Gold} drakes from the offering bowl. Take it. Please."',
            '{Leader} gasps. "The faithful gave {gold} drakes. It is yours. Let me walk out of here."',
            '{Leader} stops chanting and drops {his} hands. "Enough. {Gold} drakes, and I swear you will never see me again."',
            '{Leader} backs against the altar. "Spare me and the tithe is yours, {gold} drakes."',
            '{Leader} stares at you. "You were not in the vision. Take {gold} drakes and go, and I will leave too."',
            '{Leader} lowers {his} eyes. "The rites are done here. {Gold} drakes, and let me take my leave."',
            '{Leader} fumbles a purse from {his} robes. "{Gold} drakes. The others will never know you came."',
            '{Leader} raises {his} hands before {his} face. "Mercy. {Gold} drakes. My prince did not ask me to die today."',
        },
        warlock = {
            '{Leader} lets the spell in {his} hand die. "Enough. I have {gold} drakes. Take them and leave me to my work elsewhere."',
            '{Leader} staggers back, smoke rising from {his} sleeves. "Wait! {Gold} drakes, and you never found me."',
            '{Leader} lowers {his} staff. "You are stronger than I thought. {Gold} drakes buys your silence, yes?"',
            '{Leader} coughs. "Years of study, and it ends like this? No. {Gold} drakes, and I go."',
            '{Leader} raises a hand, and nothing comes out of it. "I am spent. {Gold} drakes. Let me walk away."',
            '{Leader} sneers, then thinks better of it. "{Gold} drakes. Gold does not care what I do with my evenings."',
            '{Leader} backs off towards the dark. "My notes are worth more to me than my life. {Gold} drakes if you let me keep both."',
            '{Leader} drops to one knee. "I yield. {Gold} drakes, and I leave this place to rot."',
            '{Leader} breathes hard. "There is {gold} in gold in the chest behind me. Take it and say I was gone."',
            '{Leader} lowers {his} voice. "Think. {Gold} drakes, and nobody ever hears of it."',
        },
        pirate = {
            '{Leader} lowers {his} blade. "Enough, enough. {Gold} drakes from the sea chest, and you never saw my face."',
            '{Leader} backs off, grinning through the blood. "A fair fight, and you won it. {Gold} drakes, and my crew sails tonight."',
            '{Leader} drops to one knee on the wet stone. "I yield. {Gold} drakes, and we find another coast."',
            '{Leader} raises an empty hand. "Every captain knows when to strike the colours. {Gold} drakes, and I strike them."',
            '{Leader} spits. "Take the share, {gold} drakes. More than the fishermen will ever pay you."',
            '{Leader} laughs. "You fight like a sailor. {Gold} drakes to let a fellow sailor go."',
            '{Leader} throws down {his} blade. "{Gold} drakes in the chest by the water. Take it, and let the tide take me elsewhere."',
            '{Leader} backs towards the water. "No more. {Gold} drakes, and you never find us again."',
            '{Leader} holds up a purse. "The last voyage\'s take. {Gold} drakes. It is yours if I walk."',
            '{Leader} wheezes. "I have sailed out of worse than you. {Gold} drakes says I sail out of this."',
        },
    },
    bribe = {
        '{Leader} presses the purse into your hand and is gone before you can change your mind.',
        'You take the gold. {Leader} slips away without another word.',
        '{Leader} counts the coins into your hand, then backs out of sight.',
        'The purse is heavy. When you look up, {Leader} is gone.',
        '{Leader} watches you weigh the gold, then turns and runs.',
        'You pocket the gold, and {Leader} vanishes into the dark.',
        '{Leader} nods once and leaves without looking back.',
        'The gold is real. {Leader} does not stay to see what you make of it.',
        '{Leader} is out of sight before the purse stops swinging.',
        'You take it. {Leader} lets out a breath and goes.',
    },
    spare = {
        bandit = {
            '{Leader} pulls off {his} signet and drops it at your feet. "Take it, then. I am leaving."',
            '{Leader} hands over {his} signet. "You will not see me again." You let {him} go.',
            '{Leader} twists the signet off {his} finger and tosses it to you. "Show them that. Tell them I am dead, if you like."',
            '{Leader} presses {his} signet into your palm. "The road is yours. I am done with it."',
            '{Leader} drops the signet in the dirt and backs away. "Keep it. I will find honest work. Or not."',
            '{Leader} hands you {his} signet without a word and walks out into the dark.',
            '{Leader} pulls the signet free. "Proof, then. Now let me go before I change my mind."',
            '{Leader} throws {his} signet at your feet and limps off.',
            '{Leader} sets {his} signet on the ground and steps back. "I am done. The road can have someone else."',
            '{Leader} works the signet off {his} finger. "Take it to them. I will be a long way off by morning."',
        },
        smuggler = {
            '{Leader} sets {his} signet on a crate. "A trade, then. That for my life." {He} slips away.',
            '{Leader} hands over {his} signet. "Tell them the business is closed." {He} does not look back.',
            '{Leader} flips the signet to you. "Worth more to you than to me now." {He} is gone by the shore path.',
            '{Leader} drops {his} signet in your hand. "We never met." You let {him} go.',
            '{Leader} pulls off the signet. "Keep the cargo too, for all I care." {He} leaves without it.',
            '{Leader} sets the signet on the floor between you and steps back. "Done. I am out of this trade."',
            '{Leader} hands it over. "Show them this and say what you like." {He} slips out.',
            '{Leader} gives up {his} signet with a shrug. "There are other coasts."',
            '{Leader} lays {his} signet on a crate and raises empty hands. "The deal is closed. I am leaving this coast."',
            '{Leader} drops the signet and turns for the water. "Tell them the boat sailed. I will not be on it."',
        },
        cultist = {
            '{Leader} pulls off {his} signet with shaking hands. "Take it. The rites are over." {He} flees.',
            '{Leader} lays {his} signet on the altar and backs away. "It is yours. I renounce all of it."',
            '{Leader} drops the signet at your feet. "My prince has turned from me. I go."',
            '{Leader} hands over {his} signet and pulls {his} hood low. "You will not see me again."',
            '{Leader} presses the signet into your hand. "Tell them I am gone. It will be true."',
            '{Leader} lets the signet fall and walks out without another word.',
            '{Leader} gives up {his} signet. "Let the shrine go cold." {He} slips away.',
            '{Leader} tears the signet off {his} finger. "Take it and let me go before the others come."',
            '{Leader} sets {his} signet on the step and backs away. "The circle is broken. I am done with the rites."',
            '{Leader} holds the signet out. "Take it, and let me walk out before they see me."',
        },
        warlock = {
            '{Leader} pulls off {his} signet. "Take your proof. I will work somewhere quieter." {He} is gone.',
            '{Leader} hands over {his} signet. "My research goes with me. The ring is yours."',
            '{Leader} drops the signet at your feet. "A trinket. Keep it. I am leaving."',
            '{Leader} sets {his} signet down among the clutter of {his} work. "Done. You will not hear of me here again."',
            '{Leader} gives up {his} signet and gathers {his} notes. You let {him} go.',
            '{Leader} flicks the signet to you. "Proof enough for those fools." {He} slips into the dark.',
            '{Leader} presses {his} signet into your hand. "Tell them I am dead. Better for both of us."',
            '{Leader} hands it over without a word, and walks out leaving {his} work behind.',
            '{Leader} sets {his} signet among the books. "Proof. I will work where nobody posts notices."',
            '{Leader} pulls the signet free and drops it. "Keep it. My notes go with me."',
        },
        pirate = {
            '{Leader} tosses you {his} signet. "Tell the fishermen what you like. We sail tonight."',
            '{Leader} pulls off {his} signet and drops it on the wet stone. "Yours. I am off this coast."',
            '{Leader} hands over the signet. "Not the first ring I have lost at sea." {He} leaves.',
            '{Leader} presses {his} signet into your hand. "We never met, sailor."',
            '{Leader} drops the signet at your feet and backs towards the water.',
            '{Leader} gives up the signet with a crooked grin. "There is always another boat."',
            '{Leader} flicks it to you. "Proof for the town. I keep my neck." {He} is gone.',
            '{Leader} hands it over. "Tell them the sea took me." You let {him} go.',
            '{Leader} sets {his} signet on the wet stone. "Yours. Find another captain to chase."',
            '{Leader} tosses the signet and turns for the boats. "We are done here."',
        },
    },
    heard = {
        'Word reaches {from} that you let {leader} buy you off. The job is gone, and so is some of your good name.',
        '{From} hears about the purse. Nobody there will be paying you for this one.',
        'Somehow {from} has heard about the gold. The job is off, and you are not welcome to ask why.',
        'Word travels. {From} knows about the purse and wants nothing more to do with you.',
        '{From} learns that {leader} paid you off. You will not be paid for this one.',
        'News of the purse reaches {from} before you do. The job is gone.',
        '{From} has heard that {leader} walked free with your help. There is no pay in it now.',
        'Someone saw {leader} leave in a hurry and talked. {From} has closed the job.',
        'By the time you think of going back, {from} knows. The work is off.',
        '{From} hears of the bargain. Your name is said a little less kindly now.',
    },
    -- The note that says the poster isn't the owner.
    liedTitle = { 'Bill of Sale', 'Folded Note', 'Scrap of Paper', 'Torn Note', 'Folded Receipt' },
    lied = {
        'Bought from a man in {town}, {price} drakes. He says it came off a house in {otown}. The family there was called {surname}. Keep it out of sight until it is sold on.',
        'This {noun} was taken from {owner} of {otown} last season, and {owner} is still asking after it. If anyone asks, we never had it.',
        'The {noun} came to us from {town}, but it is {owner}\'s, from {otown}, and {owner} has been asking about it. Get rid of it soon.',
        'Paid {price} for the {noun}. It came out of a house in {otown}, the {surname} place. Do not sell it near there.',
        'This {noun} is wanted back by {owner} of {otown}, so keep it moving. Someone in {town} is buying.',
        'Note to self: the {noun} is {owner}\'s, out of {otown}. Hold it until the asking stops.',
        'The {surname} family in {otown} put a price on this {noun}. Ours is lower. Sell it quick.',
        'Got the {noun} in {town} for {price} drakes. Stolen from {owner} in {otown}, so the seller said.',
        'Keep the {noun} wrapped. If {owner} from {otown} ever sees it, we are finished.',
        'The {noun} from {otown}. Its owner, {owner}, still asks after it. Not worth the trouble; get rid of it.',
    },
    liedLog = 'A note found with it says it belongs to {owner} of {otown}. You could take it there instead.',
    liedOwner = {
        '{Owner} turns it over in {his} hands for a long time. "I never thought I would see this again." {He} pays what {he} can.',
        '{Owner} knows it at once. "Where did you find it? No, never mind. Thank you." {He} pays you, and will remember this.',
        '{Owner} holds it close and cannot speak for a moment. Then {he} pays you.',
        '{Owner} laughs out loud. "I had given it up for lost!" {He} presses coin into your hand.',
        '{Owner} looks at it, then at you. "Whoever took this owes me more than you do." {He} pays you well.',
        '{Owner} runs a thumb over it and says nothing for a while. Then {he} pays you.',
        '{Owner} knows it before you have it out of your pack. {He} pays without haggling.',
        '{Owner} sits down heavily. "Thank you. Truly." {He} pays what {he} can spare.',
        '{Owner} turns it to the light. "The very one." {He} pays you, and tells you to come back any time.',
        '{Owner} takes it gently. "I will not ask how." {He} pays you all the same.',
    },
    -- A copy of the notice in a dead rival's pack.
    copyTitle = 'Copy of a Notice',
    copy = 'Copied from the notices in {town}: "{title}". Someone has written "mine" across the top.',
    rivalFight = {
        'You hear fighting further in. Someone got here first.',
        'Steel on steel, somewhere ahead. You are not the only one here.',
        'Shouting and the clash of blades echo from somewhere deeper in.',
        'Someone is fighting for their life further in.',
        'A scream, then the ring of steel. Another hand is at work here.',
        'You hear a fight ahead. Another sellsword, by the sound of it.',
        'Blades and shouting, not far ahead. Someone came for the same work.',
        'Spells crack somewhere ahead, and someone yells for help.',
        'You hear boots running and blades meeting. Someone else is here.',
        'Steel, a curse, a body falling. Someone is clearing the way ahead of you.',
    },
    rivalRace = {
        'Someone comes in behind you. "This one is mine, friend. Keep up or keep out of my way."',
        'Footsteps behind you. "Saw the same notice, did you? Best of luck." They push past.',
        'A voice behind you: "Well, look who else can read. Race you to it."',
        'Someone shoulders past you. "Sorry, friend. First one there gets paid."',
        'A voice at your back: "You too? Then we had best be quick."',
        'Footsteps, then a grin in the dark. "I will tell them you tried."',
        'Someone in mail jogs past. "No hard feelings. This one is mine."',
        'A stranger hurries past, already heading deeper in. "Keep up."',
        'A sellsword falls into step behind you. "Same job? Then may the faster one eat tonight."',
        'Someone pushes ahead of you. "I was here first, in spirit."',
    },
    rivalTook = {
        '{Rival} has it now, and is not about to hand it over.',
        '{Rival} found it first and turns on you. "Mine. Walk away."',
        '{Rival} holds it up and backs away. "Finders keepers."',
        '{Rival} already has it in hand. "Go home. You were too slow."',
        '{Rival} tucks it away and draws a blade. "Do not make this ugly."',
        '{Rival} looks at you, then at it. "Mine. I earned it."',
        '{Rival} has it, and does not mean to share.',
        '{Rival} turns with it in one hand and steel in the other.',
        '{Rival} holds it up. "Too late. Unless you want to fight me for it."',
        '{Rival} found it first. "Walk away, and we both live."',
    },
    worse = {
        'The {old} here are already dead, torn apart. Whatever did this is still inside.',
        'Bodies everywhere, all of them {old}. Something bigger got here first.',
        'The {old} lie in pieces on the floor. Something worse has moved in.',
        'Every one of the {old} is dead, and not by any blade.',
        'You find the {old} first, what is left of them. Their killer is near.',
        'The {old} were torn down where they stood. Something is still breathing in the dark.',
        'The {old} are scattered across the floor. The thing that came here has not left.',
        'The {old} are dead, all of them, and the marks on them are not from a weapon.',
        'Someone, or something, got to the {old} before you. It is still here.',
        'Dead {old} everywhere. The thing that did it has not gone far.',
    },
    worsePaid = '{From} goes pale at what you found in there and adds {bonus} drakes for the trouble.',
    worseLog = 'The {old} were already dead when you arrived. {New} killed them.',
    chainTitle = { 'Letter', 'Sealed Letter', 'Crumpled Letter', 'Folded Letter', 'Stained Letter' },
    chain = {
        bandit = {
            '{Leader}, the next lot goes out from {next}. Do not come yourself. Send someone you trust. Burn this.',
            'If you need us, we are at {next} now. Bring the rest of it there, and come at night.',
            '{Leader}. Things are going well at {next}. Come and see for yourself when you can.',
            '{Leader}, the others at {next} want their share. Bring it soon or they come for it.',
            'Word is the road past {next} is easy pickings. Meet us there at the new moon.',
            '{Leader}. The take from {next} is waiting. Do not send the new ones.',
            'We have moved the spoils to {next}. Nobody follows us there.',
            '{Leader}, come to {next} when it is quiet. We have something worth seeing.',
            '{Leader}, the new camp is at {next}. Bring food and keep off the road.',
            'Leave the old camp. We are at {next} now, and the watch is posted.',
        },
        smuggler = {
            '{Leader}, the next boat puts in at {next}. Have the goods ready and no lights.',
            'The Census men are watching the old spot. Use {next} from now on.',
            '{Leader}. Payment is waiting at {next}. Bring the rest of the cargo and come alone.',
            'Move everything to {next}. Burn this once you have read it.',
            '{Leader}, the buyer will meet you at {next}. Same price as before.',
            'Cargo for {next}, two nights from now. Do not be late again.',
            'The crates are at {next}. Send someone the guards do not know.',
            '{Leader}, things are hot here. {next} is safe for now. Come when you can.',
            '{Leader}, the next drop is at {next}. Come by the shore path and leave the lights out.',
            'Hold the rest of the cargo. We will take it on at {next} after dark.',
        },
        cultist = {
            '{Leader}, the faithful gather at {next}. The next rite cannot wait.',
            'Friend in the faith, the signs point to {next}. Bring the offerings there.',
            'Our prince has spoken again. We go to {next}. Bring the others.',
            '{Leader}. The shrine at {next} is ready for us. Come at dusk.',
            'Our work here has been seen. Move to {next}, and bring the books.',
            'The next offering is to be made at {next}. Tell no one outside the circle.',
            '{Leader}, they have seen us here. The circle meets at {next} now.',
            'At {next} the rites can go on. Come quickly.',
            '{Leader}, the books and the offerings go to {next}. Come at dusk and tell no one.',
            'The circle is broken here. We gather at {next} from now on.',
        },
        warlock = {
            '{Leader}, the reagents you asked for are at {next}. Come for them yourself.',
            'My work at {next} has borne fruit. You must see it.',
            '{Leader}. The Guild is asking questions here. I have moved my study to {next}.',
            'What you wanted is at {next}. Come at night and bring a cart.',
            '{Leader}, the circle at {next} is drawn. We need only you.',
            'Come to {next}. What we found there will interest you.',
            'The books are safe at {next}. Burn your copies.',
            '{Leader}, I have taken a new apprentice at {next}. Come and teach her what you taught me.',
            '{Leader}, the reagents are waiting at {next}. Come yourself, and bring no one else.',
            'My notes are packed. The new study is at {next}. Come when the road is quiet.',
        },
        pirate = {
            '{Leader}, the ship anchors off {next} at the dark of the moon. Be ready with the boats.',
            'A fat merchant is headed past {next}. Bring the crew.',
            'The rest of the take is buried near {next}. You know where.',
            '{Leader}. The crew is waiting at {next}, and they grow restless.',
            'Patrol boats out of the fort. Lie low at {next} until they pass.',
            'Your share is at {next}. Come for it before someone else does.',
            '{Leader}, the new boat is hidden at {next}. She is fast.',
            'Meet at {next}. Come by water, not the road.',
            '{Leader}, the crew waits off {next}. Bring the boats after dark.',
            'The take is split at {next}. Come by water and keep the lanterns out.',
        },
    },
    chainLead = {
        'The letter you brought back names {next}. Whoever wrote it is there now.',
        'That letter from {leader} pointed to {next}. Someone is running things from there.',
        'The letter from {leader} points to {next}. The rest of them are there.',
        'Whoever wrote to {leader} is at {next}. That is where it goes on.',
        'The letter names {next}, and someone will have to go there.',
        'The letter found on {leader} leads to {next}.',
        'According to that letter, the rest of the work goes on at {next}.',
        'That letter names {next}. The trouble did not end with {leader}.',
        'The writer of that letter is at {next}, by the sound of it.',
        'There is more of this at {next}, if the letter is right.',
    },
    chainPaid = '{From} reads the letter twice and pins up a new notice.',
}

-- A voiced list (offer, spare, chain) in this voice, else the bandits'; a plain list as it is.
function M.voiced(list, voice)
    if list[1] then return list end
    return list[voice or 'bandit'] or list.bandit
end

-- ctx (from global.lua): S(), now(), log, say, tell(player, msg), player(), SP (spawner), featureOn,
-- have(req), playerLevel(p), placeByName(name), places(), inContract(name), townOf(key),
-- boardTowns() -> { {key, town, race, faction} }, makeBook(name, text) -> record id,
-- postFollowUp(boardKey, placeName, lead, step) -> notice or nil, isHostileAlive(a),
-- dropContract(c, why), heldCount(), rnd(n) (n or nothing, like math.random).
function M.new(ctx)
    local T = {}
    local rnd = ctx.rnd

    -- An owner in another board town within reach of the poster's town.
    local function ownerFor(c)
        local here = ctx.townOf(c.board)
        local towns = {}
        for _, t in ipairs(ctx.boardTowns()) do
            if t.town ~= here then towns[#towns + 1] = t end
        end
        if #towns == 0 then return nil end
        local t = pick(towns, rnd)
        local female = rnd(2) == 1
        local name = ROSTER.name(t.race or 'dark elf', female, rnd)
        return { owner = name, surname = name:match('%s(%S+)$') or name, female = female, key = t.key, otown = t.town,
            faction = t.faction }
    end

    function T.roll(c, info)
        local on = ctx.featureOn
        if c.kind == 'bounty' then
            if on.twistOffer and rnd() < TW.OFFER then c.offer = { state = 'wait' } end
            if on.twistChains and (c.chainStep or 1) < TW.CHAIN_STEPS and rnd() < TW.CHAIN then
                c.chain = { state = 'wait', step = c.chainStep or 1 }
            end
        elseif c.kind == 'recovery' and c.poster == 'town' and on.twistLied and rnd() < TW.LIED then
            c.lied = ownerFor(c)
            if c.lied then c.lied.state = 'wait' end
        elseif c.kind == 'nest' and on.twistWorse and #(info.targets or {}) >= 3 and rnd() < TW.WORSE then
            c.worse = { state = 'wait' }
        end
        if not c.worse and on.twistRival and rnd() < TW.RIVAL then
            local moods = c.kind == 'nest' and { 'dead', 'fight' } or { 'dead', 'fight', 'race' }
            c.rival = { state = 'wait', mood = pick(moods, rnd) }
        end
        if c.offer or c.lied or c.worse or c.rival or c.chain then
            ctx.log('contract %d twists: %s%s%s%s%s', c.id, c.offer and 'offer ' or '', c.lied and 'lied ' or '',
                c.worse and 'worse ' or '', c.rival and ('rival ' .. c.rival.mood .. ' ') or '', c.chain and 'chain' or '')
        end
    end

    local function liveLeader(c)
        return c.leader and c.leader:isValid() and not types.Actor.isDead(c.leader) and c.leader.type == types.NPC
    end

    -- The voice of the group the contract is against: the band's, else the place's own leader's.
    local function voiceOf(c)
        local g = c.band and c.band.group
        if not g then
            local p = ctx.placeByName(c.place)
            g = p and p.b and p.b[4]
        end
        return M.VOICE[g or ''] or 'bandit'
    end

    local function leaderWords(c)
        local rec = types.NPC.record(c.leader)
        local a = { Leader = rec.name, leader = rec.name }
        for k, v in pairs(ST.pronouns(not rec.isMale)) do a[k] = v end
        return a
    end

    local function hostilesIn(cell)
        local out = {}
        for _, list in ipairs({ cell:getAll(types.NPC), cell:getAll(types.Creature) }) do
            for _, a in ipairs(list) do
                if a.type ~= types.Player and ctx.isHostileAlive(a) then out[#out + 1] = a end
            end
        end
        return out
    end

    local function pos(o) return { x = o.position.x, y = o.position.y, z = o.position.z } end

    -- A rival: a person from the catalog at the top of the job's tier band, named, not hostile to the
    -- player.
    local function rivalSpec(c, at)
        local list = ROSTER.people('bandit', TI.band(c.diff or 'normal')[2], ctx.have)
        local t = ROSTER.pick(list, rnd, 12)
        if not t then return nil end
        local name = ROSTER.name(t.race, t.female, rnd)
        local id = ctx.SP.record(t.id, name, types.NPC)
        if not id then return nil end
        return { id = id, cell = c.place, pos = at, yaw = at.yaw, role = 'rival' }, name
    end

    local function visitOffer(c)
        local o = c.offer
        if o.state ~= 'wait' or not liveLeader(c) then return end
        ctx.SP.change(c.id, c.leader, { surrender = TW.SURRENDER_AT })
        o.state = 'armed'
    end

    local function holderInv(c)
        local h = c.holder or (c.loose and c.loose.fallback)
        if not h or not h:isValid() then return nil end
        return h.type == types.Container and types.Container.content(h) or types.Actor.inventory(h)
    end

    local function visitLied(c, player)
        local l = c.lied
        if l.state == 'wait' then
            local inv = holderInv(c)
            if not inv then return end
            local text = fill(pick(M.LINES.lied, rnd), { town = ctx.townOf(c.board), otown = l.otown, owner = l.owner,
                surname = l.surname, noun = plainNoun(c), price = 20 + rnd(8) * 5 })
            l.note = ctx.makeBook(pick(M.LINES.liedTitle, rnd), text)
            world.createObject(l.note):moveInto(inv)
            l.state = 'placed'
            ctx.log('contract %d: the note naming %s of %s is in %s', c.id, l.owner, l.otown,
                (c.holder or c.loose.fallback).recordId)
        end
        if l.state == 'placed' and types.Actor.inventory(player):countOf(l.note) > 0 then
            l.state = 'read'
        end
    end

    local function stillOn(c) return ctx.S().contracts[c.id] == c and c.state == 'active' end

    -- Asks the player script for walkable spots; done(e) gets the answer if the job is still on.
    -- At most ASKS a contract, so a place whose navmesh never answers stops being asked.
    local ASKS = 6
    local function ask(c, tag, req, done)
        c.asks = (c.asks or 0) + 1
        req.cell = c.place
        ctx.SP.ask(ctx.player(), tag .. ':' .. c.id, req, function(e)
            if stillOn(c) then done(e) end
        end)
    end

    -- A question lost to a reload or leaving the cell goes back to waiting; past the cap, it's off.
    local function ready(c, tag, st)
        if st.state == 'asked' and not ctx.SP.waiting(tag .. ':' .. c.id) then st.state = 'wait' end
        if st.state == 'wait' and (c.asks or 0) >= ASKS then st.state = 'off' end
        return st.state == 'wait'
    end

    -- What the old group were, in the words the place data uses ("nix-hounds", "bandits"), else the
    -- creature's name made plural ("Skeleton" to "skeletons", "Wolf" to "wolves").
    local PEOPLE = { bandit = 'bandits', necromancer = 'necromancers', smuggler = 'smugglers', warlock = 'warlocks',
        vampire = 'vampires', cultist = 'cultists' }
    local function many(actor, place)
        local npc = actor.type == types.NPC
        for _, e in ipairs(place.e or {}) do
            if npc and PEOPLE[e[1]] then return PEOPLE[e[1]] end
            if not npc and not PEOPLE[e[1]] and e[3] then return e[3] end
        end
        if npc then return 'bandits' end
        local w = types.Creature.record(actor).name:lower()
        if w:find('fish$') or w:find('kwama') then return w end
        if w:find('[^aeiou]y$') then return w:sub(1, -2) .. 'ies' end
        if w:find('f$') then return w:sub(1, -2) .. 'ves' end
        if w:find('man$') then return w:sub(1, -4) .. 'men' end
        if w:find('[sx]$') or w:find('[cs]h$') then return w .. 'es' end
        return w .. 's'
    end

    local function visitRival(c, player)
        local r = c.rival
        if not ready(c, 'rival', r) then return end
        local foes = hostilesIn(player.cell)
        if #foes == 0 and r.mood ~= 'race' then r.state = 'off' return end
        local target = c.leader and c.leader:isValid() and c.leader or c.holder or foes[1]
        local anchor = r.mood == 'race' and pos(player) or pos(foes[rnd(#foes)])
        r.state = 'asked'
        ask(c, 'rival', { n = 1, anchors = { anchor }, radius = r.mood == 'race' and 300 or 500,
            away = r.mood == 'race' and 120 or 400 }, function(e)
            local at = e.spots and e.spots[1]
            if not at then
                r.state = e.retry and 'wait' or 'off'
                return
            end
            local spec, name = rivalSpec(c, at)
            if not spec then r.state = 'off' return end
            r.name = name
            if r.mood == 'dead' then
                spec.act = { kill = true }
                local text = fill(M.LINES.copy, { town = ctx.townOf(c.board), title = c.title })
                spec.items = { ctx.makeBook(M.LINES.copyTitle, text) }
            elseif r.mood == 'fight' then
                local nearest, nd
                for _, f in ipairs(foes) do
                    local d = (f.position - player.position):length()
                    if not nd or d < nd then nearest, nd = f, d end
                end
                spec.act = { fight = 30, attack = nearest }
                ctx.tell(player, pick(M.LINES.rivalFight, rnd))
            else
                spec.act = { fight = 30, travel = target and pos(target) or anchor }
                r.target = target
                ctx.tell(player, pick(M.LINES.rivalRace, rnd))
            end
            local obj = ctx.SP.actor(c.id, c.tier or 'normal', spec)
            r.obj, r.state = obj, obj and 'made' or 'off'
            ctx.say('contract %d: rival %s (%s) %s', c.id, name, r.mood, obj and 'is there' or 'could not be placed')
        end)
    end

    -- A racing rival who reaches the prize first: takes the item, or goes for the leader.
    local function tickRace(c, player)
        local r = c.rival
        if not r or r.mood ~= 'race' or r.state ~= 'made' or not r.obj or not r.obj:isValid() then return end
        if types.Actor.isDead(r.obj) then r.state = 'done' return end
        local t = r.target
        if not t or not t:isValid() or (r.obj.position - t.position):length() > 220 then return end
        r.state = 'arrived'
        if c.kind == 'bounty' then
            if liveLeader(c) then ctx.SP.tell(r.obj, { attack = c.leader }) end
            return
        end
        local inv = holderInv(c)
        local it = inv and c.item and inv:find(c.item)
        if it then
            it:moveInto(types.Actor.inventory(r.obj))
            c.holder = r.obj
            ctx.SP.tell(r.obj, { fight = 90, attack = player })
            ctx.tell(player, fill(pick(M.LINES.rivalTook, rnd), { Rival = r.name }))
            ctx.say('contract %d: the rival took the item', c.id)
        end
    end

    -- Tougher things, by the kind of place. A tomb's own dead never: daedra come for tombs.
    local WORSE_GROUP = { dwemer = 'dwemer', tomb = 'daedra', daedric = 'daedra', wreck = 'fish', sewer = 'monster' }

    local function visitWorse(c, player)
        local w = c.worse
        if not ready(c, 'worse', w) then return end
        local olds, oldTop, anchors = {}, 0, {}
        for _, t in ipairs(c.targets or {}) do
            if t:isValid() and not types.Actor.isDead(t) then
                olds[#olds + 1] = t
                anchors[#anchors + 1] = pos(t)
                oldTop = math.max(oldTop, types.Actor.stats.level(t).current)
            end
        end
        if #olds < 3 then w.state = 'off' return end
        local place = ctx.placeByName(c.place) or {}
        local group = WORSE_GROUP[place.k or ''] or (rnd(2) == 1 and 'monster' or 'daedra')
        local lo = math.max(oldTop + TW.WORSE_LEVEL, TI.band(c.diff or 'normal')[1])
        local list = ROSTER.creatures(group, lo, lo + 8, ctx.have)
        if #list == 0 then w.state = 'off' return end
        local n = math.min(math.max(2, #olds - 1), 4, ctx.SP.room(c.id, 'normal'))
        if n < 2 then w.state = 'off' return end
        w.state = 'asked'
        ask(c, 'worse', { n = n, anchors = anchors, radius = 500, away = 600 }, function(e)
            if not e.spots or #e.spots < 2 then
                w.state = e.retry and 'wait' or 'off'
                return
            end
            for _, a in ipairs(olds) do ctx.SP.change(c.id, a, { kill = true }) end
            local specs = {}
            for i, at in ipairs(e.spots) do
                local cr = list[(i - 1) % #list + 1]
                specs[#specs + 1] = { id = cr.id, cell = c.place, pos = at, yaw = at.yaw, role = 'worse',
                    act = { fight = 100 } }
            end
            w.new, w.oldMany = list[1].name, many(olds[1], place)
            c.targets = {}
            ctx.SP.queue(c.id, 'normal', specs, function(obj) c.targets[#c.targets + 1] = obj end)
            w.state = 'made'
            ctx.tell(player, fill(pick(M.LINES.worse, rnd), { old = w.oldMany }))
            ctx.say('contract %d: something worse: %d %s instead of %d %s', c.id, #specs, w.new, #olds, w.oldMany)
        end)
    end

    -- Another place run by someone (b: its hand-placed leader), for the letter to name.
    local function nextPlace(c)
        local here = ctx.placeByName(c.place)
        if not here then return nil end
        local best = {}
        for _, p in ipairs(ctx.places()) do
            if p.n ~= c.place and not p.tomb and p.b and not ctx.inContract(p.n) then
                local dx, dy = (p.x - here.x) / C.CELL, (p.y - here.y) / C.CELL
                local d = math.sqrt(dx * dx + dy * dy)
                if d >= 1 and d <= 6 then best[#best + 1] = p end
            end
        end
        return #best > 0 and pick(best, rnd) or nil
    end

    local function visitChain(c)
        local ch = c.chain
        if ch.state ~= 'wait' or not liveLeader(c) then return end
        local nxt = nextPlace(c)
        if not nxt then ch.state = 'off' return end
        local a = leaderWords(c)
        -- The letter names the place as people know it; ch.next keeps the cell for the follow-up.
        a.next = ST.area(nxt).name
        ch.next, ch.leader = nxt.n, a.Leader
        ch.letter = ctx.makeBook(pick(M.LINES.chainTitle, rnd), fill(pick(M.voiced(M.LINES.chain, voiceOf(c)), rnd), a))
        world.createObject(ch.letter):moveInto(types.Actor.inventory(c.leader))
        ch.state = 'placed'
        ctx.log('contract %d: a letter on %s names %s', c.id, a.Leader, nxt.n)
    end

    -- Every check while the player is in the job's place and the contract is active.
    function T.visit(c, player)
        if c.offer then visitOffer(c) end
        if c.lied then visitLied(c, player) end
        if c.rival then
            visitRival(c, player)
            tickRace(c, player)
        end
        if c.worse then visitWorse(c, player) end
        if c.chain then visitChain(c) end
    end

    -- Also away from the place: a note picked up and carried out still counts as read.
    function T.check(c, player)
        local l = c.lied
        if l and l.state == 'placed' and types.Actor.inventory(player):countOf(l.note) > 0 then l.state = 'read' end
    end

    -- From global.lua's contract check: false when a turn ended the contract.
    function T.step(c, player, here)
        if here then T.visit(c, player) else T.check(c, player) end
        return stillOn(c)
    end

    -- A clearing whose newcomers aren't all in yet isn't done.
    function T.holdsCompletion(c)
        local w = c.worse
        return w ~= nil and ((w.state == 'asked' and ctx.SP.waiting('worse:' .. c.id))
            or (w.state == 'made' and ctx.SP.queued() > 0))
    end

    -- Lines for the contract log, once the player knows.
    function T.logLines(c)
        local out = {}
        if c.lied and c.lied.state == 'read' then out[#out + 1] = fill(M.LINES.liedLog, c.lied) end
        if c.worse and c.worse.state == 'made' and c.worse.new then
            out[#out + 1] = fill(M.LINES.worseLog, { old = c.worse.oldMany or 'others', New = cap(ST.a(c.worse.new:lower())) .. ' and more like it' })
        end
        return #out > 0 and table.concat(out, ' ') or nil
    end

    -- The town where the item's real owner takes it back, once the note has been read.
    function T.ownerTown(c)
        return c.lied and c.lied.state == 'read' and c.state == 'done' and c.lied.otown or nil
    end

    -- The leader gave up (spawn.lua): the player chooses.
    function T.onSurrender(e)
        local c = ctx.S().contracts[tonumber(e.owner) or -1]
        if not c or not c.offer or c.offer.state ~= 'armed' or c.state ~= 'active' then return end
        c.offer.state = 'offered'
        c.offer.gold = math.max(10, math.floor(c.value * TW.BRIBE_SHARE / 5 + 0.5) * 5)
        local a = leaderWords(c)
        a.gold, a.Gold = c.offer.gold, tostring(c.offer.gold)
        ctx.player():sendEvent('OJB_Choice', {
            id = 'offer:' .. c.id, title = a.Leader,
            text = fill(pick(M.voiced(M.LINES.offer, voiceOf(c)), rnd), a),
            options = {
                { id = 'bribe', label = 'Take the gold' },
                { id = 'spare', label = fill('Take {his} signet and let {him} go', a) },
                { id = 'finish', label = 'Finish it' },
            },
        })
    end

    local function remember(c, how)
        if not ctx.featureOn.returning or not c.leader or not c.leader:isValid() then return end
        local S = ctx.S()
        S.returning = S.returning or {}
        if #S.returning >= C.DANGER.RETURN_MAX then return end
        local rec = types.NPC.record(c.leader)
        S.returning[#S.returning + 1] = { name = rec.name, template = c.leader.recordId, female = not rec.isMale,
            race = rec.race, board = c.board, poster = c.poster, place = c.place, how = how, times = 0,
            tier = c.diff or c.tier,
            day = ctx.now() + C.DANGER.RETURN_DAYS[1] + rnd(C.DANGER.RETURN_DAYS[2] - C.DANGER.RETURN_DAYS[1] + 1) - 1 }
        ctx.log('contract %d: %s may come back (%s)', c.id, rec.name, how)
    end

    function T.onChoice(e)
        local id = tonumber((e.id or ''):match('^offer:(%d+)$'))
        local c = id and ctx.S().contracts[id]
        if not c or not c.offer or c.offer.state ~= 'offered' then return end
        local player = e.player
        local option = e.option or 'finish'
        local leader = c.leader
        local a = leaderWords(c)
        if option == 'finish' or not leader:isValid() or types.Actor.isDead(leader) then
            c.offer.state = 'refused'
            ctx.SP.tell(leader, { fight = 100, stopSurrender = true, attack = player })
            return
        end
        c.offer.state = option
        if option == 'bribe' then
            world.createObject('gold_001', c.offer.gold):moveInto(types.Actor.inventory(player))
            player:sendEvent('OJB_Sound', { 'Item Gold Up' })
            ctx.tell(player, fill(pick(M.LINES.bribe, rnd), a))
            if rnd() < TW.RETURN_CHANCE then remember(c, 'bribed') end
            leader.enabled = false
            a.from, a.From = posterName(c), cap(posterName(c))
            ctx.tell(player, fill(pick(M.LINES.heard, rnd), a))
            if C.GUILDS[c.poster] and types.NPC.getFactionRank(player, c.poster) > 0 then
                types.NPC.modifyFactionReputation(player, c.poster, -2)
            end
            ctx.dropContract(c, 'bribed off')
            player:sendEvent('OJB_Contracts', { held = ctx.heldCount() })
        else
            local signet = c.item and types.Actor.inventory(leader):find(c.item)
            if signet then signet:moveInto(types.Actor.inventory(player)) end
            ctx.tell(player, fill(pick(M.voiced(M.LINES.spare, voiceOf(c)), rnd), a))
            if rnd() < TW.RETURN_CHANCE then remember(c, 'spared') end
            leader.enabled = false
            c.spared = true
            c.leaderDown = true
        end
        ctx.say('contract %d: the leader gave up; the player chose %s', c.id, option)
    end

    -- At hand-in: what changes. room: gold the pay may still grow by under the job cap.
    -- Returns { share = 0..1 of the pay, bonus = gold, lines = { ... } }.
    function T.handIn(c, player, room)
        local out = { share = 1, bonus = 0, lines = {} }
        local a = { from = posterName(c), From = cap(posterName(c)) }
        if c.spared then out.share = TW.SPARE_SHARE end
        local bonus = math.min(math.floor(c.value * TW.WORSE_BONUS / 5 + 0.5) * 5, math.floor((room or 0) / 5) * 5)
        if c.worse and c.worse.state == 'made' and bonus > 0 then
            out.bonus = bonus
            a.bonus = out.bonus
            out.lines[#out.lines + 1] = fill(M.LINES.worsePaid, a)
        end
        local ch = c.chain
        if ch and ch.state == 'placed' then
            local inv = types.Actor.inventory(player)
            local letter = inv:find(ch.letter)
            if letter then
                letter:remove()
                local nextPlace = ctx.placeByName(ch.next)
                local lead = fill(pick(M.LINES.chainLead, rnd), { leader = ch.leader,
                    next = nextPlace and ST.area(nextPlace).name or ch.next })
                if ctx.postFollowUp(c.board, ch.next, lead, ch.step + 1) then
                    out.lines[#out.lines + 1] = fill(M.LINES.chainPaid, a)
                    ch.state = 'posted'
                end
            end
        end
        return out
    end

    -- Handing a lied-about item to its real owner at their town's notices.
    function T.returnToOwner(c, player)
        local l = c.lied
        local gold = math.floor(c.value * TW.OWNER_SHARE / 5 + 0.5) * 5
        local inv = types.Actor.inventory(player)
        local it = c.item and inv:find(c.item)
        if not it then return false end
        it:remove(1)
        world.createObject('gold_001', gold):moveInto(inv)
        player:sendEvent('OJB_Sound', { 'Item Gold Up' })
        local member = l.faction and core.factions.records[l.faction] and types.NPC.getFactionRank(player, l.faction) > 0
        if member then types.NPC.modifyFactionReputation(player, l.faction, TW.OWNER_REP) end
        local a = { Owner = l.owner }
        for k, v in pairs(ST.pronouns(l.female)) do a[k] = v end
        ctx.tell(player, fill(pick(M.LINES.liedOwner, rnd), a) .. ' Paid: ' .. gold .. ' gold.')
        ctx.say('contract %d returned to its owner %s in %s: %d gold, +%d with %s', c.id, l.owner, l.otown, gold,
            member and TW.OWNER_REP or 0, tostring(l.faction))
        return true
    end

    return T
end

return M
