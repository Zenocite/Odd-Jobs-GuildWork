---@omw-context runtime
-- Tuning shared by global.lua, player.lua and the pure modules. Units: game days, gold, world units.

local C = {}

C.LOG_TAG = '[OddJobs] '
C.SETTINGS_SECTION = 'SettingsOddJobs'
C.VERSION = '1.9.0'
-- Saved state from an older number, or written by any other VERSION, gets every board placed again
-- and its notices rewritten.
C.STATE_VERSION = 7

C.MAX_HELD = 3
-- After DONE finished contracts (a setting) the player can hold HELD. LEVEL is the old rule, used
-- only with the levelGates setting.
C.PERK = { DONE = 15, HELD = 4, LEVEL = 15 }
C.FEATURES_SECTION = 'SettingsOddJobsFeatures'
-- Feature switches, each a player setting (on by default) sent to global.lua; a feature that's
-- off posts nothing new and leaves what's already held to finish as it was.
C.FEATURES = { 'slotsPerk', 'requisitions', 'companyReqs', 'collectors', 'reqTraining', 'lostLedgers',
    'twistOffer', 'twistLied', 'twistRival', 'twistWorse', 'twistChains',
    'dangerous', 'elite', 'reinfest', 'multiPart', 'returning', 'contractGroups',
    'wildCaravan', 'wildRoadblock', 'wildBeast', 'wildGuar', 'wildSmuggler', 'wildWreck', 'wildGather',
    'wildPatrol', 'wildTraveller', 'wildDrive',
    'wildGraverobber', 'wildMachine', 'wildSummon', 'wildRitual', 'wildTax', 'wildPirateCove', 'wildPirate',
    'strays', 'villageBoards' }
C.SLOTS = 4                 -- paid jobs a board posts at most before the job cap, and paper slots on a wall
C.REFRESH_DAYS = 3          -- how long a notice from a save made before rolling refresh stays up
C.CHANCE_DAYS = 3           -- DANGER.CHANCE, ELITE_CHANCE and REINFEST.CHANCE are per this many days (board.lua perRoll)
-- What a board holds (board.lua), by kind: paid place jobs, open world jobs and news or shop ads,
-- each { lo, hi } drawn at every roll; requisitions come from C.REQ.ORDERS. total: the most notices
-- on the board, news trimmed first. More notices are more choice, not more gold: contract slots
-- and the job cap (rewards.jobCap, on jobs and open world together) are unchanged.
-- Rolling refresh: a board is looked at once ROLL_DAYS have passed. A notice stays up its own STAY
-- days (drawn when posted, by family), then comes down and the gaps are filled again, so a few
-- papers change each day instead of the whole board at once. FIRST: an empty board's notices get a
-- stay drawn from FIRST instead, so they don't all come down together.
C.BOARD = {
    MIX = {
        guild = { jobs = { 2, 3 }, wild = { 1, 2 }, news = { 1, 2 }, total = 8 },
        fort = { jobs = { 1, 2 }, wild = { 1, 2 }, news = { 1, 2 }, total = 8 },
        town = { jobs = { 2, 3 }, wild = { 1, 2 }, news = { 2, 3 }, total = 10 },
        -- A village or roadside inn: two jobs, one small order (requisitions), one piece of gossip.
        village = { jobs = { 2, 2 }, wild = { 0, 0 }, news = { 1, 1 }, total = 4 },
        company = { jobs = { 0, 0 }, wild = { 0, 0 }, news = { 1, 1 }, total = 4 },
    },
    ROLL_DAYS = 1,
    STAY = { job = { 3, 6 }, wild = { 2, 4 }, news = { 2, 5 }, ad = { 4, 8 } },
    FIRST = { 1, 5 },
    AD_SHARE = 0.45,        -- of a town board's news slots that go to a shop ad, when a shop is free
}
C.RECENT_BODIES = 24        -- bodies of a board's last notices, kept across refreshes so their lines aren't reused soon
C.EXPIRE_DAYS = { 7, 10 }
C.REUSE_DAYS = 10           -- a dungeon used by a contract isn't offered again for this long
C.RADIUS_CELLS = 12
C.CELL = 8192
C.CANDIDATES_PER_REFRESH = 12
-- A refresh draws a kind of place by weight, then a place of that kind (pick.lua). Kinds come
-- from tools/build_places.py (places.lua `k`); a kind with nothing in range is left out.
C.PLACE_KIND_WEIGHT = { cave = 3, mine = 3, dwemer = 2, daedric = 2, stronghold = 2, sewer = 1, wreck = 1.5,
    tomb = 2.5 }
C.BOUNTY_FIRST = 0.7              -- chance a place with people becomes the board's bounty
C.PLACE_KIND_CAP = { tomb = 1 }   -- at most this many of a kind on a board
-- Job kind weights in a place whose own largest group lives in water (slaughterfish, dreugh):
-- clearing the fish out wears thin fast, so wrecks and sea caves lean to recoveries and bounties.
C.WATER_KIND = { nest = 0.2, recovery = 1.5, bounty = 1.5 }
C.REPOST_DAYS = 4                 -- a place posted on any board is passed over this long, if its kind has others

-- Freshness (fresh.lua): a finished kind climbs back to full weight over RECOVER days. SAMPLE:
-- the first jobs favour kinds not done yet (SAMPLE_W). A board never posts the same kind twice
-- in a row (last posted kind weighs 0).
C.FRESH = { RECOVER = 21, SAMPLE = 10, SAMPLE_W = 3 }

C.REPEAT_WINDOW_DAYS = 3         -- each contract finished this recently takes one job off a refresh
-- New in town: until DONE contracts are finished a board posts at most JOBS job notices per refresh
-- (rewards.jobCap). LEVEL is the old rule, used only with the levelGates setting.
C.EARLY = { DONE = 5, JOBS = 2, LEVEL = 10 }

-- Difficulty tiers (tier.lua). A job's tier comes from the job: what lives in the place, how many,
-- a hand-placed leader, how far. Never from the player's level.
-- score: danger (summed hostile levels, places.lua t) at TYPICAL_LEVEL, raised by up to DIST_WEIGHT
--   for distance and CHAMPION for a hand-placed leader. SCORE: where each tier starts.
-- SWING_MAX: a place whose danger at level 30 is over this many times its danger at level 5 is
--   never posted: its levelled lists decide what is there, so no rating would hold.
-- BANDS: enemy levels for what this mod spawns (bands, open world, reinfested places).
-- VALUE: what a job is worth in gold and goods; GOLD: gold's share of it, so the gold runs easy
--   50-120, normal 130-300, dangerous 350-650, elite 700-1150; SUPPLY: the highest supply tier the
--   goods come from. Training sessions and a dangerous or elite job's curated piece come on top.
-- KEEP_OUT: places never posted, whatever their tier: too crowded at high level for CONTRACT's cap.
-- WEIGHT: how often a board posts each tier; REGION and POSTER scale it (names lowercased,
--   matched as substrings of the region's name).
-- HIDE_MARGIN: with the hideAbove setting, a job whose band starts this many levels over the
--   player's level is not posted. LEGACY: the old gates, with the levelGates setting.
C.TIER = {
    ORDER = { 'easy', 'normal', 'dangerous', 'elite' },
    TYPICAL_LEVEL = 12,
    DIST_WEIGHT = 0.25,
    CHAMPION = 10,
    SCORE = { normal = 18, dangerous = 55, elite = 120 },
    SWING_MAX = 2.5,
    BANDS = { easy = { 1, 6 }, normal = { 5, 12 }, dangerous = { 12, 22 }, elite = { 22, 35 } },
    VALUE = { easy = { 85, 180 }, normal = { 190, 430 }, dangerous = { 440, 810 }, elite = { 825, 1350 } },
    KEEP_OUT = { ['Senim Ancestral Tomb'] = true, ['Nalyn Ancestral Tomb'] = true, ['Sanit'] = true },
    GOLD = { easy = 0.6, normal = 0.7, dangerous = 0.8, elite = 0.85 },
    SUPPLY = { easy = 1, normal = 2, dangerous = 3, elite = 3 },
    WEIGHT = { easy = 1, normal = 1.1, dangerous = 0.35, elite = 0.1 },
    REGION = {
        gentle = { match = { 'ascadian isles', 'west gash', 'bitter coast', 'lan orethan', 'aanthirin' },
            easy = 1.4, normal = 1, dangerous = 0.6, elite = 0.4 },
        harsh = { match = { 'ashlands', 'molag mar', 'red mountain', 'sundered scar', 'velothi mountains',
            'dagon urul', 'sea of ghosts' }, easy = 0.6, normal = 1, dangerous = 1.5, elite = 2 },
    },
    POSTER = { ['fighters guild'] = { dangerous = 1.3, elite = 1.5 }, town = { dangerous = 0.8, elite = 0.5 } },
    -- Board size (tier.size): a guild hall in a big city (hall), another board there (city), any
    -- board in a small town (small), a Legion fort (fort). SIZE scales the tier weights; elite work
    -- posts only where it is above zero. BAND_CHANCE scales the chance of a spawned dangerous band.
    HUBS = { vivec = true, balmora = true, ald_ruhn = true, sadrith_mora = true, ebonheart = true,
        old_ebonheart = true, necrom = true, almas_thirr = true, firewatch = true, narsis = true },
    SIZE = {
        hall = { easy = 0.4, normal = 1, dangerous = 2.6, elite = 1.6 },
        city = { easy = 1, normal = 1, dangerous = 1, elite = 0 },
        small = { easy = 1.4, normal = 1, dangerous = 0.45, elite = 0 },
        fort = { easy = 0.7, normal = 1, dangerous = 1.4, elite = 0 },
    },
    BAND_CHANCE = { hall = 1.6, city = 0.8, small = 0.3, fort = 1.2 },
    HIDE_MARGIN = 10,
    LEGACY = { dangerous = 10, elite = 25 },
    GAP = 2,    -- found danger this many times the rated, or under its inverse, gets a line in the log
}

-- Contract groups (threat.lua). A group is filled up to a threat budget, and it also stops at the
-- head cap. Within a tier the budget roll buys stronger people before it buys another body.
-- SCORE weights: health/8 + level*0.4 + weaponClass * skill/40 + armour/8 + spells, times NPC for a
-- person. Creatures skip the NPC factor and the weapon term. SKILL and HEALTH are clamps: a template
-- over the health line is not picked, and a weapon skill over the line is cut down on spawn.
-- CAPS are at group size 1. The group size setting scales the budget and the caps (0.5 to 1.5).
-- GEAR_VALUE: base value of everything a contract group is wearing.
-- GEAR_SELL: what a merchant would pay for that, the most that still fits under the tier's
-- value cap once gold is at the bottom of its band. HEALER and SUMMONER multiply the finished
-- group's threat.
C.THREAT = {
    CAPS = {
        easy = { npc = { 1, 3 }, creature = 4 },
        normal = { npc = { 2, 4 }, creature = 6 },
        dangerous = { npc = { 4, 6 }, creature = 8 },
        elite = { npc = { 6, 9 }, creature = 10 },
    },
    BUDGET = { easy = { 15, 45 }, normal = { 40, 90 }, dangerous = { 120, 200 }, elite = { 250, 420 } },
    SKILL = { easy = 40, normal = 55, dangerous = 70, elite = 85 },
    HEALTH = { easy = 80, normal = 120, dangerous = 180, elite = 260 },
    EASY_CREATURE = 5,
    NPC = 1.25,
    -- Measured bodies (a level 8 smuggler is about 28 before this) are heavier than the budgets
    -- above were written for. This scales every score the same way, so a stronger record is still
    -- stronger, and a minimum crew still fits in the low end of the budget.
    WEIGHT = 0.55,
    HEALER = 1.2,
    SUMMONER = 1.15,
    RECENT = 12,
    GROUP_SIZE = 1,
    GEAR_VALUE = { easy = 250, normal = 700, dangerous = 2200, elite = 6000 },
    GEAR_SELL = { easy = 130, normal = 300, dangerous = 460, elite = 650 },
    -- What a loaded actor may keep. Weapon class: 4 iron, 6 steel, 8 silver, 12 dwarven, 22 glass.
    -- Armour is the piece's base value. Ammunition dearer than AMMO_VALUE, or enchanted, comes off.
    GEAR_CLASS = { easy = 6, normal = 8, dangerous = 12, elite = 22 },
    GEAR_ARMOR = { easy = 80, normal = 200, dangerous = 500, elite = 1500 },
    AMMO_VALUE = 5,
}

C.JOB_POLL_SECONDS = 2      -- target deaths, only while the player is in a job's cell
C.ITEM_POLL_SECONDS = 5     -- recovery items, only while a recovery or bounty is held
C.NEAR_POLL_SECONDS = 2     -- player looks for unplaced board spots, only while any are left
-- A search that found nothing (no door, no wall, no answer from the rays) waits this long, or
-- until the player has moved SEARCH_AWAY, before it looks again. It does not try every poll.
C.SEARCH_BACKOFF = 4 * 3600 -- game seconds, four hours
C.SEARCH_AWAY = 12000
C.SLOW_TICK_MS = 2          -- a nearTick or one of its jobs over this is logged as it happens
C.PROFILE_SECONDS = 30      -- the footprint setting logs handler times this often
C.NEAR_BOARD_UNITS = 3000
-- Every interior a board names (each tavern of a town) carries the board's notices, beside the
-- best of its outside doors. Doors are looked up once the player is within DOOR_LOOKUP_UNITS of the
-- town; a door is checked with rays only within SPOT_REACH of the player (rays see only the loaded
-- area). A spot found later moves that interior's notices only when it scores BETTER_BY more.
C.DOOR_LOOKUP_UNITS = 9000
C.SPOT_REACH = 2500
C.BETTER_BY = 20
-- Spot score: style base, plus per paper, minus distance along the wall from the door; papers on
-- a surface facing the door's approach (a side wall, frame, pillar) just under its own front wall.
-- Lit papers gain `lit`, papers in a dark recess lose `recess`.
C.SCORE = { wall = 100, surface = 88, backed = 55, open = 40, free = 20, perPaper = 5, perUnit = 1 / 25,
    lit = 12, recess = 25 }
-- Which door is the main entrance, added to the spot score:
--   open      x share of the fan of rays out from the door that runs clear (a square, not an alley)
--   perPublic per public door (shop, guild, temple, tavern) in front within PUBLIC_RANGE, to publicMax
--   centre    minus one point per centreUnit from the middle of the town's public doors, to centreMax
--   higher    against the other doors of the same building: minus higherPer per unit this door
--             stands further off its street than the building's lowest door, past higherFree
--   upper     the door stands STEP or more above or below the street and the walk from the street is
--             long (an upper floor, a balcony); unreachable: no walk from the street at all
--   unknown   the navmesh wasn't ready to say
--   main      within mainRadius of a door towns.lua names as the main one; only a tie-breaker
-- The best door of a building gets the full set of papers; every other street-level door of it
-- (geom.streetLevel: walked to from the street, SECOND_OVER at most above the lowest door) gets
-- SECOND_PAPERS of the same notices.
C.ENTRANCE = {
    open = 40, perPublic = 4, publicMax = 24, centreUnit = 1000, centreMax = 6,
    higherPer = 0.3, higherFree = 30,
    upper = -60, unreachable = -150, unknown = -10, main = 8, mainRadius = 300, SECOND_OVER = 200,
    STEP = 120, STREET_OUT = 380, PUBLIC_RANGE = 1500, PUBLIC_DOT = 0.3,
    FAN = 9, FAN_HALF = math.rad(80), FAN_LEN = 1600, DETOUR = 2.5, DETOUR_PAD = 400,
}
C.SECOND_PAPERS = 2
-- Doors nobody would post notices by: sewer grates, trapdoors, hatches (id or mesh contains these).
C.SKIP_DOORS = { 'sewer', 'trapdoor', 'trap_door', 'hatch', 'grate', 'manhole' }
-- Statics that are windows: never wall for a paper (id or mesh contains these).
C.WINDOW_WORDS = { 'window', 'glass', 'shutter', 'wndw' }
-- Window statics this close to a door (each axis) are sent with its spot check.
C.WINDOW_NEAR = 700

-- Debug logging: a job slower than this is logged; a footprint line every so many seconds, and a
-- warning when a count has gone up at every one of the last FOOTPRINT_GROWTH lines.
C.SLOW_MS = 5
C.FOOTPRINT_SECONDS = 10
C.FOOTPRINT_GROWTH = 6

-- Hostile means fight at or above this: the engine starts a fight unprovoked when fight plus
-- iFightDistanceBase (20 at no distance) reaches 100, so below 80 an actor never does.
C.HOSTILE_FIGHT = 80
-- Never a target or counted, whatever their fight (record id or name contains one of these): kwama
-- queens don't leave their chamber, and notices say to spare them.
C.PASSIVE = { 'kwama queen', 'kwamaqn', 'kwama_queen' }
-- Fewest live foes a job is posted or taken with: a clearing counts its targets, a recovery every
-- hostile in the place.
C.MIN_FOES = { nest = 3, recovery = 2 }

-- Levels the research measured each place at; values in between are interpolated.
C.TIER_LEVELS = { 5, 15, 30 }

-- Contract groups (contractGroups setting): a place job brings its own enemies, drawn when the
-- notice goes up from the tier (C.TIER.BANDS, DANGER.FOLLOWERS) and the kind of place, and made on
-- the first visit with the contract held. The place's own occupants stay as they are.
-- HOSTILE_CAP: the place's own hostiles at the player's level plus the tier's largest group, at
--   most; a place without room for a tier is not offered at it.
-- AWAY: the group waits at least this far from the place's own hostiles where the place allows;
--   SPREAD: the points it is placed around stand this far apart (geom.awayFrom).
-- ELITE_KINDS: places big enough for an elite group.
-- Never named in directions (tools/build_landmarks.py leaves them out of data/landmarks.lua): the
-- Sixth House citadels would spoil the main quest for a new character.
C.NOT_LANDMARKS = { 'dagoth ur', 'vemynal', 'odrosal', 'tureynulal', 'endusal', 'kogoruhn' }

C.CONTRACT = {
    HOSTILE_CAP = 20,
    AWAY = 1200,
    SPREAD = 400,
    ELITE_KINDS = { dwemer = true, daedric = true, stronghold = true, tomb = true, mine = true, cave = true },
}

-- Main quest and expansion places, by name prefix (lowercase): never a job of any kind, in a place
-- or near its door. tools/build_places.py leaves them out of places.lua with the same list.
C.QUEST_PLACES = { 'ilunibi', 'dagoth ur', 'akulakhan', 'vemynal', 'odrosal', 'tureynulal', 'endusal',
    'kogoruhn', 'mamaea', 'sotha sil', 'old mournhold', 'bamz-amschend', 'urshilaku', 'arkngthand',
    'andrano ancestral tomb', 'solstheim, bloodskal barrow', 'solstheim, kolbjorn barrow',
    'solstheim, gyldenhul barrow', "solstheim, hrothmund's barrow", 'solstheim, mortrag glacier',
    'solstheim, castle karstaag' }

-- Pay: a job's value lies in its tier's VALUE band (C.TIER), placed by how far up the tier the
-- job's score sits (PAY_SCORE), how far away it is (PAY_DISTANCE) and the place's sellable loot
-- (PAY_LOOT, full at LOOT_FULL times the band's top).
C.DISTANCE_FULL_CELLS = 10
C.PAY_SCORE, C.PAY_DISTANCE, C.PAY_LOOT = 0.55, 0.25, 0.2
C.LOOT_FULL = 3

-- Supplies, one pool per kind of poster: what that poster would have to hand. ids and values are
-- Morrowind.esm records (base value, checked with oddjobs_research/reward_items.py), so they exist
-- in every load order. value: for one lot of `stack` (arrows and food come by the handful); max:
-- lots of it in one reward (weapons and amulets one). A supply tier is open up to the job's own
-- (C.TIER.SUPPLY) when the job's total value reaches it (SUPPLY_TIERS), and no lot may be worth
-- more than SUPPLY_ITEM_SHARE of the gold paid with it.
local function pool(list)
    local out = {}
    for _, e in ipairs(list) do
        out[#out + 1] = { id = e[1]:lower(), value = e[2], tier = e[3], stack = e.stack or 1, max = e.max }
    end
    return out
end
C.SUPPLIES = {
    mages = pool({
        { 'p_restore_magicka_c', 15, 1 }, { 'p_fortify_magicka_c', 15, 1 }, { 'p_spell_absorption_c', 15, 1 },
        { 'Misc_SoulGem_Petty', 10, 1 }, { 'Misc_SoulGem_Lesser', 20, 1 },
        { 'ingred_ectoplasm_01', 10, 1 }, { 'ingred_scamp_skin_01', 10, 1 }, { 'ingred_racer_plumes_01', 20, 1 },
        { 'p_restore_magicka_s', 35, 2 }, { 'p_spell_absorption_s', 35, 2 }, { 'Misc_SoulGem_Common', 40, 2, max = 2 },
        { 'sc_almsiviintervention', 63, 2, max = 1 }, { 'sc_divineintervention', 63, 2, max = 1 },
        { 'sc_firstbarrier', 68, 2, max = 1 }, { 'ingred_red_lichen_01', 25, 2 }, { 'ingred_hackle-lo_leaf_01', 30, 2 },
        { 'p_restore_magicka_q', 80, 3 }, { 'Misc_SoulGem_Greater', 60, 3, max = 1 }, { 'sc_mark', 85, 3, max = 1 },
        { 'sc_healing', 107, 3, max = 1 }, { 'ingred_frost_salts_01', 75, 3, max = 2 },
        { 'ingred_fire_salts_01', 100, 3, max = 1 }, { 'ingred_void_salts_01', 100, 3, max = 1 },
    }),
    fighters = pool({
        { 'iron arrow', 10, 1, stack = 10 }, { 'steel arrow', 20, 1, stack = 10 }, { 'hammer_repair', 10, 1 },
        { 'repair_prongs', 6, 1 }, { 'iron dagger', 10, 1, max = 1 }, { 'iron shortsword', 20, 1, max = 1 },
        { 'iron war axe', 30, 1, max = 1 }, { 'iron mace', 24, 1, max = 1 }, { 'p_restore_health_c', 15, 1 },
        { 'p_restore_fatigue_c', 15, 1 },
        { 'silver arrow', 30, 2, stack = 10 }, { 'steel bolt', 20, 2, stack = 10 }, { 'repair_journeyman_01', 20, 2 },
        { 'steel shortsword', 40, 2, max = 1 }, { 'steel spear', 40, 2, max = 1 }, { 'steel mace', 48, 2, max = 1 },
        { 'steel axe', 60, 2, max = 1 }, { 'silver dagger', 40, 2, max = 1 }, { 'p_restore_health_s', 35, 2 },
        { 'repair_master_01', 50, 3 }, { 'steel longsword', 80, 3, max = 1 }, { 'steel warhammer', 80, 3, max = 1 },
        { 'silver longsword', 160, 3, max = 1 }, { 'p_restore_health_q', 80, 3 },
    }),
    temple = pool({
        { 'p_restore_health_c', 15, 1 }, { 'p_cure_common_s', 20, 1 }, { 'p_cure_poison_s', 20, 1 },
        { 'p_cure_paralyzation_s', 20, 1 }, { 'p_restore_fatigue_c', 15, 1 },
        { 'amulet of almsivi intervention', 21, 1, max = 1 }, { 'amulet of divine intervention', 21, 1, max = 1 },
        { 'p_restore_health_s', 35, 2 }, { 'p_cure_blight_s', 30, 2 }, { 'amulet of health', 44, 2, max = 1 },
        { 'amulet of rest', 51, 2, max = 1 }, { 'sc_almsiviintervention', 63, 2, max = 1 },
        { 'p_restore_health_q', 80, 3 }, { 'amulet of shield', 50, 3, max = 1 }, { 'sc_healing', 107, 3, max = 1 },
    }),
    -- Townsfolk: ordinary goods of their trade (gold makes up the rest).
    sea = pool({
        { 'ingred_scuttle_01', 10, 1, max = 2 }, { 'ingred_crab_meat_01', 5, 1, stack = 5, max = 1 },
        { 'misc_de_fishing_pole', 7, 1, max = 1 }, { 'p_swift_swim_c', 15, 1 }, { 'p_restore_health_c', 15, 1 },
        { 'p_water_breathing_s', 35, 2 }, { 'p_restore_health_s', 35, 2 },
        { 'ingred_pearl_01', 100, 3, max = 1 }, { 'ingred_dreugh_wax_01', 100, 3, max = 1 },
    }),
    land = pool({
        { 'food_kwama_egg_02', 10, 1, stack = 5 }, { 'ingred_saltrice_01', 10, 1, stack = 10 },
        { 'ingred_bread_01', 5, 1, stack = 5 }, { 'ingred_comberry_01', 10, 1, stack = 5 },
        { 'ingred_scrib_jerky_01', 15, 1, stack = 3 }, { 'p_restore_fatigue_c', 15, 1 }, { 'p_cure_common_s', 20, 1 },
        { 'ingred_hackle-lo_leaf_01', 30, 2 }, { 'p_restore_health_s', 35, 2 }, { 'p_cure_blight_s', 30, 2 },
        { 'p_restore_health_q', 80, 3 }, { 'ingred_pearl_01', 100, 3, max = 1 },
    }),
    road = pool({
        { 'pick_apprentice_01', 10, 1 }, { 'probe_apprentice_01', 10, 1 }, { 'p_feather_c', 15, 1 },
        { 'p_restore_fatigue_c', 15, 1 },
        { 'pick_journeyman_01', 50, 2 }, { 'probe_journeyman_01', 50, 2 }, { 'p_levitation_s', 35, 2 },
        { 'p_restore_fatigue_s', 35, 2 }, { 'misc_clothbolt_01', 50, 2, max = 1 },
        { 'pick_master', 100, 3, max = 1 }, { 'probe_master', 100, 3, max = 1 },
    }),
    desk = pool({
        { 'p_night-eye_c', 15, 1 }, { 'p_restore_intelligence_c', 15, 1 }, { 'pick_apprentice_01', 10, 1 },
        { 'probe_apprentice_01', 10, 1 }, { 'p_restore_willpower_c', 15, 1 },
        { 'sc_almsiviintervention', 63, 2, max = 1 }, { 'sc_divineintervention', 63, 2, max = 1 },
        { 'p_detect_key_s', 35, 2 },
        { 'sc_mark', 85, 3, max = 1 }, { 'sc_leaguestep', 85, 3, max = 1 },
    }),
    smith = pool({
        { 'hammer_repair', 10, 1 }, { 'repair_prongs', 6, 1 }, { 'iron dagger', 10, 1, max = 1 },
        { 'iron shortsword', 20, 1, max = 1 }, { 'iron war axe', 30, 1, max = 1 },
        { 'repair_journeyman_01', 20, 2 }, { 'steel dagger', 20, 2, max = 1 }, { 'steel axe', 60, 2, max = 1 },
        { 'repair_master_01', 50, 3 }, { 'steel longsword', 80, 3, max = 1 },
    }),
    cloth = pool({
        { 'expensive_shirt_01', 15, 1, max = 1 }, { 'expensive_pants_01', 15, 1, max = 1 },
        { 'expensive_skirt_01', 15, 1, max = 1 }, { 'expensive_shoes_01', 10, 1, max = 1 },
        { 'expensive_belt_01', 10, 1, max = 1 },
        { 'misc_clothbolt_01', 50, 2, max = 1 }, { 'expensive_robe_02', 10, 2, max = 1 },
        { 'expensive_amulet_01', 30, 2, max = 1 },
        { 'extravagant_amulet_01', 120, 3, max = 1 },
    }),
    craft = pool({
        { 'hammer_repair', 10, 1 }, { 'repair_prongs', 6, 1 }, { 'ingred_guar_hide_01', 5, 1 },
        { 'p_restore_fatigue_c', 15, 1 },
        { 'repair_journeyman_01', 20, 2 }, { 'ingred_kagouti_hide_01', 10, 2, stack = 5 }, { 'p_restore_health_s', 35, 2 },
        { 'repair_master_01', 50, 3 }, { 'p_restore_health_q', 80, 3 },
    }),
}
-- Which pool pays: guild and temple posters their own, townsfolk by trade (else 'land').
C.SUPPLY_POOL = { ['mages guild'] = 'mages', ['fighters guild'] = 'fighters', temple = 'temple', legion = 'fighters' }
C.TRADE_POOL = {
    fisherman = 'sea', fisher = 'sea', boatwright = 'sea',
    farmer = 'land', herder = 'land', hunter = 'land', ['egg miner'] = 'land',
    trader = 'road', caravaner = 'road', porter = 'road', scout = 'road',
    clerk = 'desk', smith = 'smith', weaver = 'cloth', seamstress = 'cloth',
    cooper = 'craft', tanner = 'craft', pilgrim = 'temple', widow = 'temple',
}
-- Supply tier n opens for a job worth value[n] or more.
C.SUPPLY_TIERS = { value = { 0, 200, 500 } }
C.SUPPLY_ITEM_SHARE = 0.4
C.SUPPLY_KINDS = 3
C.SUPPLY_PER_KIND = 3

-- A guild session stands in for the supplies when they'd cover this share of its price.
C.TRAINING_SHARE = 1 / 3
C.TRAINING_COOLDOWN_DAYS = 3
C.TRAINING_SKILL_CAP = 70

-- Faction reputation per completed guild contract, before the half-gap cap.
C.REP = { nest = 1, recovery = 1, bounty = 2, req = 1 }

C.GUILDS = { ['fighters guild'] = true, ['mages guild'] = true }

-- Kinds each poster offers. Town boards post all three.
C.KINDS = {
    town = { 'nest', 'bounty', 'recovery' },
    ['fighters guild'] = { 'nest', 'bounty', 'recovery' },
    ['mages guild'] = { 'recovery', 'nest', 'bounty' },
    temple = { 'nest', 'recovery', 'bounty' },
    legion = { 'bounty', 'nest' },
}
-- Bounty groups a poster will name. No entry: any people group. Mages Guild: rogue mages only.
-- Temple: people who broke into a tomb or shrine.
C.BOUNTY_GROUPS = {
    ['mages guild'] = { necromancer = true, warlock = true },
    temple = { graverobber = true, necromancer = true, cultist = true },
}

-- Contract items. Each contract gets its own record made at take time from one of these bases
-- (load.lua), named for whoever posted it, so no two items in the world look alike.
-- noun: as it reads in a sentence; title: on the notice ("Lost: Hlaren Family Ring").
-- owned: the poster's surname goes in front ('family'), or the town's name ('town').
-- carried: only where people could have carried it in (raiders, smugglers) or on a wreck; trade
-- goods don't end up in a kwama mine or a beast's cave.
C.SIGNET_BASE = 'ojb_signet'
C.ITEM_KINDS = {
    town = {
        { key = 'ring', base = 'ojb_ring_family', noun = 'family ring', owned = 'family' },
        { key = 'amulet', base = 'ojb_amulet_family', noun = 'family amulet', owned = 'family' },
        { key = 'urn', base = 'ojb_urn_family', noun = 'ancestral urn', owned = 'family' },
        { key = 'ledger', base = 'ojb_ledger', noun = 'ledger', owned = 'family' },
        { key = 'journal', base = 'ojb_journal', noun = 'journal', owned = 'family' },
        { key = 'letter', base = 'ojb_letter', noun = 'letters', owned = 'family', plural = true },
        { key = 'cup', base = 'ojb_cup_family', noun = 'silver cup', owned = 'family' },
        { key = 'band', base = 'ojb_band', noun = 'wedding band', owned = 'family' },
        { key = 'seal', base = 'ojb_seal', noun = 'seal ring', owned = 'family' },
        { key = 'locket', base = 'ojb_locket', noun = 'silver locket', owned = 'family' },
        { key = 'token', base = 'ojb_token', noun = "pilgrim's token", owned = 'family' },
        { key = 'puzzlebox', base = 'ojb_puzzlebox', noun = 'puzzle box', owned = 'family' },
        { key = 'lute', base = 'ojb_lute', noun = 'family lute', owned = 'family' },
        { key = 'drum', base = 'ojb_drum', noun = 'guarskin drum', owned = 'family' },
        { key = 'writing', base = 'ojb_writing', noun = 'writing set', owned = 'family' },
        { key = 'knife', base = 'ojb_knife', noun = 'fishing knife', owned = 'family' },
        { key = 'goblet', base = 'ojb_goblet', noun = 'wedding goblet', owned = 'family' },
        { key = 'coin', base = 'ojb_coin', noun = 'Dwemer coin', owned = 'family' },
        { key = 'prayer', base = 'ojb_prayer', noun = 'prayer book', owned = 'family' },
        { key = 'housekey', base = 'ojb_key', noun = 'house key', owned = 'family' },
        -- Vanilla bases, copied whole: a usable dagger, and two enchanted pieces (Detect Enchantment).
        { key = 'dagger', base = 'steel dagger', noun = 'family dagger', owned = 'family' },
        { key = 'ancestor', base = "ancestor's ring", noun = 'ancestor ring', owned = 'family', enchanted = true },
        { key = 'charm', base = 'balm amulet', noun = 'healing charm', owned = 'family', enchanted = true },
    },
    ['fighters guild'] = {
        { key = 'goods', base = 'ojb_goods', noun = 'caravan goods', owned = 'town', plural = true, carried = true },
        { key = 'gledger', base = 'ojb_ledger', noun = 'trade ledger', owned = 'town' },
        { key = 'banner', base = 'ojb_banner', noun = 'company pennant', owned = 'town' },
    },
    ['mages guild'] = {
        { key = 'tome', base = 'ojb_tome', noun = 'guild tome', owned = 'town' },
        { key = 'notes', base = 'ojb_notes', noun = 'field notes', owned = 'town', plural = true },
        { key = 'samples', base = 'ojb_samples', noun = 'sample flask', owned = 'town' },
        { key = 'chart', base = 'ojb_chart', noun = 'star chart', owned = 'town' },
    },
    temple = {
        { key = 'token', base = 'ojb_token', noun = "pilgrim's token", owned = 'town' },
        { key = 'prayer', base = 'ojb_prayer', noun = 'prayer book', owned = 'town' },
        { key = 'urn', base = 'ojb_urn_family', noun = 'ancestral urn', owned = 'town' },
        { key = 'amulet', base = 'ojb_amulet_family', noun = 'temple amulet', owned = 'town' },
    },
}

-- Board styles. Positions are in board space: origin at the spot, +x to the right as you face it,
-- -y out of the front, +z up. The front faces the street.
--   wall: papers pinned flat on a building wall; the spot is the middle of the cluster on the wall.
--   board: posts and planks on the ground, only where no wall beside the door will do.
-- w, d, h: footprint checked for clearance before placing a board.
local HALF_PI = math.pi / 2
C.VARIANTS = {
    -- Papers on a wall: each paper's place comes from the spot check (spot.slots).
    wall = {
        parts = {},
        minPapers = 1,
    },
    board = {
        w = 180, d = 24, h = 180,
        parts = {
            { rec = 'ojb_post', x = -84, y = 0, z = 80 },
            { rec = 'ojb_post', x = 84, y = 0, z = 80 },
            { rec = 'ojb_board_vanilla', active = true, x = 0, y = 0, z = 74, plank = true },
            { rec = 'ojb_board_vanilla', active = true, x = 0, y = 0, z = 109, plank = true },
            { rec = 'ojb_board_vanilla', active = true, x = 0, y = 0, z = 144, plank = true },
        },
        minPapers = 0,
        paper = { y = -9.6 },
        slots = {
            { -38, 130, rec = 'ojb_notice_parch1', tilt = -0.07 },
            { 38, 133, rec = 'ojb_notice_note1', tilt = 0.09 },
            { -36, 92, rec = 'ojb_notice_note2', tilt = 0.05 },
            { 40, 90, rec = 'ojb_notice_parch2', tilt = -0.1 },
            { 0, 112, rec = 'ojb_notice_note1', tilt = 0.04 },
            { -70, 108, rec = 'ojb_notice_note2', tilt = -0.08 },
            { 70, 118, rec = 'ojb_notice_parch1', tilt = 0.07 },
        },
    },
}
C.HALF_PI = HALF_PI

-- Pinned papers beside a door. Probe points stand OUT in front of the door's wall, LATERAL along
-- it from the door's edge, both sides; from each a ray finds the wall at CENTRE_HEIGHT above the
-- ground. Then each paper is tried on its own patch of wall, at the SLOTS around that point: a
-- patch only has to be flat across one paper, so papers follow a curved wall, and a patch with a
-- poster or sign on it is simply left out. The cluster needs MIN_PAPERS patches.
C.WALL = {
    LATERAL = { 0, 15, 30, 65, 105, 150, 200, 255 },  -- past the door's edge plus HALF_W and EDGE_GAP
    EDGE_GAP = 12,
    OUT = 70,
    REACH = 170,
    CENTRE_HEIGHT = 128,
    HALF_W = 30,                   -- probe to the edge of the nearest paper, along the wall
    MAX_NORMAL_Z = 0.3,            -- steeper than this and it isn't a wall
    FACE_DOT = 0.3,                -- the wall must face the street side of the door (within ~72 deg)
    MAX_SETBACK = 90,              -- wall surface from the door's plane, either way
    GROUND_TOL = 110,              -- ground under the probe against the ground at the door
    PAPER_HW = 13, PAPER_HH = 17,  -- one paper plus a margin, half width and half height
    PAPER_FLAT = 4,                -- a patch may bow this much in or out under one paper
    RECESS_SAMPLES = 2,            -- of nine samples, this many may sit deeper (mortar, gaps in stone)
    FACADE_STEP = 40,              -- past LATERAL, probes along the building's front this far apart
    FACADE_REACH = 600,            -- up to this far past the door's edge
    FACADE_RAYS = 3000,            -- rays per door on walls before giving up on them
    ABOVE_DOOR = { 260, 340 },     -- heights over the threshold where the door's own building is looked for
    PAPER_NORMAL_DOT = 0.9,        -- every ray's normal on a patch against the patch's own
    CURVE_DOT = 0.7,               -- a paper may turn this far from the cluster's facing (~45 deg)
    POSTER_GAP = 14,               -- drawn this close in front of the wall: a poster, a neighbour
    FRONT_CLEAR = 45,              -- nothing solid or drawn this far in front of a paper
    MIN_PAPERS = 2,
    -- A board's papers sit on up to PATCHES stretches (left of the door, right of it, and further
    -- along the front), a few on each, when the wall allows. Stretches closer than PATCH_GAP are
    -- the same patch. SPREAD is how far along the front that search goes when it has already found
    -- a patch; past a blank stretch beside the door it still walks the whole front.
    PATCHES = 3,
    PER_PATCH = 3,
    PATCH_GAP = 100,
    SPREAD = 400,
    WINDOW_GAP = 20,               -- no paper this close to a window object's box
    PLANE_TOL = 6,                 -- every paper of a cluster within this of one plane
    BAY_REACH = 40,                -- past the outer papers, both sides, where the wall behind is tested
    BAY_DEPTH = 15,                -- the wall behind further back than this on both sides: a bay
    -- Paper positions {right, up} from the probe's wall point, best first.
    SLOTS = { { -16, 12 }, { 16, 18 }, { 17, -16 }, { -15, -22 }, { -47, -3 }, { 48, 3 }, { 0, 52 }, { 0, -56 } },
    DOOR_HALF_MAX = 90,
}
-- Records and leans for papers on a wall, in slot order. A notice's paper takes its own record
-- (paper.lua wallOf); these records stay for papers with no notice. Up to WALL.PAPERS of them.
C.WALL_PAPERS = {
    { rec = 'ojb_notice_parch1', tilt = -0.05 }, { rec = 'ojb_notice_note1', tilt = 0.08 },
    { rec = 'ojb_notice_note2', tilt = -0.06 }, { rec = 'ojb_notice_parch2', tilt = 0.04 },
    { rec = 'ojb_notice_note1', tilt = -0.09 }, { rec = 'ojb_notice_parch1', tilt = 0.06 },
    { rec = 'ojb_notice_note2', tilt = 0.03 },
}
C.WALL.PAPERS = 7
C.VARIANTS.wall.slots = C.WALL_PAPERS

-- The fallback board stands with its back to a wall beside the door, out of the walk to the door:
-- probes along the wall start BOARD_EDGE past the door's edge plus half the board.
C.BOARD_LATERAL = { 0, 45, 100, 160, 230 }
C.BOARD_WALL_GAP = 4        -- board's back edge (plus clearance pad) to the wall, where its footprint is checked
-- A board against something stands BOARD_SNUG off it; behind it, six rays (both ends and the middle,
-- two heights) must all find the backing within BOARD_GAP_MAX, and none of it inside the board.
C.BOARD_SNUG = 3
C.BOARD_GAP_MAX = 14
C.BOARD_GAP_HEIGHTS = { 85, 140 }
-- A board's front against the way out to the street; less than this and it is turned sideways.
C.BOARD_FACE_DOT = 0.6

-- Surfaces facing the way people come to a door, for papers before any board: a side wall across
-- a courtyard, a door frame, a pillar, a post, a fence. FACING_RAYS level rays fan out from where
-- you step out, FACING_REACH long; a surface counts when it faces back down the ray within
-- FACING_DOT. The FACING_TRIES nearest the door get the full paper check.
C.FACING = { RAYS = 24, REACH = 420, DOT = 0.75, MIN = 40, TRIES = 6, SPREAD = 50, BACK_DOT = -0.5 }

-- Light and openness of a paper spot: lit when a light (global.lua sends the nearest NEAR of the
-- enabled, non-negative lights round the door) stands within REACH of its radius with nothing
-- between; open is the clear share of OPEN_ANGLES rays OPEN_LEN out from the papers. Below RECESS
-- and unlit, a spot is a dark recess. Past the first spot on a door's own building, walls are
-- searched EXTRA_ALONG further for a better one, up to KEEP spots.
C.LIGHT = {
    NEAR = 4, RANGE = 900, REACH = 0.8, START = 24, OFF = 34,
    OPEN_ANGLES = { 0, 0.7, -0.7, 1.3, -1.3 }, OPEN_LEN = 260, RECESS = 0.45,
    EXTRA_ALONG = 160, KEEP = 3,
}
-- Nothing stands in front of a door: a strip DOOR_PATH long out from it, the door's width plus
-- DOOR_PATH_MARGIN each side.
C.DOOR_PATH = 260
C.DOOR_PATH_MARGIN = 45
C.BOARD_EDGE = C.DOOR_PATH_MARGIN + 10   -- must clear the door strip, or the nearest probe never passes
-- Open ground, last: {along the wall, out from the wall} from where you come out of the door.
-- Only with something solid within BACKED_REACH behind the board.
C.SPOT_OFFSETS = {
    { 175, 30 }, { -175, 30 }, { 245, 50 }, { -245, 50 },
    { 175, 150 }, { -175, 150 }, { 320, 90 }, { -320, 90 },
}
C.BACKED_REACH = 160
C.SPOT_MAX_SLOPE = 28       -- highest minus lowest ground under the footprint
C.SPOT_RAY_HEIGHTS = { 15, 70, 130, 200 }
-- Ground plants a board can stand in: their collision is a low tuft, the board's legs go through it.
C.SOFT_WORDS = { 'grass', 'reed' }
C.SPOT_STAND_ROOM = 110     -- clear ground in front of the board
C.RAYS_PER_FRAME = 24       -- the spot check pauses to the next frame after this many rays

-- Loose recovery items: lying on furniture (or, for bigger items, open floor by a wall) in the
-- deeper part of the dungeon, found by the player script on first entry. CHANCE of recovery notices
-- whose story allows it (nobody carried the item off). Distances in world units; heights above
-- the floor the player stands on.
C.LOOSE = {
    CHANCE = 0.5,
    -- Furniture worth resting on, by record id or model; `on` words the story can name.
    WORDS = { 'table', 'desk', 'shelf', 'crate', 'barrel', 'altar', 'bedroll', 'chest', 'counter', 'bench' },
    NOT_WORDS = { 'stable', 'tablet', 'shelfbook', 'broken', 'ruin_' },
    SMALL = { ring = true, amulet = true, letter = true },   -- furniture only: lost on a floor
    MIN_DEPTH = 1000,      -- straight-line from the entrance; halved in small places
    DEEP_SHARE = 0.4,      -- and at least this share of the deepest candidate's distance
    CANDIDATES = 12,       -- furniture sent to the player script, best first
    LIGHT_NEAR = 600,      -- a light within this counts as a lit spot
    MIN_SURFACE = 15, MAX_SURFACE = 135,   -- a top this high above the standing floor: not tall shelves
    CLEAR_ABOVE = 30,      -- nothing above the spot this close (a shelf board, a beam)
    FLAT = 0.9,            -- surface normal z: flat enough to lie on
    EDGE = 8,              -- the four points this far round the spot must be the same surface
    STAND_REACH = 170,     -- standing navmesh this close, horizontally
    EYE = 110,             -- eye height for the visibility ray
    FLOOR_TRIES = 8, FLOOR_RADIUS = 700, FLOOR_FLAT = 0.95, WALL_NEAR = 70, WALL_GAP = 22,
    FURNITURE_RAYS = 120,          -- no new furniture tried past this many rays
    MAX_RAYS = 160,                -- no new floor point tried past this many
    OPEN_ACROSS = 300,     -- open floor across from the wall: a room, not a passage
    SETTLE_SECONDS = 0.5,  -- the item is checked this long after it is placed
    ANSWER_SECONDS = 20,   -- no answer from the player script by then: ask again
    TRIES = 3,             -- answers of "navmesh not ready" before the item goes in a container
}

-- Requisitions (req.lua): goods a poster really uses, handed in at the board. Nothing follows the
-- player's level. Each piece pays its base value x the grade's PREMIUM, with the grade's FEE
-- spread over the order; goods on a shelf in the board's own town pay LOCAL_PREMIUM, so buying
-- them next door and handing them in earns little (vanilla sells at 0.75 to ~1.15 of value,
-- Economy Plus at 1.05 to 1.15 of its local price). Counts land the order in the grade's BAND.
C.REQ = {
    KEEP_DAYS = 9,          -- an open requisition stays up this long
    -- Orders a board keeps open, by kind of board: guild halls, Temples and forts; company offices
    -- (a rare piece COMPANY_RARE of the time); town boards (a second order TOWN_SECOND of the time).
    ORDERS = { guild = { common = 2, rare = 1 }, company = { common = 2 }, town = { common = 1 },
        village = { common = 1 } },
    TOWN_SECOND = 0.5,
    COMPANY_RARE = 0.3,
    -- rareFar: a rare piece some merchant stocks, but not in this town or a nearby one.
    -- The order's real gain is full worth with no merchant's cut; the premium is a little extra.
    PREMIUM = { common = { 1.15, 1.3 }, rare = { 1.6, 1.9 }, rareFar = 1.35, collect = 1.8, company = { 1.15, 1.3 },
        harvest = { 1.4, 1.6 } },
    RARE_FOUND_MIN = 6,     -- found-only rare pieces a poster needs before far-sold ones are left out
    -- Goods a shop in this town stocks: under worth and no fee, since vanilla sells to a strong
    -- trader at 75 to 85 percent of worth (reports/req_sim.txt has the margins).
    LOCAL_PREMIUM = { 0.85, 0.95 },
    FEE = { common = 5, rare = 10, company = 8, collect = 10 },  -- once per order
    -- harvest: an order for a plant only ever picked wild (supply row h), asked by the handful. It
    -- comes off the rare list but is a bulk lot, so it is never tagged rare.
    -- An order never totals under its band's floor: goods too cheap to reach it in COUNT.max pieces
    -- are never asked for.
    BAND = { common = { 90, 200 }, rare = { 300, 900 }, company = { 120, 320 }, harvest = { 80, 220 } },
    -- Pieces in an order, what a person gathers or buys in an afternoon or two: lo to hi; worth
    -- stackValue or less (arrows, cheap ingredients, bread) up to stack; a company lot up to
    -- company; a harvest order harvestLo to harvestHi. Never more than max, whatever the floor
    -- needs. Rare orders 1 or 2.
    COUNT = { lo = 3, hi = 10, stack = 20, stackValue = 5, company = 20, companyDear = 15, harvestLo = 5,
        harvestHi = 20, max = 20 },
    RARE_PAIR = 0.3,        -- of a rare order asking for two pieces, when two still fit the band
    PAIR_CHANCE = 0.3,      -- of a common order having a second line that shares its story
    REGION_SHARE = 0.75,    -- of picks made from goods a shop in this town or a nearby one sells
    -- Weapons, armour and tools handed in must be at least this sound.
    CONDITION = 0.75,
    -- Soul requests by grade: strength range, and the highest level of a creature named for it
    -- (the creatures a player can meet on work of that grade).
    SOULS = { common = { lo = 20, hi = 120, level = 8 }, rare = { lo = 150, hi = 400, level = 22 } },
    SOUL_SHARE = 0.4,       -- of Mages Guild orders
    CREATURE_SHARE = 0.5,
    -- Pay for a soul: what the filled gem sells for in game (req.soulWorth) x SOUL_PREMIUM, held
    -- between SOUL_PAY's floor and cap for that strength (a + b x soul each), never over max.
    -- The cap grows with the soul because one grand gem holds anything from an ogrim (165) to a
    -- golden saint (400); max keeps the strongest soul at about what elite work pays. SOUL_GEMS: the vanilla records (petty to grand) and their capacity at
    -- fSoulgemMult 3, used when the records can't be read. Vanilla worth is gem value x soul;
    -- OpenMW's "rebalance soul gem values" is 0.0001 x soul^3 + 2 x soul; Economy Plus prices by
    -- its own soul bands.
    SOUL_GEMS = { { cap = 30, value = 10 }, { cap = 60, value = 20 }, { cap = 120, value = 40 },
        { cap = 180, value = 60 }, { cap = 600, value = 200 } },
    SOUL_PAY = { floor = { 40, 2.5 }, cap = { 120, 3.5 }, max = 1500 },
    SOUL_PREMIUM = { rare = 1.4, collect = 1.6 },
    -- Collectors: one uncommon piece, at most one open per town, PREMIUM.collect over its worth.
    COLLECT_CHANCE = 0.25,
    COLLECT_SOUL_MIN = 200,  -- an enchanter asks for a soul at least this strong
    -- Requisitions handed in per board in WEEK_DAYS at most; past that the board takes no more.
    WEEK_CAP = 6, WEEK_DAYS = 7,
    -- Theft ledger: record ids at most, oldest dropped past this.
    STOLEN_MAX = 300,
}

-- Lost ledgers: a townsperson's ledger left loose in the street, found from the notice's clues and
-- handed in at the board. Placed by loose.lua while the player stands at the board (the town around
-- it is loaded then); at most one per town. Cells scanned: the board's exterior cell and any
-- neighbour within MAX_DIST of the board, five getAll each, once per attempt.
C.LOST = {
    CHANCE = 0.15,          -- of a town board's refresh trying for one
    BASE = 'ojb_ledger',
    WORDS = { bench = true, crate = true, barrel = true, table = true, counter = true, shelf = true, chest = true },
    MIN_DIST = 600, MAX_DIST = 2500,   -- from the board, straight line
    LANDMARK_NEAR = 1200,   -- a public door this close to the spot is named as the last stop
    CANDIDATES = 12,
    GOLD = { 50, 90 },      -- the reward, whatever the player's level
    STOPS = 2,              -- earlier stops named before the last, at most
}

-- Spawns (spawner.lua, spawn.lua). Every actor or prop Odd Jobs creates goes on the saved list in
-- the same call that creates it, gets the tracking script (actors), and is removed when its job
-- ends. Only into the cell the player stands in, on points the player script found on the navmesh.
C.SPAWN = {
    SCRIPT = 'scripts/ojb/spawn.lua',
    MAX_ALIVE = 24,                         -- actors alive across all of Odd Jobs
    PER_JOB = { normal = 8, dangerous = 12, elite = 16, wild = 8 },
    PER_FRAME = 3,                          -- actors created per frame; the rest on the next frames
    PROPS_MAX = 40,                         -- props (carts, crates, fires) across all jobs
    -- Player script: navmesh points around each anchor, floor confirmed by a ray within FLOOR,
    -- nothing standing within CLEAR, and at least AWAY from the player.
    RADIUS = 700, FLOOR = 40, CLEAR = 80, AWAY = 450, TRIES = 10,
    -- When the wide search finds ground but not enough of it, the rest of the group stands
    -- within CLUSTER of the first spot. A few metres: 64 units is a yard.
    CLUSTER = 320, CLUSTER_CLEAR = 70,
    CORPSE_DAYS = 3,                        -- our dead are taken away this long after their job ends
    GEN = 1,                                -- bumped when spawn rules change: older spawns remove themselves
}

-- Twists (twists.lua): small story turns on jobs already taken, rolled when the contract is taken
-- and played out on the first visit. Each is its own feature switch.
C.TWIST = {
    OFFER = 0.35,           -- of bounties on a person: the leader gives up at SURRENDER_AT health
    SURRENDER_AT = 0.3,
    BRIBE_SHARE = 0.6,      -- the purse they offer, of the contract's value
    SPARE_SHARE = 0.75,     -- the poster pays this much when the leader is let go with the signet
    RETURN_CHANCE = 0.5,    -- a leader let go may come back as a dangerous job's champion
    LIED = 0.18,            -- of town recoveries: a note on the place says it is someone else's
    OWNER_SHARE = 0.5,      -- the true owner pays this much of the value
    OWNER_REP = 2,          -- faction reputation with the true owner's faction, if any
    RIVAL = 0.15,           -- of any job: another adventurer is there, dead, fighting or racing
    WORSE = 0.12,           -- of clearing jobs with 3 or more targets: something tougher killed them
    WORSE_LEVEL = 4,        -- the newcomers stand at least this many levels above the old group
    WORSE_BONUS = 0.3,      -- of the value, on top, never past the job cap
    CHAIN = 0.25,           -- of bounties: a letter on the leader names a second place
    CHAIN_STEPS = 3,        -- the first job plus at most two follow-ups
    CHAIN_KEEP_DAYS = 10,   -- a follow-up notice stays up through refreshes this long
    NOTE = 'sc_paper plain',  -- notes and letters are made from this book
    -- Who a town's people are, and the house that hears when a stolen piece comes home.
    TOWN_RACE = { pelagiad = 'imperial', ebonheart = 'imperial', old_ebonheart = 'imperial', firewatch = 'imperial' },
    TOWN_FACTION = { balmora = 'hlaalu', suran = 'hlaalu', caldera = 'hlaalu', narsis = 'hlaalu',
        ald_ruhn = 'redoran', gnisis = 'redoran', sadrith_mora = 'telvanni', vivec = 'temple', necrom = 'temple',
        almas_thirr = 'temple', pelagiad = 'imperial legion', ebonheart = 'imperial legion',
        old_ebonheart = 'imperial legion', firewatch = 'imperial legion', seyda_neen = 'imperial legion' },
}

-- Dangerous and elite contracts (danger.lua). Band levels and pay come from C.TIER.
-- HEALTH is only for open world leaders (wild.lua). Contract groups and the bands danger.lua
-- makes do not raise anyone's health. FOLLOWERS is still the champion band's head count;
-- contract groups use C.THREAT instead.
C.DANGER = {
    CHANCE = 0.35,          -- of a refresh posting a dangerous notice (at most one per board), x TIER.BAND_CHANCE
    ELITE_CHANCE = 0.15,    -- of a big city guild hall's refresh posting an elite one
    ELITE_MIN_CELLS = 4,    -- elite places are at least this far from the board
    ELITE_PER_REGION = 1,   -- elite work open in a region (bands and elite-rated place jobs, on boards or held)
    ELITE_REST_DAYS = 20,   -- after a region's elite work ends, days before that region gets more
    -- Followers by tier, leaders apart: easy has none, normal a leader, dangerous a champion, elite
    -- a champion and a lieutenant, so groups run 2-4, 4-6, 7-9 and 10-12.
    FOLLOWERS = { easy = { 2, 4 }, normal = { 3, 5 }, dangerous = { 6, 8 }, elite = { 8, 10 } },
    HEALTH = 1.5,
    TRAINING = { dangerous = 2, elite = 3 },  -- sessions in the poster's guild skills
    REP = { dangerous = 2, elite = 3 },       -- times a normal job's guild reputation
    MULTI_CHANCE = 0.3,     -- of a normal or harder recovery asking for 2 or 3 things
    PARTIAL = 2,            -- of 3: the poster pays two thirds
    RETURN_DAYS = { 10, 20 },
    RETURN_MAX = 3,         -- champions waiting to come back at once
    RETURN_TIMES = 2,       -- a champion who came back this often and was never faced retires
    TRAITS = { dangerous = 1, elite = 2 },    -- a returning champion has one more
    LIEUTENANT_LEVEL = 3,   -- an elite lieutenant is drawn this many levels under the champion
    CREATURES = { dangerous = 1, elite = 2 }, -- of the followers, creatures that fit the place
    -- One curated piece in the pay, by the poster's supply pool: what that poster would plausibly
    -- have to give. Uncommon, never artifacts or quest items; its value comes out of the gold. Every
    -- id is vanilla; one that isn't loaded is passed over.
    RARE = {
        mages = { 'Misc_SoulGem_Greater', 'Misc_SoulGem_Grand', 'BookSkill_Alchemy2', 'bookskill_enchant3',
            'bookskill_destruction2', 'BookSkill_Mysticism2' },
        fighters = { 'dwarven claymore', 'dwarven war axe', 'orcish_cuirass', 'BookSkill_Long Blade2',
            'BookSkill_Armorer3', 'repair_master_01' },
        temple = { 'p_restore_health_e', 'p_cure_blight_s', 'sc_almsiviintervention', 'bookskill_restoration2' },
        land = { 'ingred_diamond_01', 'ingred_ruby_01', 'ingred_emerald_01', 'ingred_pearl_01' },
    },
    RARE_SHARE = 0.4,       -- the piece is worth at most this share of the gold
    SEAL = { dangerous = 'Dangerous work. Not for the untested.', elite = 'Elite work. Few come back from this one.' },
}

-- Reinfested places (danger.lua): a place whose every original hostile is dead can, DAYS later,
-- get new occupants that fit it. Nothing spawns until the player walks in.
C.REINFEST = {
    DAYS = 7,
    CHANCE = 0.25,          -- of a town or guild refresh posting one, when a cleared place is due
    KEEP = 60,              -- cleared places remembered at most (oldest dropped)
    COUNT = { 4, 7 },
    -- Tier of a reinfested place, against each other before tier.lua's size and region weights.
    -- Dangerous (a coven: champion, healer, summoner) and elite (a takeover: the full elite band,
    -- big places on guild boards only) need people to lead, and no other sealed notice up. TIER.WEIGHT
    -- already makes elite rare, and only a cleared big place can come back elite.
    TIERS = { normal = 1, dangerous = 0.45, elite = 1 },
    COVEN = { 'healer', 'summoner' },
}

-- Open world jobs (wild.lua). Sites come from data/wild.lua (road points from the exterior path
-- grids, built offline). The player script finds the spot near the site when the player is within
-- NEAR of it; nothing exists out there before.
C.WILD = {
    REQUIRES = { 'tamriel_data.esm', 'tr_mainland.esm' },
    CHANCE = 0.9,           -- of a board roll posting one, when the board has none up
    SECOND = 0.2,           -- of a roll posting another beside the one up, where the mix has room
    MIN_CELLS = 1, MAX_CELLS = 5,
    -- A board with fewer than FEW free points within MAX_CELLS (road data has one point per
    -- wilderness cell with a pathgrid, sparse around Pelagiad) looks out to FAR_CELLS instead.
    FEW = 3, FAR_CELLS = 7,
    NEAR = 4500,            -- the spot is looked for when the player comes this close
    SPOT_RADIUS = 900,      -- from the road point
    MAX_SLOPE = 0.82,       -- ground normal z at least this
    BEACH_Z = { 4, 160 },   -- height above sea level for beach jobs
    LAND_Z = 40,            -- inland spots at least this far above the water
    BEAST = { normal = { scale = 1, health = 1 }, dangerous = { scale = 1.3, health = 1.5 },
        elite = { scale = 1.5, health = 2.5 } },
    TROPHY = 300,           -- value of an elite beast's skull, the player's to keep
    GUAR_HOME = 600,        -- the guar (or a found traveller) counts as home within this of the board's door
    GATHER = { 6, 12 },     -- ingredients asked for
    GATHER_NORMAL = 150,    -- a gathering job worth more than this is normal work, else easy
    -- Guar drive: GUAR head from outside town to a herder's camp at a road point at most MAX_CELLS
    -- out. The guar wait within START of the board's door; one counts as delivered within CAMP of
    -- the camp.
    DRIVE = { GUAR = { 2, 3 }, MAX_CELLS = 3, START = 2500, CAMP = 900 },
    RITUAL_DAYS = 0.25,     -- after this, the thing the cultists called arrives
}

-- Stray notices (strays.lua): one paper away from the boards, on a post, pillar or house wall seen
-- from a street.
C.STRAY = {
    CHANCE = 0.2,           -- of a town board's refresh trying for one
    PER_TOWN = 2,
    MIN_DIST = 500, MAX_DIST = 3000,
    WORDS = { 'post', 'pillar', 'column', 'signpost', 'sign_post', 'lamp', 'stall', 'fence', 'pole' },
    NOT_WORDS = { 'poster', 'lamppost_off', 'compost', 'outpost' },
    CANDIDATES = 10,        -- objects sent to the player script per try, nearest the board first
    JOB_SHARE = 0.5,        -- of strays, a job (else a flavour notice)
    LOOK = 2500,            -- the player is within this of a candidate when it's checked
    TRIES = 3,              -- checks per stray before it's dropped
    -- Player script: the open side is the longest of 8 rays OPEN long from OFF out of the object,
    -- at least OPEN_SHARE clear; the street eye stands EYE out on it, within STEP of the ground.
    OFF = 60, OPEN = 500, OPEN_SHARE = 0.6, EYE = 250, STEP = 80,
    -- Side street walls: the wall BESIDE units either side of a house's street door (never a door
    -- of a notice board's building).
    BESIDE = 110,
}

return C
