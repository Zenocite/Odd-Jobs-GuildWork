---@omw-context global
-- Odd Jobs: harder work. Each part is its own feature switch:
--   dangerous   a named champion with a mixed band (red seal), one per board
--   elite       guild boards only: champion, lieutenant, a bigger band, far off
--   reinfest    a place whose hostiles all died gets new occupants that fit it, REINFEST.DAYS later
--   multiPart   some recoveries of normal tier or harder are split over two or three containers
-- Posted at any player level, with the seal as warning; band levels and pay come from the tier
-- (tier.lua). The levelGates setting brings back the old level gates.
--   returning   a champion who outlasted the contract, or was let go, comes back stronger
-- The band is drawn when the notice goes up, so the notice can tell of it, and made on the player's
-- first visit through spawner.lua (saved list, tracking script, caps, navmesh spots).

local core = require('openmw.core')
local types = require('openmw.types')
local world = require('openmw.world')

local C = require('scripts.ojb.config')
local G = require('scripts.ojb.geom')
local F = require('scripts.ojb.foes')
local R = require('scripts.ojb.rewards')
local TI = require('scripts.ojb.tier')
local BD = require('scripts.ojb.board')
local ROSTER = require('scripts.ojb.roster')
local THREAT = require('scripts.ojb.threat')
local ST = require('scripts.ojb.story')

local DG, RF = C.DANGER, C.REINFEST
local M = {}

local function pick(list, rnd) return list[rnd(#list)] end

local function fill(s, a)
    return (s:gsub('{(%w+)}', function(k) return a[k] ~= nil and tostring(a[k]) or ('{' .. k .. '}') end))
end

-- Who moves into which kind of place. people: a group from the spawn catalog; beasts: creatures
-- that may come along. A tomb gets necromancers and never undead, which would read as the family's
-- own dead.
local THEME = {
    cave = { { people = 'bandit', beasts = 'beast' }, { people = 'smuggler' } },
    mine = { { people = 'bandit', beasts = 'beast' } },
    wreck = { { people = 'smuggler', beasts = 'fish' } },
    dwemer = { { people = 'warlock', beasts = 'dwemer' } },
    daedric = { { people = 'cultist', beasts = 'daedra' } },
    stronghold = { { people = 'bandit' }, { people = 'warlock' } },
    sewer = { { people = 'cultist' }, { people = 'bandit', beasts = 'beast' } },
}
local REINFEST = {
    tomb = { { people = 'necromancer' } },
    cave = { { people = 'smuggler' }, { people = 'bandit' }, { beasts = 'beast' } },
    mine = { { beasts = 'beast' }, { people = 'bandit' } },
    wreck = { { people = 'smuggler' }, { beasts = 'fish' } },
    dwemer = { { beasts = 'dwemer' } },
    daedric = { { people = 'cultist' }, { beasts = 'daedra' } },
    stronghold = { { people = 'bandit' } },
    sewer = { { beasts = 'beast' }, { people = 'cultist' } },
}
-- Elite places: big enough for a real fight.
local BIG = { dwemer = true, daedric = true, stronghold = true }
-- Contract groups (contractGroups) by kind of place. A tomb's are always people who broke in, with
-- at most the dead they raised (ROSTER.RAISED), never the family's own. share: of the followers,
-- creatures. A theme whose people the catalog has only well above the tier's levels is passed over.
M.CONTRACT = {
    tomb = { { people = 'graverobber' }, { people = 'necromancer', beasts = 'raised', share = 0.5 } },
    cave = THEME.cave,
    mine = { { people = 'bandit', beasts = 'beast' }, { people = 'necromancer', beasts = 'raised', share = 0.5 } },
    wreck = { { people = 'pirate', beasts = 'fish', share = 0.25 }, { people = 'smuggler' } },
    -- A cave whose own largest group lives in water (foes.watery): a sea cave.
    sea = { { people = 'pirate', beasts = 'fish', share = 0.25 }, { people = 'smuggler' }, { people = 'pirate' } },
    dwemer = { { people = 'warlock', beasts = 'dwemer' }, { beasts = 'dwemer' } },
    daedric = { { people = 'cultist', beasts = 'daedra' }, { beasts = 'daedra' } },
    stronghold = THEME.stronghold,
    sewer = THEME.sewer,
}
M.PEOPLE_OVER = 3   -- levels over the tier's band a theme's nearest people may stand

-- Lines. Rumours and what the poster heard, never how the job works.
M.LINES = {
    -- What survivors say about the band, as phrases joined into one sentence.
    role = {
        healer = { 'one in a grey robe who patches the others up', 'a healer who keeps the rest on their feet' },
        archer = { 'bowmen who hang back and shoot', 'some who keep their distance with bows' },
        summoner = { 'one who calls things up out of thin air', 'someone who can call up help' },
        guard = { 'a big one with a shield who never leaves {his} side' },
        battlemage = { 'one with a blade in one hand and fire in the other', 'a battlemage who throws lightning' },
    },
    survivors = { 'The ones who got out talk of {list}.', 'Those who came back speak of {list}.',
        'Ask anyone who got away and you will hear of {list}.' },
    hurt = { 'The last ones who went after {him} came back hurt.', 'Others have tried. They did not get far.',
        'Two hunters went after {him} last month, and only one of them came back.' },
    lieutenant = { '{Second} gives the orders when {he} is not there.',
        '{Second} is the one who speaks for {him}.' },
    back = { 'Some will remember {Leader}. {He} got away once. This time {he} has more people with {him}.',
        '{Leader} is back, and has not learned to stay quiet. There are more of them this time.' },
    reinfestPeople = { 'The place was cleared out not long ago, but someone has moved back in.',
        'That place stood empty for a while. Not any more.' },
    reinfestBeasts = { 'The place was cleared out not long ago. Something has moved back in since.',
        'That place stood empty for a while, and now something has taken it over again.' },
    multi = { 'They were packed in {n} bundles. Whoever took them may have split them up.',
        'There were {n} bundles of them, and they may not all be in the same place.' },
    partFound = 'You found a bundle of the {phrase}. {Left} more to find.',
    partShort = '{Left} bundle is still out there somewhere.',
    void = 'Whoever you were sent after has moved on. The job is off, and nobody holds it against you.',
    plainWith = 'With {him}: {list}.',
    plainSecond = '{Second} is second in command.',
    -- Elite work, from someone who is frightened of it.
    fear = { 'I sent four of my best in there. One came back, and he will not sleep with the lamp out.',
        'Whatever is in there knew we were coming. It was waiting for us.',
        'We buried two of ours last week. I do not want to bury a third.',
        'Nobody in town will say the name aloud any more. That should tell you enough.',
        'The last one who tried was better armed than most. We found his sword by the door, and nothing else.',
        'I have posted this three times. Each time someone took it, and nobody came back to be paid.' },
}
-- The tier a champion comes back at: one above the job they got away from, dangerous at least (a
-- band below dangerous has no champion). Saves from before tiers were kept come back dangerous.
function M.upFrom(tier)
    local at = 0
    for i, t in ipairs(TI.ORDER) do if t == tier then at = i end end
    local up = TI.ORDER[math.min(at + 1, #TI.ORDER)]
    if not tier or up == 'easy' or up == 'normal' then return 'dangerous' end
    return up
end

M.ROLE_NOUN = { healer = 'a healer', archer = 'an archer', summoner = 'a summoner', guard = 'a shield bearer',
    battlemage = 'a battlemage' }

-- ctx: twists' ctx (global.lua) plus usedOn(key), directionsTo(key, place), regionName(x, y),
-- boardOrigin(key), postersOf(key), trainingFor(player, faction), makeItem(base, name),
-- targetsOf(place, level).
function M.new(ctx)
    local D = {}
    local rnd = ctx.rnd

    local function S() return ctx.S() end
    local function stillOn(c) return S().contracts[c.id] == c and c.state == 'active' end

    -- Records in the load order, so nothing is created or cast that isn't there.
    local function itemExists(id)
        return id ~= nil and (types.Weapon.records[id] ~= nil or (types.Armor.records and types.Armor.records[id] ~= nil))
    end
    local function spellExists(id)
        return id ~= nil and core.magic ~= nil and core.magic.spells.records[id] ~= nil
    end
    local VALUED = { 'Weapon', 'Armor', 'Book', 'Miscellaneous', 'Potion', 'Ingredient', 'Repair', 'Clothing' }
    local function recordOf(id)
        for _, t in ipairs(VALUED) do
            local recs = types[t] and types[t].records
            local r = recs and recs[id]
            if r and r.value then return r end
        end
        return nil
    end

    -- What a role carries and casts. step: gear step 1 to 3; undead: summons undead.
    local function kit(role, step, undead)
        local k = { items = {}, equip = {}, spells = {} }
        local function give(id, n)
            if not itemExists(id) then return end
            k.items[#k.items + 1] = n and { id, n } or id
            k.equip[#k.equip + 1] = id
        end
        local function cast(id) if spellExists(id) then k.spells[#k.spells + 1] = id end end
        local gear = ROSTER.GEAR[step] or ROSTER.GEAR[1]
        local roles = ROSTER.ROLES
        if role == 'healer' then
            give(roles.healer.weapon)
            for _, s in ipairs(roles.healer.spells) do cast(s) end
        elseif role == 'archer' then
            give(pick(roles.archer.bows, rnd))
            give(roles.archer.arrows[math.min(step, #roles.archer.arrows)], roles.archer.count)
        elseif role == 'summoner' then
            cast((undead and roles.summoner.undead or roles.summoner.spells)[step])
        elseif role == 'battlemage' then
            give(pick(gear.weapon, rnd))
            for _, s in ipairs(roles.battlemage.spells) do cast(s) end
        elseif role == 'guard' or role == 'champion' or role == 'lieutenant' then
            give(pick(gear.weapon, rnd))
            for _, a in ipairs(gear.armor) do give(a) end
            if role == 'guard' then give(gear.shield) end
        end
        return k
    end

    local function people(group, level)
        return ROSTER.people(group, level, ctx.have)
    end

    -- A named leader from the group's templates near `level`. Traits that have no spell loaded are
    -- passed over.
    local function leader(group, level, traits, step, ret, chosen)
        local t
        if ret then
            t = { id = ret.template, race = ret.race, female = ret.female }
        elseif chosen then
            t = chosen
        else
            t = ROSTER.pick(people(group, level), rnd, 4)
        end
        if not t then return nil end
        local k = kit('champion', step)
        local keys, open = {}, {}
        for _, key in ipairs(ROSTER.TRAIT_KEYS) do
            local ok = false
            for _, s in ipairs(ROSTER.TRAITS[key].spells) do if spellExists(s) then ok = true end end
            if ok then open[#open + 1] = key end
        end
        for _, key in ipairs(ret and ret.traits or {}) do
            for i, o in ipairs(open) do if o == key then keys[#keys + 1] = key table.remove(open, i) break end end
        end
        while #keys < traits and #open > 0 do keys[#keys + 1] = table.remove(open, rnd(#open)) end
        for _, key in ipairs(keys) do
            for _, s in ipairs(ROSTER.TRAITS[key].spells) do if spellExists(s) then k.spells[#k.spells + 1] = s end end
        end
        return { template = t.id, name = ret and ret.name or ROSTER.name(t.race, t.female, rnd), female = t.female == true,
            race = t.race, group = group, traits = keys, kit = k, times = ret and ret.times or 0 }
    end

    -- The band for a notice. tier: 'dangerous', 'elite' or 'normal' (reinfested, no leader).
    -- Returns { tier, group, beasts, champion, lieutenant, members = { { id, role, creature, kit } } }.
    -- Levels come from the tier's fixed band (C.TIER.BANDS), never the player's: followers at a level
    -- drawn in the band, the champion at its top. opts (open world sites): roles, the members' roles
    -- in order instead of the tier's; followers, { lo, hi } instead of DANGER.FOLLOWERS. opts.contract
    -- (a place job's own group): any tier; easy has no leader, normal a leader with no traits.
    -- The same picker the place jobs use. Returning champions keep the old path so the same
    -- person comes back. A band this builds is marked contract, so it is stripped and clamped.
    local function threatBand(tier, theme)
        local state = S()
        state.seenFaces = state.seenFaces or {}
        local b = THREAT.contract({
            tier = tier, theme = theme, scale = ctx.rules and ctx.rules.groupSize, rnd = rnd,
            have = ctx.have, level = TI.levelIn(tier, rnd), recent = state.seenFaces,
            widen = theme.people == 'smuggler' or theme.people == 'pirate',
            makeLeader = function(group, lv, traits, step, chosen)
                local n = (tier == 'dangerous' or tier == 'elite') and (traits or 0) or 0
                return leader(group, lv, n, step, nil, chosen)
            end,
            kit = function(role, step, undead) return kit(role, step, undead) end,
            remember = function(ids)
                for _, id in ipairs(ids) do table.insert(state.seenFaces, 1, id:lower()) end
                while #state.seenFaces > (C.THREAT.RECENT or 12) do table.remove(state.seenFaces) end
            end,
        })
        if not b or (#b.members == 0 and not b.champion) then return nil end
        b.contract, b.state = true, 'wait'
        return b
    end

    local function band(tier, theme, ret, opts)
        if theme and theme.people and not ret then
            local built = threatBand(tier, theme)
            if built then return built end
        end
        local contract = opts and opts.contract
        local lim = TI.band(tier)
        local level = TI.levelIn(tier, rnd)
        local b = { tier = tier, group = theme.people, beasts = theme.beasts, members = {}, state = 'wait', level = level }
        local step = tier == 'elite' and (level >= 28 and 3 or 2) or tier == 'dangerous' and (level >= 18 and 2 or 1) or 1
        local times = ret and ret.times or 0
        local led = (contract and tier ~= 'easy' and theme.people ~= nil) or (not contract and tier ~= 'normal')
        local traitN = (tier == 'dangerous' or tier == 'elite') and ((DG.TRAITS[tier] or 0) + (ret and 1 or 0)) or 0
        if led then
            b.champion = leader(theme.people, lim[2], traitN, step, ret)
            if not b.champion then return nil end
            if tier == 'elite' then
                b.lieutenant = leader(theme.people, lim[2] - DG.LIEUTENANT_LEVEL, 1, math.max(1, step - 1))
            end
        end
        local range = opts and opts.followers or ((tier == 'normal' and not contract) and RF.COUNT or DG.FOLLOWERS[tier])
        local n = range[1] + rnd(range[2] - range[1] + 1) - 1 + times
        local roles = {}
        if opts and opts.roles then for i, r in ipairs(opts.roles) do roles[i] = r end
        elseif tier == 'dangerous' then roles = { 'healer', rnd(2) == 1 and 'archer' or 'summoner' }
        elseif tier == 'elite' then roles = { 'healer', 'archer', 'summoner', 'guard' }
        elseif theme.people and tier ~= 'easy' then roles = { 'archer' } end
        local beasts = 0
        if theme.beasts and theme.share and theme.people then beasts = math.floor(n * theme.share + 0.5)
        elseif theme.beasts then
            beasts = (tier == 'normal' or tier == 'easy') and (theme.people and 1 or n) or DG.CREATURES[tier]
        end
        if theme.beasts then
            -- The dead a necromancer raised answer to the strongest of them: a bonelord at the sealed tiers.
            if theme.beasts == 'raised' and (tier == 'dangerous' or tier == 'elite') and beasts > 0 then
                local lords = ROSTER.creatures('raised', 1, lim[2], ctx.have, 'bonelord')
                table.sort(lords, function(x, y) return x.level > y.level end)
                if lords[1] then
                    b.members[#b.members + 1] = { id = lords[1].id, creature = true, name = lords[1].name, master = true }
                    beasts = beasts - 1
                end
            end
            local cl = ROSTER.creatures(theme.beasts, lim[1], lim[2], ctx.have)
            for _ = 1, math.min(beasts, n) do
                local cr = ROSTER.pick(cl, rnd)
                if cr then b.members[#b.members + 1] = { id = cr.id, creature = true, name = cr.name } end
            end
        end
        if theme.people then
            local list = people(theme.people, level)
            while #b.members < n and #list > 0 do
                local t = ROSTER.pick(list, rnd, 6)
                local role = table.remove(roles, 1)
                b.members[#b.members + 1] = { id = t.id, role = role,
                    kit = role and kit(role, step, theme.people == 'necromancer') or nil }
            end
        end
        if #b.members == 0 and not b.champion then return nil end
        return b
    end
    D.band = band

    -- The band as the story builder counts foes: { group, n } entries, the biggest first.
    local function composition(b)
        local folk, beasts = (b.champion and 1 or 0) + (b.lieutenant and 1 or 0), 0
        for _, m in ipairs(b.members) do
            if m.creature then beasts = beasts + 1 else folk = folk + 1 end
        end
        local out = {}
        if b.group and folk > 0 then out[#out + 1] = { group = b.group, n = folk } end
        if b.beasts and beasts > 0 then out[#out + 1] = { group = b.beasts, n = beasts } end
        -- The raised dead are told after the people who raised them, however many they are.
        if b.beasts ~= 'raised' then table.sort(out, function(x, y) return x.n > y.n end) end
        return out
    end
    D.composition = composition

    local function size(b)
        return #b.members + (b.champion and 1 or 0) + (b.lieutenant and 1 or 0)
    end
    D.size = size

    -- A place job's own group (contractGroups): a theme for the place's kind whose people the
    -- catalog has near the tier's levels, and the band for it. Returns the band with within (how far
    -- up the tier it sits) and danger (its summed levels, for the notice's feel), or nil.
    function D.contractBand(p, tier)
        local lim = TI.band(tier)
        local options = {}
        local themes = (p.k == 'cave' and F.watery(p)) and M.CONTRACT.sea or M.CONTRACT[p.k] or {}
        for _, th in ipairs(themes) do
            local near = th.people and people(th.people, lim[2])[1]
            if not th.people or (near and near.level <= lim[2] + M.PEOPLE_OVER) then options[#options + 1] = th end
        end
        while #options > 0 do
            local th = table.remove(options, rnd(#options))
            local state = S()
            state.seenFaces = state.seenFaces or {}
            local b = THREAT.contract({
                tier = tier, theme = th, scale = ctx.rules and ctx.rules.groupSize, rnd = rnd,
                have = ctx.have, level = TI.levelIn(tier, rnd), recent = state.seenFaces,
                widen = th.people == 'smuggler' or th.people == 'pirate',
                makeLeader = function(group, lv, traits, step, chosen)
                    return leader(group, lv, traits, step, nil, chosen)
                end,
                kit = function(role, step, undead) return kit(role, step, undead) end,
                remember = function(ids)
                    for _, id in ipairs(ids) do table.insert(state.seenFaces, 1, id:lower()) end
                    while #state.seenFaces > (C.THREAT.RECENT or 12) do table.remove(state.seenFaces) end
                end,
            })
            if b and size(b) > 0 then
                b.contract = true
                b.within = TI.groupWithin(tier, size(b), b.level)
                b.danger = b.level * size(b)
                return b
            end
        end
        return nil
    end

    local function distCells(ax, ay, bx, by)
        local dx, dy = (ax - bx) / C.CELL, (ay - by) / C.CELL
        return math.sqrt(dx * dx + dy * dy)
    end

    local function tierNotices(key)
        local n = 0
        for _, x in ipairs(S().boards[key] and S().boards[key].notices or {}) do
            if x.tier or x.seal then n = n + 1 end
        end
        return n
    end

    -- Elite work open in a region: elite bands and elite-rated place jobs, on any board or held.
    -- DG.ELITE_PER_REGION caps both.
    -- When a region's elite work ends, the region rests DG.ELITE_REST_DAYS before more is posted.
    -- S.eliteOpen: notice id (a contract keeps its notice's id) -> region, from posting until
    -- D.eliteSweep finds it on no board and held by nobody; S.eliteRest: region -> day the rest
    -- ends. Elite work posted before this existed is never registered and starts no rest.
    local function isElite(x) return x.tier == 'elite' or x.diff == 'elite' end
    function D.elitePosted(n)
        if isElite(n) and n.region then
            S().eliteOpen = S().eliteOpen or {}
            S().eliteOpen[n.id] = n.region
        end
    end
    -- Run after notices come down (each board roll) and after a contract ends, so a rest starts
    -- when the work ends, or at the next roll for notices removed elsewhere.
    function D.eliteSweep()
        local open = S().eliteOpen
        if not open or next(open) == nil then return end
        local live = {}
        for id in pairs(S().contracts) do live[id] = true end
        for _, b in pairs(S().boards) do
            for _, x in ipairs(b.notices or {}) do live[x.id] = true end
        end
        local t = ctx.now()
        S().eliteRest = S().eliteRest or {}
        for id, region in pairs(open) do
            if not live[id] then
                open[id] = nil
                S().eliteRest[region] = t + DG.ELITE_REST_DAYS
            end
        end
    end
    local function eliteIn(region)
        if not region then return 0 end
        if (S().eliteRest and S().eliteRest[region] or -1e9) > ctx.now() then return DG.ELITE_PER_REGION end
        local n = 0
        for _, c in pairs(S().contracts) do if isElite(c) and c.region == region then n = n + 1 end end
        for _, b in pairs(S().boards) do
            for _, x in ipairs(b.notices or {}) do if isElite(x) and x.region == region then n = n + 1 end end
        end
        return n
    end
    D.eliteIn = eliteIn

    -- A place for a tier's band: themed, free, in reach; elite ones far off and big.
    local function placeFor(key, tier, want)
        local ox, oy = ctx.boardOrigin(key)
        if not ox then return nil end
        if want then
            local p = ctx.placeByName(want)
            if p and not ctx.inContract(p.n) and THEME[p.k] and (tier ~= 'elite'
                or (BIG[p.k] and eliteIn(ctx.regionName(p.x, p.y)) < DG.ELITE_PER_REGION)) then
                return p
            end
        end
        local cut = ctx.now() - C.REUSE_DAYS
        local out = {}
        for _, p in ipairs(ctx.places()) do
            local d = distCells(ox, oy, p.x, p.y)
            local ok = THEME[p.k] and not p.tomb and not ctx.inContract(p.n) and (S().used[p.n] or -1e9) < cut
            if ok and tier == 'elite' then
                ok = BIG[p.k] and d >= DG.ELITE_MIN_CELLS and d <= C.RADIUS_CELLS * 1.5
                    and eliteIn(ctx.regionName(p.x, p.y)) < DG.ELITE_PER_REGION
            elseif ok then
                ok = d <= C.RADIUS_CELLS
            end
            if ok then out[#out + 1] = p end
        end
        return #out > 0 and pick(out, rnd) or nil
    end

    -- Pay: the tier's value, gold its share, the rest training sessions in the guild's skill or the
    -- poster's goods, and one curated piece on top of the gold. within: how far up the tier the
    -- band sits (nil: drawn).
    local function pay(id, tier, dist01, poster, trade, player, within)
        local value = TI.value(tier, within or math.random(), dist01, nil, math.random())
        local sessions = DG.TRAINING[tier] or 1
        local skill, price
        if C.GUILDS[poster] then skill, price = ctx.trainingFor(player, poster) end
        local reward = R.split(value, tier, price and price * sessions or nil, id, R.poolFor(poster, trade))
        if reward.training then reward.sessions = sessions end
        local pool = R.poolFor(poster, trade)
        local rare = {}
        for _, rid in ipairs(DG.RARE[pool] or DG.RARE.land) do
            local r = recordOf(rid)
            if r and (r.value or 0) > 0 and r.value <= reward.gold * DG.RARE_SHARE then rare[#rare + 1] = { id = rid, value = r.value } end
        end
        if #rare > 0 then
            local r = pick(rare, rnd)
            reward.items = reward.items or {}
            reward.items[r.id] = (reward.items[r.id] or 0) + 1
            reward.rare = r.id
        end
        return reward, value, reward.training and skill or nil
    end
    D.pay = pay

    local function newId()
        local s = S()
        local id = s.nextId
        s.nextId = s.nextId + 1
        return id
    end

    -- The story builder's bounty, with the band's tells put in after the opening line. lead: a line
    -- to tell first (a reinfested place's).
    local function tierText(key, p, tier, b, poster, level, ret, lead)
        local ch = b.champion
        local region = ctx.regionName(p.x, p.y)
        -- The place's own occupants are not this job's group. A cave's skeletons are not
        -- "beasts with him".
        local targets = composition(b)
        local text, why = ST.build({
            kind = 'bounty', poster = poster, place = p, level = level, danger = 0, hostiles = 0, guardians = 0,
            targets = targets, boss = { name = ch.name, female = ch.female, group = b.group },
            town = ctx.townOf(key), region = region, where = ctx.directionsTo(key, p), freeItems = {},
            used = ctx.usedOn(key), hold = 'chest', rnd = rnd,
        })
        if not text then return nil, why end
        local a = { Leader = ch.name, Second = b.lieutenant and b.lieutenant.name }
        for k, v in pairs(ST.pronouns(ch.female)) do a[k] = v end
        -- One problem, then at most two rumours, then the ask. A lieutenant's name goes in the
        -- problem so it does not cost a rumour. A trait line is one of the rumours, and only when
        -- that trait's spell is actually on the leader.
        local problem = text.story[1]
        local ask = text.ask
        local rumours, plainBits = {}, {}
        local function add(s, plain)
            if s and s ~= '' and #rumours < 2 then
                rumours[#rumours + 1] = s
                plainBits[#plainBits + 1] = plain or s
            end
        end
        if lead then add(lead) end
        if ret then add(fill(pick(M.LINES.back, rnd), a)) end
        local told, nouns, seen = {}, {}, {}
        for _, m in ipairs(b.members) do
            if m.role and not seen[m.role] then
                seen[m.role] = true
                told[#told + 1] = fill(pick(M.LINES.role[m.role], rnd), a)
                nouns[#nouns + 1] = M.ROLE_NOUN[m.role]
            end
        end
        if #told > 0 then
            local list = #told == 1 and told[1] or (table.concat(told, ', ', 1, #told - 1) .. ' and ' .. told[#told])
            local nl = #nouns == 1 and nouns[1] or (table.concat(nouns, ', ', 1, #nouns - 1) .. ' and ' .. nouns[#nouns])
            add(fill(pick(M.LINES.survivors, rnd), { list = list }), fill(M.LINES.plainWith, { him = a.him, list = nl }))
        end
        if tier == 'elite' then add(pick(M.LINES.fear, rnd)) end
        local carried = {}
        for _, id in ipairs(ch.kit and ch.kit.spells or {}) do carried[id] = true end
        for _, t in ipairs(ch.traits or {}) do
            local tr = ROSTER.TRAITS[t]
            local applied = false
            if tr then for _, s in ipairs(tr.spells) do if carried[s] then applied = true end end end
            if applied then add(fill(tr.said, a)) break end
        end
        if text.story[2] and text.story[2] ~= ask then add(text.story[2]) end
        if b.lieutenant and not problem:find(b.lieutenant.name, 1, true) then
            local clause = fill(pick(M.LINES.lieutenant, rnd), a)
            if problem:sub(-1) == '.' then problem = problem:sub(1, -2) .. '. ' .. clause
            else problem = problem .. ' ' .. clause end
            plainBits[#plainBits + 1] = fill(M.LINES.plainSecond, a)
        end
        local story = { problem }
        for _, s in ipairs(rumours) do story[#story + 1] = s end
        if ask then story[#story + 1] = ask end
        text.story = story
        text.body = table.concat(story, ' ')
        local cut = text.ask and text.plain:find(text.ask, 1, true)
        local bit = table.concat(plainBits, ' ')
        if bit ~= '' then bit = bit .. ' ' end
        if cut then
            text.plain = text.plain:sub(1, cut - 1) .. bit .. text.plain:sub(cut)
        else
            text.plain = text.plain .. ' ' .. bit
        end
        text.plain = text.plain:gsub('%s+', ' '):gsub('^%s+', ''):gsub('%s+$', '')
        return ST.shorten(text)
    end

    -- A place job's story text with lines told just before its ask (body), and plain ones there too.
    function D.tellBeforeAsk(text, lines, plainLines)
        if #lines == 0 and #(plainLines or {}) == 0 then return text end
        local story, at = {}, nil
        for i, s in ipairs(text.story or {}) do if s == text.ask then at = i end end
        if text.story then
            at = at or #text.story + 1
            for i = 1, at - 1 do story[#story + 1] = text.story[i] end
            for _, s in ipairs(lines) do story[#story + 1] = s end
            for i = at, #text.story do story[#story + 1] = text.story[i] end
            text.story = story
            text.body = table.concat(story, ' ')
        end
        local p = table.concat(plainLines or {}, ' ')
        if p ~= '' then
            local cut = text.ask and text.plain:find(text.ask, 1, true)
            text.plain = cut and (text.plain:sub(1, cut - 1) .. p .. ' ' .. text.plain:sub(cut)) or (text.plain .. ' ' .. p)
        end
        return ST.shorten(text)
    end

    -- What a place job's sealed group adds to its notice: the band's tells as tierText tells them,
    -- and the fear in an elite one.
    function D.contractLines(b, tier)
        local lines, plain = {}, {}
        local ch = b.champion
        if (tier == 'dangerous' or tier == 'elite') and ch then
            local a = { Leader = ch.name, Second = b.lieutenant and b.lieutenant.name }
            for k, v in pairs(ST.pronouns(ch.female)) do a[k] = v end
            local told, nouns, seen = {}, {}, {}
            for _, m in ipairs(b.members) do
                if m.role and not seen[m.role] then
                    seen[m.role] = true
                    told[#told + 1] = fill(pick(M.LINES.role[m.role], rnd), a)
                    nouns[#nouns + 1] = M.ROLE_NOUN[m.role]
                end
            end
            if #told > 0 then
                local list = #told == 1 and told[1] or (table.concat(told, ', ', 1, #told - 1) .. ' and ' .. told[#told])
                lines[#lines + 1] = fill(pick(M.LINES.survivors, rnd), { list = list })
                local nl = #nouns == 1 and nouns[1] or (table.concat(nouns, ', ', 1, #nouns - 1) .. ' and ' .. nouns[#nouns])
                plain[#plain + 1] = fill(M.LINES.plainWith, { him = a.him, list = nl })
            end
            if tier == 'elite' and #lines < 2 then lines[#lines + 1] = pick(M.LINES.fear, rnd) end
            local carried = {}
            for _, id in ipairs(ch.kit and ch.kit.spells or {}) do carried[id] = true end
            for _, t in ipairs(ch.traits or {}) do
                if #lines >= 2 then break end
                local tr = ROSTER.TRAITS[t]
                local applied = false
                if tr then for _, s in ipairs(tr.spells) do if carried[s] then applied = true end end end
                if applied then
                    lines[#lines + 1] = fill(tr.said, a)
                    plain[#plain + 1] = lines[#lines]
                    break
                end
            end
            if b.lieutenant and not (lines[1] and lines[1]:find(b.lieutenant.name, 1, true)) then
                local clause = fill(pick(M.LINES.lieutenant, rnd), a)
                if not lines[1] then lines[1] = clause
                elseif lines[1]:sub(-1) == '.' then lines[1] = lines[1]:sub(1, -2) .. '. ' .. clause
                else lines[1] = lines[1] .. ' ' .. clause end
                plain[#plain + 1] = fill(M.LINES.plainSecond, a)
            end
        end
        while #lines > 2 do table.remove(lines) end
        return lines, plain
    end

    -- A sealed notice for band b's tier at place p. ret: a returning champion. re: a reinfested
    -- place, { line } told first.
    local function bandNotice(key, player, tier, p, theme, ret, re, opts)
        local level = ctx.playerLevel(player)
        local b = band(tier, theme, ret, opts)
        if not b then return nil, 'no band for ' .. tostring(theme.people) end
        -- Two people on one board share a surname only when the notice says they are family.
        local function sur(name) return name and name:match(' (%S+)$') end
        local function bare(name) return name and (name:match('^(%S+)') or name) end
        local usedSur = {}
        local function take(name)
            local s = sur(name)
            if s and usedSur[s] then return bare(name) end
            if s then usedSur[s] = true end
            return name
        end
        local board = S().boards and S().boards[key]
        for _, n in ipairs(board and board.notices or {}) do
            if n.band and n.band.champion then take(n.band.champion.name) end
            if n.band and n.band.lieutenant then take(n.band.lieutenant.name) end
            if n.from then take(n.from) end
        end
        if b.champion then b.champion.name = take(b.champion.name) end
        if b.lieutenant then b.lieutenant.name = take(b.lieutenant.name) end
        local posters = ctx.postersOf(key) or { 'town' }
        local poster = posters[rnd(#posters)]
        if tier == 'elite' then
            poster = nil
            for _, x in ipairs(posters) do if C.GUILDS[x] then poster = x end end
            if not poster then return nil, 'elite work is posted by guilds' end
        elseif ret and ret.poster then
            for _, x in ipairs(posters) do if x == ret.poster then poster = x end end
        end
        local text, why = tierText(key, p, tier, b, poster, level, ret, re and re.line)
        if not text then return nil, why end
        local id = newId()
        local ox, oy = ctx.boardOrigin(key)
        local dist01 = math.min(1, distCells(ox, oy, p.x, p.y) / C.DISTANCE_FULL_CELLS)
        local reward, value, skill = pay(id, tier, dist01, poster, text.trade, player)
        S().posted[p.n] = ctx.now()
        return {
            id = id, kind = 'bounty', poster = poster, place = p.n, pk = p.k or 'cave', level = level, value = value, reward = reward,
            skill = skill, title = text.title, body = text.body, plain = text.plain, where = text.where,
            from = text.from, trade = text.trade,
            expireDays = math.random(C.EXPIRE_DAYS[1], C.EXPIRE_DAYS[2]) + (tier == 'elite' and 4 or 2),
            tier = tier, diff = tier, seal = DG.SEAL[tier], band = b, region = ctx.regionName(p.x, p.y),
            returning = ret and true or nil, reinfest = re and true or nil,
        }
    end

    local function noticeFor(key, player, tier, ret)
        local p = placeFor(key, tier, ret and ret.place)
        if not p then return nil, 'no place for a ' .. tier .. ' band' end
        local options = THEME[p.k]
        local theme = options[rnd(#options)]
        if ret then theme = { people = ret.group or theme.people, beasts = theme.beasts } end
        return bandNotice(key, player, tier, p, theme, ret)
    end

    -- A cleared place in reach whose time has come.
    local function clearedFor(key)
        local ox, oy = ctx.boardOrigin(key)
        if not ox then return nil end
        local due = ctx.now() - RF.DAYS
        local out = {}
        for name, e in pairs(S().cleared or {}) do
            local p = ctx.placeByName(name)
            if p and e.day <= due and REINFEST[p.k] and not ctx.inContract(name)
                and ctx.now() - (e.postedAt or -1e9) >= C.REPOST_DAYS and distCells(ox, oy, p.x, p.y) <= C.RADIUS_CELLS then
                out[#out + 1] = p
            end
        end
        table.sort(out, function(x, y) return x.n < y.n end)
        return #out > 0 and pick(out, rnd) or nil
    end

    -- Who leads a sealed reinfestation: the place's reinfesting people, else the people its
    -- dangerous work has; an elite takeover brings the creatures that go with them there.
    local function ledTheme(p, tier)
        local list = {}
        for _, o in ipairs(REINFEST[p.k]) do if o.people then list[#list + 1] = o.people end end
        if #list == 0 then
            for _, o in ipairs(THEME[p.k] or {}) do if o.people then list[#list + 1] = o.people end end
        end
        if #list == 0 then return nil end
        local people = pick(list, rnd)
        local beasts
        if tier == 'elite' then
            for _, o in ipairs(THEME[p.k] or {}) do if o.people == people then beasts = o.beasts end end
        end
        return { people = people, beasts = beasts }
    end

    local function guildOf(key)
        for _, x in ipairs(ctx.postersOf(key) or {}) do if C.GUILDS[x] then return x end end
    end

    -- The tier a reinfested place comes back at (RF.TIERS, board size, region, the rules).
    local function reinfestTier(key, player, p)
        local on, size, level = ctx.featureOn, ctx.sizeOf(key), ctx.playerLevel(player)
        local region = ctx.regionName(p.x, p.y)
        local sealed = tierNotices(key) == 0 and ledTheme(p, 'dangerous') ~= nil
        local list, total = {}, 0
        for _, tier in ipairs(TI.ORDER) do
            local w = RF.TIERS[tier]
            local ok = w ~= nil
            if ok and tier ~= 'normal' then
                ok = sealed and on[tier] ~= false and TI.postsAt(tier, size) and TI.allowed(tier, level, ctx.rules)
            end
            if ok and tier == 'elite' then
                ok = BIG[p.k] and guildOf(key) ~= nil and eliteIn(region) < DG.ELITE_PER_REGION
            end
            if ok then
                w = w * TI.weight(tier, region, guildOf(key), size)
                if w > 0 then
                    list[#list + 1] = { tier, w }
                    total = total + w
                end
            end
        end
        if total <= 0 then return 'normal' end
        local r = rnd() * total
        for _, e in ipairs(list) do
            r = r - e[2]
            if r <= 0 then return e[1] end
        end
        return list[#list][1]
    end

    local function reinfestNotice(key, player)
        local p = clearedFor(key)
        if not p then return nil, 'nothing cleared and due' end
        local level = ctx.playerLevel(player)
        local tier = reinfestTier(key, player, p)
        if tier ~= 'normal' then
            local theme = ledTheme(p, tier)
            local line = pick(M.LINES.reinfestPeople, rnd)
            local n, why = bandNotice(key, player, tier, p, theme, nil, { line = line },
                tier == 'dangerous' and { roles = RF.COVEN } or nil)
            if n then
                S().cleared[p.n].postedAt = ctx.now()
                return n
            end
            ctx.log('%s: no %s reinfestation of %s (%s), a normal one instead', key, tier, p.n, tostring(why))
        end
        local theme = pick(REINFEST[p.k], rnd)
        local b = band('normal', theme)
        if not b then return nil, 'no occupants fit ' .. p.k end
        local posters = ctx.postersOf(key) or { 'town' }
        local poster = posters[rnd(#posters)]
        local text, why = ST.build({
            kind = 'nest', poster = poster, place = p, level = level, danger = 0, hostiles = #b.members, guardians = 0,
            targets = composition(b), town = ctx.townOf(key), region = ctx.regionName(p.x, p.y),
            where = ctx.directionsTo(key, p), freeItems = {}, used = ctx.usedOn(key), hold = 'chest', rnd = rnd,
        })
        if not text then return nil, why end
        local line = pick(theme.people and M.LINES.reinfestPeople or M.LINES.reinfestBeasts, rnd)
        local story, at = {}, #text.story
        for i, s in ipairs(text.story) do if s == text.ask then at = i end end
        for i, s in ipairs(text.story) do
            if i == at then story[#story + 1] = line end
            story[#story + 1] = s
        end
        text.body = table.concat(story, ' ')
        local cut = text.ask and text.plain:find(text.ask, 1, true)
        text.plain = cut and (text.plain:sub(1, cut - 1) .. line .. ' ' .. text.plain:sub(cut)) or (text.plain .. ' ' .. line)
        ST.shorten(text)
        local id = newId()
        local value = TI.value('normal', math.random(), nil, nil, math.random())
        local skill, price
        if C.GUILDS[poster] then skill, price = ctx.trainingFor(player, poster) end
        local reward = R.split(value, 'normal', price, id, R.poolFor(poster, text.trade))
        S().cleared[p.n].postedAt = ctx.now()
        return {
            id = id, kind = 'nest', poster = poster, place = p.n, pk = p.k or 'cave', level = level, value = value, reward = reward, diff = 'normal',
            skill = reward.training and skill or nil, title = text.title, body = text.body, plain = text.plain,
            where = text.where, from = text.from, trade = text.trade,
            expireDays = math.random(C.EXPIRE_DAYS[1], C.EXPIRE_DAYS[2]), band = b, reinfest = true,
        }
    end

    -- A returning champion due on this board.
    local function dueReturn(key)
        local list = S().returning or {}
        for i, r in ipairs(list) do
            if r.board == key and r.day <= ctx.now() then return r, i end
        end
        return nil
    end

    -- At a board roll: at most one dangerous or elite notice and one reinfested place, each taking
    -- one of room (board.lua room: paid jobs the board may still put up).
    function D.post(key, player, notices, room)
        local on, level = ctx.featureOn, ctx.playerLevel(player)
        local size = ctx.sizeOf(key)
        room = room or 1
        if room > 0 and tierNotices(key) == 0 then
            local n, why
            local ret, ri = nil, nil
            local rules = ctx.rules
            if on.returning and on.dangerous and TI.allowed('dangerous', level, rules) then ret, ri = dueReturn(key) end
            if ret then
                local up = M.upFrom(ret.tier)
                if up == 'elite' and not (on.elite and TI.postsAt('elite', size) and TI.allowed('elite', level, rules)) then
                    up = 'dangerous'
                end
                n, why = noticeFor(key, player, up, ret)
                if not n and up == 'elite' then n, why = noticeFor(key, player, 'dangerous', ret) end
                if n then table.remove(S().returning, ri) end
            elseif on.elite and TI.postsAt('elite', size) and TI.allowed('elite', level, rules)
                and rnd() < BD.perRoll(DG.ELITE_CHANCE) then
                n, why = noticeFor(key, player, 'elite')
            elseif on.dangerous and TI.allowed('dangerous', level, rules)
                and rnd() < BD.perRoll(math.min(1, DG.CHANCE * (C.TIER.BAND_CHANCE[size] or 1))) then
                n, why = noticeFor(key, player, 'dangerous')
            end
            if n then
                notices[#notices + 1] = n
                D.elitePosted(n)
                room = room - 1
                ctx.say('%s: %s notice for %s at %s (%d followers%s)', key, n.tier, n.band.champion.name, n.place,
                    #n.band.members, n.returning and ', back again' or '')
            elseif why then
                ctx.log('%s: no dangerous notice (%s)', key, why)
            end
        end
        if on.reinfest and room > 0 and rnd() < BD.perRoll(RF.CHANCE) then
            local n, why = reinfestNotice(key, player)
            if n then
                notices[#notices + 1] = n
                D.elitePosted(n)
                ctx.say('%s: %s has new occupants (%s, %d%s)', key, n.place, n.diff, #n.band.members,
                    n.band.champion and (', led by ' .. n.band.champion.name) or '')
            else
                ctx.log('%s: no reinfested place (%s)', key, why)
            end
        end
    end

    -- Taking a notice with a band: the band waits for the first visit. Returns true when handled.
    -- A recovery keeps its own item; only a bounty's champion carries a signet.
    function D.take(c, n)
        if not n.band then return false end
        c.band, c.tier, c.seal, c.region, c.reinfest = n.band, n.tier or n.diff or 'normal', n.seal, n.region, n.reinfest
        c.band.state, c.band.asks = 'wait', 0
        c.targets = {}
        if n.band.champion and n.kind == 'bounty' then
            local name = n.band.champion.name
            c.itemName, c.itemPhrase = name .. "'s Signet", name .. "'s signet"
            c.item = ctx.makeItem(C.SIGNET_BASE, c.itemName)
        end
        if n.reinfest and S().cleared then S().cleared[n.place] = nil end
        return true
    end

    local function fail(c, player, why)
        c.band.state = 'gone'
        ctx.tell(player, M.LINES.void)
        ctx.dropContract(c, why)
        player:sendEvent('OJB_Contracts', { held = ctx.heldCount() })
    end

    -- Where the band waits: containers, lights and actors of the cell (one getAll each, once per
    -- search), away from the place's own living hostiles (geom.awayFrom), deep from the way in.
    local function anchors(player)
        local cell = player.cell
        local pts, foes = {}, {}
        for _, t in ipairs({ types.NPC, types.Creature }) do
            for _, o in ipairs(cell:getAll(t)) do
                if o.type ~= types.Player then
                    local p = o.position
                    if ctx.isHostileAlive(o) then foes[#foes + 1] = { x = p.x, y = p.y, z = p.z }
                    else pts[#pts + 1] = { x = p.x, y = p.y, z = p.z } end
                end
            end
        end
        for _, t in ipairs({ types.Container, types.Light }) do
            for _, o in ipairs(cell:getAll(t)) do
                local p = o.position
                pts[#pts + 1] = { x = p.x, y = p.y, z = p.z }
            end
        end
        local at = player.position
        local out = G.awayFrom(pts, foes, { x = at.x, y = at.y, z = at.z }, C.CONTRACT.AWAY, 4)
        if #out == 0 then out[1] = { x = at.x, y = at.y, z = at.z } end
        return out
    end

    local function spec(c, id, at, role, k, extra)
        local s = { id = id, cell = c.place, pos = at, yaw = at.yaw, role = role,
            items = {}, act = { fight = 100 } }
        for _, it in ipairs(k and k.items or {}) do s.items[#s.items + 1] = it end
        for _, it in ipairs(extra or {}) do s.items[#s.items + 1] = it end
        if k and #k.spells > 0 then s.act.spells = k.spells end
        if k and #k.equip > 0 then s.act.equip = k.equip end
        if c.band and c.band.contract then s.strip = true end
        return s
    end

    local function makeBand(c, player, e)
        local b = c.band
        local spots = e.spots or {}
        if #spots == 0 then
            if e.retry then b.state = 'wait' else fail(c, player, 'no room for the band') end
            return
        end
        local i = 1
        -- carries: the champion, else the first of the band, has the job's item (a bounty's signet, or
        -- a recovery's when the place had nowhere to put it).
        local carries = c.kind == 'bounty' or c.bandCarries
        if b.champion then
            local ch = b.champion
            local head = b.contract and THREAT.otherHead(ch.template) or nil
            local id = ctx.SP.record(ch.template, ch.name, types.NPC, head)
            local s = id and spec(c, id, spots[1], 'champion', ch.kit, carries and { c.item } or nil)
            if ch.skillName then s.act.skill, s.act.skillAt = ch.skillName, ch.skillAt end
            local obj = s and ctx.SP.actor(c.id, c.tier, s)
            if not obj then fail(c, player, 'the champion could not be made') return end
            c.leader, c.targets = obj, { obj }
            if carries then c.holder = obj end
            carries = false
            i = 2
            if b.lieutenant and spots[i] then
                local lt = b.lieutenant
                local lid = ctx.SP.record(lt.template, lt.name, types.NPC)
                local ls = lid and spec(c, lid, spots[i], 'lieutenant', lt.kit)
                if ls and lt.skillName then ls.act.skill, ls.act.skillAt = lt.skillName, lt.skillAt end
                c.lieutenant = ls and ctx.SP.actor(c.id, c.tier, ls) or nil
                i = i + 1
            end
        end
        local specs = {}
        for _, m in ipairs(b.members) do
            local at = spots[i]
            if not at then break end
            local give = carries and not m.creature
            specs[#specs + 1] = spec(c, m.id, at, m.role or (m.creature and 'beast' or 'follower'), m.kit,
                give and { c.item } or nil)
            if m.skillName then specs[#specs].act.skill, specs[#specs].act.skillAt = m.skillName, m.skillAt end
            if give then specs[#specs].carries, carries = true, false end
            i = i + 1
        end
        local planned = #b.members + (b.champion and 1 or 0) + (b.lieutenant and 1 or 0)
        b.state, b.made = 'made', #specs + (b.champion and 1 or 0) + (c.lieutenant and 1 or 0)
        local nest = c.kind == 'nest'
        ctx.SP.queue(c.id, c.tier, specs, function(obj, s)
            if nest then c.targets[#c.targets + 1] = obj end
            if s.carries then c.holder = obj end
        end)
        if b.made < planned then
            c.short = true
            ctx.log('contract %d: planned %d, placed %d; the rest had no ground (%s)', c.id, planned, b.made,
                e.tried or 'no reason given')
        end
        ctx.say('contract %d: %s band made: %s%d of %d placed', c.id, c.tier,
            b.champion and (b.champion.name .. ', ') or '', b.made, planned)
    end

    local ASKS = 6
    local function visit(c, player)
        local b = c.band
        if b.state == 'asked' and not ctx.SP.waiting('band:' .. c.id) then b.state = 'wait' end
        if b.state ~= 'wait' then return end
        if (b.asks or 0) >= ASKS then fail(c, player, 'no spots for the band') return end
        local want = #b.members + (b.champion and 1 or 0) + (b.lieutenant and 1 or 0)
        want = math.min(want, ctx.SP.room(c.id, c.tier))
        if want <= 0 then return end
        b.state, b.asks = 'asked', (b.asks or 0) + 1
        ctx.SP.ask(player, 'band:' .. c.id, { cell = c.place, n = want, anchors = anchors(player), radius = 700,
            away = 600 }, function(e)
            if stillOn(c) then makeBand(c, player, e) end
        end)
    end

    -- From global.lua's contract check: false while a band contract has nobody to fight yet.
    function D.step(c, player, here)
        local b = c.band
        if not b or b.state == 'made' then return true end
        if here then visit(c, player) end
        return stillOn(c) and b.state == 'made'
    end

    -- Completion waits for the rest of the band to arrive, and on elite work for the lieutenant.
    function D.holds(c)
        local b = c.band
        if not b then return false end
        if b.state ~= 'made' then return true end
        if c.kind == 'nest' and ctx.SP.queued() > 0 then return true end
        local lt = c.lieutenant
        return lt ~= nil and lt:isValid() and lt.enabled and lt.count > 0 and not types.Actor.isDead(lt)
    end

    ---------------------------------------------------------------------------------------------
    -- Multi-part recoveries

    -- A recovery notice of a plural item, a normal job or harder: two or three bundles.
    function D.multi(n, text, diff)
        if not ctx.featureOn.multiPart or n.kind ~= 'recovery' or diff == 'easy' then return end
        if not (text.item and text.item.plural) or rnd() >= DG.MULTI_CHANCE then return end
        n.parts = 2 + rnd(2) - 1
        n.hold = nil
        local line = fill(pick(M.LINES.multi, rnd), { n = ST.number(n.parts) })
        n.body = n.body .. ' ' .. line
        n.plain = n.plain .. ' ' .. line
        ST.shorten(n)
    end

    -- After the first bundle went into the holder: the rest into other containers, farthest first.
    function D.spread(c, n, info)
        if not n.parts or not c.holder or c.holder.type ~= types.Container then return end
        local others = {}
        for _, h in ipairs(info.containers or {}) do
            if h ~= c.holder then others[#others + 1] = { obj = h, d = (h.position - c.holder.position):length() } end
        end
        table.sort(others, function(x, y) return x.d > y.d end)
        local holders = {}
        for i = 1, math.min(n.parts - 1, #others) do
            local h = others[i].obj
            world.createObject(c.item):moveInto(types.Container.content(h))
            holders[#holders + 1] = h
        end
        if #holders == 0 then return end
        local total = #holders + 1
        c.parts = { total = total, need = total >= 3 and DG.PARTIAL or total, seen = 0, holders = holders }
        ctx.log('contract %d: %d bundles, in %s and %d more containers', c.id, total, c.holder.recordId, #holders)
    end

    function D.need(c) return c.parts and c.parts.need or 1 end

    -- Each bundle found is told; the last one short of all of them too.
    function D.partsStep(c, player, inv)
        local p = c.parts
        if not p then return end
        local got = inv:countOf(c.item)
        if got <= p.seen then return end
        p.seen = got
        if got < p.need then
            ctx.tell(player, fill(M.LINES.partFound, { phrase = c.itemPhrase or 'goods',
                Left = (ST.number(p.need - got):gsub('^%l', string.upper)) }))
        elseif got < p.total then
            ctx.tell(player, fill(M.LINES.partShort, { Left = (ST.number(p.total - got):gsub('^%l', string.upper)) }))
        end
    end

    -- Hand-in: every bundle carried goes; the share of the pay is what was brought.
    function D.handInItems(c, inv, it)
        if not c.parts then
            it:remove(1)
            return 1
        end
        local got = math.min(inv:countOf(c.item), c.parts.total)
        local left = got
        while left > 0 do
            local x = inv:find(c.item)
            if not x then break end
            local k = math.min(left, x.count)
            x:remove(k)
            left = left - k
        end
        return got / c.parts.total
    end

    ---------------------------------------------------------------------------------------------
    -- Training sessions, reputation, champions who come back, places cleared

    -- Sessions as given, never past the training cap.
    function D.sessions(reward, player, skill)
        local n = reward.sessions or 1
        local stat = types.NPC.stats.skills[skill]
        if not stat then return 1 end
        return math.max(1, math.min(n, C.TRAINING_SKILL_CAP - stat(player).base))
    end

    function D.repFactor(c) return DG.REP[c.tier or ''] or 1 end

    local function remember(c, how)
        local ch = c.band and c.band.champion
        if not ch or not ctx.featureOn.returning then return end
        local times = (ch.times or 0) + 1
        if times > DG.RETURN_TIMES then
            ctx.log('contract %d: %s has gone for good', c.id, ch.name)
            return
        end
        local s = S()
        s.returning = s.returning or {}
        if #s.returning >= DG.RETURN_MAX then return end
        s.returning[#s.returning + 1] = { name = ch.name, template = ch.template, female = ch.female, race = ch.race,
            group = ch.group, traits = ch.traits, board = c.board, poster = c.poster, place = c.place, how = how,
            times = times, tier = c.tier,
            day = ctx.now() + DG.RETURN_DAYS[1] + rnd(DG.RETURN_DAYS[2] - DG.RETURN_DAYS[1] + 1) - 1 }
        ctx.log('contract %d: %s may come back (%s, time %d)', c.id, ch.name, how, times)
    end

    -- A contract ending without a hand-in: an unfaced or living champion may return; spare bundles go.
    function D.dropped(c, why)
        if c.band and c.band.champion and (why == 'expired' or why == 'abandoned') then
            local alive = c.band.state ~= 'made'
                or (c.leader and c.leader:isValid() and c.leader.count > 0 and not types.Actor.isDead(c.leader))
            if alive then remember(c, why) end
        end
        for _, h in ipairs(c.parts and c.parts.holders or {}) do
            if h:isValid() then
                local x = types.Container.content(h):find(c.item)
                if x then x:remove() end
            end
        end
    end

    -- A job done with the player in the place and nothing hostile left: the place is cleared.
    function D.completed(c, player)
        if not ctx.featureOn.reinfest then return end
        if not player.cell or player.cell.name ~= c.place then return end
        for _, t in ipairs({ types.NPC, types.Creature }) do
            for _, a in ipairs(player.cell:getAll(t)) do
                if a.type ~= types.Player and ctx.isHostileAlive(a) then return end
            end
        end
        local s = S()
        s.cleared = s.cleared or {}
        s.cleared[c.place] = { day = ctx.now() }
        local names = {}
        for name, e in pairs(s.cleared) do names[#names + 1] = { name, e.day } end
        if #names > RF.KEEP then
            table.sort(names, function(x, y) return x[2] < y[2] end)
            for i = 1, #names - RF.KEEP do s.cleared[names[i][1]] = nil end
        end
        ctx.log('contract %d: %s is cleared', c.id, c.place)
    end

    return D
end

return M
