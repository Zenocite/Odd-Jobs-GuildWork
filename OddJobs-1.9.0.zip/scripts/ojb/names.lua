---@omw-context runtime
-- Pure: item names as they read in a sentence. A record name ("Silver Javelin", "Bread",
-- "Chitin Greaves", "Cheap Restore Health") becomes "a silver javelin", "ten loaves of bread",
-- "two pairs of chitin greaves", "five cheap restore health potions". No engine calls; any name
-- a mod adds goes through the same rules, and EXACT holds the names the rules get wrong.

local M = {}

local NUMBER = { 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve',
    'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty' }
local TENS = { [20] = 'twenty', [30] = 'thirty', [40] = 'forty', [50] = 'fifty', [60] = 'sixty' }

function M.number(n)
    if NUMBER[n] then return NUMBER[n] end
    local t = math.floor(n / 10) * 10
    if TENS[t] then return n == t and TENS[t] or (TENS[t] .. '-' .. NUMBER[n - t]) end
    return tostring(n)
end

-- Words that stay capitalised in prose: peoples, places, gods, and the spell names on scrolls.
local PROPER = {}
for w in ([[Dwarven Dwemer Imperial Nordic Orcish Colovian Cyrodilic Redoran Hlaalu Telvanni Indoril Dres Ashlander
    Akaviri Breton Daedra Daedric Almsivi Mara Kynareth Stendarr Arkay Dibella Julianos Zenithar Akatosh Vivec Sotha
    Thirrine Surilie Skyrim Morrowind Cyrodiil Velothi Argonian Khajiit Bosmer Altmer Dunmer]]):gmatch('%S+') do
    PROPER[w] = true
end

-- Whole names the rules would get wrong: { singular, plural } as they read in a sentence.
local EXACT = {
    ["apprentice's armorer's hammer"] = { "apprentice's hammer", "apprentice's hammers" },
    ["journeyman's armorer's hammer"] = { "journeyman's hammer", "journeyman's hammers" },
    ["master's armorer's hammer"] = { "master's hammer", "master's hammers" },
    ['repair prongs'] = { 'set of repair prongs', 'sets of repair prongs' },
    ['metal tongs'] = { 'pair of metal tongs', 'pairs of metal tongs' },
    ['scales'] = { 'handful of scales', 'handfuls of scales' },
    ['olives'] = { 'jar of olives', 'jars of olives' },
}

-- Last words that name a stuff, not a thing: counted in units. { singular unit, plural unit }.
local UNITS = {
    bread = { 'loaf', 'loaves' }, jerky = { 'piece', 'pieces' }, meat = { 'piece', 'pieces' },
    mutton = { 'cut', 'cuts' }, cuttle = { 'piece', 'pieces' }, jelly = { 'jar', 'jars' }, honey = { 'jar', 'jars' },
    cheese = { 'round', 'rounds' }, flour = { 'sack', 'sacks' }, salt = { 'bag', 'bags' },
    saltrice = { 'measure', 'measures' }, wickwheat = { 'bundle', 'bundles' }, rye = { 'bundle', 'bundles' },
    marshmerrow = { 'stalk', 'stalks' }, heather = { 'sprig', 'sprigs' }, nightshade = { 'sprig', 'sprigs' },
    kanet = { 'sprig', 'sprigs' }, chokeweed = { 'bunch', 'bunches' }, scathecraw = { 'bunch', 'bunches' },
    roobrush = { 'bunch', 'bunches' }, sweetpulp = { 'piece', 'pieces' }, facia = { 'piece', 'pieces' },
    muck = { 'lump', 'lumps' }, resin = { 'lump', 'lumps' }, wax = { 'lump', 'lumps' }, fat = { 'lump', 'lumps' },
    sulphur = { 'lump', 'lumps' }, sulfur = { 'lump', 'lumps' }, coal = { 'lump', 'lumps' }, ore = { 'lump', 'lumps' },
    tin = { 'lump', 'lumps' }, glass = { 'piece', 'pieces' }, metal = { 'piece', 'pieces' },
    bonemeal = { 'measure', 'measures' }, ectoplasm = { 'measure', 'measures' }, salts = { 'measure', 'measures' },
    gravedust = { 'pinch', 'pinches' }, dust = { 'pinch', 'pinches' }, powder = { 'pinch', 'pinches' },
    pollen = { 'pinch', 'pinches' }, lichen = { 'clump', 'clumps' }, moss = { 'clump', 'clumps' },
    fiber = { 'bundle', 'bundles' }, leather = { 'piece', 'pieces' }, silk = { 'length', 'lengths' },
    ivory = { 'piece', 'pieces' }, hair = { 'lock', 'locks' }, dye = { 'jar', 'jars' }, oil = { 'flask', 'flasks' },
    milk = { 'bottle', 'bottles' }, wine = { 'bottle', 'bottles' }, ale = { 'bottle', 'bottles' },
    brandy = { 'bottle', 'bottles' }, slaughterfish = { 'piece', 'pieces' }, armor = { 'piece', 'pieces' },
    armour = { 'piece', 'pieces' }, mail = { 'piece', 'pieces' }, ringmail = { 'piece', 'pieces' },
    amber = { 'piece', 'pieces' }, jade = { 'piece', 'pieces' }, turquoise = { 'piece', 'pieces' },
    lazuli = { 'piece', 'pieces' }, coral = { 'piece', 'pieces' }, onyx = { 'piece', 'pieces' },
    malachite = { 'piece', 'pieces' }, pulp = { 'piece', 'pieces' }, musk = { 'vial', 'vials' },
    -- Already plural: a bunch or handful of them.
    parts = { 'set', 'sets' }, schematics = { 'set', 'sets' },
    petals = { 'bunch', 'bunches' }, flowers = { 'bunch', 'bunches' }, fronds = { 'bunch', 'bunches' },
    stalks = { 'bunch', 'bunches' }, seeds = { 'handful', 'handfuls' }, spines = { 'handful', 'handfuls' },
    berries = { 'handful', 'handfuls' }, weepings = { 'vial', 'vials' }, plumes = { 'bunch', 'bunches' },
}
-- Last words that are already plural: counted in pairs or sets.
local PAIRS = { greaves = { 'pair', 'pairs' }, boots = { 'pair', 'pairs' }, shoes = { 'pair', 'pairs' },
    pants = { 'pair', 'pairs' }, gloves = { 'pair', 'pairs' }, gauntlets = { 'pair', 'pairs' },
    tongs = { 'pair', 'pairs' }, prongs = { 'set', 'sets' } }
-- Irregular plurals of a last word.
local IRREGULAR = { leaf = 'leaves', knife = 'knives', shelf = 'shelves', loaf = 'loaves', wolf = 'wolves', staff = 'staffs',
    tooth = 'teeth', foot = 'feet', man = 'men', mouse = 'mice', fish = 'fish', sheep = 'sheep', potato = 'potatoes',
    tomato = 'tomatoes', cactus = 'cacti', fungus = 'fungi', thief = 'thieves', half = 'halves', hoof = 'hooves' }
-- Single-word drinks are their own names: a bottle of Sujamma, of Greef, of Mazte.
local DRINK_KIND = { wine = true, ale = true, brandy = true, whiskey = true, beer = true, mead = true, liquor = true }
local PLAIN_DRINK = { sweet = true, sour = true, red = true, white = true, cheap = true, fine = true, dark = true,
    guar = true, rice = true, honey = true }
local POTION_QUALITY = { bargain = true, cheap = true, standard = true, quality = true, exclusive = true }

local function plural(word)
    local low = word:lower()
    if IRREGULAR[low] then return IRREGULAR[low] end
    if low:find('[sxz]$') or low:find('[cs]h$') then return word .. 'es' end
    if low:find('[^aeiou]y$') then return word:sub(1, -2) .. 'ies' end
    return word .. 's'
end

-- Lower case where it reads naturally: every word but the PROPER ones; a hyphenated word by its
-- first part ("Hackle-Lo" -> "hackle-lo").
function M.lower(name)
    local out = {}
    for w in name:gmatch('%S+') do
        if PROPER[w] then out[#out + 1] = w else out[#out + 1] = w:lower() end
    end
    return table.concat(out, ' ')
end

local function article(s)
    return (s:find("^[aeiouAEIOU]") and not s:find('^[Uu]ni') and not s:find('^[Oo]ne')) and 'an' or 'a'
end

-- The forms of a name: { one = 'silver javelin', many = 'silver javelins', unit = nil }, or for a
-- stuff { one = 'loaf of bread', many = 'loaves of bread' }. drink: name is a drink (bottles of it).
function M.forms(name, drink)
    name = (name or ''):gsub('%s+', ' '):gsub('^ ', ''):gsub(' $', '')
    local low = name:lower()
    local exact = EXACT[low]
    if exact then return { one = exact[1], many = exact[2] } end
    -- Potions: "Cheap Restore Health", "Standard Restore Health Potion", "Potion of Cure Poison".
    local effect = low:match('^potion of (.+)$')
    local quality
    if not effect then
        local q, rest = low:match('^(%a+) (.+)$')
        if q and POTION_QUALITY[q] then quality, effect = q, rest:gsub(' potion$', '') end
    end
    if effect and not drink then
        local pre = quality and (quality .. ' ') or ''
        return { one = pre .. effect .. ' potion', many = pre .. effect .. ' potions' }
    end
    -- "Scroll of Divine Intervention": the head word counts, the title keeps its capitals.
    local head, tail = name:match('^(%a+) of (.+)$')
    if head then
        return { one = head:lower() .. ' of ' .. tail, many = plural(head:lower()) .. ' of ' .. tail }
    end
    if drink then
        -- "Free Estates Wine" names a place: its words keep their capitals, the kind of drink
        -- doesn't. "Sweet Wine" and "Guar Milk" are plain words throughout.
        local shown = name
        local kind = low:match(' (%a+)$')
        if kind then
            local first = low:match('^(%a+)')
            if PLAIN_DRINK[first] then
                shown = M.lower(name)
            elseif DRINK_KIND[kind] then
                shown = name:sub(1, #name - #kind) .. kind
            end
        end
        return { one = 'bottle of ' .. shown, many = 'bottles of ' .. shown }
    end
    local shown = M.lower(name)
    local last = (shown:match('(%S+)$') or ''):lower()
    local lastPart = last:match('%-(%a+)$') or last
    local u = UNITS[lastPart] or PAIRS[lastPart]
    if u then return { one = u[1] .. ' of ' .. shown, many = u[2] .. ' of ' .. shown } end
    local stem = shown:sub(1, #shown - #last)
    return { one = shown, many = stem .. plural(last) }
end

-- "an iron dagger", "a loaf of bread".
function M.a(name, drink)
    local one = M.forms(name, drink).one
    return article(one) .. ' ' .. one
end

-- "silver javelins", "loaves of bread": the plural without a number.
function M.plural(name, drink)
    return M.forms(name, drink).many
end

-- "three silver javelins", "one loaf of bread", "twenty-five iron arrows". article: "a"/"an"
-- in place of "one".
function M.count(name, n, drink, useArticle)
    local f = M.forms(name, drink)
    if n == 1 then return (useArticle and article(f.one) or 'one') .. ' ' .. f.one end
    return M.number(n) .. ' ' .. f.many
end

-- "a", "a and b", "a, b and c".
function M.list(parts)
    if #parts <= 1 then return parts[1] or '' end
    return table.concat(parts, ', ', 1, #parts - 1) .. ' and ' .. parts[#parts]
end

-- A short name for a table row or title: "Iron arrows", "Loaves of bread".
function M.label(name, drink)
    local many = M.forms(name, drink).many
    return (many:gsub('^%l', string.upper))
end

return M
