---@omw-context player
-- Flat, visible patches on walls for small things pinned up (notices now; stray notices on posts,
-- stalls and lamp posts later). Callers pass the rays: ctx = { ray(a, b), seen(a, b), nameOf(obj),
-- isWindow(obj), isActor(obj), isDoor(obj) }, so pacing and counting stay with them.
--
-- Two engine facts shape the checks. A building's collision shell often stands a few units in
-- front of its drawn stone (ex_common_building_03: about 10), so a paper rests on the drawn
-- surface and the clear-in-front ray starts outside the shell, not on the paper. And a lamp or
-- sign on the wall has collision of its own: a sample that lands on another object standing
-- proud of the wall blocks that one paper, not the whole stretch of wall.

local util = require('openmw.util')

local C = require('scripts.ojb.config')
local G = require('scripts.ojb.geom')

local v3 = util.vector3
local UP = v3(0, 0, 1)
local W = C.WALL

local M = {}

-- The wall along `dir` (level, unit) from `from`, within `reach`. Returns { hit, n (level, unit,
-- facing back along dir), obj } or nil, why.
function M.wallAt(ctx, from, dir, reach)
    local r = ctx.ray(from, from + dir * reach)
    if not r.hit then return nil, 'no wall within reach' end
    local o = r.hitObject
    if not o then return nil, 'ground or rock, not a wall' end
    if ctx.isDoor(o) then return nil, 'the door itself' end
    if ctx.isWindow(o) then return nil, 'a window: ' .. ctx.nameOf(o) end
    if ctx.isActor(o) then return nil, 'someone standing there' end
    local nrm = r.hitNormal
    if math.abs(nrm.z) > W.MAX_NORMAL_Z then
        return nil, string.format('surface not upright (leans %.0f deg): %s', math.deg(math.asin(math.abs(nrm.z))),
            ctx.nameOf(o))
    end
    return { hit = r.hitPos, n = v3(nrm.x, nrm.y, 0):normalize(), obj = o }
end

-- One paper's patch round `c` (a point on the wall), rays along -n. `wall` is the object the
-- patch must be on. Returns { pos, n (level), n3 (the surface's own, leaning), lean, on } or nil,
-- why. Recesses (mortar, gaps between stones) up to RECESS_SAMPLES of the nine are fine: the
-- paper lies on the front face. Anything standing proud of the face is not.
function M.patch(ctx, c, n, right, wall)
    local samples = G.paperSamples()
    local hits, normals, gap = {}, v3(0, 0, 0), 0
    for i, s in ipairs(samples) do
        local a = c + right * s[1] + UP * s[2] + n * 30
        local b = a - n * 60
        local pr = ctx.ray(a, b)
        if not pr.hit then return nil, 'edge' end
        local o = pr.hitObject
        if not o then return nil, 'ground' end
        if ctx.isDoor(o) then return nil, 'door' end
        if ctx.isActor(o) then return nil, 'someone' end
        if ctx.isWindow(o) then return nil, 'window' end
        local dev = (pr.hitPos - a):length() - 30
        -- Another object standing proud of the wall plane (a lamp, a sign's post); a neighbouring
        -- piece of wall flush with it is fine.
        if wall and o.id ~= wall.id and dev < -W.PAPER_FLAT then return nil, 'in front: ' .. ctx.nameOf(o) end
        local vr = ctx.seen(a, b)
        if not vr.hit then return nil, 'not drawn' end
        local vo = vr.hitObject
        if ctx.isActor(vo) then return nil, 'someone' end
        if ctx.isWindow(vo) then return nil, 'window' end
        local vdev = (vr.hitPos - a):length() - 30
        if not vo or vo.id ~= o.id then
            if vdev >= dev - W.POSTER_GAP then return nil, 'poster ' .. ctx.nameOf(vo) end
            return nil, 'something hangs in front: ' .. ctx.nameOf(vo)
        end
        if vdev - dev > gap then gap = vdev - dev end
        hits[i] = vr.hitPos
        normals = normals + pr.hitNormal
    end
    if normals:length() < 0.1 then return nil, 'uneven' end
    local n3 = normals:normalize()
    if math.abs(n3.z) > W.MAX_NORMAL_Z then return nil, 'not upright' end
    local pn = v3(n3.x, n3.y, 0):normalize()
    if pn:dot(n) < W.CURVE_DOT then return nil, 'curves away' end
    -- Depth of each drawn hit along the surface's facing, + toward the street. The face is the
    -- median; a sample PAPER_FLAT proud of it is a bump, one PAPER_FLAT behind it a recess.
    local ds, sorted = {}, {}
    for i, h in ipairs(hits) do
        ds[i] = (h - hits[1]):dot(n3)
        sorted[i] = ds[i]
    end
    table.sort(sorted)
    local face = sorted[math.ceil(#sorted / 2)]
    local front, recesses = -math.huge, 0
    for _, d in ipairs(ds) do
        if d > face + W.PAPER_FLAT then return nil, string.format('bump %.0f', d - face) end
        if d < face - W.PAPER_FLAT then
            recesses = recesses + 1
        elseif d > front then
            front = d
        end
    end
    if recesses > W.RECESS_SAMPLES then return nil, string.format('uneven (%d recesses)', recesses) end
    local pos = hits[1] + n3 * (front - ds[1])
    -- Nothing in front of it: lamps, signs, beams. Corners are on the surface, lean included. The
    -- physics ray starts outside the collision shell; the drawn one at the paper.
    local shell = math.min(gap, 30) + 2
    local pright = v3(-pn.y, pn.x, 0)
    local pup = (UP - n3 * UP:dot(n3)):normalize()
    for _, s in ipairs({ { 0, 0 }, { -W.PAPER_HW, W.PAPER_HH }, { W.PAPER_HW, -W.PAPER_HH } }) do
        local a = pos + pright * s[1] + pup * s[2] + n3 * 2
        local b = a + n3 * W.FRONT_CLEAR
        local pr = ctx.ray(a + n3 * shell, b)
        if pr.hit and not ctx.isActor(pr.hitObject) then
            return nil, ctx.isWindow(pr.hitObject) and 'window' or ('blocked in front by ' .. ctx.nameOf(pr.hitObject))
        end
        local vr = ctx.seen(a, b)
        if vr.hit and not ctx.isActor(vr.hitObject) then
            return nil, ctx.isWindow(vr.hitObject) and 'window' or ('blocked in front by ' .. ctx.nameOf(vr.hitObject))
        end
    end
    return { pos = pos, n = pn, n3 = n3, lean = math.asin(n3.z), on = ctx.nameOf(wall) }
end

-- Probe points along a facade from a door, nearest first, alternating sides, out in front of the
-- wall: the old beside-the-door offsets, then every FACADE_STEP to FACADE_REACH. door: { x, y,
-- half }; out: unit vector to the street.
function M.facadeProbes(door, out)
    local rx, ry = -out.y, out.x
    local start = math.min(door.half or 50, W.DOOR_HALF_MAX) + W.HALF_W + W.EDGE_GAP
    local list = {}
    local function add(dist)
        for _, side in ipairs({ 1, -1 }) do
            local along = side * dist
            list[#list + 1] = {
                x = door.x + rx * along + out.x * W.OUT,
                y = door.y + ry * along + out.y * W.OUT,
                side = side, along = along,
            }
        end
    end
    local last = 0
    for _, extra in ipairs(W.LATERAL) do
        add(start + extra)
        last = extra
    end
    for extra = last + W.FACADE_STEP, W.FACADE_REACH, W.FACADE_STEP do add(start + extra) end
    return list
end

return M
