---@omw-context global
-- Odd Jobs: stray notices (feature "strays"). Now and then a town board's refresh pins one more
-- notice, a job or a flavour notice, on a post, pillar, lamp, stall or fence elsewhere in town,
-- seen from the street. Each stray is a board of its own (status 'virtual', like a guild steward's
-- list) holding that one notice, so taking it, the board window and the contract all go through
-- the core unchanged; its contracts are handed in at the town's notices (b.handIn).
-- The paper goes up when the player is near a candidate: player.lua checks one paper's patch on
-- each (OJB_CheckStray) and answers through OJB_SpotResult with the stray's key.

local core = require('openmw.core')
local types = require('openmw.types')
local world = require('openmw.world')

local C = require('scripts.ojb.config')
local G = require('scripts.ojb.geom')
local ST = require('scripts.ojb.story')
local TOWNS = require('scripts.ojb.data.towns')

local SC = C.STRAY
local M = {}

-- Interiors behind any notice board's doors: their outside doors already carry notices.
local boardRooms = {}
for _, t in ipairs(TOWNS) do
    for _, b in ipairs(t.boards) do
        for _, d in ipairs(b.doors) do boardRooms[d:lower()] = true end
    end
end

local function houseDoor(o)
    if not types.Door.isTeleport(o) then return false end
    local dest = types.Door.destCell(o)
    return dest ~= nil and not dest.isExterior and not boardRooms[dest.name:lower()]
end

local PREFIX = 'stray_'

-- ctx: twists' ctx plus byObject, spawnPaper, removeAll, makeNotice, touch, lightsAt, spotBusy.
function M.new(ctx)
    local SY = {}
    local function S() return ctx.S() end

    -- Posts, pillars, lamps, stalls, fences and house doors (for the wall beside them) round each
    -- board, read once a session. Key: board key; lives for the session (statics and doors don't
    -- move); never invalidated; a board with none keeps an empty list. 36 getAll calls the first
    -- time a board posts a stray, none after.
    local found = {}
    local function candidates(key)
        if found[key] then return found[key] end
        local ox, oy = ctx.boardOrigin(key)
        local out = {}
        if ox then
            local gx, gy = math.floor(ox / C.CELL), math.floor(oy / C.CELL)
            for dx = -1, 1 do
                for dy = -1, 1 do
                    local cell = ctx.touch(world.getExteriorCell(gx + dx, gy + dy))
                    for _, t in ipairs({ types.Static, types.Activator, types.Light, types.Door }) do
                        for _, o in ipairs(cell:getAll(t)) do
                            local id = o.recordId
                            local ok
                            if t == types.Door then ok = houseDoor(o)
                            else ok = G.hasWord(id, SC.WORDS) and not G.hasWord(id, SC.NOT_WORDS) end
                            if ok then
                                local p = o.position
                                local d = math.sqrt((p.x - ox) ^ 2 + (p.y - oy) ^ 2)
                                if d >= SC.MIN_DIST and d <= SC.MAX_DIST then out[#out + 1] = o end
                            end
                        end
                    end
                end
            end
        end
        found[key] = out
        ctx.log('%s: %d posts, stalls and house walls in reach for stray notices', key, #out)
        return out
    end

    -- Stray keys held now, rebuilt on load. Runtime only.
    local live = {}

    function SY.owns(key) return type(key) == 'string' and key:sub(1, #PREFIX) == PREFIX end

    local function takeDown(sk)
        local b = S().boards[sk]
        if not b then return end
        for _, o in ipairs(b.papers or {}) do ctx.byObject()[o.id] = nil end
        if b.papers then ctx.removeAll(b.papers, b.spot) end
        b.papers, b.spot = nil, nil
    end

    local function remove(sk)
        takeDown(sk)
        S().boards[sk] = nil
        live[sk] = nil
    end

    function SY.clear(originKey)
        for sk in pairs(live) do
            local b = S().boards[sk]
            if not b or b.stray.origin == originKey then remove(sk) end
        end
    end

    function SY.clearAll()
        for sk in pairs(live) do remove(sk) end
    end

    local function inTown(originKey)
        local town, n = ctx.townOf(originKey), 0
        for sk in pairs(live) do
            local b = S().boards[sk]
            if b and ctx.townOf(b.stray.origin) == town then n = n + 1 end
        end
        return n
    end

    local function flavour(key)
        local f = ST.flavour({ town = ctx.townOf(key), used = ctx.usedOn(key), rnd = math.random })
        if not f then return nil end
        local s = S()
        f.id, f.kind, f.poster = s.nextId, 'flavour', 'town'
        s.nextId = s.nextId + 1
        return f
    end

    local function cooled(st, pos)
        local h = st.hold
        if not h then return true end
        local dx, dy = pos.x - h.x, pos.y - h.y
        if core.getGameTime() >= h.t or dx * dx + dy * dy >= C.SEARCH_AWAY * C.SEARCH_AWAY then
            st.hold = nil
            return true
        end
        return false
    end

    local function ask(player, sk)
        local b = S().boards[sk]
        local st = b.stray
        local pos = player.position
        local near = {}
        for _, o in ipairs(candidates(st.origin)) do
            if o:isValid() and o.enabled and not st.bad[o.id] then
                local p = o.position
                local d = (p.x - pos.x) ^ 2 + (p.y - pos.y) ^ 2
                if d < SC.LOOK * SC.LOOK then near[#near + 1] = { o = o, d = d } end
            end
        end
        if #near == 0 then return end
        table.sort(near, function(a, c) return a.d < c.d end)
        local cands, ids = {}, {}
        for i = 1, math.min(#near, SC.CANDIDATES) do
            cands[i], ids[i] = near[i].o, near[i].o.id
        end
        st.state, st.at, st.tries, st.sent = 'asked', core.getRealTime(), st.tries + 1, ids
        st.px, st.py = pos.x, pos.y
        local lights = {}
        for _, l in ipairs(ctx.lightsAt(st.origin) or {}) do
            if (l.x - pos.x) ^ 2 + (l.y - pos.y) ^ 2 < SC.LOOK * SC.LOOK and #lights < 24 then lights[#lights + 1] = l end
        end
        player:sendEvent('OJB_CheckStray', { key = sk, cands = cands, lights = lights })
    end

    -- From the board's refresh, as it finishes: the old strays of this board go; maybe a new one.
    -- job: the refresh (its unused candidate places can make the job notice).
    function SY.refreshed(job, player)
        local key = job.key
        SY.clear(key)
        if not ctx.featureOn.strays then return end
        local posters = ctx.postersOf(key)
        local b = S().boards[key]
        if not posters or posters[1] ~= 'town' or not b or b.status ~= 'placed' then return end
        if inTown(key) >= SC.PER_TOWN or math.random() >= SC.CHANCE then return end
        if #candidates(key) == 0 then return end
        local n
        if math.random() < SC.JOB_SHARE then
            for i = job.i, #job.cands do
                n = ctx.makeNotice(key, job.cands[i], player, 'town', job.have)
                if n then break end
            end
        end
        n = n or flavour(key)
        if not n then return end
        local sk = PREFIX .. n.id
        S().boards[sk] = { status = 'virtual', notices = { n }, refreshedAt = 1e12, originKey = key, handIn = key,
            posters = { 'town' }, stray = { origin = key, state = 'wait', tries = 0, bad = {} } }
        live[sk] = true
        ctx.say('%s: stray notice %d (%s) waiting for a post', key, n.id, n.flavour and 'flavour' or n.kind)
    end

    -- From nearTick: a waiting stray is checked when the player is outdoors near one of its
    -- candidates and no board check is running.
    function SY.tick(player)
        if not next(live) or not player.cell.isExterior or ctx.spotBusy() then return end
        for sk in pairs(live) do
            local b = S().boards[sk]
            local st = b and b.stray
            if st and st.state == 'asked' and core.getRealTime() - st.at > 15 then st.state = 'wait' end
            if st and st.state == 'wait' and cooled(st, player.position) then
                ask(player, sk)
                if st.state == 'asked' then return end
            end
        end
    end

    function SY.onSpots(e)
        local b = S().boards[e.key]
        local st = b and b.stray
        if not st or st.state ~= 'asked' then return end
        if e.busy then
            -- The ray budget is in use. Ask again on a later poll, not after the long backoff.
            st.state, st.tries = 'wait', st.tries - 1
            return
        end
        local res = e.results or {}
        local failed = res.spot and (res.index - 1) or #(st.sent or {})
        for i = 1, failed do st.bad[st.sent[i]] = true end
        if res.spot and #b.notices > 0 then
            local obj = ctx.spawnPaper(res.spot)
            b.papers, b.spot = { obj }, { x = res.spot.x, y = res.spot.y, z = res.spot.z }
            ctx.byObject()[obj.id] = e.key
            st.state = 'placed'
            ctx.say('%s: stray notice pinned on %s at %.0f, %.0f, %.0f%s (%d rays)', st.origin, res.spot.label,
                res.spot.x, res.spot.y, res.spot.z, res.spot.lit and ', lit' or '', e.rays or 0)
            return
        end
        ctx.log('%s: no post took the stray notice: %s', st.origin, table.concat(res.tried or {}, '; '))
        if e.error or st.tries >= SC.TRIES then
            ctx.say('%s: stray notice dropped after %d tries', st.origin, st.tries)
            remove(e.key)
        else
            st.state = 'wait'
            st.hold = { t = core.getGameTime() + C.SEARCH_BACKOFF, x = st.px or 0, y = st.py or 0 }
        end
    end

    -- From syncPapers: once its notice is taken the paper comes down. The board itself stays
    -- until the town board's next refresh, so the window open on it still has something to show.
    function SY.sync(sk)
        local b = S().boards[sk]
        if b and #(b.notices or {}) == 0 then
            takeDown(sk)
            b.stray.state = 'gone'
        end
    end

    function SY.reconcile()
        live = {}
        for sk, b in pairs(S().boards) do
            if b.stray then
                live[sk] = true
                for _, o in ipairs(b.papers or {}) do ctx.byObject()[o.id] = sk end
            end
        end
    end

    return SY
end

return M
