---@omw-context global
-- Pure: shop ads from the town's real merchants (supply.lua towns[key].shops, built from the load
-- order). An ad is written in the shopkeeper's voice, names a few things the shop really stocks
-- and says roughly where it is from the board. Opening one shows a shop card; there is nothing to
-- take. No engine calls.

local G = require('scripts.ojb.geom')
local Q = require('scripts.ojb.req')
local N = require('scripts.ojb.names')

local M = {}

-- Voices by trade (class name, lowercased, matched as a substring). {items}: two or three things
-- in stock; {place}: the shop as a townsperson says it; {Name}: the shopkeeper.
local VOICE = {
    { match = { 'publican' }, titles = { 'A bed and a hot meal', 'Food and drink at {place}', 'Thirsty?' },
      lines = { 'Food, drink and a bed for the night at {place}. Ask for {items}. Pay in coin, not in stories.',
          'Come in out of the ash. There is {items}, and a fire that stays lit.',
          'Cold drink, warm room, and nobody asks your business. {items} behind the counter.' } },
    { match = { 'smith', 'fletcher' }, titles = { 'Arms and armour', 'Blades mended and sold', 'At the forge' },
      lines = { 'Good steel at fair prices. {items}, and repairs while you wait.',
          'Your blade is blunt. I can tell from here. Bring it to {place}, and look at {items} while you wait.',
          'Honest work, honest metal. I have {items} on the rack this week.' } },
    { match = { 'alchemist', 'apothecary' }, titles = { 'Potions and remedies', 'For what ails you', 'Fresh from the still' },
      lines = { 'Potions for wounds, fatigue and worse. In stock now: {items}.',
          'Whatever ails you, there is something on my shelf for it. {items}, among others.',
          'Remedies brewed here, not bought in. Try {items}. Ingredients bought at a fair price too.' } },
    { match = { 'enchanter' }, titles = { 'Enchantments made', 'Charms and soul gems', 'Magic for sale' },
      lines = { 'Rings, amulets and blades given a little more. I have {items} ready now.',
          'Bring me a soul and a good piece, and I will make it sing. Or buy {items} today.',
          'Enchanted goods for those who can pay. {items}, and more by order.' } },
    { match = { 'clothier', 'tailor', 'outfitter' }, titles = { 'Clothes for every purse', 'Dressed for the season', 'New clothes in' },
      lines = { 'Look like you belong in {town}. {items}, and more on the shelves.',
          'Shirts, trousers, belts and shoes. This week: {items}.',
          'Your clothes have seen better days. Mine have not seen any yet. {items}, at fair prices.' } },
    { match = { 'bookseller' }, titles = { 'Books bought and sold', 'Something to read', 'New books in' },
      lines = { 'Histories, tales and a few things you will not find elsewhere. On the shelf now: {items}.',
          'A good book is a long road with no cliff racers. Try {items}.',
          'Books bought and sold. This week: {items}.' } },
    { match = { 'baker' }, titles = { 'Fresh bread', 'Baked this morning' },
      lines = { 'Bread, baked this morning, and sweet things for after. Today there is {items}.',
          'Fresh from the oven at {place}: {items}. Come early, it goes fast.' } },
    { match = { 'pawnbroker' }, titles = { 'Bought and sold', 'Odds and ends', 'Fair prices paid' },
      lines = { 'Anything bought, most things sold. In today: {items}.',
          'Short of coin? I buy. Long on coin? I sell. Right now: {items}.',
          'Odd things, useful things, and a few that are both. {items} at {place}.' } },
    { match = { 'trader', 'merchant' }, titles = { 'General goods', 'Everything for the road', 'Goods bought and sold' },
      lines = { 'Rope, lamps, food for the road and more. This week: {items}.',
          'Whatever you need for the road, ask at {place}. {items}, and I buy what you bring back.',
          'Fair weights, fair prices. In stock: {items}.' } },
}

local function voiceOf(trade)
    local t = (trade or ''):lower()
    for _, v in ipairs(VOICE) do
        for _, m in ipairs(v.match) do
            if t:find(m, 1, true) then return v end
        end
    end
    return VOICE[#VOICE]
end

local function list(names)
    if #names == 1 then return names[1] end
    return table.concat(names, ', ', 1, #names - 1) .. ' and ' .. names[#names]
end

local function fill(s, vars)
    return (s:gsub('{(%w+)}', function(k) return vars[k] or ('{' .. k .. '}') end))
end

-- Where the shop is from the notices, as a townsperson says it: "a short walk northwest of here,
-- near the Eight Plates". Written once when the ad goes up, so it never gives a number.
function M.where(shop, ox, oy)
    local dx, dy = shop.at[1] - ox, shop.at[2] - oy
    local dist = math.sqrt(dx * dx + dy * dy)
    local dir = G.bearing(ox, oy, shop.at[1], shop.at[2])
    local s
    if dist < 600 then
        s = 'just ' .. dir .. ' of here'
    elseif dist < 3000 then
        s = 'a little way ' .. dir .. ' of here'
    else
        s = 'a short walk ' .. dir .. ' of here'
    end
    if shop.mark then s = s .. ', near ' .. Q.placeName(shop.mark) end
    return s
end

-- An ad for a board. args: { shops (supply town shops), ox, oy (board origin), town, used (set of
-- shop ids already advertised), closed (set of shop ids no longer trading), itemName (id -> name),
-- have (id -> bool: its content file loaded), rnd, cheap (optional { name } from Economy Plus) }.
-- Returns a notice table or nil.
function M.make(args)
    local rnd = args.rnd
    local open = {}
    for _, s in ipairs(args.shops or {}) do
        if not (args.used and args.used[s.id]) and not (args.closed and args.closed[s.id]) then
            open[#open + 1] = s
        end
    end
    if #open == 0 then return nil end
    local shop = open[rnd(#open)]
    -- Goods named after their maker keep the maker's capitals: "Sirollus Saccus' hammer".
    local function keeperCase(s, keeper)
        for w in keeper:gmatch('%a+') do
            local low = w:lower()
            if low ~= w then s = s:gsub('%f[%a]' .. low .. '%f[%A]', w) end
        end
        return s
    end
    local found = {}
    for _, id in ipairs(shop.stock or {}) do
        if not args.have or args.have(id) then
            local nm = args.itemName and args.itemName(id)
            if nm and nm ~= '' then found[#found + 1] = { id = id, name = nm } end
        end
    end
    -- One name per thing: "Bread" goes when "Colovian Bread" is on the list, and a name twice once.
    local names, stock, seen = {}, {}, {}
    for _, s in ipairs(found) do
        local low = s.name:lower()
        local inner = false
        for _, o in ipairs(found) do
            local ol = o.name:lower()
            if ol ~= low and ol:sub(-#low - 1) == ' ' .. low then inner = true end
        end
        if not inner and not seen[low] then
            seen[low] = true
            stock[#stock + 1] = s
            if #names < 3 then names[#names + 1] = keeperCase(N.lower(s.name), shop.name) end
        end
    end
    if #names < 2 then return nil end
    local place = Q.placeName(shop.cell)
    local v = voiceOf(shop.trade)
    local vars = { items = list(names), place = place, town = args.town or 'town', Name = shop.name }
    local body = fill(v.lines[rnd(#v.lines)], vars):gsub('^%l', string.upper)
        :gsub('([%.!?]%s+)(%l)', function(a, b) return a .. b:upper() end)
    if args.cheap and args.cheap.name then
        body = body .. ' ' .. N.lower(args.cheap.name):gsub('^%l', string.upper) .. ' is cheap in '
            .. (args.town or 'town') .. ' this week.'
    end
    local where = M.where(shop, args.ox, args.oy)
    -- The shop's name is on the card's strip; cell names ("Interior", "Main Keep") are not signatures.
    local sign = (shop.trade or 'shopkeeper'):lower()
    return {
        kind = 'ad', title = fill(v.titles[rnd(#v.titles)], vars), body = body, plain = body,
        from = shop.name .. ', ' .. sign, shop = { npc = shop.id, name = place, keeper = shop.name,
            trade = shop.trade, cell = shop.cell, where = where, stock = stock },
    }
end

return M
