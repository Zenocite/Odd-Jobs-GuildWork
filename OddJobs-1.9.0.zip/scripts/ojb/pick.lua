---@omw-context global
-- Pure: which places a refresh looks at and what job each becomes. A kind of place is drawn by
-- weight first, then a place of that kind, so the data's many ancestral tombs (151 of 334) don't
-- crowd out caves, mines and ruins. No engine calls, so tests run it as is.

local C = require('scripts.ojb.config')
local F = require('scripts.ojb.foes')
local FR = require('scripts.ojb.fresh')

local M = {}

-- list: { {place, dist, w}, ... }, every place this board may use; w (default 1) weighs the pick
-- within a kind. recent: place name -> true for places posted lately, used only when their kind
-- has nothing else. onBoard: place kind -> notices of that kind already up on the board, counted
-- against C.PLACE_KIND_CAP so the cap holds for the board, not just one refresh. Returns at most n.
function M.spread(list, n, recent, random, onBoard)
    random = random or math.random
    onBoard = onBoard or {}
    local byKind, kinds = {}, {}
    for _, c in ipairs(list) do
        local k = c.place.k or 'cave'
        local t = byKind[k]
        if not t then
            t = { fresh = {}, stale = {}, taken = onBoard[k] or 0 }
            byKind[k] = t
            kinds[#kinds + 1] = k
        end
        local into = recent and recent[c.place.n] and t.stale or t.fresh
        into[#into + 1] = c
    end
    table.sort(kinds)
    local out = {}
    while #out < n do
        local total, open = 0, {}
        for _, k in ipairs(kinds) do
            local t = byKind[k]
            if #t.fresh + #t.stale > 0 and t.taken < (C.PLACE_KIND_CAP[k] or n) then
                local w = C.PLACE_KIND_WEIGHT[k] or 1
                open[#open + 1] = { k = k, w = w }
                total = total + w
            end
        end
        if total == 0 then break end
        local r, kind = random() * total, open[#open].k
        for _, o in ipairs(open) do
            r = r - o.w
            if r < 0 then kind = o.k break end
        end
        local t = byKind[kind]
        local from = #t.fresh > 0 and t.fresh or t.stale
        local sum = 0
        for _, c in ipairs(from) do sum = sum + (c.w or 1) end
        local at, pickI = random() * sum, #from
        for i, c in ipairs(from) do
            at = at - (c.w or 1)
            if at < 0 then pickI = i break end
        end
        out[#out + 1] = table.remove(from, pickI)
        t.taken = t.taken + 1
    end
    return out
end

-- What a place offers a notice, from its build-time data at this level: hostiles (all foes),
-- targets (F.targets), boss (a named leader placed by hand) or band (a people group with no named
-- leader; the strongest of them is made the leader when the contract is taken or the cell spawns).
function M.info(place, level, foes)
    local targets = F.targets(place, level)
    local boss = F.boss(place)
    local band
    if not boss and targets[1] and F.PEOPLE[targets[1].group] then
        band = { group = targets[1].group, word = F.WORDS[targets[1].group] }
    end
    return { hostiles = foes, targets = targets, boss = boss, band = band }
end

-- A job kind this poster offers that the place supports, at most two of a kind per board. Each kind
-- that fits weighs 1 plus the kinds that don't fit just before it in the poster's list (as if a
-- start were drawn and the first fit after it taken). watery: the place's own largest group lives
-- in water (foes.watery), so each kind's weight is also scaled by C.WATER_KIND.
local function bountyGroup(sinfo)
    return sinfo.boss and sinfo.boss.group or sinfo.band and sinfo.band.group
end

-- Whether this poster will name a bounty on the place's people. C.BOUNTY_GROUPS limits a poster
-- to the groups that fit its work (mages: warlocks and necromancers; temple: tomb and shrine folk).
function M.offersBounty(poster, sinfo)
    if not (sinfo.boss or sinfo.band) then return false end
    local allow = C.BOUNTY_GROUPS[poster]
    if not allow then return true end
    local g = bountyGroup(sinfo)
    return g and allow[g] or false
end

function M.kind(poster, sinfo, have, random, watery, fresh)
    random = random or math.random
    local kinds = C.KINDS[poster] or C.KINDS.town
    -- Few places hold people, so a place that does is a bounty first, at most one per board.
    if M.offersBounty(poster, sinfo) and not have.bounty and random() < C.BOUNTY_FIRST
        and FR.weight('bounty', fresh) > 0 then
        for _, k in ipairs(kinds) do
            if k == 'bounty' then return k end
        end
    end
    local ok = {}
    for i, kind in ipairs(kinds) do
        ok[i] = (have[kind] or 0) < 2 and (
            (kind == 'bounty' and M.offersBounty(poster, sinfo))
            or (kind == 'nest' and F.count(sinfo.targets) >= C.MIN_FOES.nest - 0.5)
            or (kind == 'recovery' and sinfo.hostiles >= C.MIN_FOES.recovery - 0.5))
    end
    local fits, total = {}, 0
    for i, kind in ipairs(kinds) do
        if ok[i] then
            local w, j = 1, i
            for _ = 1, #kinds - 1 do
                j = (j - 2) % #kinds + 1
                if ok[j] then break end
                w = w + 1
            end
            w = w * (watery and C.WATER_KIND[kind] or 1) * FR.weight(kind, fresh)
            if w > 0 then
                fits[#fits + 1] = { kind, w }
                total = total + w
            end
        end
    end
    if total <= 0 then return nil end
    -- Clearing is all a water place offers this poster: taken at its weight, else another place.
    if watery and #fits == 1 and fits[1][1] == 'nest' and random() >= C.WATER_KIND.nest then return nil end
    local r = random() * total
    for _, f in ipairs(fits) do
        r = r - f[2]
        if r < 0 then return f[1] end
    end
    return fits[#fits][1]
end

return M
