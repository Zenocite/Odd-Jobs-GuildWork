Odd Jobs 1.3 for OpenMW 0.51
============================

Notices are pinned to the wall beside taverns and guild halls in 15 towns (10 in vanilla Morrowind,
5 more with Tamriel Rebuilt). Each spot holds up to four: clear out a nest, bring down a bandit
leader and return their signet, or recover something lost in a nearby cave, mine, ruin, shrine,
stronghold, wreck or tomb. Take up to three at once, then come back to the notices (or, for guild
work, any notices or steward of that guild) to be paid. Each contract item carries its own name, so
you can tell it from other loot.

Every door into a town's taverns or guild hall is tried, and the notices go beside the best one
(a flat wall near the door, in sight of the street). A door further off is tried when you pass
it, and the notices move there if it's clearly better.

Jobs are spread over kinds of place, with at most one tomb on a board at a time. Bounties include
bands whose leader nobody has named: whoever leads them when you get there carries the signet.

Requirements
------------
Tamriel Data and Tamriel Rebuilt (Tamriel_Data.esm and TR_Mainland.esm) are required. Vvardenfell
towns keep working, since they're in the same load order. Without them, the open world jobs stay
off and the game tells you so once.

Install
-------
Add this folder as a data directory and enable both files, in this order:
  data="<path to this folder>"
  content=OddJobs.esp
  content=OddJobs.omwscripts

Only the game's own meshes are used. Papers follow leaning and gently curved walls; where no wall
beside the door will take them, a small board of shack posts and planks stands with its back to
the wall instead, never in the way to the door.

Long notices scroll with the mouse wheel when UIToolkit 1.1.0 or newer is installed (Economy Plus
already needs it). Without it, click the ^ and v marks beside the text.

Settings (Options > Scripts > Odd Jobs)
---------------------------------------
  Show boards     Turn off before removing the mod; boards and papers are taken down.
  Contract log    Bind a key to see the contracts you hold. Unbound by default.
  Debug log       Board placement and contract details in openmw.log.

Pay
---
Every job has a difficulty, worked out from the job itself (who lives there, how many, how far),
never from your level: easy, normal, dangerous or elite. Dangerous and elite work carries a seal
on the notice and is posted at any level; take it at your own risk. Pay follows the difficulty:
about 60 to 150 gold for easy work, 160 to 400 for normal, 450 to 800 for dangerous and 1000 to
1800 for elite, part of it in the poster's goods or a session with the guild trainer. Pay is never
cut for working a lot. Instead, each contract finished in the last three days means one fewer new
job when a board next refreshes. Until you have finished five contracts you are new in town, and
a board posts at most two jobs at a time; after fifteen you can hold a fourth contract.
Old level gates (a setting, off by default) brings back the old rules: dangerous work from level
10, elite from 25, and the job limit and fourth contract by level.

Guild contracts count toward faction reputation, but never more than half of what the next rank
needs; the rest still has to come from guild quests.

Harsh Measures
--------------
Detected automatically. Tomb contracts aren't offered from the moment you're accused of tomb
robbing until the matter is settled with a donation; notices in
the Morag Tong's territory carry a warning, and its assassins are never part of a contract.

Ancestral tombs
---------------
A family tomb's skeletons and spirits are its guardians, and no board asks you to kill them.
Clearing and bounty jobs in a tomb are only ever against intruders (bandits, necromancers,
smugglers, daedra); a tomb with nothing but its guardians gets none. Recovering something from a
tomb is still offered, with a warning that the guardians will not welcome you.

Uninstalling
------------
Turn off "Show boards", save, then remove the mod. Contract items held at the time disappear.

Changes
-------
1.3  Every door of a board's taverns or guild hall is a candidate, scored, best wins; Almas Thirr
     adds the Limping Scrib and The Pious Pirate, Sadrith Mora Dirty Muriel's Cornerclub.
     Places: 731 (was 334), including vanilla dungeons with one-word names (Hlormaren,
     Nchardahrk, Ilunibi) that were missed before; Ashlander camps are never jobs.
     At most one tomb job per board; places drawn by kind (cave, mine, Dwemer ruin, shrine,
     stronghold, wreck, sewer, tomb). Bounties on unnamed band leaders.
     Steward lists are prepared when you walk into the guild hall, not when you ask.
1.7  Notices search the whole street front of a building, not just beside the door.
1.7  A building's collision shell standing in front of its stone no longer blocks its own wall.
1.7  Rough stone counts as flat: mortar gaps under a paper are fine, bumps still are not.
1.7  A lamp or sign blocks only the paper in front of it, not the whole wall.
1.7  The Firewatch Mages Guild posts on the stone base beside its main door.
1.7  Where no wall or backed spot is found, a board stands free near the door (Ald-ruhn Fighters Guild).
1.7  Grass and reeds no longer stop a board standing in them.
1.7  Fewer new jobs when you have done a lot of work lately, instead of lower pay; said in the window, not on the notice.
1.7  Below level 10 a board posts at most two jobs.
1.7  Animals in clues only react; they never count or report numbers.
1.7  Caravan goods are only ever lost where people or ships carried them, never in egg mines or animal caves.
1.7  Loose items are searched for with at most 160 rays before the floor fallback.
1.7  Quest places are never jobs: main quest, Tribunal and Bloodmoon strongholds, and every part of a place whose other rooms hold quest characters or are named in quest scripts (598 places, was 731).
1.7  More lines for flooded caves and for "there are more of them".
